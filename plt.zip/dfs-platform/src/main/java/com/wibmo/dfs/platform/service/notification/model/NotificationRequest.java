package com.wibmo.dfs.platform.service.notification.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public class NotificationRequest implements Serializable {
    @Min(1)
    private int eventId;
    private String fcmToken;
    private String mobileNumber;
    private String emailId;
    private long accountNumber;
    private String deviceId;
    private boolean whatsappEnabled;
    @NotNull
    private transient Map<String, String> placeHolders;

    private List<Attachment> attachments;

    private String subject;
    private String body;
    private int programId;

}
