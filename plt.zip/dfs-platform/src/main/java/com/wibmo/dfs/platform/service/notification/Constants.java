package com.wibmo.dfs.platform.service.notification;

public class Constants {
    private Constants() {}
    public static final String X_PROGRAM_ID = "X-PROGRAM-ID";
    public static final String GLOBAL_NOTIFICATION_SERVICE_EP = "/notification-service/notification/sendAlert";
	public static final String GLOBAL_OTP_GENERATE_SERVICE_EP = "/otp-service/otp/generate";
	public static final String ERROR = "ERROR";
	public static final int OTP_SERVICE_ERROR_CODE = 150;
	public static final int NOTIFICATION_SERVICE_ERROR_CODE = 50;
	public static final String OTP_VALUE = "OTP_VALUE";
	//Storage Constants
	public static final String SUCCESS_CODE = "200" ;
	public static final String ERROR_CODE = "500" ;
	public static final String UPLOAD_DOCUMENT_SUCCESS_MESSAGE = "Upload document is success";
	public static final String UPLOAD_DOCUMENT_ERROR_MESSAGE = "Upload document is failed";
	public static final String DOWNLOAD_DOCUMENT_SUCCESS_MESSAGE = "Download document is success";
	public static final String DOWNLOAD_DOCUMENT_ERROR_MESSAGE = "Download document is failed";
	public static final String ATTRIBUTE_KEY = "attributeKey";
	public static final String GLOBAL_ADMIN_SERVICE_EP = "/admin/prog-attribute/internal/fetch";
	public static final String NOT_AVAILABLE = "N/A";
	public static final String S3_ATTRIBUTE_KEY = "S3_STORAGE_INFO";
	public static final String STORAGE_DEFAULT_KEY = "DEFAULT_STORAGE_TYPE";
	public static final String ADMIN_SERVICE_FAILED_ERROR = "Error occured while invoking admin service" ;
}
