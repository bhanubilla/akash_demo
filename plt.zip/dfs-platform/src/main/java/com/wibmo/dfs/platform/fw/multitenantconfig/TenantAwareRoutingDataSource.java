package com.wibmo.dfs.platform.fw.multitenantconfig;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

/**
 * DataSource selection is made at runtime based on the tenant id.
 *
 * @author: Ala Venkateswarlu
 * @Created On: 16-07-2021
 */

public class TenantAwareRoutingDataSource extends AbstractRoutingDataSource {

    /**
     * Retrieve the current target DataSource. Determines the
     * {@link #determineCurrentLookupKey() current lookup key}, performs
     * a lookup in the {@link #setTargetDataSources targetDataSources} map,
     * falls back to the specified
     * {@link #setDefaultTargetDataSource default target DataSource} if necessary.
     * @see #determineCurrentLookupKey()
     */
    @Override
    protected Object determineCurrentLookupKey() {
        return ThreadLocalStorage.getTenantId();
    }
}
