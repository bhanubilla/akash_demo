package com.wibmo.dfs.platform.fw.logging.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;

import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Configuration
@Slf4j
public class LoggingUtil {

    @Value("${platform.logging.api.mask.sensitive.data:}")
    private String[] sensitiveData;

    private Set<String> sensitiveSet = new HashSet<>(Arrays.asList("dob",
            "cardExpiry",
            "expiryMM",
            "expiryYYYY",
            "cvv",
            "cvv2",
            "cardNumber",
            "vpa",
            "pan",
            "expiryDate"));

    @Value("${platform.logging.api.mask.regex:[0-9]}")
    private String regex;

    @Value("${platform.logging.api.mask.placeholder:X}")
    private String placeholder;

    @Value("${platform.logging.api.exclude.urls:}")
    private String[] excludeUrls;

    private Set<String> excludeUrlsSet = new HashSet<>(Arrays.asList("/swagger-resources","/swagger-resources/configuration/security","/swagger-resources/configuration/ui","/swagger-ui.html","/v2/api-docs","/csrf","/webjars/springfox-swagger-ui"));


    public Map<String, String> doMask(String reqBody) {
        ObjectMapper mapper = new ObjectMapper();
        Map<String, String> m = new LinkedHashMap<>();
        try {
            if(null != reqBody) {
                Iterator<Map.Entry<String, JsonNode>> fields = mapper.readTree(reqBody).fields();
                while (fields.hasNext()) {
                    Map.Entry<String, JsonNode> field = fields.next();
                    Map<String, Object> modMap = new LinkedHashMap<>();
                    checkFieldValue(field, modMap);
                    if (null != field.getValue()) {
                        m.put(field.getKey(), modMap.isEmpty() ? new ObjectMapper().writeValueAsString(field.getValue()) :
                                findValue(field, modMap));
                    } else {
                        m.put(field.getKey(), new ObjectMapper().writeValueAsString(field.getValue()));
                    }
                }
            }
        } catch(Exception e) {
            log.error("error :{}",e);
        }
        return m;
    }

    private String findValue(Map.Entry<String, JsonNode> field, Map<String, Object> modMap) throws JsonProcessingException {
        if(field.getValue().isContainerNode()) {
            return field.getValue().isObject() ? new ObjectMapper().writeValueAsString(modMap) : new ObjectMapper().writeValueAsString(modMap.get(field.getKey()));
        } else {
            return new ObjectMapper().writeValueAsString(modMap.get(field.getKey()));
        }
    }


    private void checkFieldValue(Map.Entry<String, JsonNode> field, Map<String, Object> modMap) {
        if (null != field.getValue() && field.getValue().isContainerNode()) {
            List<String> result = StreamSupport.stream(
                    Spliterators.spliteratorUnknownSize(field.getValue().fieldNames(), Spliterator.ORDERED), false)
                    .collect(Collectors.toList());
            checkComplexPojo(field, modMap, result);
        } else {
            if(null != field.getValue()) {
                Map<String, Object> map = new HashMap<>();
                map.put(field.getKey(), field.getValue().asText());
                maskSensitiveData(map);
                modMap.put(field.getKey(), map.get(field.getKey()));
            }
        }
    }

    private void checkComplexPojo(Map.Entry<String, JsonNode> field, Map<String, Object> modMap, List<String> result) {
        if (!result.isEmpty()) {

            result.stream().forEach(k -> {
                try {
                    if (field.getValue().get(k).isArray()) {
                        Map<String, JsonNode> subMap = new HashMap<>();
                        subMap.put(k, field.getValue().get(k));
                        convertArray(k,subMap, modMap);
                    } else if (field.getValue().get(k).isObject()) {
                        Map<String, JsonNode> subMap = new HashMap<>();
                        subMap.put(k, field.getValue().get(k));
                        convertObject(k, subMap, modMap);
                    } else {
                        if(null != field.getValue().get(k)) {
                            Map<String, Object> map = new HashMap<>();
                            map.put(k, field.getValue().get(k).asText());
                            maskSensitiveData(map);
                            modMap.put(k, map.get(k));
                        }
                    }
                } catch (JsonProcessingException e) {
                    log.error("ParseException: {}", e.toString());
                }

            });
        } else {
            try {
                if (field.getValue().isObject()) {
                    convertObject(field, modMap);
                } else if (field.getValue().isArray()) {
                    convertArray(field, modMap);
                }
            } catch (JsonProcessingException e) {
                log.error("ParseException: {}", e.toString());
            }
        }
    }

    private void convertObject(Map.Entry<String, JsonNode> field, Map<String, Object> modMap) throws JsonProcessingException {
        Map<String, Object> map = new ObjectMapper().readValue(new ObjectMapper().writeValueAsString(field.getValue()),
                new TypeReference<LinkedHashMap<String, Object>>(){});
        checkSubPojo(map);
        maskSensitiveData(map);
        modMap.put(field.getKey(), map);
    }

    private void convertObject(String key,Map<String, JsonNode> field, Map<String, Object> modMap) throws JsonProcessingException {
        Map<String, Object> map = new ObjectMapper().readValue(new ObjectMapper().writeValueAsString(field),
                new TypeReference<LinkedHashMap<String, Object>>(){});
        checkSubPojo(map);
        maskSensitiveData(map);
        modMap.put(key, map.get(key));
    }

    private void checkSubPojo(Map<String, Object> map) {
        isComplexObject(map);
    }

    private void isComplexObject(Map<String, Object> map) {
        map.forEach((k, v) -> {
            if(v instanceof List<?>) {
                List<Object> subArray = (List<Object>) v;
                List<Map<String, Object>> liMap =  new LinkedList<>();
                for(Object obj : subArray) {
                    liMap.add(stringToMap(obj));
                    map.put(k,liMap);
                }
            } else if(v instanceof LinkedHashMap) {
                map.put(k,stringToMap(v));
            } else {
                maskSensitiveData(map);
            }
        });
    }

    private Map<String, Object> stringToMap(Object obj) {
        Map<String, Object> subPojo = null;
        try {
            subPojo = new ObjectMapper().readValue(new ObjectMapper().writeValueAsString(obj),
                    new TypeReference<LinkedHashMap<String, Object>>(){});
            //complex pojo
            Map<String, Object> finalSubPojo = subPojo;
            subPojo.forEach((k, v)-> {
                Map<String, Object> map = new LinkedHashMap<>();
                map.put(k,v);
                if(v instanceof List<?> || v instanceof LinkedHashMap) {
                    isComplexObject(map);
                    finalSubPojo.put(k,map.get(k));
                } else {
                    maskSensitiveData(map);
                }
            });
            maskSensitiveData(finalSubPojo);
        } catch (JsonProcessingException e) {
            log.error("error in map conversion: {}",e);
        }
        return subPojo;
    }

    private void maskSensitiveData(Map<String, Object> map) {
        if(null == sensitiveData) sensitiveData = new String[]{};
        sensitiveSet.addAll(Arrays.asList(sensitiveData));
        for (Map.Entry<String, Object> pair : map.entrySet()) {
            String key = pair.getKey();
            for (String senKey : sensitiveSet) {
                if (key.equalsIgnoreCase(senKey))
                    map.computeIfPresent(key, (kay, val) -> (String.valueOf(val)).replaceAll(regex, placeholder));
            }
        }
    }

    private void convertArray(Map.Entry<String, JsonNode> field, Map<String, Object> modMap) throws JsonProcessingException {
        JSONArray array = new JSONObject(new ObjectMapper().writeValueAsString(field)).optJSONArray(field.getKey());
        List<Map<String, Object>> lmap = new LinkedList<>();
        List<Object> lvalues = new LinkedList<>();
        iterateArray(array, lmap, lvalues);
        if(lvalues.isEmpty()){
            modMap.put(field.getKey(),lmap);
        } else modMap.put(field.getKey(), lvalues);
    }

    private void convertArray(String key, Map<String, JsonNode> field, Map<String, Object> modMap) throws JsonProcessingException {
        JSONArray array = new JSONObject(new ObjectMapper().writeValueAsString(field)).optJSONArray(key);
        List<Map<String, Object>> lmap = new LinkedList<>();
        List<Object> lvalues = new LinkedList<>();
        iterateArray(array, lmap, lvalues);
        if(lvalues.isEmpty()){
            modMap.put(key,lmap);
        } else modMap.put(key, lvalues);
    }

    private void iterateArray(JSONArray array, List<Map<String, Object>> lmap, List<Object> lvalues) throws JsonProcessingException {
        if (null != array) {
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = null;
                if (array.get(i) instanceof JSONObject) {
                    obj = (JSONObject) array.get(i);
                    Map<String, Object> map = new ObjectMapper().readValue(String.valueOf(array.get(i)), new TypeReference<LinkedHashMap<String, Object>>() {
                    });
                    isComplexObject(map);
                    lmap.add(map);
                } else if (array.get(i) instanceof Object) {
                    lvalues.add(array.get(i));
                }
            }
        }
    }

    public Map<String, String> getTypesafeRequestMap(HttpServletRequest request) {
        Map<String, String> typesafeRequestMap = new HashMap<>();
        Enumeration<?> requestParamNames = request.getParameterNames();
        if(null == sensitiveData) sensitiveData = new String[]{};
        sensitiveSet.addAll(Arrays.asList(sensitiveData));
        while (requestParamNames.hasMoreElements()) {
            String requestParamName = (String) requestParamNames.nextElement();
            String requestParamValue;
            if (sensitiveSet.contains(requestParamName)) {
                requestParamValue = request.getParameter(requestParamName).replaceAll(regex, placeholder);
            } else {
                requestParamValue = request.getParameter(requestParamName);
            }
            typesafeRequestMap.put(requestParamName, requestParamValue);
        }
        return typesafeRequestMap;
    }

    /**
     * check the url is in exclude list , if yes skip the logging else continue
     * @param path
     * @return
     */
    public boolean validateUrl(String path) {
        if(null == excludeUrls) excludeUrls = new String[]{};
        excludeUrlsSet.addAll(Arrays.asList(excludeUrls));
        for(String url : excludeUrlsSet) {
            boolean matched =  path.contains(url);
            if(matched) return false;
        }
        return true;
    }

    /**
     * check the content type, only "application/json" will allow.
     * @param contentType
     * @return
     */
    public boolean validateContentType(String contentType) {
        return (null!= contentType && contentType.equalsIgnoreCase(MediaType.APPLICATION_JSON_VALUE));
    }
}
