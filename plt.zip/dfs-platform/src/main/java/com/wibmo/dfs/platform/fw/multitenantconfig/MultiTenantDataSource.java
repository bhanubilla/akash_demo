package com.wibmo.dfs.platform.fw.multitenantconfig;

import com.wibmo.dfs.hsm_client.CryptoException;
import com.wibmo.dfs.hsm_client.CryptoHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * DataSource properties are retrieved by the following class from the application.yml
 *
 * @author: Ala Venkateswarlu
 * @Created On: 16-07-2021
 */

@Component
@ConfigurationProperties(prefix = "db.datasources")
@Slf4j
public class MultiTenantDataSource {


    @Autowired
    private CryptoHandler cryptoHandler;

    private Map<Integer, Map<String, String>> tenants;

    private Map<String, String> global;

    private Map<Object, Object> configurations = new LinkedHashMap<>();

    public DataSource convert(Map<String, String> source) {
        try {
            return DataSourceBuilder.create()
                    .url(source.get("url"))
                    .driverClassName(source.get("driverClassName"))
                    .username(source.get("username"))
                    .password(cryptoHandler.getClearData(source.get("password")))
                    .build();
        } catch (CryptoException e) {
            log.error("Failed to decrypt password::{}",e);
        }
        return null;

    }

    public Map<Integer, Map<String, String>> getTenants() {
        return tenants;
    }

    public void setTenants(Map<Integer, Map<String, String>> tenants) {
        this.tenants = tenants;
    }

    public Map<Object, Object> getConfigurations() {
        if (configurations.isEmpty()){
            addConfigurations();
        }
        return configurations;
    }

    public void addConfigurations() {
        if(tenants == null ||this.tenants.isEmpty()){
            log.warn("No Data Sources available for multitenancy, Ignore if using Global data Source");
            return;
        }
        this.tenants
                .forEach((key, value) -> this.configurations.put(key, convert(value)));
    }

    public Map<String, String> getGlobal() {
        return global;
    }

    public void setGlobal(Map<String, String> global) {
        this.global = global;
    }

    public DataSource globalDataSource(){
        Map<String, String> source =getGlobal();
        if (null == source || source.isEmpty()){
            log.info("Global data source not configured, Ignore if using multitenancy");
            return null;
        }
        try {
            return DataSourceBuilder.create()
                    .url(source.get("url"))
                    .driverClassName(source.get("driverClassName"))
                    .username(source.get("username"))
                    .password(cryptoHandler.getClearData(source.get("password")))
                    .build();
        } catch (CryptoException e) {
            log.error("Failed to decrypt password::{}",e);
        }
        return null;
    }
}
