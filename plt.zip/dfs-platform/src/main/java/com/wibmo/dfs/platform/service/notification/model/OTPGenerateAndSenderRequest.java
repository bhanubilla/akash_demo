package com.wibmo.dfs.platform.service.notification.model;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OTPGenerateAndSenderRequest implements Serializable {
	private static final long serialVersionUID = 1L;
	// OTP generation Params
	private int eventId;
	private String accessString;
	// Notification Service params
	private String mobileNumber;
	private String fcmToken;
	private String emailId;
	private long accountNumber;
	private String deviceId;
	private boolean whatsappEnabled;
	private Map<String, String> placeHolders;
	private List<Attachment> attachments;
	
	private int programId;

}
