package com.wibmo.dfs.platform.fw.multitenantconfig;

/**
 * @author: Ala Venkateswarlu
 * @Created On: 16-07-2021
 */

public class ThreadLocalStorage {

    private ThreadLocalStorage() {
        //private constructor
    }

    /**
     * 'static' makes the ThreadLocal variable available across multiple classes for the respective thread only.
     * it's a kind of Global variable declaration of the respective thread local variables across multiple classes.
     */
    private static final InheritableThreadLocal<Integer> currentTenant = new InheritableThreadLocal<>();

    public static void setTenantId(Integer tenantId) {
        currentTenant.set(tenantId);
    }

    public static Integer getTenantId() {
        return currentTenant.get();
    }

    public static void clear(){
        currentTenant.remove();
    }
}
