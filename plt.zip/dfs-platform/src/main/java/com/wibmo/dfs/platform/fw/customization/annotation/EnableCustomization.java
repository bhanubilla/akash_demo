package com.wibmo.dfs.platform.fw.customization.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
/*
  Marker Interface to allow methods to be customized
 */
public @interface EnableCustomization {


    /**
     * Name of the method argument which holds value of the program id.
     * This is used in conjunction with {@link #customizationBeanPrefix()} to load
     * the customization corresponding to the program.
     * Defaults to "programId".
     *
     * @return String
     */
    String programIdArgName() default "programId";

    /**
     * Bean name prefix to be used to provide customization for this method.
     * This is used in conjunction with the {@link #programIdArgName()} to load the customization
     * corresponding to the program.
     * Default value will be FQCN+"."+methodName on which the annotation is applied.
     * FQCN is Fully Qualified Class Name (package name and class name).
     *
     * @return String
     */
    String customizationBeanPrefix();
}
