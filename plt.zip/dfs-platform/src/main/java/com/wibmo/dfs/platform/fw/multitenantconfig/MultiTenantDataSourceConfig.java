package com.wibmo.dfs.platform.fw.multitenantconfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.wibmo.dfs.platform.fw.annotations.ConditionalOnPropertyNotEmpty;

import javax.sql.DataSource;

/**
 * @author: Ala Venkateswarlu
 * @Created On: 16-07-2021
 */

@Configuration
public class MultiTenantDataSourceConfig {

    private final MultiTenantDataSource multiTenantDataSource;

    public MultiTenantDataSourceConfig(MultiTenantDataSource multiTenantDataSource) {
        this.multiTenantDataSource = multiTenantDataSource;
    }

    @Bean(name = "multiTenant")
    @Primary
    @Lazy
    @ConditionalOnPropertyNotEmpty(value = "db.datasources.tenants")
    public DataSource dataSource() {
        TenantAwareRoutingDataSource customDataSource = new TenantAwareRoutingDataSource();
        customDataSource.setTargetDataSources(multiTenantDataSource.getConfigurations());
        return customDataSource;
    }


    @Primary
    @Bean(name = "multiTenantJdbcTemplate")
    @Autowired
    @Lazy
    @ConditionalOnPropertyNotEmpty(value = "db.datasources.tenants")
    public JdbcTemplate jdbcTemplate(@Qualifier("multiTenant") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    @Bean(name = "multiTenantNamedJdbcTemplate")
    @Primary
    @Autowired
    @Lazy
    @ConditionalOnPropertyNotEmpty(value = "db.datasources.tenants")
    public NamedParameterJdbcTemplate namedParameterJdbcTemplate(@Qualifier("multiTenant") DataSource dataSource) {
        return new NamedParameterJdbcTemplate(dataSource);
    }

    @Bean(name = "globalDataSource")
    @Lazy
    @ConditionalOnPropertyNotEmpty(value = "db.datasources.global")
    public DataSource gloablDataSource() {
      return multiTenantDataSource.globalDataSource();
    }

    @Bean(name = "globalJdbcTemplate")
    @Autowired
    @Lazy
    @ConditionalOnPropertyNotEmpty(value = "db.datasources.global")
    public JdbcTemplate globalJdbcTemplate(@Qualifier("globalDataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    @Bean(name = "globalNamedJdbcTemplate")
    @Autowired
    @Lazy
    @ConditionalOnPropertyNotEmpty(value = "db.datasources.global")
    public NamedParameterJdbcTemplate globalNamedParameterJdbcTemplate(@Qualifier("globalDataSource") DataSource dataSource) {
        return new NamedParameterJdbcTemplate(dataSource);
    }

}
