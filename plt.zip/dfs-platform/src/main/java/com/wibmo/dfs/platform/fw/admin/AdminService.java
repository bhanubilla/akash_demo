package com.wibmo.dfs.platform.fw.admin;


import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.platform.model.WibmoResponse;
import com.wibmo.dfs.platform.service.notification.Constants;

import lombok.extern.slf4j.Slf4j;

/**
 * This class is used to fetch attributes from admin service
 * 
 * @author venkatanarayana.redd
 * @version 1.0
 */
@Service
@Slf4j
@ConditionalOnProperty(name = "platform.admin.service.enable", matchIfMissing = false)
public class AdminService {

	private RestTemplate restTemplate = new RestTemplate();

	/**
	 * This method is used to fetch attributes
	 * 
	 * @param programId
	 * @param key
	 * @param adminUrl
	 * @return
	 */
	public String fetchAttribute(int programId, String key, String adminUrl) {
		String value = Constants.NOT_AVAILABLE;
		try {
			log.info("AdminService::fetchProgramAttributes programId: {}, attributeKey: {}, adminURL: {}.", programId,
					key, adminUrl);
			HttpHeaders headers = new HttpHeaders();
			headers.set(Constants.ATTRIBUTE_KEY, key);
			headers.set(Constants.X_PROGRAM_ID, String.valueOf(programId));
			HttpEntity<String> entity = new HttpEntity<>(headers);
			String url =  adminUrl.concat(Constants.GLOBAL_ADMIN_SERVICE_EP);
			ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(url, HttpMethod.GET, entity,
					WibmoResponse.class);
			WibmoResponse apiResponse = responseEntity.getBody();
			if (apiResponse != null && Constants.SUCCESS_CODE.equalsIgnoreCase(apiResponse.getResCode())) {
				value = getResponseDescription(apiResponse, value);
			}
		} catch (Exception ex) {
			log.error("Error occured while calling fetchAttribute API of adminservice: ", ex);
		}
		log.info("AdminService::fetchProgramAttributesprogramId: {}, attributeKey: {}, attributeValue: {} ", programId,
				key, value);
		return value;
	}

	private String getResponseDescription(WibmoResponse apiResponse, String response) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			response = mapper.convertValue(apiResponse.getData(), String.class);
		} catch (Exception ex) {
			log.error("Error occured while getResponseDescription : ", ex);
		}
		return response;
	}

}
