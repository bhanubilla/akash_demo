package com.wibmo.dfs.platform.fw.logging.interceptor;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.platform.fw.logging.util.LoggingUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Component
public class LoggingInterceptor implements ClientHttpRequestInterceptor {

    @Autowired
    private LoggingUtil util;

    @Override
    public ClientHttpResponse intercept(
      HttpRequest req, byte[] reqBody, ClientHttpRequestExecution ex) throws IOException {
        ClientHttpResponse response = ex.execute(req, reqBody);
        try {
            MediaType content = req.getHeaders().getContentType();
            if(util.validateUrl(req.getURI().getPath()) &&
                    util.validateContentType(null!= content ? content.toString() : null)) {
                final StringBuilder logRequest = new StringBuilder("\n").append(req.getMethod())
                        .append(" ").append(req.getURI());
                StringBuilder sb = new StringBuilder();
                sb.append(logRequest.toString()).append(fetchHeaders(req)).append("\n").append("Request body: ").append(util.doMask(new String(reqBody, StandardCharsets.UTF_8)));

                InputStreamReader isr = new InputStreamReader(
                        response.getBody(), StandardCharsets.UTF_8);
                BufferedReader bf = new BufferedReader(isr);
                String body = bf.lines()
                        .collect(Collectors.joining("\n"));
                sb.append("\n").append("Response body: ").append(util.doMask(body));
                log.debug(sb.toString());
                bf.close();
                isr.close();
            }
        } catch (Exception e) {
            log.error("error in logging intercept: {}",e);
        }
        return response;
    }

    private String fetchHeaders(HttpRequest req) throws JsonProcessingException {
        Map<String, Object> map = new ObjectMapper().readValue(new ObjectMapper().writeValueAsString(req.getHeaders()),
                new TypeReference<LinkedHashMap<String, Object>>(){});
        StringBuilder sb = new StringBuilder();
        map.forEach((k,v) -> sb.append("\n").append(k).append(":").append(v));
        return sb.toString();
    }

}
