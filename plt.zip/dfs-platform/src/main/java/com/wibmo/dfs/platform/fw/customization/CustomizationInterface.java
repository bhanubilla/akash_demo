package com.wibmo.dfs.platform.fw.customization;

import com.wibmo.dfs.platform.fw.customization.vo.CustomizationResponseVO;

import java.util.Map;

/**
 * This interface defines the contract to be implemented for customizing product
 * behavior.
 */
public interface CustomizationInterface {

    /**
     * Override to return <code>true</code> if pre execution hook has been added.
     *
     * @return
     */
    default boolean isPreExecutionCustomized() {
        return false;
    }

    /**
     * Override to return true if product process has been customized.
     *
     * @return
     */
    default boolean isProcessExecutionCustomized() {
        return false;
    }

    /**
     * Override to return <code>true</code> if post execution behavior has been
     * added.
     *
     * @return
     */
    default boolean isPostExecutionCustomized() {
        return false;
    }

    /**
     * Override to implement pre execution. Default behavior is to return a new
     * instance of {@link CustomizationResponseVO}.
     * <p>
     * NOTE: override {@link #isPreExecutionCustomized()} to return
     * <code>true</code>, else the overridden behavior will not be invoked.
     *
     * @param argsMap : method arguments of the product code being customized. They
     *                can be referred from the map using the argument name declared
     *                in the product code.
     * @return
     */
    default CustomizationResponseVO preExecution(Map<String, Object> argsMap) {
        return new CustomizationResponseVO();
    }

    /**
     * Override to implement pre execution. Default behavior is to return a new
     * instance of {@link CustomizationResponseVO}.
     * <p>
     * NOTE: override {@link #isProcessExecutionCustomized()} to return
     * <code>true</code>, else the overridden behavior will not be invoked.
     *
     * @param argsMap : method arguments of the product code being customized. They
     *                can be referred from the map using the argument name declared
     *                in the product code.
     * @return
     */
    default CustomizationResponseVO processExecution(Map<String, Object> argsMap) {
        return new CustomizationResponseVO();
    }

    /**
     * Override to implement pre execution. Default behavior is to return responseVO passed in the input argument.
     * <p>
     * NOTE: override {@link #isProcessExecutionCustomized()} to return
     * <code>true</code>, else the overridden behavior will not be invoked.
     *
     * @param argsMap    : method arguments of the product code being customized. They
     *                   can be referred from the map using the argument name declared
     *                   in the product code.
     * @param responseVO : this is the output of the product/customization process execution.
     * @return
     */
    default CustomizationResponseVO postExecution(Map<String, Object> argsMap, CustomizationResponseVO responseVO) {
        return responseVO;
    }

}
