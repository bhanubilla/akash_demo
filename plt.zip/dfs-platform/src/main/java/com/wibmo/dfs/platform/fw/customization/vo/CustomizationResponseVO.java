package com.wibmo.dfs.platform.fw.customization.vo;

public class CustomizationResponseVO {

	public CustomizationResponseVO() {
		this.response = null;
		this.returnStatus = RETURN_STATUS.DEFAULT;
	}

	
	public CustomizationResponseVO(Object response) {
		this.response = response;
		this.returnStatus = RETURN_STATUS.DEFAULT;
	}
	
	public CustomizationResponseVO(Object response, RETURN_STATUS returnStatus) {
		this.response = response;
		if (returnStatus != null) {
			this.returnStatus = returnStatus;
		}
	}

	private RETURN_STATUS returnStatus = RETURN_STATUS.DEFAULT;

	private Object response;

	public Object getResponse() {
		return response;
	}

	public void setResponse(Object response) {
		this.response = response;
	}

	/**
	 * This will never return NULL, if returnStatus is set as NULL during execution,
	 * this method will replace NULL with RETURN_STATUS.DEFAULT
	 * @return
	 */
	public RETURN_STATUS getReturnStatus() {
		return returnStatus==null?RETURN_STATUS.DEFAULT:returnStatus;
	}

	public void setReturnStatus(RETURN_STATUS returnStatus) {
		this.returnStatus = returnStatus;
	}

}
