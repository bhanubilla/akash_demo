package com.wibmo.dfs.platform.service.notification.model;

import lombok.Data;

@Data
public class Attachment {
    private String content;
    private String name;
    private String contentType;
}
