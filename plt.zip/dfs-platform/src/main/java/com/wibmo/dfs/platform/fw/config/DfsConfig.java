package com.wibmo.dfs.platform.fw.config;

import com.wibmo.dfs.platform.fw.logging.interceptor.LoggingInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class DfsConfig {

    @Autowired
    private LoggingInterceptor loggingInterceptor;

    @Value("${platform.logging.api.enable:false}")
    private boolean apiLogging;

    /**
     * Create singleton restTemplate success bean for consuming service.
     *
     * @return
     */
    @Bean
    public RestTemplate getRestTemplate() {
        if (apiLogging) {
            ClientHttpRequestFactory factory = new BufferingClientHttpRequestFactory(
                    new SimpleClientHttpRequestFactory());
            RestTemplate restTemplate = new RestTemplate(factory);
            List<ClientHttpRequestInterceptor> interceptors = restTemplate.getInterceptors();
            if (CollectionUtils.isEmpty(interceptors)) {
                interceptors = new ArrayList<>();
            }
            interceptors.add(loggingInterceptor);
            restTemplate.setInterceptors(interceptors);
            return restTemplate;
        } else {
            return new RestTemplate();
        }

    }
}
