package com.wibmo.dfs.platform.fw.storage;

import com.wibmo.dfs.platform.model.WibmoResponse;

public interface StorageService {

	public WibmoResponse upload(Request request);

	public WibmoResponse download(Request request);

}
