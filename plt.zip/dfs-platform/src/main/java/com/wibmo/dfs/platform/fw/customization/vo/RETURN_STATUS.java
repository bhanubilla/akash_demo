package com.wibmo.dfs.platform.fw.customization.vo;

/**
 * <ul>
 * <li>SKIP_PROCESS setting this in return will skip the process execution. This
 * applies to both product and customization process execution. This is a
 * runtime evaluation.</li>
 * <li>
 * 
 * SKIP_POST setting this in return will skip the customization post execution
 * behavior. This is a runtime evaluation, customization done for post execution
 * will be skipped if this flag is set in the return.</li>
 * 
 * <li>
 * 
 * SKIP_ALL setting this in return will skip all process execution and post
 * execution. The product process behavior will also be skipped. This is a
 * runtime evaluation.</li>
 * <li>DEFAULT setting this in return will execute the product/customization
 * behavior as configured by default. This is the default value the return
 * status flag in customization response.</li>
 */
public enum RETURN_STATUS {

	/**
	 * SKIP_PROCESS setting this in return will skip the process execution. This
	 * applies to both product and customization process execution. This is a
	 * runtime evaluation.
	 */
	SKIP_PROCESS,
	/**
	 * SKIP_POST setting this in return will skip the customization post execution
	 * behavior. This is a runtime evaluation, customization done for post execution
	 * will be skipped if this flag is set in the return.
	 */
	SKIP_POST,

	/**
	 * SKIP_ALL setting this in return will skip all process execution and post
	 * execution. The product process behavior will also be skipped. This is a
	 * runtime evaluation.
	 */
	SKIP_ALL,

	/**
	 * DEFAULT setting this in return will execute the product/customization
	 * behavior as configured by default. This is the default value the return
	 * status flag in customization response.
	 */
	DEFAULT

}
