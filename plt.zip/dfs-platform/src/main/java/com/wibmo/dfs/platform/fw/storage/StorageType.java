package com.wibmo.dfs.platform.fw.storage;
/**
 * Enumeration for StorageTypes
 */
public enum StorageType {

	S3_STORAGE("S3");

	private final String name;

	private StorageType(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

}
