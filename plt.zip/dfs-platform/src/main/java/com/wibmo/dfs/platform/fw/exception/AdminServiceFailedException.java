package com.wibmo.dfs.platform.fw.exception;

public class AdminServiceFailedException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private final String message;

	public AdminServiceFailedException(String message) {
		super();
		this.message = message;
	}

	@Override
	public String getMessage() {
		return message;
	}

}
