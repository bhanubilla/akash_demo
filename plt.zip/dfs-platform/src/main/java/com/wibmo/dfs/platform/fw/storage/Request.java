package com.wibmo.dfs.platform.fw.storage;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Request {

	private String bucket;
	private String path;
	private byte[] data;
	private String contentType;

}
