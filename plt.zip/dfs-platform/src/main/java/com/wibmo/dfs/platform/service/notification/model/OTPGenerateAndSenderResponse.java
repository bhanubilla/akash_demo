package com.wibmo.dfs.platform.service.notification.model;

import com.wibmo.dfs.platform.service.notification.WibmoResponse;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@ToString
public class OTPGenerateAndSenderResponse extends WibmoResponse {
	private static final long serialVersionUID = 1L;
	private String otpRef;
	private String otpValue;
	private int eventId;
	private long expireAt;
	private String accessString;
	private String referenceId;
}
