package com.wibmo.dfs.platform.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
public class WibmoResponse implements Serializable {

	private String  resCode;
	private String resDesc;
	private transient Object data;

	public WibmoResponse(String resCode, String resDesc, Object data) {
		super();
		this.resCode = resCode;
		this.resDesc = resDesc;
		this.data = data;
	}

	public WibmoResponse(String resCode, String resDesc) {
		super();
		this.resCode = resCode;
		this.resDesc = resDesc;
	}

}
