package com.wibmo.dfs.platform.service.notification;

import com.wibmo.dfs.platform.service.notification.model.NotificationRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.scheduling.annotation.Async;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;


@Slf4j
public class NotificationServiceCall {

	RestTemplate restTemplate = new RestTemplate();

	@Async("notificationThreadPoolExecutor")
	public void send(NotificationRequest aRequest, String notificationUrl) {
		try {
			MultiValueMap<String, String> customNotificationHeader = new LinkedMultiValueMap<>();
			customNotificationHeader.add(HttpHeaders.CONTENT_TYPE, String.valueOf(MediaType.APPLICATION_JSON));
			customNotificationHeader.add(Constants.X_PROGRAM_ID, String.valueOf(aRequest.getProgramId()));
			HttpEntity<Object> notificationEntity = new HttpEntity<>(aRequest, customNotificationHeader);
			ResponseEntity<WibmoResponse> response = restTemplate.exchange( notificationUrl+ Constants.GLOBAL_NOTIFICATION_SERVICE_EP, HttpMethod.POST, notificationEntity, WibmoResponse.class);
			if(response.getBody().getResCode()!=200) {
				log.debug("Notification sending failed: {}", response.getBody().getErrorMessage());
			}
		}
		catch(Exception e) {
			log.error("Issue while sending notification " + e.getMessage());
		}

	}
}
