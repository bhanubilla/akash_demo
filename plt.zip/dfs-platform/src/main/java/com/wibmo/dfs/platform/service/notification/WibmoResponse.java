package com.wibmo.dfs.platform.service.notification;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = Visibility.ANY)
public class WibmoResponse implements Serializable {
	private static final long serialVersionUID = 1L;
	private int resCode;
	private String resDesc;
	private String errorMessage;
	private transient Object data;

	public WibmoResponse(int resCode, String resDesc, Object data) {
		super();
		this.resCode = resCode;
		this.resDesc = resDesc;
		this.data = data;
	}

	public WibmoResponse(int resCode, String resDesc) {
		super();
		this.resCode = resCode;
		this.resDesc = resDesc;
	}

}
