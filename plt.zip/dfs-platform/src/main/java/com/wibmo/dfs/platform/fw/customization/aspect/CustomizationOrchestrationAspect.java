package com.wibmo.dfs.platform.fw.customization.aspect;


import com.wibmo.dfs.platform.fw.customization.CustomizationInterface;
import com.wibmo.dfs.platform.fw.customization.annotation.EnableCustomization;
import com.wibmo.dfs.platform.fw.customization.vo.CustomizationResponseVO;
import com.wibmo.dfs.platform.fw.customization.vo.RETURN_STATUS;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.CodeSignature;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.BeanNotOfRequiredTypeException;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Aspect
@Component
@Slf4j
public final class CustomizationOrchestrationAspect {

    @Autowired
    ApplicationContext appContext;

    @Around("@annotation(com.wibmo.dfs.platform.fw.customization.annotation.EnableCustomization)")
    public Object injectCustomization(ProceedingJoinPoint pjp) throws Throwable {

        /*
          AspectJ method signature class is used to read argument names.
         */
        CodeSignature methodSignature = (org.aspectj.lang.reflect.CodeSignature) pjp.getSignature();

        /*
         * Method signature is used to read the param values from the AllowCustomization
         * annotation
         */
        EnableCustomization allowCustomization = ((MethodSignature) pjp.getSignature()).getMethod()
                .getAnnotation(EnableCustomization.class);
        String programIdArgName = allowCustomization.programIdArgName();

        String customizationBeanNamePrefix = !"".equals(allowCustomization.customizationBeanPrefix()) ?
                allowCustomization.customizationBeanPrefix() : pjp.getSignature().getDeclaringTypeName() + "." + pjp.getSignature().getName();

        /*
         * Evaluate program id and make a map of method arguments to pass to the
         * customization function.
         */
        String programId = null;


        Map<String, Object> argsMap = new HashMap<>();

        for (int i = 0; i < methodSignature.getParameterNames().length; i++) {

            String argName = methodSignature.getParameterNames()[i];
            Object argValue = pjp.getArgs()[i];

            argsMap.put(argName, argValue);

            if (programIdArgName.equalsIgnoreCase(argName)) {
                programId = String.valueOf(pjp.getArgs()[i]);
            }

        }

        /*
         * This can be exploded to load bean based on more than just program Id.
         */

        CustomizationInterface fnImpl = null;
        try {
            fnImpl = appContext.getBean(customizationBeanNamePrefix + "." + programId, CustomizationInterface.class);
        } catch (NoSuchBeanDefinitionException | BeanNotOfRequiredTypeException e) {
            log.debug("no customization bean found for prefix: {}, programId: {}", customizationBeanNamePrefix, programId);
        }

        /*
         * if no customization exists then run the product code and return.
         */
        if (fnImpl == null) {
            return pjp.proceed();
        }


        CustomizationResponseVO responseVO = null;
        /*
         * Customization found, proceeding with customization execution.
         * Evaluate and execute an pre execution customization code.
         */
        if (fnImpl.isPreExecutionCustomized()) {
            responseVO = fnImpl.preExecution(argsMap);
        }

        /*
         * SKIP_ALL is set response, so skip any process and post execution and return response from here.
         */
        if (responseVO != null && responseVO.getReturnStatus().equals(RETURN_STATUS.SKIP_ALL)) {
            log.debug("SKIP_ALL is set response, so skip any process and post execution and return response from here.");
            return responseVO.getResponse();
        }

        /*
         * Continue evaluation to check of custom process or product process has to be executed.
         */
        if (responseVO != null && responseVO.getReturnStatus().equals(RETURN_STATUS.SKIP_PROCESS)) {
            log.debug("skipping process execution as SKIP_PROCESS flag is set");
        } else {
            if (fnImpl.isProcessExecutionCustomized()) {
                /*
                 * Customized implementation invocation
                 */
                log.debug("about to execute customized process execution");
                responseVO = fnImpl.processExecution(argsMap);
            } else {
                /*
                 * Product implementation invocation if no customization
                 */
                log.debug("about to execute product process execution");
                Object productResponse = pjp.proceed();
                responseVO = new CustomizationResponseVO(productResponse, RETURN_STATUS.DEFAULT);
            }

        }

        if (responseVO != null && responseVO.getReturnStatus().equals(RETURN_STATUS.SKIP_POST)) {
            log.debug("skipping post execution as SKIP_POST flag is set");
        } else {
            if (fnImpl.isPostExecutionCustomized()) {
                log.debug("about to execute post process execution");
                responseVO = fnImpl.postExecution(argsMap, responseVO);
            }
        }
        return responseVO == null ? null : responseVO.getResponse();
    }


}
