package com.wibmo.dfs.platform.fw.storage;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.model.S3Object;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.platform.fw.admin.AdminService;
import com.wibmo.dfs.platform.fw.annotations.Storage;
import com.wibmo.dfs.platform.fw.exception.AdminServiceFailedException;
import com.wibmo.dfs.platform.fw.multitenantconfig.ThreadLocalStorage;
import com.wibmo.dfs.platform.model.WibmoResponse;
import com.wibmo.dfs.platform.service.notification.Constants;

import lombok.extern.slf4j.Slf4j;

/**
 * This class used to handle upload and download documents to the s3 bucket
 * 
 * @author venkatanarayana.redd
 * @version 1.0
 */
@Slf4j
@Storage(name = "S3")
@Service
@ConditionalOnProperty(name = "platform.storage.s3.enable", matchIfMissing = false)
public class S3StorageServiceImpl implements StorageService {

	private Map<Integer, AmazonS3> s3ClientMap = new HashMap<>();

	@Autowired
	private AdminService adminSevice;

	@Value("${resource.url.admin}")
	private String adminUrl;

	/**
	 * This method used to upload documents to the s3 bucket
	 * 
	 * @param request
	 * @return
	 *
	 */
	@Override
	public WibmoResponse upload(Request request) {
		int programId = ThreadLocalStorage.getTenantId();
		WibmoResponse response = new WibmoResponse();
		if (Objects.nonNull(request.getData())) {
			try (InputStream contentStream = new ByteArrayInputStream(request.getData())) {
				uploadFile(programId, contentStream, request.getBucket(), request.getPath(), request.getContentType(),
						request.getData().length, response);
			} catch (Exception e) {
				log.error("Error occured while uploading document to s3 bucket: {}, filePath: {}. Reason: ",
						request.getBucket(), request.getPath(), e);
				s3ClientMap.remove(programId);
				response.setResCode(Constants.ERROR_CODE);
				response.setResDesc(Constants.UPLOAD_DOCUMENT_ERROR_MESSAGE);

			}
		} else {
			log.error("Required information is missing in request.  data:{} ", request.getData());
			response.setResCode(Constants.ERROR_CODE);
			response.setResDesc(Constants.UPLOAD_DOCUMENT_ERROR_MESSAGE);
		}
		return response;
	}

	/**
	 * This method used to download the documents from the s3 bucket
	 * 
	 * @param request
	 * @return
	 */
	@Override
	public WibmoResponse download(Request request) {
		int programId = ThreadLocalStorage.getTenantId();
		WibmoResponse response = new WibmoResponse();
		GetObjectRequest getReq = new GetObjectRequest(request.getBucket(), request.getPath());
		try (S3Object o = getS3Client(programId).getObject(getReq)) {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			IOUtils.copy(o.getObjectContent(), baos);
			response.setData(baos.toByteArray());
			response.setResCode(Constants.SUCCESS_CODE);
			response.setResDesc(Constants.DOWNLOAD_DOCUMENT_SUCCESS_MESSAGE);
		} catch (Exception ex) {
			log.error("Error Occured while downloading documents from s3 bucket: {}, filePath: {}. Reason: ",
					request.getBucket(), request.getPath(), ex);
			s3ClientMap.remove(programId);
			response.setResCode(Constants.ERROR_CODE);
			response.setResDesc(Constants.DOWNLOAD_DOCUMENT_ERROR_MESSAGE);
		}
		return response;
	}

	private WibmoResponse uploadFile(int programId, InputStream fileContent, String bucketName, String filePath,
			String contentType, int contentLength, WibmoResponse response) {
		try {
			ObjectMetadata metaData = new ObjectMetadata();
			metaData.setContentType(contentType);
			metaData.setContentLength(contentLength);
			PutObjectRequest req = new PutObjectRequest(bucketName, filePath, fileContent, metaData);
			PutObjectResult result = getS3Client(programId).putObject(req);
			if (Objects.nonNull(result)) {
				response.setResCode(Constants.SUCCESS_CODE);
				response.setResDesc(Constants.UPLOAD_DOCUMENT_SUCCESS_MESSAGE);
			} else {
				response.setResCode(Constants.ERROR_CODE);
				response.setResDesc(Constants.UPLOAD_DOCUMENT_ERROR_MESSAGE);
			}

		} catch (Exception e) {
			log.error("Error Occured while uploading documents to s3 bucket: {}, filePath: {}. Reason: ", bucketName,
					filePath, e);
			s3ClientMap.remove(programId);
			response.setResCode(Constants.ERROR_CODE);
			response.setResDesc(Constants.UPLOAD_DOCUMENT_ERROR_MESSAGE);
		}

		return response;
	}

	private AmazonS3 getS3Client(int programId) {
		if (!s3ClientMap.containsKey(programId)) {
			AWSCredentials credentials = getAWSCredentials(programId, adminUrl);
			BasicAWSCredentials awsCreds = new BasicAWSCredentials(credentials.getAccessKey(),
					credentials.getSecretKey());
			Regions region = Regions.fromName(credentials.getRegion());
			AmazonS3 s3Client = AmazonS3ClientBuilder.standard()
					.withCredentials(new AWSStaticCredentialsProvider(awsCreds)).withRegion(region).build();
			s3ClientMap.put(programId, s3Client);
		}
		return s3ClientMap.get(programId);
	}

	private AWSCredentials getAWSCredentials(int programId, String adminUrl) {
		AWSCredentials awsCredentials = null;
		try {
			String value = adminSevice.fetchAttribute(programId, Constants.S3_ATTRIBUTE_KEY, adminUrl);
			ObjectMapper mapper = new ObjectMapper();
			awsCredentials = mapper.readValue(value, AWSCredentials.class);
		} catch (Exception ex) {
			log.error("Error occured while getResponseDescription: ", ex);
			throw new AdminServiceFailedException(Constants.ADMIN_SERVICE_FAILED_ERROR);
		}
		return awsCredentials;
	}

}