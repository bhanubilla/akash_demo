package com.wibmo.dfs.platform.fw.notification;

import java.util.HashMap;
import java.util.Objects;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.wibmo.dfs.platform.service.notification.Constants;
import com.wibmo.dfs.platform.service.notification.model.OTPGenerateAndSenderRequest;
import com.wibmo.dfs.platform.service.notification.model.OTPGenerateAndSenderResponse;

import lombok.extern.slf4j.Slf4j;

/**
 * <h1>Generate OTP and send Notification</h1> This class is used to generate
 * OTP and send notification
 * 
 * @author venkatanarayana.redd
 * @version 1.0
 */
@Service
@Slf4j
@ConditionalOnProperty(name = "platform.notification.enable", matchIfMissing = false)
public class OTPGenerateAndSenderService {

	private RestTemplate restTemplate = new RestTemplate();

	/**
	 * This method is used to generate OTP and send notification
	 * 
	 * @param request
	 * @param otpGenerateUrl
	 * @param notificationUrl
	 * @return
	 */
	public OTPGenerateAndSenderResponse generateAndSendOTP(OTPGenerateAndSenderRequest request, String otpGenerateUrl,
			String notificationUrl) {
		MultiValueMap<String, String> customNotificationHeader = new LinkedMultiValueMap<>();
		customNotificationHeader.add(HttpHeaders.CONTENT_TYPE, String.valueOf(MediaType.APPLICATION_JSON));
		customNotificationHeader.add(Constants.X_PROGRAM_ID, String.valueOf(request.getProgramId()));
		HttpEntity<Object> requestEntity = new HttpEntity<>(request, customNotificationHeader);
		// making otp generation service call
		OTPGenerateAndSenderResponse response = makeOtpSerivceCall(requestEntity, otpGenerateUrl);
		if (response.getResCode() != 200) {
			log.debug("Generate OTP failed. Reason : {}", response.getErrorMessage());
			return response;
		}
		populatePlaceHolders(request, response);
		// making notification service call
		makeNotificationServiceCall(requestEntity, notificationUrl, response);
		if (response.getResCode() != 100) {
			log.debug("Notification Service call failed. Reason : {}", response.getErrorMessage());
			return response;
		}
		return response;
	}

	private void makeNotificationServiceCall(HttpEntity<Object> requestEntity, String url,
			OTPGenerateAndSenderResponse response) {
		try {
			ResponseEntity<OTPGenerateAndSenderResponse> serviceResponse = restTemplate.exchange(
					url + Constants.GLOBAL_NOTIFICATION_SERVICE_EP, HttpMethod.POST, requestEntity,
					OTPGenerateAndSenderResponse.class);
			OTPGenerateAndSenderResponse responseBody = serviceResponse.getBody();
			if (Objects.nonNull(responseBody)) {
				response.setReferenceId(responseBody.getReferenceId());
				response.setResCode(responseBody.getResCode());
				response.setResDesc(responseBody.getResDesc());
			} else {
				response.setResCode(Constants.NOTIFICATION_SERVICE_ERROR_CODE);
				response.setResDesc(Constants.ERROR);
			}
		} catch (Exception e) {
			log.error("Error occured while calling notification service. Reason : {} ", e.getMessage());
			response.setResCode(Constants.NOTIFICATION_SERVICE_ERROR_CODE);
			response.setResDesc(Constants.ERROR);
		}
	}

	private OTPGenerateAndSenderResponse makeOtpSerivceCall(HttpEntity<Object> requestEntity, String url) {
		OTPGenerateAndSenderResponse responseBody = null;
		try {
			ResponseEntity<OTPGenerateAndSenderResponse> serviceResponse = restTemplate.exchange(
					url + Constants.GLOBAL_OTP_GENERATE_SERVICE_EP, HttpMethod.POST, requestEntity,
					OTPGenerateAndSenderResponse.class);
			responseBody = serviceResponse.getBody();
			if (Objects.isNull(responseBody)) {
				responseBody = new OTPGenerateAndSenderResponse();
				responseBody.setResCode(Constants.OTP_SERVICE_ERROR_CODE);
				responseBody.setResDesc(Constants.ERROR);
			}
		} catch (Exception e) {
			log.error("Error occured while calling otp service. Reason : {}. ", e.getMessage());
			responseBody = new OTPGenerateAndSenderResponse();
			responseBody.setResCode(Constants.OTP_SERVICE_ERROR_CODE);
			responseBody.setResDesc(Constants.ERROR);
		}
		return responseBody;
	}

	private void populatePlaceHolders(OTPGenerateAndSenderRequest request, OTPGenerateAndSenderResponse response) {
		if (Objects.isNull(request.getPlaceHolders())) {
			request.setPlaceHolders(new HashMap<>());
		}
		request.getPlaceHolders().put(Constants.OTP_VALUE, response.getOtpValue());
	}

}
