package com.wibmo.dfs.platform.fw.multitenantconfig;

import org.springframework.stereotype.Component;
import org.springframework.ui.ModelMap;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.context.request.WebRequestInterceptor;

/**
 * @author: Ala Venkateswarlu
 * @Created On: 16-07-2021
 */

@Component
public class HeaderTenantInterceptor implements WebRequestInterceptor {

    private static final String TENANT_HEADER = "X-PROGRAM-ID";

    @Override
    public void preHandle(WebRequest request) throws Exception {
        String tenantId = request.getHeader(TENANT_HEADER);
        if (null!=tenantId && !"".equals(tenantId.trim())) {
            ThreadLocalStorage.setTenantId(Integer.parseInt(tenantId));
        }
    }

    /**
     * Intercept the execution of a request handler <i>after</i> its successful
     * invocation, right before view rendering (if any).
     * <p>Allows for modifying context resources after successful handler
     * execution (for example, flushing a Hibernate Session).
     *
     * @param request the current web request
     * @param model   the map of model objects that will be exposed to the view
     *                (may be {@code null}). Can be used to analyze the exposed model
     *                and/or to add further model attributes, if desired.
     * @throws Exception in case of errors
     */
    @Override
    public void postHandle(WebRequest request, ModelMap model) throws Exception {
        // Ignore
    }

    /**
     * Callback after completion of request processing, that is, after rendering
     * the view. Will be called on any outcome of handler execution, thus allows
     * for proper resource cleanup.
     * <p>Note: Will only be called if this interceptor's {@code preHandle}
     * method has successfully completed!
     *
     * @param request the current web request
     * @param ex      exception thrown on handler execution, if any
     * @throws Exception in case of errors
     */
    @Override
    public void afterCompletion(WebRequest request, Exception ex) throws Exception {
        ThreadLocalStorage.clear();
    }

    // other methods omitted

}
