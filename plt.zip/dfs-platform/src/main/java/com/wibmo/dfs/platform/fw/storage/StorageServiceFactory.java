package com.wibmo.dfs.platform.fw.storage;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.wibmo.dfs.platform.fw.admin.AdminService;
import com.wibmo.dfs.platform.fw.annotations.Storage;
import com.wibmo.dfs.platform.fw.multitenantconfig.ThreadLocalStorage;
import com.wibmo.dfs.platform.service.notification.Constants;

/**
 * Factory of storage service
 * 
 * @author venkatanarayana.redd
 * @version 1.0
 */
@Component
@ConditionalOnProperty(name = "platform.storage.factory.enable", matchIfMissing = false)
public class StorageServiceFactory {

	private Map<String, StorageService> storageServices = new HashMap<>();

	@Autowired
	private AdminService adminService;

	@Autowired
	private ApplicationContext applicationContext;

	@Value("${resource.url.admin}")
	private String adminUrl;

	@PostConstruct
	public void init() {
		applicationContext.getBeansWithAnnotation(Storage.class).values().forEach(storageService -> {
			String key = storageService.getClass().getAnnotation(Storage.class).name();
			storageServices.put(key, (StorageService) storageService);
		});
	}

	/**
	 * get default storageService
	 * 
	 * @return
	 */
	public StorageService get() {
		int programId = ThreadLocalStorage.getTenantId();
		String value = adminService.fetchAttribute(programId, Constants.STORAGE_DEFAULT_KEY, adminUrl);
		return storageServices.get(value);
	}

	/**
	 * get storageService by storageType
	 * 
	 * @param storageType
	 * @return
	 */
	public StorageService get(StorageType storageType) {
		return storageServices.get(storageType.getName());
	}

}
