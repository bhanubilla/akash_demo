package com.wibmo.dfs.upi.adapter.juspay.model;

import java.io.Serializable;
import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayCreateAndLinkResponsePayload implements Serializable {
	private static final long serialVersionUID = 1L;
	private String merchantId;
	private String merchantChannelId;
	private String merchantCustomerId;
	private String customerMobileNumber;
	private List<JuspayVpaAccountResponse> vpaAccounts;
}
