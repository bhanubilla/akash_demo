package com.wibmo.dfs.upi.model.response;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VpaValidResponse {
	
	private boolean vpaValid;
	private List<String> vpaSuggestions;

}
