package com.wibmo.dfs.upi.dao;

import com.wibmo.dfs.upi.model.UpiDeregisteredCustInfo;

public interface UpiDeregisterCustInfoDAO {
    void saveDetail(UpiDeregisteredCustInfo upiDeregisteredCustInfo);
}
