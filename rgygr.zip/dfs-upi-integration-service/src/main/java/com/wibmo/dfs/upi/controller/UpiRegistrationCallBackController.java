package com.wibmo.dfs.upi.controller;

import com.wibmo.dfs.upi.model.response.WibmoResponse;
import com.wibmo.dfs.upi.service.UpiService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/upi/callback")
@Slf4j
public class UpiRegistrationCallBackController {

    @Autowired
    private UpiService upiService;

    @PostMapping("/v1/device/status")
    public WibmoResponse deviceStatusCallback(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestBody String request) {
        log.info("device status method");
        return upiService.deviceStatusCallback(programId, request);
    }
}
