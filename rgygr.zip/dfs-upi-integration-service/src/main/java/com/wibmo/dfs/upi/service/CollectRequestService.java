package com.wibmo.dfs.upi.service;

import com.wibmo.dfs.upi.model.request.UpiIncomingCollectRequest;
import com.wibmo.dfs.upi.model.response.WibmoResponse;

public interface CollectRequestService {

    WibmoResponse incomingCollectRequest(String programId, String accountNumber, UpiIncomingCollectRequest upiIncomingCollectRequest);
}
