package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayIncomingCommonPayload {
    private String refUrl;
    private String remarks;
    private String bankAccountUniqueId;
    private String bankCode;
    private String maskedAccountNumber;
    private String amount;
    private String transactionTimestamp;
    private String gatewayTransactionId;
    private String gatewayReferenceId;
    private String gatewayResponseStatus;
    private String gatewayResponseCode;
    private String gatewayResponseMessage;
}
