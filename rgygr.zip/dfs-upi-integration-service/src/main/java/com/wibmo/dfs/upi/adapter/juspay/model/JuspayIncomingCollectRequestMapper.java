package com.wibmo.dfs.upi.adapter.juspay.model;

import com.wibmo.dfs.upi.constants.UpiGatewayStatusConstants;
import com.wibmo.dfs.upi.dao.VPADetailsDAO;
import com.wibmo.dfs.upi.dao.VPALinkedAccountDAO;
import com.wibmo.dfs.upi.model.VPADetails;
import com.wibmo.dfs.upi.model.VPALinkedAccount;
import com.wibmo.dfs.upi.model.request.UpiIncomingCollectRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@Slf4j
public class JuspayIncomingCollectRequestMapper {

    @Autowired
    private VPADetailsDAO vpaDetailsDAO;

    @Autowired
    private VPALinkedAccountDAO vpaLinkedAccountDAO;

    public UpiIncomingCollectResponse map(JuspayIncomingCollectResponse response) {
        log.info("mapping JuspayIncomingCollectResponse to UpiIncomingCollectResponse");
        UpiIncomingCollectResponse res = new UpiIncomingCollectResponse();
        res.setTxnId(response.getPayload().getMerchantRequestId());
        res.setApprovalStatus(response.getPayload().getRequestType());
        res.setPayerVpa(response.getPayload().getPayerVpa());
        res.setPayeeVpa(response.getPayload().getPayeeVpa());
        res.setPayeeName(response.getPayload().getPayeeName());
        res.setTxnAmount(impliedDecimalString(response.getPayload().getAmount()));
        res.setTxnMode("UPI");
        res.setRemarks(response.getPayload().getRemarks());
        res.setTxnDate(new Date().getTime());
        setWibmoStatus(res, response.getPayload());
        return res;

    }

    private void setWibmoStatus(UpiIncomingCollectResponse upiIncomingCollectResponse , JuspayIncomingCollectPayload payload){
        log.info("gateway response is :: {}", payload.getGatewayResponseCode());
        switch (payload.getGatewayResponseCode()){
            case "00":
            case "96":
                log.info("Considering is as success");
                upiIncomingCollectResponse.setWibmoRespCode(200);
                upiIncomingCollectResponse.setWibmoResDesc("SUCCESS");
                break;
            case "01":
                log.info("Considering is as success");
                upiIncomingCollectResponse.setWibmoRespCode(202);
                upiIncomingCollectResponse.setWibmoResDesc("PENDING");
                break;
            case "ZA":
                upiIncomingCollectResponse.setWibmoRespCode(200);
                upiIncomingCollectResponse.setWibmoResDesc("SUCCESS");
                break;
            case "Z9":
            case "Z8":
            case "Z7":
            case "Z6":
            case "ZM":
            case "Else":
                log.info("Considering is as failure");
                upiIncomingCollectResponse.setWibmoRespCode(100);
                upiIncomingCollectResponse.setWibmoResDesc("FAILURE");
                upiIncomingCollectResponse.setWibmoErrorMessage(payload.getGatewayResponseMessage());
                break;
            case "JPFL":
                upiIncomingCollectResponse.setWibmoRespCode(100);
                upiIncomingCollectResponse.setWibmoResDesc("FAILURE");
                upiIncomingCollectResponse.setWibmoErrorMessage(UpiGatewayStatusConstants.SEND_MONEY_JPFL.getStatusMsg());
                break;
            case "JPFP":
                upiIncomingCollectResponse.setWibmoRespCode(100);
                upiIncomingCollectResponse.setWibmoResDesc("FAILURE");
                upiIncomingCollectResponse.setWibmoErrorMessage(UpiGatewayStatusConstants.SEND_MONEY_JPFP.getStatusMsg());
                break;
            case "JPPL":
                upiIncomingCollectResponse.setWibmoRespCode(100);
                upiIncomingCollectResponse.setWibmoResDesc("FAILURE");
                upiIncomingCollectResponse.setWibmoErrorMessage(UpiGatewayStatusConstants.SEND_MONEY_JPPL.getStatusMsg());
                break;
            case "JPCL":
                upiIncomingCollectResponse.setWibmoRespCode(100);
                upiIncomingCollectResponse.setWibmoResDesc("FAILURE");
                upiIncomingCollectResponse.setWibmoErrorMessage(UpiGatewayStatusConstants.SEND_MONEY_JPCL.getStatusMsg());
                break;
            case "JPZ8":
                upiIncomingCollectResponse.setWibmoRespCode(100);
                upiIncomingCollectResponse.setWibmoResDesc("FAILURE");
                upiIncomingCollectResponse.setWibmoErrorMessage(UpiGatewayStatusConstants.SEND_MONEY_JPZ8.getStatusMsg());
                break;
            case "JPZU":
                upiIncomingCollectResponse.setWibmoRespCode(100);
                upiIncomingCollectResponse.setWibmoResDesc("FAILURE");
                upiIncomingCollectResponse.setWibmoErrorMessage(UpiGatewayStatusConstants.SEND_MONEY_JPZU.getStatusMsg());
                break;
            case "JPML":
                upiIncomingCollectResponse.setWibmoRespCode(100);
                upiIncomingCollectResponse.setWibmoResDesc("FAILURE");
                upiIncomingCollectResponse.setWibmoErrorMessage(UpiGatewayStatusConstants.SEND_MONEY_JPML.getStatusMsg());
                break;
            default:
                log.info("response code is not mention in juspay document");
                upiIncomingCollectResponse.setWibmoRespCode(100);
                upiIncomingCollectResponse.setWibmoResDesc("FAILURE");
                upiIncomingCollectResponse.setWibmoErrorMessage(payload.getGatewayResponseMessage());
        }

    }

    public JuspayIncomingCollectRequest map(UpiIncomingCollectRequest request, String accountNumber) {
        log.info("preparing JuspayIncomingCollectRequest from UpiIncomingCollectRequest for account number :: {}",accountNumber);
        JuspayIncomingCollectRequest req = new JuspayIncomingCollectRequest();
        VPADetails vpaDetails = vpaDetailsDAO.findByAccountNumber(Long.parseLong(accountNumber));
        VPALinkedAccount vpaLinkedAccount = vpaLinkedAccountDAO.findByAccountNumber(Long.parseLong(accountNumber));
        req.setMerchantCustomerId(String.valueOf(vpaDetails.getUpiCustomerId()));
        req.setDeviceFingerPrint(vpaDetails.getDeviceFingerprint());
        req.setMerchantRequestId(request.getTxnId());
        req.setBankAccountUniqueId(String.valueOf(vpaLinkedAccount.getBankAccUniqueId()));
        req.setPayeeVpa(request.getPayeeVpa());
        req.setPayerVpa(request.getPayerVpa());
        req.setAmount(request.getTxnAmount());
        req.setRequestType(request.getApprovalStatus());
        req.setBankAccountUniqueId(vpaLinkedAccount.getBankAccUniqueId());
        req.setCurrency(request.getCurrency()==null?"INR":request.getCurrency());
        req.setIsAmountBlocked(true);
        req.setCollectType("TRANSACTION");
        req.setUdfParameters(req.getUdfParameters() == null ? "{}" : req.getUdfParameters());

        return req;
    }

    private String impliedDecimalString(String decimalValue){
        try{
            decimalValue = decimalValue.replace(".", "");
            log.info("impliedDecimalString :: {}",decimalValue);
            return decimalValue;
        }catch (Exception ex){
            log.info("Exception ex :: {}",ex);
            return null;
        }
    }

}


