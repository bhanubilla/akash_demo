package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayDeregisterCustomerRequest {
    private String merchantCustomerId;
    private String udfParameters;
}
