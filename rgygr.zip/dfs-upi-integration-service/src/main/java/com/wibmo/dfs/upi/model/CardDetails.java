package com.wibmo.dfs.upi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CardDetails {
    private String customerId;
    private String name;
    private int walletId;
    private String mobile;
    private String cardNumber;
    private String cardExpiry;
}
