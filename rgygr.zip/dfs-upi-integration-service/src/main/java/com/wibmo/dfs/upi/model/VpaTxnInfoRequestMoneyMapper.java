package com.wibmo.dfs.upi.model;

import com.wibmo.dfs.upi.adapter.juspay.model.JuspayRequestMoneyResponse;
import com.wibmo.dfs.upi.constants.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Component
@Slf4j
public class VpaTxnInfoRequestMoneyMapper {
	public VpaTxnInfo map(JuspayRequestMoneyResponse juspayRequestMoneyResponse) {
		log.info("Mapping JuspayRequestMoney Response to VpaTxnInfo..");
		VpaTxnInfo response = new VpaTxnInfo();
		response.setMerchantCustomerId(juspayRequestMoneyResponse.getPayload().getMerchantCustomerId());
		response.setMerchantRequestId(juspayRequestMoneyResponse.getPayload().getMerchantRequestId());
		String mobileNumber = juspayRequestMoneyResponse.getPayload().getCustomerMobileNumber();
		response.setCustomerMobileNumber(mobileNumber.length()==12 ? mobileNumber.substring(2) : mobileNumber);
		response.setPayerVpa(juspayRequestMoneyResponse.getPayload().getPayerVpa());
		response.setPayeeMcc(juspayRequestMoneyResponse.getPayload().getPayeeMcc());
		response.setPayeeName(juspayRequestMoneyResponse.getPayload().getPayerName());
		response.setPayeeVpa(juspayRequestMoneyResponse.getPayload().getPayeeVpa());
		response.setRefUrl(juspayRequestMoneyResponse.getPayload().getRefUrl());
		response.setBankAccountUniqueId(juspayRequestMoneyResponse.getPayload().getBankAccountUniqueId());
		response.setBankCode(juspayRequestMoneyResponse.getPayload().getBankCode());
		response.setMaskedAccountNumber(juspayRequestMoneyResponse.getPayload().getMaskedAccountNumber());
		response.setAmount(Double.valueOf(juspayRequestMoneyResponse.getPayload().getAmount()));

		DateTimeFormatter formatDateTime = DateTimeFormatter.ISO_ZONED_DATE_TIME;
	    LocalDateTime localDateTime = LocalDateTime.from(formatDateTime.parse(juspayRequestMoneyResponse.getPayload().getTransactionTimestamp()));
	    Timestamp ts = Timestamp.valueOf(localDateTime);
	    response.setTransactionTimestamp(ts);
		
		response.setGatewayTxnId(juspayRequestMoneyResponse.getPayload().getGatewayTransactionId());
		response.setGatewayResponseStatus(juspayRequestMoneyResponse.getPayload().getGatewayResponseStatus());
		response.setGatewayReferenceId(juspayRequestMoneyResponse.getPayload().getGatewayReferenceId());
		response.setGatewayResponseCode(juspayRequestMoneyResponse.getPayload().getGatewayResponseCode());
		response.setGatewayResponseMessage(juspayRequestMoneyResponse.getPayload().getGatewayResponseMessage());
		response.setGatewayPayerResponseCode(juspayRequestMoneyResponse.getPayload().getGatewayPayerResponseCode());
		response.setGatewayPayeeResponseCode(juspayRequestMoneyResponse.getPayload().getGatewayPayeeResponseCode());
		response.setGatewayPayerReversalResponseCode(juspayRequestMoneyResponse.getPayload().getGatewayPayerReversalResponseCode());
		response.setGatewayPayeeReversalResponseCode(juspayRequestMoneyResponse.getPayload().getGatewayPayeeReversalResponseCode());
		if(juspayRequestMoneyResponse.getPayload().getGatewayResponseStatus().equals(Constants.SUCCESS) || juspayRequestMoneyResponse.getPayload().getGatewayResponseStatus().equals(Constants.DEEMED))
			response.setStatus(Constants.REQUEST_MONEY_PENDING);
		else
			response.setStatus(Constants.REQUEST_MONEY_FAILED);
		response.setMessage(juspayRequestMoneyResponse.getResponseMessage());
		return response;
	}
}
