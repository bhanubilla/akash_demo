package com.wibmo.dfs.upi.model.response;

import com.auth0.jwt.internal.com.fasterxml.jackson.annotation.JsonIgnore;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayRequestMoneyResponsePayload;

import com.wibmo.dfs.upi.entity.TrackingTxnStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class SendMoneyResponse extends JuspaySendMoneyResponseCommon{
	
	private String status;
    private String responseCode;
    private String responseMessage;
    @JsonIgnore
    private String customGatewayStatusCode;
	private Object trackingTxnStatus;
	private int wibmoRespCode;
	private String wibmoResDesc;
	private String wibmoErrorMessage;
}
