package com.wibmo.dfs.upi.exception;

public class UpiGenericException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public UpiGenericException(String message, Throwable cause){
	        super(message, cause);
	    }
	
	public UpiGenericException(String errorMessage){
        super(errorMessage);
    }
}
