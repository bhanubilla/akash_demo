package com.wibmo.dfs.upi.dao;

import com.wibmo.dfs.upi.adapter.juspay.model.JuspayRequestMoneyRequest;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspaySendMoneyRequest;
import com.wibmo.dfs.upi.model.VpaTxnInfo;

import java.util.List;

public interface VpaTxnDAO {
	int save(VpaTxnInfo vpaTxnInfo);
	int saveSendMoneyRequestDetails(JuspaySendMoneyRequest juspaySendMoneyRequest);
	long insertRequestMoneyDetails(JuspayRequestMoneyRequest juspayRequestMoneyRequest);
	int updateSuccessRespRequestMoneyDetails(VpaTxnInfo vpaTxnInfo);
	int updateFailRespRequestMoneyDetails(long id, String status);
	int updateViaIncomingMoneyToCustomerCsCallback(String gatewayTransactionId,String gatewayResponseStatus);
	VpaTxnInfo fetchById(int id);
	boolean updateVpaTxnInfo(VpaTxnInfo vpaTxnInfo);
	List<VpaTxnInfo> fetchPendingVpaTxnsByVPA(String vpa);
	public void updateVpaTxnInfoByTxnId(String gatewayStatus, String status, String gatewayTransactionId,String gatewayResponseMessage,String upiRequestId, long id);
	VpaTxnInfo fetchByGatewayTxnId(String id);
	void updateVpaTxnInfoById(VpaTxnInfo vpaTxnInfo);
}
