package com.wibmo.dfs.upi.dao;

import java.sql.Timestamp;

public interface VpaUnblockLogDao {


    int insertVpaUnblock(String accountNumber, String vpa, Timestamp blockedTs);
}
