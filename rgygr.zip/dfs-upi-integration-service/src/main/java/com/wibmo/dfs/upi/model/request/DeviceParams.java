package com.wibmo.dfs.upi.model.request;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DeviceParams {

	private String deviceId;
	private String manufacturer;
	private String model;
	private String version;
	private String os;
	private String ssid;

}
