package com.wibmo.dfs.upi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CheckUdirComplaintStatus{

    private String txnId;
    private String complaintRefNo;
    private String complaintType;
}
