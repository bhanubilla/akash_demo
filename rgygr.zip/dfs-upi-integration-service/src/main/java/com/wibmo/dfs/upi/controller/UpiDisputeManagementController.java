package com.wibmo.dfs.upi.controller;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.wibmo.dfs.upi.model.CheckUdirComplaintStatus;
import com.wibmo.dfs.upi.model.CheckUdirComplaints;
import com.wibmo.dfs.upi.model.request.RaiseUdirComplaintRequest;
import com.wibmo.dfs.upi.model.response.WibmoResponse;
import com.wibmo.dfs.upi.service.UpiDisputeManagementService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/upi/dispute-management")
@Slf4j
public class UpiDisputeManagementController {

    @Autowired
    private UpiDisputeManagementService upiDisputeManagementService;

    @JsonIgnoreProperties
    @PostMapping("/v1/complaint")
    public WibmoResponse complaint(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber, @RequestBody RaiseUdirComplaintRequest raiseUdirComplaintRequest){
        log.info("UDIR Raise Complaint");
        return upiDisputeManagementService.raiseComplaint(programId,accountNumber,raiseUdirComplaintRequest);
    }

    @JsonIgnoreProperties
    @PostMapping("/v1/complaint/status")
    public WibmoResponse status(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber,@RequestBody CheckUdirComplaintStatus checkUdirComplaintStatus){
        return upiDisputeManagementService.checkComplaint(programId,accountNumber,checkUdirComplaintStatus);
    }

    @JsonIgnoreProperties
    @PostMapping("/v1/complaints")
    public WibmoResponse complaints(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber, @RequestBody CheckUdirComplaints checkUdirComplaints){
        return upiDisputeManagementService.listComplaints(programId,accountNumber,checkUdirComplaints);
    }
}
