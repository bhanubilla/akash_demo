package com.wibmo.dfs.upi.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CBSRequest {
        private String accountIdentifier;
        private String amount;
        private String complaintUpiRequestId;
        private String currCycle;
        private String gatewayReferenceId;
        private String gatewayTransactionId;
        private String remarks;
        private String type;
        private Boolean isDirectCredit;
}
