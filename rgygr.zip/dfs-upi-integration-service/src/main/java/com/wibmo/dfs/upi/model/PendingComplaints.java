package com.wibmo.dfs.upi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PendingComplaints {

    private String payerVpa;
    private String payeeVpa;
    private String orgTxnStatus;
    private String merchantCustomerId;
    private String customerMobileNumber;
    private String originalUpiRequestId;
    private String upiRequestId;
    private String crn;
    private String orgTxnDate;
    private String complaintDate;
    private String status;
    private String remarks;
    private String reqAdjAmount;
    private String reqAdjCode;
    private String reqAdjFlag;
}
