package com.wibmo.dfs.upi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UpiDeregisteredCustInfo {
    private Long accountNumber;
    private String mobileNumber;
    private Long upiCustomerId;
    private String deviceId;
    private String ssid;
    private String deviceFingerprint;
    private String vpa;
    private String aliasVpa;
    private Long linkedAccountId;
    private String status;
    private boolean active;
    private String bankName;
    private String bankAccountNumber;
    private String bankIfsc;
    private String bankCode;
    private String type;
    private String bankAccUniqueId;
    private Long walletId;
}
