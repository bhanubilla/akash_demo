package com.wibmo.dfs.upi.model.response;

import com.wibmo.dfs.upi.model.BankAccounts;
import com.wibmo.dfs.upi.model.UserLinkedCardInfo;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
public class FetchAccountsResponse {
    private List<BankAccounts> accounts;
    private List<UserLinkedCardInfo> linkedCards;
    private List<FetchCardResponse> wallets;
    private Map<String, List<UserLinkedCardInfo>> listOfCards;
}
