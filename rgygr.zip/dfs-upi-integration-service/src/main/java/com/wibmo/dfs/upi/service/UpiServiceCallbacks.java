package com.wibmo.dfs.upi.service;

import com.wibmo.dfs.upi.model.response.JuspayCallbackResponse;
import com.wibmo.dfs.upi.model.response.WibmoResponse;

public interface UpiServiceCallbacks {
     JuspayCallbackResponse creditMoneyCBSCallback(String programId, String request);
    WibmoResponse incomingCollectRequestToCustomer(String programId, String request);
    WibmoResponse incomingMoneyToCustomerCsCallback(String programId, String request);
    WibmoResponse outgoingCollectRequestFromCustomerCallback(String programId, String request);
    String buildRequestPayload(int programId, String request);
}
