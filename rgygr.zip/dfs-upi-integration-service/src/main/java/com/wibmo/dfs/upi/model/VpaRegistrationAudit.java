package com.wibmo.dfs.upi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
//@AllArgsConstructor
public class VpaRegistrationAudit {
	private long id;
	private long accountNumber;
	private String mobileNumber;
	private String walletUrn;
	private long merchantCustomerId;
	private String smsToken;
	private String deviceFingerPrint;
	private String deviceId;
	private String ssid;
	private String vpa;
	private String status;


	
}
