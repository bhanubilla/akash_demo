package com.wibmo.dfs.upi.kafka.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class UpdtTxnDetails {

	private String txnStatus;
	private String originalTxnId;
	private String txnFlow;
	private String merCategory;
}
