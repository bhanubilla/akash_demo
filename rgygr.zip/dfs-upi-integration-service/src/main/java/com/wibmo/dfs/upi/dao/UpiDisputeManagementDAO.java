package com.wibmo.dfs.upi.dao;

import com.wibmo.dfs.upi.adapter.juspay.model.JuspayRaiseComplaintUdirPayload;
import com.wibmo.dfs.upi.entity.DisputeComplaints;
import com.wibmo.dfs.upi.model.CheckUdirComplaints;
import com.wibmo.dfs.upi.model.CheckUdirComplaintStatus;
import com.wibmo.dfs.upi.model.response.UdirComplaintStatusResponse;

import java.sql.Timestamp;
import java.util.List;

public interface UpiDisputeManagementDAO {

    int addComplaints(String accountNumber,JuspayRaiseComplaintUdirPayload juspayRaiseComplaintUdirPayload);
    DisputeComplaints fetchComplaintByTxnId(String txnId);
     Timestamp fetchInsertedTimestamp(String crn) ;

    DisputeComplaints fetchComplaintByGatewayComplaintId(String gatewayComplaintId);
}
