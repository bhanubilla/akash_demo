package com.wibmo.dfs.upi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CreditMoneyCBSResponse {

	private static final long serialVersionUID = 1L;
	private String cbsStatus;
	private String cbsResponseCode;
	private String cbsResponseMessage;
	private String amount;
	private String gatewayTransactionId;
	private String gatewayReferenceId;
	private String accountIdentifier;
	private String cbsReferenceId;
	private String updatedAt;
	private String remarks;

}
