package com.wibmo.dfs.upi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.junit.Ignore;

@NoArgsConstructor
@AllArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class RaiseComplaintCallback {
          private String  adjAmount;
          private String  adjFlag;
          private String  adjCode;
          private String  customerMobileNumber;
          private String  crn;
          private String  currCycle;
          private String  gatewayComplaintId;
          private String  gatewayReferenceId;
          private String  gatewayResponseCode;
          private String  gatewayResponseStatus;
          private String  gatewayResponseMessage;
          private String  merchantId;
          private String  merchantChannelId;
          private String  merchantCustomerId;
          private String  originalGatewayTransactionId;
          private String  orgSettRespCode;
          private String  originalTransactionTimestamp;
          private String  payeeVpa;
          private String  payerVpa;
          private String  remarks;
          private String  transactionAmount;
          private String  type;
          private String reqAdjCode;
          private String reqAdjFlag;
          private String ref;
          private String reqAdjAmount;
}
