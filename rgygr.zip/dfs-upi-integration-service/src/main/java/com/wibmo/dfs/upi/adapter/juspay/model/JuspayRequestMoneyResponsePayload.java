package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class JuspayRequestMoneyResponsePayload extends JuspayIncomingCollectPayload {
    private String merchantId;
    private String merchantChannelId;
    private String merchantCustomerId;
    private String merchantRequestId;
    private String customerMobileNumber;
    private String expiryTimestamp;
    private String payeeVpa;
    private String payeeMcc;
    private String payerVpa;
    private String payerName;
    private String gatewayPayerResponseCode;
    private String gatewayPayeeResponseCode;
    private String gatewayPayerReversalResponseCode;
    private String gatewayPayeeReversalResponseCode;
}
