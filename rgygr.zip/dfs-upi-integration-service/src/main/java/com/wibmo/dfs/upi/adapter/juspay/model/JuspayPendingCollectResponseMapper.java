package com.wibmo.dfs.upi.adapter.juspay.model;

import com.wibmo.dfs.upi.model.response.PendingCollectResponse;
import org.springframework.stereotype.Component;


@Component
public class JuspayPendingCollectResponseMapper {
	public PendingCollectResponse map() {
		return new PendingCollectResponse();
	}
}
