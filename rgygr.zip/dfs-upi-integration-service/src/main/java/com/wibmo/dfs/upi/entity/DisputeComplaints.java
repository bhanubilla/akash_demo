package com.wibmo.dfs.upi.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DisputeComplaints {
    private Long id;
    private String accountNumber;
    private String txnId;
    private String crn;
    private String gatewayComplaintId;
}
