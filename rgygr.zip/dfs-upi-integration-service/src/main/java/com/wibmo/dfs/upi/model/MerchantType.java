package com.wibmo.dfs.upi.model;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class MerchantType implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private Identifier identifier;
    private Name name;
    private Ownership ownership;
}

