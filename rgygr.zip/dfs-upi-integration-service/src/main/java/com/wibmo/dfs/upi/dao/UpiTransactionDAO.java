package com.wibmo.dfs.upi.dao;

import java.util.List;

import com.wibmo.dfs.upi.model.VPADetailsMini;

public interface UpiTransactionDAO {
	List<VPADetailsMini> findByMobileNumber(String programId, int accountNumber, String mobileNumber);
}
