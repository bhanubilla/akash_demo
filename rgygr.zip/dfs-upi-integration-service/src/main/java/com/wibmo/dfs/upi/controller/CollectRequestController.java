package com.wibmo.dfs.upi.controller;

import com.wibmo.dfs.upi.adapter.juspay.model.UpiIncomingCollectResponse;
import com.wibmo.dfs.upi.model.request.UpiIncomingCollectRequest;
import com.wibmo.dfs.upi.model.response.WibmoResponse;
import com.wibmo.dfs.upi.service.CollectRequestService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/collectrequest")

@Slf4j
public class CollectRequestController {
    @Autowired
    private CollectRequestService collectRequestService;

    @PostMapping("/v1/incoming")
    public WibmoResponse incomingCollectRequest(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber, @RequestBody UpiIncomingCollectRequest request) {
        log.info("incomingCollectRequest for account number :: {}, program id :: {}",accountNumber, programId);
        return collectRequestService.incomingCollectRequest(programId, accountNumber, request);
    }
}
