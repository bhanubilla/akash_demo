package com.wibmo.dfs.upi.model.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SmsTokenRequest {
	@ApiModelProperty(dataType="String", required=false)
	private String serviceProvider;
	private String udfParameters;
	
	
}
