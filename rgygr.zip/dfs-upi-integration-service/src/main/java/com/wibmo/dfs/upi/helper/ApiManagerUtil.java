package com.wibmo.dfs.upi.helper;

import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpHeaders;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.wibmo.dfs.upi.adapter.juspay.util.CommonUtil;
import com.wibmo.dfs.upi.constants.Constants;
import com.wibmo.dfs.upi.model.CustomerMiniProfile;
import com.wibmo.dfs.upi.model.response.WibmoResponse;

import javax.ws.rs.core.MediaType;

@Configuration
@Slf4j
public class ApiManagerUtil {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${resource.url.onboarding}")
    private String onBoardingUrl;

    @Autowired
    public DozerBeanMapper dozerBeanMapper;

    // fetch customer profile
    public CustomerMiniProfile fetchUserProfile(String programId, String userId, String mobileNo) {
        try {
            MultiValueMap<String, String> custHeader = populateCustomHeaders(userId, programId, mobileNo);
            WibmoResponse apiResponse = CommonUtil.invokeApi(restTemplate, HttpMethod.GET, onBoardingUrl, Constants.FETCH_CUST_MINI_PROFILE, custHeader);
            log.info("fetch customer profile api response: {}", apiResponse);
            if (null != apiResponse && apiResponse.getResCode() == 200) {
                return dozerBeanMapper.map(apiResponse.getData(), CustomerMiniProfile.class);
            }
        } catch (Exception e) {
            log.error("Exception in onboarding api :{}",e);
        }
        return null;
    }


    private MultiValueMap<String, String> populateCustomHeaders(String customerId, String programId, String mobileNo) {
        MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
        custHeader.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
        custHeader.add(Constants.X_PROGRAM_ID, programId);
        custHeader.add(Constants.X_ACCOUNT_NUMBER, customerId);
        custHeader.add(Constants.X_MOBILE_NUMBER, mobileNo);
        return custHeader;
    }
}
