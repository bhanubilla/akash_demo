package com.wibmo.dfs.upi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wibmo.dfs.upi.constants.ProgramParamConstants;
import com.wibmo.dfs.upi.dao.ProgramParamsDAO;

@Service
public class UpiServiceFactory {

		@Autowired
		private ProgramParamsDAO progParamDao;

		@Autowired
		private List<UpiServiceAdapter> upiServiceAdapterList;

		public UpiServiceAdapter getUpiService(String programId) {
			UpiServiceAdapter upiServiceVendor = null;
			String configuredUpiVendor = progParamDao.fetchParamValueByParamName(programId, ProgramParamConstants.UPI_VENDOR.toString());
			if (configuredUpiVendor != null) {
				upiServiceVendor = upiServiceAdapterList.stream()
						.filter(serviceVendor -> configuredUpiVendor.equals(serviceVendor.getVendorId(programId))).findAny().orElse(null);
			}
			return upiServiceVendor;

		}

}
