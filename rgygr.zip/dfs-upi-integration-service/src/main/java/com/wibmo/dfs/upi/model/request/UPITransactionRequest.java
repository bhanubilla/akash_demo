package com.wibmo.dfs.upi.model.request;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class UPITransactionRequest {
	
	private String deviceFingerprint;
	private String payerVpa;
	private String payeeVpa;
	private String payeeName;
	private long amount;
	private String upiRequestId;
	private String bankAccountUniqueId;
	private String remarks;
	private String currency;
	private String transacType;
	private boolean isAmountBlocked=true;
	private String refUrl;
	private String refCategory;
	private String mcc;
	private String transacationReference;
	private String udfParameters;
	private String originalTxnId;
}
