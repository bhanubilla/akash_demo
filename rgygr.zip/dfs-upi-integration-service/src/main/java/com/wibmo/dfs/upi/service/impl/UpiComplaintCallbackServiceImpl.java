package com.wibmo.dfs.upi.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.upi.adapter.juspay.util.CallbackRequestValidator;
import com.wibmo.dfs.upi.adapter.onboarding.DisputeManagementMSAdapter;
import com.wibmo.dfs.upi.constants.EventConstants;
import com.wibmo.dfs.upi.entity.DisputeComplaints;
import com.wibmo.dfs.upi.helper.ApiManagerUtil;
import com.wibmo.dfs.upi.model.*;
import com.wibmo.dfs.upi.model.response.WibmoResponse;
import com.wibmo.dfs.upi.service.UpiComplaintCallbackService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.wibmo.dfs.upi.dao.UpiDisputeManagementDAO;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class UpiComplaintCallbackServiceImpl implements UpiComplaintCallbackService {

    public static final String MAPPING_EXCEPTION = "Mapping Exception :{}";

    @Autowired
    private DisputeManagementMSAdapter disputeManagementMSAdapter;

    @Autowired
    ApiManagerUtil apiManagerUtil;

    @Autowired
    UpiDisputeManagementDAO upiDisputeManagementDAO;

    @Value("${resource.url.notification}")
    private String notificationUrl;

    @Autowired
    private CallbackRequestValidator requestValidator;

    @Autowired
    RestTemplate restTemplate;

    @Value("${resource.url.onboarding}")
    private String onboardingUrl;

    @Override
    public WibmoResponse complaintRaiseCallback(String programId, String request) {
    log.info("complaintRaiseCallback::start :: {}",request);
        RaiseComplaintCallback raiseComplaintCallback = null;
        try {
            WibmoResponse validate = requestValidator.validateComplaintRaised(request);
            if(null != validate)
            {
                log.info("Bad request from vendor");
                return validate;
            }
            raiseComplaintCallback = new ObjectMapper().readValue(request, RaiseComplaintCallback.class);
        } catch (Exception e) {
            log.error(MAPPING_EXCEPTION,e);
        }
        if(null != raiseComplaintCallback){
            // API call to update status in UDIR Audit MS
            UpdateComplaintStatus status = new UpdateComplaintStatus();
            status.setComplaintNumber(raiseComplaintCallback.getGatewayComplaintId());
            status.setStatus(raiseComplaintCallback.getGatewayResponseStatus());
            disputeManagementMSAdapter.updateComplaintStatus(programId,status);
        }
        return new WibmoResponse(200, "SUCCESS");
    }

    @Override
    public WibmoResponse complaintResolvedCallback(String programId, String request) {
        log.info("complaintResolvedCallback::start");
        ComplaintResolvedCallback complaintResolvedCallback = null;
        try {
            WibmoResponse validate = requestValidator.validateComplaintResolved(request);
            if(null != validate)
            {
                log.info("Bad request from vendor");
                return validate;
            }
            complaintResolvedCallback = new ObjectMapper().readValue(request, ComplaintResolvedCallback.class);
        } catch (Exception e) {
            log.error(MAPPING_EXCEPTION,e);
        }
        if(null != complaintResolvedCallback){
            // API call to update status in UDIR Audit MS
            UpdateComplaintStatus status = new UpdateComplaintStatus();
            status.setComplaintNumber(complaintResolvedCallback.getGatewayComplaintId());
            status.setStatus(complaintResolvedCallback.getGatewayResponseStatus());
            disputeManagementMSAdapter.updateComplaintStatus(programId,status);
            DisputeComplaints disputeComplaints = upiDisputeManagementDAO.fetchComplaintByGatewayComplaintId(complaintResolvedCallback.getGatewayComplaintId());
            if (disputeComplaints != null) {
                CustomerMiniProfile payeeMinProfile = apiManagerUtil.fetchUserProfile(programId, disputeComplaints.getAccountNumber(), null);
                Map<String, String> placeHolder = new HashMap<>();
                placeHolder.put("AMOUNT", complaintResolvedCallback.getReqAdjAmount());
                placeHolder.put("VPA", complaintResolvedCallback.getPayerVpa());
                placeHolder.put("CRN", complaintResolvedCallback.getCrn());
                if (payeeMinProfile != null) {
                    sendPushNotification(programId, payeeMinProfile, placeHolder);
                } else {
                    log.info("User profile not found");
                }
            } else {
                log.info("Complaint is not present");
            }
        }
        return new WibmoResponse(200, "SUCCESS");
    }

    public void sendPushNotification(String programId,CustomerMiniProfile payeeMinProfile, Map<String, String> placeHolder){
        UserProfileResponse userProfileResponse = null;
        log.debug(" UpiComplaintCallbackServiceImpl : sendPushNotification : programId :{} , accountNumber : {}, payerName :: {}", programId, payeeMinProfile.getCustomerId(),payeeMinProfile.getFirstName());
        try{
            MultiValueMap<String, String> userProfileDetailsHeader = new LinkedMultiValueMap<>();
            userProfileDetailsHeader.add("Content-Type", String.valueOf(org.springframework.http.MediaType.APPLICATION_JSON));
            userProfileDetailsHeader.add("X-PROGRAM-ID", programId);
            userProfileDetailsHeader.add("X-ACCOUNT-NUMBER", payeeMinProfile.getCustomerId());
            HttpEntity<String> entity = new HttpEntity<>(userProfileDetailsHeader);
            ResponseEntity<UserProfileResponse> result = this.restTemplate.exchange(onboardingUrl + "/onboarding/userProfile/fetchUserProfileDetails/v1", HttpMethod.GET, entity, UserProfileResponse.class);
            userProfileResponse = result.getBody();
            if ( userProfileResponse != null) {
                AlertRequest alertRequest = new AlertRequest();
                alertRequest.setEventId(EventConstants.UPI_RAISED_COMPLAINT_RESOLVED);
                alertRequest.setFcmToken(userProfileResponse.getFcmId());
                alertRequest.setAccountNumber(Long.parseLong(payeeMinProfile.getCustomerId()));
                alertRequest.setDeviceId(userProfileResponse.getDeviceId());
                alertRequest.setWhatsappEnabled(false);
                alertRequest.setMobileNumber(payeeMinProfile.getMobileNo());
                alertRequest.setPlaceHolders(placeHolder);
                callToNotificationSendAlert(programId, alertRequest);
            }
        }
        catch (Exception ex) {
            log.error("Issue while fetching userProfileDetails " + ex.getMessage());
        }
    }




    private void callToNotificationSendAlert(String programId, AlertRequest alertRequest) {
        try {
            MultiValueMap<String, String> customNotificationHeader = new LinkedMultiValueMap<>();
            customNotificationHeader.add("Content-Type", String.valueOf(org.springframework.http.MediaType.APPLICATION_JSON));
            customNotificationHeader.add("X-PROGRAM-ID", programId);
            HttpEntity<Object> notificationEntity = new HttpEntity<>(alertRequest, customNotificationHeader);
            ResponseEntity<WibmoResponse> resp = this.restTemplate.exchange(notificationUrl + "/notification-service/notification/sendAlert", HttpMethod.POST, notificationEntity, WibmoResponse.class);
            WibmoResponse wibmoResponse = resp.getBody();
            if (resp.getStatusCodeValue() != 200 && wibmoResponse!=null) {
                log.debug("Notification sending failed: {}", (wibmoResponse).getErrorMessage());
            }
        } catch (Exception var6) {
            log.error("Issue while sending notification " + var6.getMessage());
        }
    }

    @Override
    public WibmoResponse cbsComplaintStatusUpdateCallback(String programId, String request) {
        log.info("cbsComplaintStatusUpdateCallback::start");
        log.info("complaintResolvedCallback::start");
        CbsComplaintStatusUpdateCallback cbsComplaintStatusUpdateCallback = null;
        try {
            WibmoResponse validate = requestValidator.validateCbsComplaintStatusUpdate(request);
            if(null != validate)
            {
                log.info("Bad request from vendor");
                return validate;
            }
            cbsComplaintStatusUpdateCallback = new ObjectMapper().readValue(request, CbsComplaintStatusUpdateCallback.class);
        } catch (Exception e) {
            log.error(MAPPING_EXCEPTION,e);
        }
        if(null != cbsComplaintStatusUpdateCallback){
            // API call to update status in UDIR Audit MS
            UpdateComplaintStatus status = new UpdateComplaintStatus();
            status.setComplaintNumber(cbsComplaintStatusUpdateCallback.getGatewayComplaintId());
            status.setStatus(cbsComplaintStatusUpdateCallback.getGatewayResponseStatus());
            disputeManagementMSAdapter.updateComplaintStatus(programId,status);
        }
        return new WibmoResponse(200, "SUCCEESS");
    }
}
