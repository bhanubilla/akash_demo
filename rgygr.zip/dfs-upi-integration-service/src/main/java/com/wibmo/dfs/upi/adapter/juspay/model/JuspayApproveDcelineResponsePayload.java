package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class JuspayApproveDcelineResponsePayload implements Serializable {
    private String status;
    private String responseCode;
    private String merchantId;
    private String merchantChannelId;
    private String merchantCustomerId;
    private String customerMobileNumber;
    private String udfParameters;


}
