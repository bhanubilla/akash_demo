package com.wibmo.dfs.upi.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.wibmo.dfs.upi.constants.UpiStatusConstants;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
@ApiModel(description="Onboarding service Response Model")
public class WibmoResponse implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(notes ="Response Code",name="resCode")
	private int resCode;
	@ApiModelProperty(notes ="Response message",name="resDesc")
	private String resDesc;
	@ApiModelProperty(notes ="Error message",name="resDesc")
	private String errorMessage;
	@ApiModelProperty(notes ="Object",name="data")
	private transient Object data;

	public WibmoResponse(int resCode, String resDesc, Object data) {
		super();
		this.resCode = resCode;
		this.resDesc = resDesc;
		this.data = data;
	}

	public WibmoResponse(int resCode, String resDesc) {
		super();
		this.resCode = resCode;
		this.resDesc = resDesc;
	}

	public WibmoResponse(UpiStatusConstants status, String errorMessage) {
		super();
		this.resCode = status.getStatusCode();
		this.resDesc = status.getStatusMsg();
		this.errorMessage = errorMessage;
	}

	public WibmoResponse(UpiStatusConstants status, Object data) {
		super();
		this.resCode = status.getStatusCode();
		this.resDesc = status.getStatusMsg();
		this.data = data;
	}

	public WibmoResponse(UpiStatusConstants status) {
		super();
		this.resCode = status.getStatusCode();
		this.resDesc = status.getStatusMsg();
	}


}
