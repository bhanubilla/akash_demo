package com.wibmo.dfs.upi.model;

import org.springframework.stereotype.Component;

import com.wibmo.dfs.upi.adapter.juspay.model.JuspayVpaValidResponse;
import com.wibmo.dfs.upi.model.response.VpaValidResponse;

@Component
public class VpaResponseMapper {
	public VpaValidResponse map(JuspayVpaValidResponse juspayVpaValidResponse) {
		VpaValidResponse vpaValidResponse = new VpaValidResponse();
		vpaValidResponse.setVpaValid(juspayVpaValidResponse.getPayload().isAvailable());
		vpaValidResponse.setVpaSuggestions(juspayVpaValidResponse.getPayload().getVpaSuggestions());
		return vpaValidResponse;

	}

}
