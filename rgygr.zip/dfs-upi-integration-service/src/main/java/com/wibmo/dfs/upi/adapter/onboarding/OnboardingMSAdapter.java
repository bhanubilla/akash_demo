package com.wibmo.dfs.upi.adapter.onboarding;

import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.wibmo.dfs.upi.model.response.UserProfileResponse;
import com.wibmo.dfs.upi.model.response.WibmoResponse;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class OnboardingMSAdapter {
    public static final String X_PROGRAM_ID = "X-PROGRAM-ID";
    public static final String X_ACCOUNT_NUMBER = "X-ACCOUNT-NUMBER";
    public static final String X_MOBILE_NUMBER = "X-MOBILE-NUMBER";
    public static final String FETCH_USER_PROFILE_DETAILS_API_V1 = "/onboarding/userProfile/fetchDetails/v1";
    @Autowired
    private RestTemplate restTemplate;
    
    @Autowired
    public DozerBeanMapper dozerBeanMapper;

    @Value("${resource.url.onboarding}")
    private String onboardingServiceUrlValue;

    public UserProfileResponse fetchUserProfile(String programId, String accountNumber){
        log.info("START OnboardingAdapter:fetchUserProfile===");
        try {
            String url = onboardingServiceUrlValue + FETCH_USER_PROFILE_DETAILS_API_V1;
            MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
            custHeader.add(X_PROGRAM_ID, programId);
            custHeader.add(X_ACCOUNT_NUMBER, accountNumber);
            HttpEntity<Object> entity = new HttpEntity<>(custHeader);
            ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(url, HttpMethod.GET, entity,
    				WibmoResponse.class);
            WibmoResponse apiResponse = responseEntity.getBody();
            if (null != apiResponse && apiResponse.getResCode() == 200) {
                return dozerBeanMapper.map(apiResponse.getData(), UserProfileResponse.class);
            }
        }catch (Exception ex){
            log.error("Exception while fetching user profiles :: ",ex);
        }
        log.info("END OnboardingAdapter:fetchUserProfile===");
        return null;
    }
    
}
