package com.wibmo.dfs.upi.model.response;

import com.wibmo.dfs.upi.adapter.juspay.model.JuspayUdirComplaintStatusResponse;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UdirComplaintStatusResponse {

    private String status;
    private String responseMessage;
    private String responseCode;
    private JuspayUdirComplaintStatusResponse payload;
    private String udfParameters;
}
