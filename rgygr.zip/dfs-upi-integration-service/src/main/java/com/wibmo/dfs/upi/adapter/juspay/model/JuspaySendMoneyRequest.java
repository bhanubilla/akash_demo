package com.wibmo.dfs.upi.adapter.juspay.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspaySendMoneyRequest {
	 private String merchantCustomerId;
	 private String deviceFingerPrint;
	 private String merchantRequestId;
	 private String payerVpa;
	 private String payeeVpa;
	 private String payeeName;
	 private String amount;
	 private String upiRequestId;
	 private String bankAccountUniqueId;
	 private String remarks;
	 private String currency;
	 private String transactionType;
	 @JsonProperty(value="isAmountBlocked") 
	 private boolean isAmountBlocked;
	 private String transactionReference;
	 private String refUrl;
	 private String refCategory;
	 private String mcc;
	 private String udfParameters;

}
