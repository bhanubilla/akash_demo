package com.wibmo.dfs.upi.config;

import org.dozer.DozerBeanMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 
 * @author meriyala.raghavendra
 *
 */
@Configuration
public class BeanConfig {

	/**
	 * Create singleton DozerBeanMapper bean for mapping object to object.
	 * 
	 * @return
	 */
	@Bean
	public DozerBeanMapper dozerBeanMapper() {
		return new DozerBeanMapper();
	}
}
