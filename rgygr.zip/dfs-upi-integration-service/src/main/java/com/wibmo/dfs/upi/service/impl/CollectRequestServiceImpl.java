package com.wibmo.dfs.upi.service.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.platform.service.notification.NotificationServiceCall;
import com.wibmo.dfs.platform.service.notification.model.NotificationRequest;
import com.wibmo.dfs.upi.adapter.juspay.model.UpiIncomingCollectResponse;
import com.wibmo.dfs.upi.adapter.juspay.util.CommonUtil;
import com.wibmo.dfs.upi.constants.*;
import com.wibmo.dfs.upi.dao.*;
import com.wibmo.dfs.upi.helper.ApiManagerUtil;
import com.wibmo.dfs.upi.helper.CommonHelper;
import com.wibmo.dfs.upi.helper.PushNotificationHelper;
import com.wibmo.dfs.upi.kafka.KafkaProducer;
import com.wibmo.dfs.upi.kafka.model.CreditMoneyTxnDetailsRequest;
import com.wibmo.dfs.upi.kafka.model.CreditStatusTxnDetailsRequest;
import com.wibmo.dfs.upi.kafka.model.TxnDetails;
import com.wibmo.dfs.upi.kafka.model.UpdtTxnDetails;
import com.wibmo.dfs.upi.model.*;
import com.wibmo.dfs.upi.model.request.BlockedVpaRequest;
import com.wibmo.dfs.upi.model.request.UpiIncomingCollectRequest;
import com.wibmo.dfs.upi.model.request.VerifyVpaRequest;
import com.wibmo.dfs.upi.model.response.LoadUnloadResponse;
import com.wibmo.dfs.upi.model.response.VerifyVpaResponse;
import com.wibmo.dfs.upi.model.response.WibmoResponse;
import com.wibmo.dfs.upi.service.CollectRequestService;
import com.wibmo.dfs.upi.service.UpiService;
import com.wibmo.dfs.upi.service.UpiServiceAdapter;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.ws.rs.core.MediaType;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class CollectRequestServiceImpl implements CollectRequestService {

    public static final String DECLINE = "DECLINE";
    public static final String ACCEPT = "ACCEPT";
    public static final String BLOCK = "BLOCK";
    public static final String FAILURE = "Failure";
    public static final String BLOCKED = "BLOCKED";
    public static final String X_PROGRAM_ID = "X-PROGRAM-ID";
    public static final String X_ACCOUNT_NUMBER = "X-ACCOUNT-NUMBER";
    @Autowired
    private UpiServiceAdapter upiServiceAdapter;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private VpaTxnDAO vpaTxnDAO;

    @Autowired
    private UpiCollectRequestDAO upiCollectRequestDAO;

    @Value("${resource.url.wallet}")
    private String walletUrl;

    @Value("${resource.url.orchestrate}")
    private String orchestrateUrl;

    @Value("${resource.url.notification}")
    private String notificationUrl;

    @Value("${resource.url.onboarding}")
    private String onboardingUrl;
    
    @Autowired
   	private ApiManagerUtil apiManagerUtil;

    @Autowired
    private UpiService upiService;

    @Autowired
    private BlockedVpaDao blockedVpaDao;

    @Autowired
    private VPADetailsDAO vpaDetailsDAO;

    @Autowired
    private ProgramParamsDAO programParamsDAO;

    @Autowired
    private KafkaProducer kafkaProducer;

    @Autowired
    private PushNotificationHelper helper;

    private static final String PAYER_VPA_VERIFICATION_FAILED="Payee VPA verification failed";

    @Override
    public WibmoResponse incomingCollectRequest(String programId, String accountNumber, UpiIncomingCollectRequest upiIncomingCollectRequest) {
        log.info("============ incomingCollectRequest started===========");
        WibmoResponse response = new WibmoResponse();
        try {
            switch (upiIncomingCollectRequest.getApprovalStatus().toUpperCase()) {
                case ACCEPT:
                    log.info("user accepted so mutating upi request as per user action");
                    upiIncomingCollectRequest.setApprovalStatus(Constants.APPROVE);
                    response = handleAccept(upiIncomingCollectRequest, programId, accountNumber);
                    break;
                case DECLINE:
                    log.info("user declined so mutating upi request as per user action");
                    upiIncomingCollectRequest.setApprovalStatus(Constants.DECLINE);
                    //update call
                    updateStatus(programId, upiIncomingCollectRequest.getTxnId(), Constants.REQUEST_MONEY_DECLINED, DECLINE);
                    response = handleDecline(upiIncomingCollectRequest, programId, accountNumber);
                    break;
                case BLOCK:
                    log.info("user block so mutating upi request as per user action");
                    //Update in database like user blocked
                    BlockedVpaRequest blockVpaRequst = new BlockedVpaRequest();
                    blockVpaRequst.setVpa(upiIncomingCollectRequest.getPayeeVpa());
                    String blockedUserName = getVPAUserName(upiIncomingCollectRequest.getPayeeVpa(), programId);
                    if(blockedUserName == null)
                        return new WibmoResponse(UpiStatusConstants.INVALID_PAYEE_VPA, PAYER_VPA_VERIFICATION_FAILED);
                    blockedVpaDao.insertBlockedVpaAccountNumber(accountNumber, blockVpaRequst, blockedUserName);
                    upiIncomingCollectRequest.setApprovalStatus(DECLINE);
                    //update call
                    updateStatus(programId, upiIncomingCollectRequest.getTxnId(), Constants.REQUEST_MONEY_BLOCKED, BLOCKED);
                    response = handleDecline(upiIncomingCollectRequest, programId, accountNumber);
                    break;
                default:
                    log.info("Invalid user action type :: {}", upiIncomingCollectRequest.getApprovalStatus().toUpperCase());
                    response.setResCode(100);
                    response.setResDesc("Txn Mode is not valid");
                    break;
            }
        }catch (Exception ex){
            log.error("Exception while handling accept/ decline/ block request money",ex);
            response.setResCode(100);
            response.setResDesc(FAILURE);
        }
        return response;
    }

    public String getVPAUserName(String vpa, String programId){
        VerifyVpaRequest verifyPayeeVpaRequest = new VerifyVpaRequest();
        verifyPayeeVpaRequest.setVpa(vpa);
        WibmoResponse verifyVpaResponse = upiService.verifyVpa(programId, verifyPayeeVpaRequest);
        if(verifyVpaResponse.getResCode()!= UpiGatewayStatusConstants.VERIFY_VPA_00.getStatusCode()){
            log.info("verifyVpaResponse.getResCode() :: {}",verifyVpaResponse.getResCode());
            return null;
        }
        VerifyVpaResponse response = VerifyVpaResponse.class.cast(verifyVpaResponse.getData());
        log.info("name ::{} for VPA :: {} ",response.getName(),vpa);
        return response.getName();
    }

    private WibmoResponse handleAccept(UpiIncomingCollectRequest upiIncomingCollectRequest,String programId, String accountNumber){
        WibmoResponse response = new WibmoResponse();
        String payeeVPAName = getVPAUserName(upiIncomingCollectRequest.getPayeeVpa(),programId);
        if(payeeVPAName == null)
            return new WibmoResponse(UpiStatusConstants.INVALID_PAYEE_VPA, PAYER_VPA_VERIFICATION_FAILED);
        String payerVPAName = getVPAUserName(upiIncomingCollectRequest.getPayerVpa(),programId);
        if(payerVPAName == null)
            return new WibmoResponse(UpiStatusConstants.INVALID_PAYER_VPA, PAYER_VPA_VERIFICATION_FAILED);
        log.info("VPA Validations are passed..");
        Runnable txnTrackingPayInit = () -> kafkaProducer.publishUpiTxnTracking(upiIncomingCollectRequest.getTxnId(),TxnTrackingConstants.PAYMENT_INITIATION_SUCCESS);
        new Thread(txnTrackingPayInit).start();
        //unload funds
        WibmoResponse fundsUnloadResp = unloadFunds(upiIncomingCollectRequest,programId,accountNumber);
        if(fundsUnloadResp.getResCode() != 200) {
            log.info("Funds are unloaded failed...");
            Runnable txnTrackingMbf = () -> kafkaProducer.publishUpiTxnTracking(upiIncomingCollectRequest.getTxnId(), TxnTrackingConstants.MONEY_DEBIT_FAILURE);
            new Thread(txnTrackingMbf).start();
            return fundsUnloadResp;
        }
        if(fundsUnloadResp.getResCode() == 200){
            Runnable txnDebutSuccessStatus = () -> kafkaProducer.publishUpiTxnTracking(upiIncomingCollectRequest.getTxnId(), TxnTrackingConstants.MONEY_DEBIT_SUCCESS);
            new Thread(txnDebutSuccessStatus).start();
            log.info("Funds are unloaded successfully... :: {}",fundsUnloadResp.getData());
            try {
                ObjectMapper objectMapper = new ObjectMapper();
                LoadUnloadResponse unloadResponse = objectMapper.convertValue(fundsUnloadResp.getData(), new TypeReference<LoadUnloadResponse>() {
                });
                log.info("unloadResponse :: {}",unloadResponse);
            }catch (Exception ex){
                Runnable txnTrackingMbf = () ->kafkaProducer.publishUpiTxnTracking(upiIncomingCollectRequest.getTxnId(), TxnTrackingConstants.MONEY_DEBIT_FAILURE);
                new Thread(txnTrackingMbf).start();
                log.error("Exception :: {}",ex);
            }
        }
        upiIncomingCollectRequest.setPayeeName(payeeVPAName);
        upiIncomingCollectRequest.setPayerName(payerVPAName);
        UpiIncomingCollectResponse acceptUpiresponse = upiServiceAdapter.incomingRequest(programId, accountNumber, upiIncomingCollectRequest);
            //in case of failure load funds
        if(acceptUpiresponse.getWibmoRespCode() != 200) {
            log.info("request accept is failed");
            response.setResCode(acceptUpiresponse.getWibmoRespCode());
            response.setResDesc(acceptUpiresponse.getWibmoResDesc());
            response.setErrorMessage(acceptUpiresponse.getWibmoErrorMessage());
            //update call in upi repository
            updateStatus(programId, upiIncomingCollectRequest.getTxnId(), Constants.FAILED, Constants.FAILED);
            // insert into txn history
            txnHistoryDataPopulation(upiIncomingCollectRequest, accountNumber, programId,acceptUpiresponse);
            log.info("trying to refund amount");
            loadFunds(upiIncomingCollectRequest, programId, accountNumber);
        }else {
            response.setResCode(acceptUpiresponse.getWibmoRespCode());
            response.setResDesc(acceptUpiresponse.getWibmoResDesc());
            response.setData(acceptUpiresponse);
            //update call
            log.info("update status as accepted ");
            updateStatus(programId, upiIncomingCollectRequest.getTxnId(), Constants.APPROVE, Constants.APPROVE);

            // insert into txn history
            txnHistoryDataPopulation(upiIncomingCollectRequest, accountNumber, programId,acceptUpiresponse);
            //Sending push notification to payee(Payee account and payer name)
            VPADetails vpaDetails = vpaDetailsDAO.findByVpa(upiIncomingCollectRequest.getPayeeVpa());
            String agentName = programParamsDAO.fetchParamValueByParamName(programId, ProgramParamConstants.AGENT_NAME.getValue());
            String vpaAddress = programParamsDAO.fetchParamValueByParamName(programId, ProgramParamConstants.VPA_ADDRESS_PAYU.name());
            if (CommonHelper.checkOnUs(upiIncomingCollectRequest.getPayeeVpa(), agentName, vpaAddress)) {
                helper.sendPushNotification(programId, vpaDetails.getAccountNumber().toString(), upiIncomingCollectRequest.getTxnAmount(), upiIncomingCollectRequest.getPayerName(), Constants.APPROVED, Constants.RM_ACCEPT_EVENT_ID, buildPushNotificationData(programId, upiIncomingCollectRequest));
                
                //send notification alert to payer saying funds have been transferred from his account
                log.info("sending notification alert to payer saying funds have been transferred from his account to payee");
                CustomerMiniProfile payeeMinProfile = apiManagerUtil.fetchUserProfile(programId, accountNumber, null);
                log.info("payerMinProfile : {}", payeeMinProfile);
                Map<String, String> placeHolder = new HashMap<>();
    			placeHolder.put("PAYER", payeeMinProfile.getFirstName());
                placeHolder.put("PAYEE", getNameFromUpiIncomingReq(upiIncomingCollectRequest));
    			placeHolder.put("CURRENCY", Constants.CURRENCY_IND);
    			placeHolder.put("AMOUNT", CommonUtil.decimalFormat(Long.valueOf(upiIncomingCollectRequest.getTxnAmount())));
                NotificationRequest aRequest = NotificationRequest.builder()
        		        .mobileNumber(payeeMinProfile.getMobileNo())
        		        .programId(Integer.valueOf(programId))
        		        .eventId(Integer.valueOf(Constants.RM_PAYER_ALERT_EVENT_ID))
        		        .emailId(payeeMinProfile.getEmailId())
        		        .whatsappEnabled(false)
        		        .placeHolders(placeHolder).build();
        		NotificationServiceCall notificationServiceCall = new NotificationServiceCall();
        		notificationServiceCall.send(aRequest, notificationUrl);
            }
        }
        return response;
    }
    private String getNameFromUpiIncomingReq(UpiIncomingCollectRequest upiIncomingCollectRequest){
        if(upiIncomingCollectRequest.getPayeeName()!=null) {
            return upiIncomingCollectRequest.getPayeeName();
        } else {
            return upiIncomingCollectRequest.getPayeeVpa();
        }
    }

    private void txnHistoryDataPopulation(UpiIncomingCollectRequest upiIncomingCollectRequest, String accountNumber, String programId,UpiIncomingCollectResponse upiResponse) {
        log.info("txnHistoryDataPopulation : upiIncomingCollectRequest :{} accountNumber :{} programId :{}", upiIncomingCollectRequest, accountNumber, programId);
        StringBuilder txnDesc = new StringBuilder();
        CreditMoneyTxnDetailsRequest cm = new CreditMoneyTxnDetailsRequest();
        cm.setSourceAccount(upiIncomingCollectRequest.getPayerVpa());
        cm.setDestAccount(upiIncomingCollectRequest.getPayeeVpa());
        cm.setCustomerId(accountNumber + "");
        cm.setOriginalTxnId(upiIncomingCollectRequest.getTxnId());
        cm.setTxnCategory("RMD");
        if(Constants.DECLINE.equalsIgnoreCase(upiIncomingCollectRequest.getApprovalStatus())){
            log.info("It's a declined txn...");
            cm.setTxnStatus("D");
            cm.setTxnDesc(Constants.DECLINE);
            cm.setMerCategory("Request Declined");
        } else {
            if(upiResponse.getWibmoRespCode()==200) {
                cm.setTxnStatus("S");
                cm.setMerCategory("Request Accepted");
            }
            else{
                cm.setTxnStatus("F");
                cm.setMerCategory("Request Expired");
            }
            txnDesc.append(Constants.SENT).append(Constants.RS_SYMBOL).append(CommonUtil.decimalFormat(Long.parseLong(upiIncomingCollectRequest.getTxnAmount()))).append(Constants.TO).append(upiIncomingCollectRequest.getPayeeName());
            log.info("txnDesc.toString() : {} : upiIncomingCollectRequest.getPayerName() {} ",  txnDesc.toString(), upiIncomingCollectRequest.getPayerName());
            cm.setTxnDesc(txnDesc.toString());
        }
        cm.setTxnShortDesc(upiIncomingCollectRequest.getPayeeName());
        cm.setTxnAmount(Long.parseLong(upiIncomingCollectRequest.getTxnAmount()));
        log.info("handleAccept : txnHistoryDataPopulation : txn short desc : {} txn_desc :{}", cm.getTxnShortDesc(), cm.getTxnDesc());
        cm.setTxnType("RM");
        cm.setPaymentMode("RW");
        cm.setTxnDate(new Timestamp(System.currentTimeMillis()));
        cm.setTxnFlow("O");

        TxnDetails txnDetails = new TxnDetails();
        txnDetails.setProgramId(programId);
        txnDetails.setTxnType(Constants.CREDIT_MONEY_CBS_OFFUS);
        txnDetails.setData(cm);
        if (Constants.APPROVE.equalsIgnoreCase(upiIncomingCollectRequest.getApprovalStatus())){
            log.info("Approved hence updating data...");
            Runnable updatePayerHistoryDetails = () -> kafkaProducer.publishUpiTxn(txnDetails);
            new Thread(updatePayerHistoryDetails).start();
        }
        String agentName = programParamsDAO.fetchParamValueByParamName(programId, Constants.AGENT_NAME);
        String vpaAddress = programParamsDAO.fetchParamValueByParamName(programId, Constants.VPA_ADDRESS_PAYU);
        boolean isItCitrusPayee = (upiIncomingCollectRequest.getPayeeVpa().contains(agentName) || upiIncomingCollectRequest.getPayeeVpa().contains("bankezy")) && upiIncomingCollectRequest.getPayeeVpa().contains(vpaAddress);
        if (Constants.DECLINE.equalsIgnoreCase(upiIncomingCollectRequest.getApprovalStatus()) && isItCitrusPayee) {
            log.info("payee belongs to citrus .. so updating decline status...");
            CreditStatusTxnDetailsRequest cs = new CreditStatusTxnDetailsRequest();
            //Original txn_id already set so we are not keeping here
            cs.setTxnCategory("RMC");
            cs.setTxnFlow("I");
            cs.setTxnStatus("D");
            cs.setOriginalTxnId(upiIncomingCollectRequest.getTxnId());
            txnDesc.setLength(0);//clearing existing data
            txnDesc.append(Constants.DECLINE).append(" "+Constants.RS_SYMBOL).append(CommonUtil.decimalFormat(Long.parseLong(upiIncomingCollectRequest.getTxnAmount()))).append(Constants.BY).append(upiIncomingCollectRequest.getPayerName());
            cs.setTxnDesc(txnDesc.toString());
            cs.setMerCategory("Request Declined");
            log.info(" txn desc creditMoneyCBSCallback : {} ", cs.getTxnDesc());
            cs.setTxnShortDesc(upiIncomingCollectRequest.getPayerName());
            log.info("cs :: {}",cs);
            txnDetails.setProgramId(programId);
            txnDetails.setTxnType(Constants.CREDIT_MONEY_CBS_ONUS);
            txnDetails.setData(cs);
            log.info("updating details in txnHistory for payee {}",txnDetails);
            Runnable payeeRunnable = () -> kafkaProducer.publishUpiTxn(txnDetails);
            new Thread(payeeRunnable).start();

        }else if(Constants.APPROVE.equalsIgnoreCase(upiIncomingCollectRequest.getApprovalStatus()) && isItCitrusPayee){
            log.info("payer belongs to citrus .. so updating failed status...");
            TxnDetails txnDetls = new TxnDetails();
            txnDetls.setTxnType("TXN_UPDATE");
            txnDetls.setProgramId(programId);
            UpdtTxnDetails updtTxnDetails = new UpdtTxnDetails();
            updtTxnDetails.setOriginalTxnId(upiIncomingCollectRequest.getTxnId());
            updtTxnDetails.setTxnStatus("S");
            updtTxnDetails.setTxnFlow("O");
            updtTxnDetails.setMerCategory("Request Approved");
            txnDetls.setData(updtTxnDetails);
            Runnable payerRecordUpdate = () -> kafkaProducer.publishUpiTxn(txnDetls);
            new Thread(payerRecordUpdate).start();
            log.info("payee belongs to citrus .. so updating failed status...");
            updtTxnDetails.setTxnStatus("S");
            updtTxnDetails.setTxnFlow("I");
            updtTxnDetails.setMerCategory("Request Approved");
            txnDetls.setData(updtTxnDetails);
            Runnable payeeRecordUpdate = () -> kafkaProducer.publishUpiTxn(txnDetls);
            new Thread(payeeRecordUpdate).start();
        }
    }

    private WibmoResponse handleDecline(UpiIncomingCollectRequest upiIncomingCollectRequest, String programId, String accountNumber){
        WibmoResponse response = new WibmoResponse();
        String payeeVPAName = getVPAUserName(upiIncomingCollectRequest.getPayeeVpa(), programId);
        if(payeeVPAName == null)
            return new WibmoResponse(UpiStatusConstants.INVALID_PAYEE_VPA, PAYER_VPA_VERIFICATION_FAILED);
        String payerVPAName = getVPAUserName(upiIncomingCollectRequest.getPayerVpa(),programId);
        if(payerVPAName == null)
            return new WibmoResponse(UpiStatusConstants.INVALID_PAYER_VPA, PAYER_VPA_VERIFICATION_FAILED);
        upiIncomingCollectRequest.setPayeeName(payeeVPAName);
        upiIncomingCollectRequest.setPayerName(payerVPAName);
        log.info("VPA Validations are passed..");
            UpiIncomingCollectResponse declineUpiResponse = upiServiceAdapter.incomingRequest(programId, accountNumber, upiIncomingCollectRequest);
            if(declineUpiResponse.getWibmoRespCode() == 200){
                response.setData(declineUpiResponse);
                // insert into txn history
                VPADetails vpaDetails = vpaDetailsDAO.findByVpa(upiIncomingCollectRequest.getPayeeVpa());
                String agentName = programParamsDAO.fetchParamValueByParamName(programId, ProgramParamConstants.AGENT_NAME.getValue());
                String vpaAddress = programParamsDAO.fetchParamValueByParamName(programId, ProgramParamConstants.VPA_ADDRESS_PAYU.name());
                if(CommonHelper.checkOnUs(upiIncomingCollectRequest.getPayeeVpa(), agentName, vpaAddress)){
                    // push notification to payee
                    helper.sendPushNotification(programId, vpaDetails.getAccountNumber().toString(), upiIncomingCollectRequest.getTxnAmount(), upiIncomingCollectRequest.getPayerName() , Constants.REJECTED, Constants.RM_REJECT_EVENT_ID, buildPushNotificationData(programId, upiIncomingCollectRequest));
                }
                txnHistoryDataPopulation(upiIncomingCollectRequest, accountNumber, programId,declineUpiResponse);
            }else {
                response.setErrorMessage(declineUpiResponse.getWibmoErrorMessage());
            }
            response.setResCode(declineUpiResponse.getWibmoRespCode());
            response.setResDesc(declineUpiResponse.getWibmoResDesc());
            log.info("decline response :: {}",response);
            return  response;
    }

    private WibmoResponse unloadFunds(UpiIncomingCollectRequest upiIncomingCollectRequest,String programId,String accountNumber){
        WibmoResponse response = new WibmoResponse();
        MultiValueMap<String, String> customFundHeader = null;
        ResponseEntity<WibmoResponse> responseEntity = null;
        String wibmoTxnId = CommonUtil.generateWibmoTxnId();
        FundRequest fundRequest = new FundRequest();
        fundRequest.setAmount(Long.parseLong(upiIncomingCollectRequest.getTxnAmount()));
        fundRequest.setTxnType(Constants.P2P_DEBIT);
        fundRequest.setCustId(accountNumber);
        fundRequest.setRrn(wibmoTxnId);
        fundRequest.setWalletId(Integer.parseInt(upiIncomingCollectRequest.getWalletId()));
        customFundHeader = new LinkedMultiValueMap<>();
        customFundHeader.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
        customFundHeader.add(X_PROGRAM_ID, programId);
        customFundHeader.add(X_ACCOUNT_NUMBER, accountNumber);
        HttpEntity<Object> fundUnloadEntity = new HttpEntity<>(fundRequest, customFundHeader);
        try {
            responseEntity = restTemplate.exchange(walletUrl + Constants.DEBIT_FUND_EP, HttpMethod.POST, fundUnloadEntity, WibmoResponse.class);
            WibmoResponse wibmoResponse=responseEntity.getBody();
            if (wibmoResponse!=null && wibmoResponse.getResCode() == 1) {
                log.debug("amount debited");
                response.setResCode(200);
            } else {
                log.debug("amount not debited! Error occurred in unload fund process");
                response.setResCode(100);
                response.setResDesc(FAILURE);
                response.setErrorMessage("Exception while funds debit");
            }
        }catch (Exception ex){
            log.error("Exception while unloadFunds :: {}",ex);
            response.setResCode(100);
            response.setResDesc(FAILURE);
            response.setErrorMessage("Exception while calling funds debit");
        }
        return response;
    }
    
    public void loadFunds(UpiIncomingCollectRequest upiIncomingCollectRequest,String programId,String accountNumber){
        MultiValueMap<String, String> customFundHeader = null;
        ResponseEntity<WibmoResponse> responseEntity = null;
        String wibmoTxnId = CommonUtil.generateWibmoTxnId();
        FundRequest fundRequest = new FundRequest();
        fundRequest.setAmount(Long.parseLong(upiIncomingCollectRequest.getTxnAmount()));
        fundRequest.setTxnType(Constants.P2P_CREDIT);
        fundRequest.setCustId(accountNumber);
        fundRequest.setRrn(wibmoTxnId);
        fundRequest.setWalletId(Integer.parseInt(upiIncomingCollectRequest.getWalletId()));

        customFundHeader = new LinkedMultiValueMap<>();
        customFundHeader.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
        customFundHeader.add(X_PROGRAM_ID, programId);
        customFundHeader.add(X_ACCOUNT_NUMBER, accountNumber);
        HttpEntity<Object> fundLoadEntity = new HttpEntity<>(fundRequest, customFundHeader);
        try {
            responseEntity = restTemplate.exchange(walletUrl + Constants.CREDIT_FUND_EP, HttpMethod.POST, fundLoadEntity, WibmoResponse.class);
            WibmoResponse wibmoResponse=responseEntity.getBody();
            if (wibmoResponse!=null && wibmoResponse.getResCode() == 1) {
                log.debug("amount refunded");
            } else {
                log.debug("amount not refunded! Error occurred in load fund process");
            }
        }catch (Exception ex){
            log.error("Exception while loadFunds :: {}",ex);
        }
    }

    private void updateStatus(String programId, String txnId, String vpaStatus, String upiCollectRequestStatus) {
        log.debug("calling CollectRequestServiceImpl : updateStatus() :  vpaStatus : {} , upiCollectRequestStatus : {}", vpaStatus, upiCollectRequestStatus);
        VpaTxnInfo vpaTxnInfo = new VpaTxnInfo();
        try {
            if (CommonHelper.checkTxnIdHasAlphabet(txnId)) {
                vpaTxnInfo = vpaTxnDAO.fetchByGatewayTxnId(txnId);
            } else {
                vpaTxnInfo = vpaTxnDAO.fetchById(Integer.parseInt(txnId));
            }
            vpaTxnInfo.setStatus(vpaStatus);

            String agentName = programParamsDAO.fetchParamValueByParamName(programId, ProgramParamConstants.AGENT_NAME.getValue());
            String vpaAddress = programParamsDAO.fetchParamValueByParamName(programId, ProgramParamConstants.VPA_ADDRESS_PAYU.name());

            //check on-us
            if (CommonHelper.checkOnUs(vpaTxnInfo.getPayeeVpa(), agentName, vpaAddress)) {
                log.debug("payee vpa belongs to on-us");
                //update vpa txn info tbl status
                vpaTxnInfo.setUpdatedTs(new Timestamp(new Date().getTime()));
                vpaTxnDAO.updateVpaTxnInfoById(vpaTxnInfo);
            }

            //update upi_collect_request tbl status
            upiCollectRequestDAO.updateUpiCollectRequestStatusByTxnId(upiCollectRequestStatus, vpaTxnInfo.getGatewayTxnId());
        } catch (Exception e) {
            log.error("Exception while calling CollectRequestServiceImpl : updateStatus : {}", e);
        }
    }

    private PushNotificationData buildPushNotificationData(String programId, UpiIncomingCollectRequest upiIncomingCollectRequest) {
        PushNotificationData data = new PushNotificationData();
        Timestamp createTimeStamp = new Timestamp( new Date().getTime());
        try {
            String programParams = programParamsDAO.fetchParamValueByParamName(programId, Constants.COLLECT_REQ_EXP_MINUTES);
            long expiryTimeInMin = Long.parseLong(programParams);
            data.setTxnMode("W2UPI");
            data.setTxnRefNumber(upiIncomingCollectRequest.getTxnId());
            data.setPayeeName(upiIncomingCollectRequest.getPayeeName());
            data.setRequestedDate(upiIncomingCollectRequest.getTxnDate());
            data.setTxnAmount(upiIncomingCollectRequest.getTxnAmount());
            data.setPayeeVPA(upiIncomingCollectRequest.getPayeeVpa());
            data.setRequestedDate(createTimeStamp.getTime());
            data.setExpiryDate(createTimeStamp.getTime() + (expiryTimeInMin * 60 * 1000));
        } catch (Exception e) {
            log.error("Exception while buildPushNotificationData : {}", e);
        }
        return data;
    }

}
