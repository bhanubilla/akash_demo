package com.wibmo.dfs.upi.adapter.juspay.service.impl;

import com.wibmo.dfs.upi.adapter.juspay.model.*;
import com.wibmo.dfs.upi.dao.UpiDisputeManagementDAO;
import com.wibmo.dfs.upi.model.request.RaiseUdirComplaintRequest;
import com.wibmo.dfs.upi.model.response.RaiseUdirComplaintResponse;
import com.wibmo.dfs.upi.model.response.UdirComplaintStatusResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class JuspayMockServiceImpl {

    @Autowired
    UpiDisputeManagementDAO upiDisputeManagementDAO;

    private static final String SUCCESS="SUCCESS";
    private static final String PENDING="PENDING";


    public RaiseUdirComplaintResponse raiseComplaint( String accountNumber, RaiseUdirComplaintRequest raiseUdirComplaintRequest) {

        log.debug("JuspayMockServiceImpl : raiseComplaint ");
        RaiseUdirComplaintResponse raiseUdirComplaintResponse=new RaiseUdirComplaintResponse();
        raiseUdirComplaintResponse.setResponseCode(SUCCESS);
        raiseUdirComplaintResponse.setStatus(SUCCESS);
        JuspayRaiseComplaintUdirPayload juspayRaiseComplaintUdirPayload=new JuspayRaiseComplaintUdirPayload();
        juspayRaiseComplaintUdirPayload.setMerchantCustomerId(accountNumber);
        juspayRaiseComplaintUdirPayload.setCrn("1232234456");
        juspayRaiseComplaintUdirPayload.setGatewayComplaintId("xyz_complaint_id");
        juspayRaiseComplaintUdirPayload.setGatewayResponseStatus(SUCCESS);
        juspayRaiseComplaintUdirPayload.setGatewayResponseCode("200");
        juspayRaiseComplaintUdirPayload.setReqAdjAmount("100");
        juspayRaiseComplaintUdirPayload.setTxnId(raiseUdirComplaintRequest.getTxnId());
        raiseUdirComplaintResponse.setPayload(juspayRaiseComplaintUdirPayload);
        upiDisputeManagementDAO.addComplaints(accountNumber,raiseUdirComplaintResponse.getPayload());
        return raiseUdirComplaintResponse;
    }

    public UdirComplaintStatusResponse checkComplaint(String accountNumber) {
        log.debug("JuspayMockServiceImpl : checkComplaint ");
        UdirComplaintStatusResponse udirComplaintStatusResponse=new UdirComplaintStatusResponse();
        udirComplaintStatusResponse.setResponseCode(SUCCESS);
        udirComplaintStatusResponse.setResponseMessage(SUCCESS);
        udirComplaintStatusResponse.setStatus(SUCCESS);
        JuspayUdirComplaintStatusResponse juspayUdirComplaintStatusResponse=new JuspayUdirComplaintStatusResponse();
        juspayUdirComplaintStatusResponse.setCrn("1232234456");
        juspayUdirComplaintStatusResponse.setGatewayResponseStatus(PENDING);
        juspayUdirComplaintStatusResponse.setMerchantCustomerId(accountNumber);
        udirComplaintStatusResponse.setPayload(juspayUdirComplaintStatusResponse);
        return udirComplaintStatusResponse;
    }
}
