package com.wibmo.dfs.upi.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DisputeRemarksDetails {

    private String name;
    private String initiationMode;
    private String adjFlag;
    private String adjCode;
    private String desc;
}
