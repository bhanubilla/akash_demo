package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class JuspayIncomingCollectResponse extends JuspayBaseResponse implements Serializable {
    private static final long serialVersionUID = 1L;
    private JuspayIncomingCollectPayload payload;

}
