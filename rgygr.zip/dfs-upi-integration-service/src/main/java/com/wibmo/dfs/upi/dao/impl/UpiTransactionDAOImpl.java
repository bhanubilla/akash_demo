package com.wibmo.dfs.upi.dao.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;

import com.wibmo.dfs.upi.dao.UpiTransactionDAO;
import com.wibmo.dfs.upi.model.VPADetailsMini;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class UpiTransactionDAOImpl implements UpiTransactionDAO {

	private static final String QUERY_FETCH_VPA_DETAILS_MINI = "SELECT VPA, IS_PRIMARY_VPA FROM VPA_DETAILS WHERE ACCOUNT_NUMBER=? AND MOBILE_NUMBER=? AND ACTIVE=1";
	
	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	//find VPADetails by mobile number
	@Override
    public List<VPADetailsMini> findByMobileNumber(String programId, int accountNumber, String mobileNumber) {
    	List<VPADetailsMini> vpaDetailsList = new ArrayList<>();
    	log.debug("UpiTransactionDAOImpl - List<VPADetailsMini> findByMobileNumber ");
    		try {
    			BeanPropertyRowMapper<VPADetailsMini> rowMapper = BeanPropertyRowMapper.newInstance(VPADetailsMini.class);
    			vpaDetailsList = jdbcTemplate.query(QUERY_FETCH_VPA_DETAILS_MINI,
    					new PreparedStatementSetter() {

    						public void setValues(PreparedStatement preparedStatement) throws SQLException {
    							preparedStatement.setInt(1, accountNumber);
    							preparedStatement.setString(2, mobileNumber);
    						}
    					}, rowMapper);
    	}catch (CannotGetJdbcConnectionException e) {
			log.error("program :{}, not configured ,error: {}", programId, e.toString());
		} catch (Exception e) {
			log.error("Exception :{}", e);
		}
		return vpaDetailsList;
    }
}
