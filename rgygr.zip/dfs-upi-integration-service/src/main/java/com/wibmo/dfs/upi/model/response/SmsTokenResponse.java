package com.wibmo.dfs.upi.model.response;

import java.math.BigInteger;

import com.wibmo.dfs.upi.model.ServiceProvider;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SmsTokenResponse {
	private BigInteger refId;
	private String smsContent;
    private ServiceProvider[] serviceProviders;
}
