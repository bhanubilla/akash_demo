package com.wibmo.dfs.upi.adapter.juspay.model;

import com.wibmo.dfs.upi.model.PendingComplaints;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class JuspayUdirListAllComplaintsResponse {

    private String merchantId;
    private String merchantChannelId;
    private List<PendingComplaints> complaintsList;
    private String udfParameters;
}
