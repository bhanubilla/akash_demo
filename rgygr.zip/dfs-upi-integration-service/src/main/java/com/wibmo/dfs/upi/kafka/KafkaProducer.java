package com.wibmo.dfs.upi.kafka;

import com.wibmo.dfs.upi.constants.TxnTrackingConstants;
import com.wibmo.dfs.upi.kafka.model.TxnTrackingStatus;
import com.wibmo.dfs.upi.kafka.model.TxnDetails;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.KafkaTemplate;

import java.sql.Timestamp;
import java.util.Date;

@Slf4j
@Configuration
public class KafkaProducer {

	@Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;

	@Value("${kafka.topicName.txnDetails: dfs-transaction-history}")
	private String txnHistoryTopicName;

	@Value("${kafka.topicName.txnTrackingDetails:dfs-transaction-tracking}")
	private String txnTrackingTopicName;


	public String publishUpiTxn(TxnDetails txns) {
		log.debug("req details ---> {}",txns);
		try {
			kafkaTemplate.send(txnHistoryTopicName, txns);
		} catch(Exception e) {
			log.error("exception on publishing message: {}",e);
		}
		return "topic published";
	}
	
	public String publishUpiTxnTracking(String upiRequestId, TxnTrackingConstants status) {
		TxnTrackingStatus trackingtxnstatus = new TxnTrackingStatus();
		trackingtxnstatus.setTxnNumber(upiRequestId);
		trackingtxnstatus.setTxnStatusDescription(status.getStatusDescription());
		trackingtxnstatus.setTxnStatusName(status.getStatusName());
		trackingtxnstatus.setCreateAt(new Timestamp(new Date().getTime()));
		log.info("req details for txn tracking---> {}",trackingtxnstatus);
		try {
			kafkaTemplate.send(txnTrackingTopicName, trackingtxnstatus);
		} catch(Exception e) {
			log.error("exception on publishing txn tracking message: {}",e);
		}
		return "topic published";
	}
}
