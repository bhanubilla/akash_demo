package com.wibmo.dfs.upi.adapter.onboarding;

import com.wibmo.dfs.upi.model.UpdateComplaintStatus;
import com.wibmo.dfs.upi.model.response.WibmoResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

@Component
@Slf4j
public class DisputeManagementMSAdapter {

    public static final String X_PROGRAM_ID = "X-PROGRAM-ID";
    private static final String UPDATE_TXN_TRACKING_STATUS = "/dispute-management/v1/complaintDetails";
    @Autowired
    private RestTemplate restTemplate;
    @Value("${resource.url.dispute}")
    private String disputeManagementUrlValue;

    public void updateComplaintStatus(String programId, UpdateComplaintStatus updateComplaintStatus){
        log.info("START DisputeManagementMSAdapter:updateComplaintStatus===");
        log.info("programId :: {}, complaintNumber :: {}, status :: {}",programId,updateComplaintStatus.getComplaintNumber(),updateComplaintStatus.getStatus());
        try{
            String url = disputeManagementUrlValue + UPDATE_TXN_TRACKING_STATUS;
            MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
            custHeader.add(X_PROGRAM_ID, programId);
            HttpEntity<Object> entity = new HttpEntity<>(updateComplaintStatus, custHeader);
            ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(url, HttpMethod.PUT, entity,
                    WibmoResponse.class);
            WibmoResponse wibmoResponse= responseEntity.getBody();
            if(wibmoResponse !=null && wibmoResponse.getResCode()==200){
                log.info("Updated complaint status in Dispute Management MS");
            }else
                log.info("Unable to update check Dispute Management logs");
        }catch (Exception ex){
            log.error("Exception while updating complaint status :: {}",ex);
        }
    }
}
