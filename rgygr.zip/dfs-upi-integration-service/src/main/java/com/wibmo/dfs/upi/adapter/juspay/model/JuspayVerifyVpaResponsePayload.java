package com.wibmo.dfs.upi.adapter.juspay.model;

import com.wibmo.dfs.upi.model.MerchantType;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayVerifyVpaResponsePayload {
	private String merchantId;
	private String merchantChannelId;
	private String gatewayTransactionId;
	private String gatewayResponseStatus;
	private String gatewayResponseCode;
	private String gatewayResponseMessage;
	private String vpa;
	private String name;
	private String ifsc;
	private String iin;
	private String isMerchant;
	private String isMerchantVerified;
	private boolean isMandateSupported;
	private String mcc;
	private MerchantType merchantType;
	private String udfParameters;

}
