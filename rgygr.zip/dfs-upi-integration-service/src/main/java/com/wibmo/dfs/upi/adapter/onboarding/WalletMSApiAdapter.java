package com.wibmo.dfs.upi.adapter.onboarding;

import com.wibmo.dfs.upi.model.response.WibmoResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

@Component
@Slf4j
public class WalletMSApiAdapter {
    public static final String X_PROGRAM_ID = "X-PROGRAM-ID";
    public static final String X_ACCOUNT_NUMBER = "X-ACCOUNT-NUMBER";
    public static final String WALLET_LC_FETCH_API_V_1 = "/wallet/lc/fetch/api/v1";
    @Autowired
    private RestTemplate restTemplate;

    @Value("${resource.url.wallet}")
    private String baseUrl;

    public void fetchLinkedCardDetails(String programId, String accountNumber) {
        try {
            log.info("WalletMSApiAdapter::fetchLinkedCardDetails");
            MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
            custHeader.add(X_PROGRAM_ID, programId);
            custHeader.add(X_ACCOUNT_NUMBER, accountNumber);
            HttpEntity<Object> entity = new HttpEntity<>(custHeader);
            String url = baseUrl + WALLET_LC_FETCH_API_V_1;
            ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(url, HttpMethod.POST, entity,
                    WibmoResponse.class);
            WibmoResponse apiResponse = responseEntity.getBody();
            if(apiResponse != null && apiResponse.getResCode() == 200) {
                log.info("apiResponse.getData() :: {}",apiResponse.getData());
            }
        } catch (Exception ex) {
            log.error("Exception in Wallet MS api call:{}", ex);
        }
    }


}
