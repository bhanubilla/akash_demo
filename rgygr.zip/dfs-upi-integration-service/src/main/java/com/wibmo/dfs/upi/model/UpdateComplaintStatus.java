package com.wibmo.dfs.upi.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UpdateComplaintStatus {
    private String complaintNumber;
    private String status;
}
