package com.wibmo.dfs.upi.model;

import com.wibmo.dfs.platform.service.notification.model.Attachment;
import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Map;

@Data
public class AlertRequest {

    private static final long serialVersionUID = -9048534539305002846L;

    @Min(1)
    private int eventId;
    private String fcmToken;
    private String mobileNumber;
    private String emailId;
    private long accountNumber;
    private String deviceId;
    private boolean whatsappEnabled;
    @NotNull
    private Map<String, String> placeHolders;


    private List<Attachment> attachments;

}
