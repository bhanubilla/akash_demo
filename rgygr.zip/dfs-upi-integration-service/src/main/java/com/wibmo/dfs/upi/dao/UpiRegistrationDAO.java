package com.wibmo.dfs.upi.dao;

import com.wibmo.dfs.upi.entity.VpaBasicDetails;
import com.wibmo.dfs.upi.entity.VpaDetails;
import com.wibmo.dfs.upi.entity.VpaTxnInfoDetails;
import com.wibmo.dfs.upi.model.VpaRegistrationAudit;
import com.wibmo.dfs.upi.model.request.DeviceBindingRequest;

import java.math.BigInteger;
import java.util.List;

public interface UpiRegistrationDAO {

	List<VpaBasicDetails> fetchVpaDetailsBasedOnAccountNo(String programId, int accountNumber);
	BigInteger saveVpaRegistrationLogDetails(VpaRegistrationAudit vpaAudit);
	BigInteger updateVpaRegistrationLogDetails(String status, DeviceBindingRequest request, String deviceFingerPrint);
	BigInteger updateVpaRegistrationLogDetails(String status, DeviceBindingRequest request);
	VpaRegistrationAudit fetchVpaRegistrationLogInfoByRefId(BigInteger refId);
	String fetchSmsToken(String refId);
	VpaRegistrationAudit fetchVpaRegInfoBySmsAndMobile(String smsContent, String mobileNumber);
	void updateVpaRegistrationLogByRefID(String vpa, BigInteger refNumber);
	void updateVpaRegLogByRefID(String status, BigInteger refNumber);
	void updateVpaTxnInfoByTxnId(String gatewayStatus, String status, String gatewayTransactionId, String payeeMerchantCustomerId);
	VpaTxnInfoDetails fetchStatusBasesOnGatewayTxnId(String gatewayTransactionId, String payeeMerchantCustomerId);
	VpaTxnInfoDetails fetchVpaTxnInfoBasesOnGatewayTxnIdGatewayRefId(String gatewayTransactionId, String gatewayReferenceId, String amount);
	VpaDetails fetchVpaDetailsBasesOnMerchantCustId(String merchantCustomerId, String payerVpa);
	VpaDetails fetchVpaDetailsBasesOnVpa(String payeeVpa);
	VpaRegistrationAudit fetchVpaRegistrationLogInfoByAccountNumber(String accountNumber);
	
}
