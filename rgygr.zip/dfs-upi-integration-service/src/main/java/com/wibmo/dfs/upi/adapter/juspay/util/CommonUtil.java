package com.wibmo.dfs.upi.adapter.juspay.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpHeaders;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.wibmo.dfs.upi.constants.Constants;
import com.wibmo.dfs.upi.model.response.WibmoResponse;

import java.security.SecureRandom;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.ws.rs.core.MediaType;

@Slf4j
public class CommonUtil {

	public static final String URL = "url :: {}";
	private static SecureRandom srandom;


	static {
		try {
			srandom = SecureRandom.getInstance("SHA1PRNG");
		} catch (Exception e) {
			log.warn("SecureRandom generation failed! : {0}", e);
		}
	}

	private CommonUtil() { 

	}

	/*
	 * This method will generate random string
	 * @param len
	 * 
	 * @return String
	 */

	public static String decimalFormat(long amount) {
		DecimalFormat decimalFormat = new DecimalFormat("###,###.####");
		decimalFormat.setMinimumFractionDigits(2);
		return decimalFormat.format(amount / 100.0);

	}
	public static String generateRandomString(int len) {
		StringBuilder sb = new StringBuilder();
		while (sb.length() < len) {
			sb.append((char) ('0' + srandom.nextInt(10)));
			if(sb.length() < len) sb.append((char) ('a' + srandom.nextInt(26)));
			if(sb.length() < len) sb.append((char) ( 'A' + srandom.nextInt(26)));
		}
		return sb.toString();
	}

	public static String generateWibmoTxnId() {
		StringBuilder sb = new StringBuilder();
		sb.append(new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date()));
		sb.append(generateRandomString(4));
		sb.append(generateRandomString(4));
		return sb.toString();
	}

	public static String generateRequestTime(SimpleDateFormat sdf) {
		return sdf.format(new Date());
	}

	
	public static void startThreadNameForLogging(String orgThreadName, String... params) {
        try {
            StringBuilder sb = new StringBuilder(200);
            sb.append(orgThreadName);
            for(String param : params){
                sb.append("|").append(param);
            }
            Thread.currentThread().setName(sb.toString());
        } catch (Exception e) {
            log.error("Exception while generating threadName ", e);
        }
    }
	
	public static int lastDayOfMonth(int year, int month, int date)
    {
        // Creating a calendar object
        Calendar cal = new GregorianCalendar(year, month, date);
        return cal.getActualMaximum(Calendar.DATE);
    }

	public static String truncate(String value, int length) {
		// Ensure String length is longer than requested size.
		if (StringUtils.isNotBlank(value) && value.length() > length) {
			return value.substring(0, length-2)+"..";
		} else {
			return value;
		}
	}
	
	public static WibmoResponse invokeApi(RestTemplate restTemplate, HttpMethod method,String url, String endPoint, String programId, Object request) {
        String serverURL = url + endPoint;
        log.info(URL,serverURL);
        MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
		custHeader.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
		if(null != programId)
			custHeader.add(Constants.X_PROGRAM_ID, programId);
        HttpEntity<Object> entity = new HttpEntity<>(request, custHeader);
        ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(serverURL, method,entity,WibmoResponse.class);
        return responseEntity.getBody();
	}

	public static WibmoResponse invokeApi(RestTemplate restTemplate, HttpMethod method,String url, String endPoint, Object request, MultiValueMap<String, String> custHeader) {
		String serverURL = url + endPoint;
		log.info(URL,serverURL);
		HttpEntity<Object> entity = new HttpEntity<>(request, custHeader);
		ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(serverURL, method, entity,
				WibmoResponse.class);
		return responseEntity.getBody();
	}

	public static WibmoResponse invokeApi(RestTemplate restTemplate, HttpMethod method,String url, String endPoint, MultiValueMap<String, String> custHeader) {
		String serverURL = url + endPoint;
		log.info(URL,serverURL);
		HttpEntity<Object> entity = new HttpEntity<>(custHeader);
		ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(serverURL, method, entity,
				WibmoResponse.class);
		return responseEntity.getBody();
	}
}
