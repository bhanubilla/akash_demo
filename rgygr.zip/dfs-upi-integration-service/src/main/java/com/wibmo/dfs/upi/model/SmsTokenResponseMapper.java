package com.wibmo.dfs.upi.model;

import java.math.BigInteger;
import java.util.Optional;

import org.springframework.stereotype.Component;

import com.wibmo.dfs.upi.adapter.juspay.model.JuspaySMSTokenResponsePayload;
import com.wibmo.dfs.upi.model.response.SmsTokenResponse;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SmsTokenResponseMapper {
	public SmsTokenResponse map(Optional<JuspaySMSTokenResponsePayload> juspaySMSTokenResponse, BigInteger refId) {
		log.info("Mapping Juspay SmsToken Response to Sms Token Response..");
		SmsTokenResponse smsTokenResponse = new SmsTokenResponse();
		smsTokenResponse.setRefId(refId);
		smsTokenResponse.setSmsContent(juspaySMSTokenResponse.isPresent() ? juspaySMSTokenResponse.get().getSmsContent() : null);
		smsTokenResponse.setServiceProviders(juspaySMSTokenResponse.isPresent() ? juspaySMSTokenResponse.get().getServiceProviders() : null);
		return smsTokenResponse;

	}

}
