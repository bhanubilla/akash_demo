package com.wibmo.dfs.upi.backbackexec;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CallbackExecutor implements Runnable{

    private String callBackName;
    public CallbackExecutor(String callBackName){
        this.callBackName = callBackName;
    }
    @Override
    public void run() {
    log.info("Calling IncomingCollectRequestToCustomer for gateWayTxnId:: {}");
    switch (callBackName){
        case "ICR2C":
            log.info("incoming collect request callback");
            break;
        case "CBS":
            log.info("CBS callback" );
            break;
        case "InMoney2CCS":
            log.info("incoming money to customer collect status callback");
            break;
        default:
            log.info("No callback");
            break;
    }

    }

    public static void main(String[] args) {
        CallbackExecutor cbe = new CallbackExecutor("ICR2C");
        Thread t1 = new Thread(cbe);
        t1.start();
    }
}
