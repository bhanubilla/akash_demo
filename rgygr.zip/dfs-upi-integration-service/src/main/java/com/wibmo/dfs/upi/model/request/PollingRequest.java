package com.wibmo.dfs.upi.model.request;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

@Data
@NoArgsConstructor
public class PollingRequest {

	private BigInteger refNumber;
	
}
