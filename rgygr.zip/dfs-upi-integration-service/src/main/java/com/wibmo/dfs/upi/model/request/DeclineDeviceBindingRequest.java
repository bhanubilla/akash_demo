package com.wibmo.dfs.upi.model.request;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DeclineDeviceBindingRequest {
    private String udfParameters;
    private String smsContent;
}
