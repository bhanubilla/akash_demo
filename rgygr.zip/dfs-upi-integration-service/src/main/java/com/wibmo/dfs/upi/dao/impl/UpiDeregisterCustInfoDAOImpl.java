package com.wibmo.dfs.upi.dao.impl;

import com.wibmo.dfs.upi.dao.UpiDeregisterCustInfoDAO;
import com.wibmo.dfs.upi.model.UpiDeregisteredCustInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
@Slf4j
public class UpiDeregisterCustInfoDAOImpl implements UpiDeregisterCustInfoDAO {

    private static final String SAVE_DEREGISTER_CUST_INFO_QUERY = "INSERT INTO UPI_DEREGISTERED_CUST_INFO (account_number ,  mobile_number ,  upi_customer_id ,  device_id ,  ssid ,  device_fingerprint ,  vpa ,  alias_vpa ,  linked_account_id ,  status ,  active ,  bank_name ,  bank_account_number ,  bank_ifsc ,  bank_code ,  type ,  bankAccUniqueId ,  wallet_id)"
            + " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public void saveDetail(UpiDeregisteredCustInfo row) {
        String sql = SAVE_DEREGISTER_CUST_INFO_QUERY;
        try {
            jdbcTemplate.update(sql, row.getAccountNumber(), row.getMobileNumber(), row.getUpiCustomerId(), row.getDeviceId(),
                    row.getSsid(), row.getDeviceFingerprint(), row.getVpa(), row.getAliasVpa(), row.getLinkedAccountId(),
                    row.getStatus(), row.isActive(), row.getBankName(), row.getBankAccountNumber(), row.getBankIfsc(),
                    row.getBankCode(), row.getType(), row.getBankAccUniqueId(), row.getWalletId());
        } catch (DataAccessException e) {
            log.error("Error occurred in UpiDeregisterCustInfoDAOImpl : UPI_DEREGISTERED_CUST_INFO {}", e.getMessage());
        }
    }
}
