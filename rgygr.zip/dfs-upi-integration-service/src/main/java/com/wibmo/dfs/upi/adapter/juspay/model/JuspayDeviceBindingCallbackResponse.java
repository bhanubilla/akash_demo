package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

@Data
@NoArgsConstructor
public class JuspayDeviceBindingCallbackResponse {
    private BigInteger refId;
    private String accountNumber;
    private String status;
}
