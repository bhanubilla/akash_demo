package com.wibmo.dfs.upi.adapter.juspay.model;

import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.wibmo.dfs.upi.constants.RegistrationConstants;
import com.wibmo.dfs.upi.model.request.DeviceBindingRequest;

@Component
public class JuspayDeviceBindingRequestMapper {
	String indiaCountryCode = "91";
	public JuspayDeviceBindingRequest map(DeviceBindingRequest request, String accountNum, String smsContent) {
		JuspayDeviceBindingRequest juspayRequest = new JuspayDeviceBindingRequest();
		juspayRequest.setMerchantCustomerId(accountNum);
		juspayRequest.setSmsContent(smsContent);
		juspayRequest.setDeviceId(request.getDeviceParams().getDeviceId());
		juspayRequest.setManufacturer(request.getDeviceParams().getManufacturer());
		juspayRequest.setModel(request.getDeviceParams().getModel());
		juspayRequest.setVersion(request.getDeviceParams().getVersion());
		juspayRequest.setOs(request.getDeviceParams().getOs());
		juspayRequest.setSsid(request.getDeviceParams().getSsid());
		String mobileNo = request.getMobileNumber();
		juspayRequest.setMobileNumber(mobileNo.length() == 10 ? indiaCountryCode + request.getMobileNumber() : request.getMobileNumber());
		juspayRequest.setPackageName(request.getPackageName());
		juspayRequest.setDeregisterOldCustomer(RegistrationConstants.TRUE);
		if(request.getUdfParameters() == null || request.getUdfParameters().isEmpty()) {
			juspayRequest.setUdfParameters(new JSONObject().toString());
		} 
			else juspayRequest.setUdfParameters(request.getUdfParameters());
		return juspayRequest;

	}
}
