package com.wibmo.dfs.upi.controller;

import com.wibmo.dfs.upi.model.request.BlockedVpaRequest;
import com.wibmo.dfs.upi.model.request.BlockedVpasRequest;
import com.wibmo.dfs.upi.model.response.WibmoResponse;
import com.wibmo.dfs.upi.service.BlockedVpaService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
//upi/accountmanagement
@RequestMapping("/upi/accountmanagement")
@Slf4j
public class AccountManagementController {
    @Autowired
    private BlockedVpaService blockedVpaService;
    //v1/vpa/blockvpa
    @PostMapping("/v1/vpa/blockvpa")
    public WibmoResponse blockedVpa(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber, @RequestBody BlockedVpaRequest request) {
        log.info("Blocked Vpa called for programId :: {}, accountId :: {}", programId, accountNumber);
        return blockedVpaService.blockedVpa(programId, accountNumber, request);
    }

    @PostMapping("/v1/vpa/unblockvpa")
    public WibmoResponse unblockedVpa(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber, @RequestBody BlockedVpaRequest request) {
        log.info("Unblocked Vpa called for programId :: {}, accountId :: {}", programId, accountNumber);
        return blockedVpaService.unblockedVpa(accountNumber, request);
    }

   @PostMapping("v1/vpa/blockedvpalist")
   public WibmoResponse blockedVpaList(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber, @RequestBody BlockedVpasRequest request){
       log.info("Get blockedvpalist for programId :: {}, accountId ::{}", programId, accountNumber);
       return  blockedVpaService.blockedVpaList(accountNumber,request);
   }

    @GetMapping("v1/vpa/fetchallblockedvpalist")
    public WibmoResponse fetchAllBlockedVpaList(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber) {
        log.info("fetchAllBlockedVpaList for programId :: {}, accountId ::{}", programId, accountNumber);
        return blockedVpaService.fetchAllBlockedVpaList(programId, accountNumber);
    }
}


