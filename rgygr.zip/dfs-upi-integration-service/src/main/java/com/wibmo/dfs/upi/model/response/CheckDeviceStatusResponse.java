package com.wibmo.dfs.upi.model.response;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class CheckDeviceStatusResponse {



    private boolean isIsValidateDeviceBinding;
    private List<VpaStatus> vpaStatus;
    private String bankAccountNumber;
    private String bankIfsc;
}
