package com.wibmo.dfs.upi.kafka.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CreditStatusTxnDetailsRequest{
    private String originalTxnId;
    private String category;
    private String status;
    private String customerId;
    private String mobile;
    private String paymentMode;
    private String txnDesc;
    private String merCategory;
    private String txnCategory;
    private String txnType;
    private long txnAmount;
    private String txnDateStr;
    private String txnStatus;
    private String remarks;
    private String txnFlow;
    private String txnShortDesc;
    // meta data
    private int tryCount;
    private String failureReason;
    private long closingBalance;
}
