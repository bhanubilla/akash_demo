package com.wibmo.dfs.upi.model.response;

import com.wibmo.dfs.upi.model.CreditMoneyCBSResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class JuspayCallbackResponse {
     private String status;
     private String responseCode;
    private String responseMessage;
    private CreditMoneyCBSResponse payload;
    }
