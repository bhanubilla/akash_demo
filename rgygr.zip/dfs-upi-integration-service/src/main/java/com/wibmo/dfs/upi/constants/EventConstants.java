package com.wibmo.dfs.upi.constants;

public class EventConstants {

	private EventConstants() {
	}

	public static final int UPI_REGISTRATION_ALERT_EVENT = 1101;
	public static final int UPI_RAISED_COMPLAINT_RESOLVED = 9998;

}
