package com.wibmo.dfs.upi.adapter.juspay.model;

import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.wibmo.dfs.upi.model.request.CreateWalletAndLinkRequest;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class JuspayCreateAndLinkRequestMapper {
	
	public JuspayCreateAndLinkRequest map(CreateWalletAndLinkRequest request, String accountNum) {
		JuspayCreateAndLinkRequest juspayRequest = new JuspayCreateAndLinkRequest();
		juspayRequest.setMerchantCustomerId(accountNum);
		juspayRequest.setCustomerVpa(request.getCustomerVpa());
		JuspayAccountRequest juspayAccountRequest = new JuspayAccountRequest();
		Date currentDate = new Date();
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		String strDate = dateFormat.format(currentDate);
		juspayAccountRequest.setAccountNumber(strDate + accountNum);
		juspayAccountRequest.setName(request.getName());
		juspayAccountRequest.setType(request.getType());
		juspayAccountRequest.setKycStatus(request.getKycStatus());
		juspayRequest.setAccount(juspayAccountRequest);
		juspayRequest.setSetAsDefaultBank("true");
		if(request.getUdfParameters()==null || request.getUdfParameters().isEmpty()) {
			juspayRequest.setUdfParameters(new JSONObject().toString());
		} else juspayRequest.setUdfParameters(request.getUdfParameters());
		
		return juspayRequest;
	}

}
