package com.wibmo.dfs.upi.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MerchantDetails {
	private String merchantId;
	private String merchantChannelId;
}
