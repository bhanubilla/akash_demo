package com.wibmo.dfs.upi.model.request;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DeleteVpaRequest {
    private String customerVpa;
    private String udfParameters;
}
