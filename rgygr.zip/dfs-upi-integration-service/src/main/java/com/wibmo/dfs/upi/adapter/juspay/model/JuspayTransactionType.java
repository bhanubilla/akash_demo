package com.wibmo.dfs.upi.adapter.juspay.model;


public enum JuspayTransactionType {
	
	P2M_PAY, P2P_PAY, INTENT_PAY, SCAN_PAY
}
