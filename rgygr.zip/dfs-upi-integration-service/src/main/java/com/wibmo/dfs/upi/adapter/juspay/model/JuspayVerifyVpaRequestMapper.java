package com.wibmo.dfs.upi.adapter.juspay.model;

import com.wibmo.dfs.upi.model.request.VerifyVpaRequest;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

@Component
public class JuspayVerifyVpaRequestMapper {
	public JuspayVerifyVpaRequest map(VerifyVpaRequest request) {
		JuspayVerifyVpaRequest juspayRequest = new JuspayVerifyVpaRequest();
		juspayRequest.setVpa(request.getVpa());
		if(request.getUdfParameters() == null || request.getUdfParameters().isEmpty()) {
			juspayRequest.setUdfParameters(new JSONObject().toString());
		} 
			else juspayRequest.setUdfParameters(request.getUdfParameters());
		return juspayRequest;

	}
}
