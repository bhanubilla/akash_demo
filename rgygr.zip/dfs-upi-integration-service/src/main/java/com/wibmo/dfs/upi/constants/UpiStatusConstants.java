package com.wibmo.dfs.upi.constants;

import io.swagger.annotations.ApiModelProperty;

public enum UpiStatusConstants {

	SUCCESS(200, "SUCCESS"), FAILURE(100, "Server errpr. Please try after some time"),
	VENDOR_TOKEN_API_UNAUTHORIZED(401, "Server error. Please try after sometime"), VENDOR_TOKEN_API_INTERNAL_SERVER(500, "Internal server error. Please try after sometime"),
	SMS_VERIFICATION_PENDING(150, "Creating VPA and linking account"),
	SMS_VERIFICATION_MISMATCH(160, "Device Binding failed. Please use valid mobile number"),
	SMS_VERIFICATION_EXPIRED(165, "Device Bining failed due to SMS token expired"),
	REGISTRATION_DECLINED(170, "Device Binding failed. Please try again after some time"),
	BIND_DEVICE_LIMIT_EXCEEDED(175, "You have exceeded the number of UPI Device binding attempts for the day. Please try again tomorrow."),
	PENDING_DEVICE_BINDING(195, "Device binding is in pending state"),
	DEVICE_BINDING_SUCCESS(203, "Device binding success"),
	NO_DATA(205, "Failed! Please try after sometime."),
	PENDING_VPA_CREATION(301, "VPA creation in pending state"),
	VERIFIED(503, "Successfully created VPA and linked account"),
	DECLINED(501, "Device binding process declined due to fraud."),
	EXPIRED(502,"Device binding expired."),
	OPERATION_RESTRICTED_DEREGISTER_CUSTOMER(504, "Active device binding already exists for the customer, deregister before continuing"),
	BAD_REQUEST(500, "badrequest. Please try after some time"),
	INVALID_DATA(506, "No active device binding for merchantCustomer"),
	INVALID_SMS_CONTENT(507, "Invalid sms content"),
	DEVICE_FINGERPRINT_MISMATCH(508, "Customer device fingerprint is not valid"),
	SERVICE_UNAVAILABLE(509, "service is not reachable"),
	REQUEST_EXPIRED(509, "x-timestamp header passed in request is older than 30 minutes"),
	MCC_IS_EMPTY(35, "mcc is empty"),
	PAYEE_VPA_IS_EMPTY(36, "payee VPA is empty"),
	AMOUNT_IS_EMPTY(37, "amount is empty"),
	REMARKS_IS_EMPTY(38, "remarks is empty"),
	SEND_MONEY_INVALID_DATA(39, "Invalid data"),
	SEND_MONEY_BAD_REQUEST(40, "Wrong input"),
	DEVICE_ID_IS_EMPTY(41, "deviceId is empty"),
	SSID_IS_EMPTY(42, "ssid is empty"),
	REF_NUMBER_IS_EMPTY(43, "ref number is empty"),
	VPA_IS_EMPTY(44, "vpa is empty"),
	MOBILE_NUMBER_IS_EMPTY(45, "mobile number is empty"),
	INVALID_AMOUNT(410, "Amount is invalid"),
	INVALID_PAYEE_VPA(411, "Payee VPA is invalid"),
	INVALID_PAYER_VPA(412, "Payer VPA is invalid"),
	PAYEE_VPA_MANDATORY(413, "Payee VPA is mandatory"),
	PAYER_VPA_MANDATORY(414, "Payer VPA is mandatory"),
	VPA_BLOCKED_SUCCESS(200,"Vpa blocked/spammed successfully."),
	VPA_BLOCKED_FAILED(100,"Vpa block/spam failed"),
	VPA_UMBLOCKED_SUCCESS(200,"Vpa unblocked successfull"),
	VPA_UNBLOCKED_FAILED(100,"Vpa unblock falied."),
	UPI_REGISTRATION_MINKYC_USER(210,"MinKyc User, Kindly update your KYC level for upi registration");

	
	
	
	@ApiModelProperty(notes = "Status Code", name = "statusCode")
	private final int statusCode;
	@ApiModelProperty(notes = "Status message", name = "statusMsg")
	private final String statusMsg;

	UpiStatusConstants(int statusCode, String statusMsg) {
    this.statusCode = statusCode;
    this.statusMsg = statusMsg;
}

	/**
	 * Return the integer statusCode.
	 */
	public int getStatusCode() {
		return this.statusCode;
	}

	/**
	 * Return the status msg.
	 */
	public String getStatusMsg() {
		return this.statusMsg;
	}

}
