package com.wibmo.dfs.upi.adapter.juspay.util;

import com.wibmo.dfs.upi.constants.Constants;
import com.wibmo.dfs.upi.model.response.WibmoResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
@Slf4j
public class CallbackRequestValidator {
    public static final String BAD_REQUEST = "BAD_REQUEST";
    public static final String EXCEPTION_WHILE_VALIDATE_COLLECT_REQUEST_RECEIVED = "Exception while validateCollectRequestReceived :: ";

    public WibmoResponse validateCreditMoneyCBS(String request){
        List<String> cbsMandateFields = Arrays.asList("gatewayReferenceId,gatewayTransactionId,accountIdentifier,amount,type".split(","));
        try {
            JSONObject jsonObject = new JSONObject(request);
            for (String field: cbsMandateFields) {
                String value = (String) jsonObject.get(field);
                WibmoResponse response = validateString(value, field);
                if(response != null)
                    return response;
            }
            return null;
        }catch (Exception ex){
            log.error("Exception while validating cbs request :: {}",ex);
            return new WibmoResponse(400, BAD_REQUEST);
        }
    }
    private WibmoResponse validateString(String value, String fieldName){
        if(StringUtils.isEmpty(value)){
            log.info("Empty value for :: {}",fieldName);
            return new WibmoResponse(400, BAD_REQUEST);
        }
        if(fieldName.equalsIgnoreCase(Constants.AMOUNT)){
            String regex = "^[1-9]\\d*\\.\\d{2}$";
            if(!value.matches(regex)) {
                log.info("Invalid amount passed in request :: {}",value);
                return new WibmoResponse(400, BAD_REQUEST);
            }
        }
        return null;
    }

    public WibmoResponse validateTransactionStatusCallback(String request){
        try{
            JSONObject jsonObject = new JSONObject(request);
            String type = (String) jsonObject.get(Constants.TYPE);
            if(StringUtils.isEmpty(type)){
                log.error("Transaction type is null/empty");
                return new WibmoResponse(400,BAD_REQUEST);
            }
            switch (type){
                case "CUSTOMER_DEBITED_VIA_PAY":
                    log.info("validating for CUSTOMER_DEBITED_VIA_PAY");
                    List<String> customerDebitedViaPayMandateFields = Arrays.asList("gatewayReferenceId,gatewayTransactionId,type,gatewayResponseCode".split(","));
                    for (String field : customerDebitedViaPayMandateFields) {
                        String value = (String) jsonObject.get(field);
                        WibmoResponse response = validateString(value, field);
                        if(response != null)
                            return response;
                    }
                    break;
                case "CUSTOMER_DEBITED_FOR_MERCHANT_VIA_COLLECT":
                    log.info("validating for CUSTOMER_DEBITED_FOR_MERCHANT_VIA_COLLECT");
                    List<String> customerDebitedForMerchantViaCollectMandateFields = Arrays.asList("gatewayReferenceId,gatewayTransactionId,type,gatewayResponseCode".split(","));
                    for (String field : customerDebitedForMerchantViaCollectMandateFields) {
                        String value = (String) jsonObject.get(field);
                        WibmoResponse response = validateString(value, field);
                        if(response != null)
                            return response;
                    }
                    break;
                case "CUSTOMER_DEBITED_FOR_MERCHANT_VIA_PAY":
                    log.info("validating for CUSTOMER_DEBITED_FOR_MERCHANT_VIA_PAY");
                    List<String> customerDebitedForMerchantViaPayMandateFields = Arrays.asList("gatewayReferenceId,gatewayTransactionId,type,gatewayResponseCode".split(","));
                    for (String field : customerDebitedForMerchantViaPayMandateFields) {
                        String value = (String) jsonObject.get(field);
                        WibmoResponse response = validateString(value, field);
                        if(response != null)
                            return response;
                    }
                    break;
                case "CUSTOMER_DEBITED_VIA_COLLECT":
                    log.info("validating for CUSTOMER_DEBITED_VIA_COLLECT");
                    List<String> customerDebitedViaCollectMandateFields = Arrays.asList("gatewayReferenceId,gatewayTransactionId,type,gatewayResponseCode".split(","));
                    for (String field : customerDebitedViaCollectMandateFields) {
                        String value = (String) jsonObject.get(field);
                        WibmoResponse response = validateString(value, field);
                        if(response != null)
                            return response;
                    }
                    break;
                default:
                    log.info("Type :: {}",type);
            }
            return null;
        }catch(Exception ex){
        log.error("Exception while validating data :: ",ex);
        return new WibmoResponse(400,BAD_REQUEST);
        }
    }

    public WibmoResponse validateCustomerDeviceBinding(String request){
        try{
            log.info("validateCustomerDeviceBinding :: {}",request);
            JSONObject jsonObject = new JSONObject(request);
            String type = (String) jsonObject.get(Constants.TYPE);
            if(StringUtils.isEmpty(type)){
                log.error("Transaction type is null/empty");
                return new WibmoResponse(400,BAD_REQUEST);
            }
            if(!type.equals("CUSTOMER_DEVICE_BINDING"))
                return null;
            List<String> customerDeviceBinding = Arrays.asList("customerMobileNumber,merchantChannelId,merchantCustomerId,merchantId,smsContent,status,type".split(","));
            for (String field: customerDeviceBinding) {
                String value = (String) jsonObject.get(field);
                WibmoResponse response = validateString(value, field);
                if(response != null)
                    return response;
            }
            return null;
        }catch(Exception ex){
            log.error("Exception while validateCustomerDeviceBinding :: ",ex);
            return new WibmoResponse(400,BAD_REQUEST);
        }
    }

    public WibmoResponse validateIncomingCollectRequestToCustomer(String request){
        try{
            log.info("validateCollectRequestReceived :: {}",request);
            //Validate CUSTOMER_CREDITED_VIA_COLLECT and COLLECT_REQUEST_RECEIVED
            JSONObject jsonObject = new JSONObject(request);
            String type = (String) jsonObject.get("type");
            if(StringUtils.isEmpty(type)){
                log.error("Transaction type is null/empty");
                return new WibmoResponse(400,BAD_REQUEST);
            }
            if(!"CUSTOMER_CREDITED_VIA_COLLECT".equalsIgnoreCase(type) && !"COLLECT_REQUEST_RECEIVED".equalsIgnoreCase(type)){
                return null;
            }
            List<String> collectRequestReceivedMandateFields = Arrays.asList("amount,gatewayReferenceId,gatewayTransactionId,type".split(","));
            for (String field: collectRequestReceivedMandateFields) {
                String value = (String) jsonObject.get(field);
                WibmoResponse response = validateString(value, field);
                if(response != null)
                    return response;
            }
            return null;
        }catch(Exception ex){
            log.error(EXCEPTION_WHILE_VALIDATE_COLLECT_REQUEST_RECEIVED,ex);
            return new WibmoResponse(400,BAD_REQUEST);
        }
    }
    public WibmoResponse validateCollectRequestSent(String request){
        List<String> mandateFields = Arrays.asList("gatewayReferenceId,gatewayTransactionId","gatewayResponseCode","type");
        try{
            JSONObject jsonObject = new JSONObject(request);
            log.info("validateCollectRequestReceived");
            for (String field: mandateFields) {
                String value = (String) jsonObject.get(field);
                WibmoResponse response = validateString(value, field);
                if(response != null)
                    return response;
            }
            return null;
        }catch(Exception ex){
            log.error(EXCEPTION_WHILE_VALIDATE_COLLECT_REQUEST_RECEIVED,ex);
            return new WibmoResponse(400,BAD_REQUEST);
        }
    }
    public WibmoResponse validateCustomerCreditedViaCollect(String request){
        List<String> mandateFields = Arrays.asList("amount,gatewayReferenceId,gatewayTransactionId,isVerifiedPayee,merchantCustomerId,merchantId,payeeMerchantCustomerId,payeeVpa,payerMerchantCustomerId,payerVpa,type".split(","));
        try{
            JSONObject jsonObject = new JSONObject(request);
            log.info("validateCustomerCreditedViaCollect");
            for (String field: mandateFields) {
                String value = (String) jsonObject.get(field);
                WibmoResponse response = validateString(value, field);
                if(response != null)
                    return response;
            }
            return null;
        }catch(Exception ex){
            log.error(EXCEPTION_WHILE_VALIDATE_COLLECT_REQUEST_RECEIVED,ex);
            return new WibmoResponse(400,BAD_REQUEST);
        }
    }
    public WibmoResponse validateComplaintRaised(String request){
        List<String> mandateFields = Arrays.asList("type,transactionAmount,gatewayResponseCode,gatewayComplaintId,originalGatewayTransactionId".split(","));
        try{
            JSONObject jsonObject = new JSONObject(request);
            log.info("validateComplaintRaised");
            for (String field: mandateFields) {
                String value = (String) jsonObject.get(field);
                WibmoResponse response = validateString(value, field);
                if(response != null)
                    return response;
            }
            return null;
        }catch(Exception ex){
            log.error(EXCEPTION_WHILE_VALIDATE_COLLECT_REQUEST_RECEIVED,ex);
            return new WibmoResponse(400,BAD_REQUEST);
        }
    }
    public WibmoResponse validateCbsComplaintStatusUpdate(String request){
        List<String> mandateFields = Arrays.asList("gatewayComplaintId,gatewayResponseCode,gatewayReferenceId,originalGatewayTransactionId".split(","));
        try{
            JSONObject jsonObject = new JSONObject(request);
            log.info("validateCbsComplaintStatusUpdate");
            for (String field: mandateFields) {
                String value = (String) jsonObject.get(field);
                WibmoResponse response = validateString(value, field);
                if(response != null)
                    return response;
            }
            return null;
        }catch(Exception ex){
            log.error(EXCEPTION_WHILE_VALIDATE_COLLECT_REQUEST_RECEIVED,ex);
            return new WibmoResponse(400,BAD_REQUEST);
        }
    }
    public WibmoResponse validateComplaintResolved(String request){
        try{
            List<String> mandateFields = Arrays.asList("gatewayComplaintId,gatewayResponseCode,gatewayReferenceId,originalGatewayTransactionId".split(","));
            JSONObject jsonObject = new JSONObject(request);
            log.info("validateComplaintResolved");
            for (String field: mandateFields) {
                String value = (String) jsonObject.get(field);
                WibmoResponse response = validateString(value, field);
                if(response != null)
                    return response;
            }
            return null;
        }catch(Exception ex){
            log.error(EXCEPTION_WHILE_VALIDATE_COLLECT_REQUEST_RECEIVED,ex);
            return new WibmoResponse(400,BAD_REQUEST);
        }
    }
}
