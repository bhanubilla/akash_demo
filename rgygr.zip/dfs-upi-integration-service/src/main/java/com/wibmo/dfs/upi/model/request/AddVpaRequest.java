package com.wibmo.dfs.upi.model.request;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AddVpaRequest {
    private String customerVpa;
    private boolean deleteCustomerPrimaryVpa;
    private String udfParameters;
}
