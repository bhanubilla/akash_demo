package com.wibmo.dfs.upi.constants;

import io.swagger.annotations.ApiModelProperty;

public enum CollectRequestConstants {
    COLLECT_REQUEST_BLOCKED_00(200, Constants.SUCCESS,"Collect request blocked"),
    COLLECT_REQUEST_BLOCKED_FAILED(100, Constants.FAILURE,"Collect request blocked failed"),
    COLLECT_REQUEST_DECLINE_00(200, Constants.SUCCESS,"Collect request declined"),
    COLLECT_REQUEST_DECLINE_FAILED(100, Constants.FAILURE,"Collect request declined failed"),
    COLLECT_REQUEST_ACCEPT_00(200, Constants.SUCCESS,"Collect request accepted"),
    COLLECT_REQUEST_ACCEPT_FAILED(100, Constants.FAILURE,"Collect request accept failed");
    @ApiModelProperty(notes = "Status Code", name = "statusCode")
    private final int statusCode;
    @ApiModelProperty(notes = "Status message", name = "statusMsg")
    private final String statusMsg;
    @ApiModelProperty(notes = "Status Details", name = "statusDetails")
    private final String statusDetails;

    CollectRequestConstants(int statusCode, String statusMsg,String statusDetails) {
        this.statusCode = statusCode;
        this.statusMsg = statusMsg;
        this.statusDetails = statusDetails;
    }

    /**
     * Return the integer statusCode.
     */
    public int getStatusCode() {
        return this.statusCode;
    }

    /**
     * Return the status msg.
     */
    public String getStatusMsg() {
        return this.statusMsg;
    }
    /**
     * Return the status details.
     */
    public String getStatusDetails() {
        return statusDetails;
    }
}
