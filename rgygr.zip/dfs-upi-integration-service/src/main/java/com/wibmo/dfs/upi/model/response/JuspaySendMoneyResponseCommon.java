package com.wibmo.dfs.upi.model.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class JuspaySendMoneyResponseCommon {
    private String merchantId;
    private String merchantChannelId;
    private String merchantCustomerId;
    private String merchantRequestId;
    private String customerMobileNumber;
    private String payerVpa;
    private String payeeMcc;
    private String payeeMerchantCustomerId;
    private String payeeName;
    private String payeeVpa;
    private String refUrl;
    private String bankAccountUniqueId;
    private String bankCode;
    private String maskedAccountNumber;
    private String amount;
    private String transactionType;
    private String transactionTimestamp;
    private String gatewayTransactionId;
    private String gatewayReferenceId;
    private String gatewayResponseStatus;
    private String gatewayResponseCode;
    private String gatewayResponseMessage;
    private String udfParameters;
}
