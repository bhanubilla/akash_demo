package com.wibmo.dfs.upi.adapter.juspay.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class JuspayIncomingMoneyToCustomerPay {
            private String amount;
            private String bankAccountUniqueId;
            private String bankCode;
            private String customResponse;
            private String gatewayReferenceId;
            private String gatewayResponseCode;
            private String gatewayResponseMessage;
            private String gatewayTransactionId;
            private String maskedAccountNumber;
            private String merchantCustomerId;
            private String merchantId;
            private String payeeMcc;
            private String payeeMerchantCustomerId;
            private String payeeMobileNumber;
            private String payeeVpa;
            private String payerMerchantCustomerId;
            private String payerName;
            private String payerVpa;
            private String refUrl;
            private String transactionTimestamp;
            private String type;
}
