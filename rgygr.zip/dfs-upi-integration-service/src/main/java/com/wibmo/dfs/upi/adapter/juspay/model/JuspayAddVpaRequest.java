package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayAddVpaRequest {
    private String merchantCustomerId;
    private String customerVpa;
    private String customerPrimaryVpa;
    private String deleteCustomerPrimaryVpa;
    private String udfParameters;
}
