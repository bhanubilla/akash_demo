package com.wibmo.dfs.upi.service;

import com.wibmo.dfs.upi.model.CheckUdirComplaints;
import com.wibmo.dfs.upi.model.CheckUdirComplaintStatus;
import com.wibmo.dfs.upi.model.request.RaiseUdirComplaintRequest;
import com.wibmo.dfs.upi.model.response.WibmoResponse;

public interface UpiDisputeManagementService {

     WibmoResponse raiseComplaint(String programId, String accountNum,RaiseUdirComplaintRequest raiseUdirComplaintRequest);
     WibmoResponse checkComplaint(String programId, String accountNum, CheckUdirComplaintStatus checkUdirComplaintStatusRequest);
     WibmoResponse listComplaints(String programId, String accountNum, CheckUdirComplaints checkUdirComplaints);
}
