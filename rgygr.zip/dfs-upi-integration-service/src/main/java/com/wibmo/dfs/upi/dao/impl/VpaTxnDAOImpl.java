package com.wibmo.dfs.upi.dao.impl;

import com.wibmo.dfs.upi.adapter.juspay.model.JuspayRequestMoneyRequest;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspaySendMoneyRequest;
import com.wibmo.dfs.upi.constants.Constants;
import com.wibmo.dfs.upi.constants.RegistrationConstants;
import com.wibmo.dfs.upi.dao.VpaTxnDAO;
import com.wibmo.dfs.upi.exception.InternalServerException;
import com.wibmo.dfs.upi.model.VpaTxnInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

@Repository
@Slf4j
public class VpaTxnDAOImpl implements VpaTxnDAO {
	
	private static final String INSERT_QUERY = "insert into vpa_txn_info(merchant_request_id, merchant_customer_id, customer_mobile_number, payer_vpa, payee_mcc, payee_merchant_customer_id, payee_name, payee_vpa, ref_url, bankAccountUniqueId, bank_code, masked_account_number, amount, transaction_type, transaction_timestamp, original_txn_id, gateway_txn_id, gateway_response_status, gateway_reference_id, gateway_response_code, gateway_response_message, status, message, upi_request_id) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	private static final String UPDATE_QUERY = "update vpa_txn_info set merchant_customer_id=?, customer_mobile_number=?, payer_vpa=?, payee_mcc=?, payee_merchant_customer_id=?, payee_name=?, payee_vpa=?, ref_url=?, bankAccountUniqueId=?, bank_code=?, masked_account_number=?, amount=?, transaction_type=?, original_txn_id=?, gateway_txn_id=?, gateway_response_status=?, gateway_reference_id=?, gateway_response_code=?, gateway_response_message=?, status=?, message=? where merchant_request_id=?";
	private static final String UPDATE_STATUS_BY_ID = "update vpa_txn_info set status = ?, updated_ts= ?  where id = ?";
	private static  final String FETCH_PENDING_VPA_TXNS_BY_VPA = "select * from vpa_txn_info where payer_vpa = ? and status = ?";
	private static final String UPDATE_TXN_STATUS = "update vpa_txn_info set GATEWAY_RESPONSE_STATUS = ?, STATUS = ?, GATEWAY_TXN_ID = ? , gateway_response_message = ?, upi_request_id= ? where id = ?";
	private static final String INSERT_UPI_REQUEST_MONEY_DETAILS = "insert into vpa_txn_info(merchant_customer_id,merchant_request_id,payer_vpa,payee_vpa,bankAccountUniqueId,amount, status, message, original_txn_id, gateway_txn_id, upi_request_id,transaction_type,payee_mcc) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?)";
	private static final String EXCEPTION_MSG_UPDATE_STATUS_BY_ID = "Error occurred in VpaTxnDAOImpl : updateVpaTxnInfoById  {}";

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public int save(VpaTxnInfo vpaTxnInfo) {
		log.info("saving data into DB - vpa_txn_info TABLE");
		KeyHolder keyHolder = new GeneratedKeyHolder();

		jdbcTemplate.update(connection -> {
			PreparedStatement ps = connection.prepareStatement(INSERT_QUERY, Statement.RETURN_GENERATED_KEYS);
			int i = 1;
			ps.setString(i++, vpaTxnInfo.getMerchantRequestId());
			ps.setString(i++, vpaTxnInfo.getMerchantCustomerId());
			ps.setString(i++, vpaTxnInfo.getCustomerMobileNumber());
			ps.setString(i++, vpaTxnInfo.getPayerVpa());
			ps.setString(i++, vpaTxnInfo.getPayeeMcc());
			ps.setString(i++, vpaTxnInfo.getPayeeMerchantCustomerId());
			ps.setString(i++, vpaTxnInfo.getPayeeName());
			ps.setString(i++, vpaTxnInfo.getPayeeVpa());
			ps.setString(i++, vpaTxnInfo.getRefUrl());
			ps.setString(i++, vpaTxnInfo.getBankAccountUniqueId());
			ps.setString(i++, vpaTxnInfo.getBankCode());
			ps.setString(i++, vpaTxnInfo.getMaskedAccountNumber());
			ps.setDouble(i++, vpaTxnInfo.getAmount());
			ps.setString(i++, vpaTxnInfo.getTransactionType());
			ps.setTimestamp(i++, vpaTxnInfo.getTransactionTimestamp());
			ps.setString(i++, vpaTxnInfo.getOriginalTxnId());
			ps.setString(i++, vpaTxnInfo.getGatewayTxnId());
			ps.setString(i++, vpaTxnInfo.getGatewayResponseStatus());
			ps.setString(i++, vpaTxnInfo.getGatewayReferenceId());
			ps.setString(i++, vpaTxnInfo.getGatewayResponseCode());
			ps.setString(i++, vpaTxnInfo.getGatewayResponseMessage());
			ps.setString(i++, vpaTxnInfo.getStatus());
			ps.setString(i++, vpaTxnInfo.getMessage());
			ps.setString(i++, vpaTxnInfo.getUpiRequestId());

			return ps;
		}, keyHolder);
		
		Number value =keyHolder.getKey();
		return null != value ? value.intValue():0;
	}

	@Override
	public int saveSendMoneyRequestDetails(JuspaySendMoneyRequest juspaySendMoneyRequest) {
		log.info("Saving SendMoneyRequestDetails ");
		try {
			log.info("We are trying to save jusPay request money details");
			KeyHolder keyHolder = new GeneratedKeyHolder();
			//(merchant_customer_id,merchant_request_id,payer_vpa,payee_vpa,bankAccountUniqueId,amount, status, message)
			jdbcTemplate.update(connection -> {
				PreparedStatement ps = connection.prepareStatement(INSERT_UPI_REQUEST_MONEY_DETAILS, Statement.RETURN_GENERATED_KEYS);
				int i = 1;
				ps.setString(i++, juspaySendMoneyRequest.getMerchantCustomerId());
				ps.setString(i++, juspaySendMoneyRequest.getMerchantRequestId());
				ps.setString(i++, juspaySendMoneyRequest.getPayerVpa());
				ps.setString(i++, juspaySendMoneyRequest.getPayeeVpa());
				ps.setString(i++, juspaySendMoneyRequest.getBankAccountUniqueId());
				ps.setDouble(i++, Double.parseDouble(juspaySendMoneyRequest.getAmount())*100);
				ps.setString(i++, "SEND_MONEY_INITIATED");
				ps.setString(i++, juspaySendMoneyRequest.getRemarks());
				ps.setString(i++, juspaySendMoneyRequest.getUpiRequestId());
				ps.setString(i++, juspaySendMoneyRequest.getUpiRequestId());
				ps.setString(i++, juspaySendMoneyRequest.getUpiRequestId());
				ps.setString(i++, juspaySendMoneyRequest.getTransactionType());
				ps.setString(i++, juspaySendMoneyRequest.getMcc());
				return ps;
			}, keyHolder);

			Number value = keyHolder.getKey();
			return null != value ? value.intValue() : 0;
		}catch (Exception ex){
			log.error("Exception while saving request money details :: {}",ex);
			return 0;
		}
	}

	@Override
	public long insertRequestMoneyDetails(JuspayRequestMoneyRequest juspayRequestMoneyRequest) {
		try {
			log.info("We are trying to save jusPay request money details");
			KeyHolder keyHolder = new GeneratedKeyHolder();
			//(merchant_customer_id,merchant_request_id,payer_vpa,payee_vpa,bankAccountUniqueId,amount, status, message)
			jdbcTemplate.update(connection -> {
				PreparedStatement ps = connection.prepareStatement(INSERT_UPI_REQUEST_MONEY_DETAILS, Statement.RETURN_GENERATED_KEYS);
				int i = 1;
				ps.setString(i++, juspayRequestMoneyRequest.getMerchantCustomerId());
				ps.setString(i++, juspayRequestMoneyRequest.getMerchantRequestId());
				ps.setString(i++, juspayRequestMoneyRequest.getPayerVpa());
				ps.setString(i++, juspayRequestMoneyRequest.getPayeeVpa());
				ps.setString(i++, juspayRequestMoneyRequest.getBankAccountUniqueId());
				ps.setDouble(i++, Double.parseDouble(juspayRequestMoneyRequest.getAmount())*100);
				ps.setString(i++, "REQUEST_MONEY_INITIATED");
				ps.setString(i++, juspayRequestMoneyRequest.getRemarks());
				ps.setString(i++, "ORIGINAL_TXN_ID"); //Since these are not null passing some dummy
				ps.setString(i++, juspayRequestMoneyRequest.getUpiRequestId());
				ps.setString(i++, juspayRequestMoneyRequest.getUpiRequestId());
				ps.setString(i++, "UPI_RM");
				ps.setString(i++, "0000");
				return ps;
			}, keyHolder);

			Number value = keyHolder.getKey();
			return null != value ? value.intValue() : 0;
		}catch (Exception ex){
			log.error("Exception while saving request money details :: {}",ex);
			return 0;
		}
	}

	@Override
	public int updateSuccessRespRequestMoneyDetails(VpaTxnInfo vpaTxnInfo) {
		try {
			log.info("We are going update request money details :: {}",vpaTxnInfo);
			String updateRequestMonetDetails="update vpa_txn_info set customer_mobile_number=?, payee_mcc =?, payee_merchant_customer_id=?,payee_name=?,ref_url=?,bank_code=?"+
					", masked_account_number=?, transaction_type=?, original_txn_id=?, gateway_txn_id=?, gateway_response_status=?,gateway_reference_id=?, "+
					"gateway_response_code= ?, gateway_response_message=?, status=?, gateway_payer_response_code=?, gateway_payee_response_code=?," +
					"gateway_payer_reversal_response_code=?, gateway_payee_reversal_response_code=? where id=?";

				return jdbcTemplate.update(updateRequestMonetDetails,
						vpaTxnInfo.getCustomerMobileNumber(), vpaTxnInfo.getPayeeMcc(), vpaTxnInfo.getPayeeMerchantCustomerId(), vpaTxnInfo.getPayeeName(), vpaTxnInfo.getRefUrl(), vpaTxnInfo.getBankCode(),
						vpaTxnInfo.getMaskedAccountNumber(), vpaTxnInfo.getTransactionType(), vpaTxnInfo.getOriginalTxnId(), vpaTxnInfo.getGatewayTxnId(), vpaTxnInfo.getGatewayResponseStatus(), vpaTxnInfo.getGatewayReferenceId(),
						vpaTxnInfo.getGatewayResponseCode(), vpaTxnInfo.getGatewayResponseMessage(), vpaTxnInfo.getStatus(),
						vpaTxnInfo.getGatewayPayerResponseCode(),vpaTxnInfo.getGatewayPayeeResponseCode(),vpaTxnInfo.getGatewayPayerReversalResponseCode(),
						vpaTxnInfo.getGatewayPayeeReversalResponseCode(),vpaTxnInfo.getId());


		}catch (Exception ex){
			log.error("Unable to update request money details :: {}",ex);
			return 0;
		}
	}

	@Override
	public int updateFailRespRequestMoneyDetails(long id, String status) {
		try {
			log.info("updateFailRespRequestMoneyDetails for id :: {}, status as {}",id,status);
			String updateRequestMonetDetails="update vpa_txn_info set status=? where id=?";
			return jdbcTemplate.update(updateRequestMonetDetails,status,id);
		}catch (Exception ex){
			log.error("Unable to updateFailRespRequestMoneyDetails :: {}",ex);
			return 0;
		}
	}

	@Override
	public int updateViaIncomingMoneyToCustomerCsCallback(String gatewayTransactionId, String gatewayResponseStatus) {
		try {
			log.info("updateFailRespRequestMoneyDetails for id :: {}, status :: {}",gatewayTransactionId,gatewayResponseStatus);
			String updateRequestMonetDetails="update vpa_txn_info set status=? where gateway_txn_id=?";
			return jdbcTemplate.update(updateRequestMonetDetails,gatewayResponseStatus,gatewayTransactionId);
		}catch (Exception ex){
			log.error("Unable to updateFailRespRequestMoneyDetails :: {}",ex);
			return 0;
		}
	}

	@Override
	public VpaTxnInfo fetchById(int id) {
		//"select * from vpa_tnx_info where id = ?",
		VpaTxnInfo blockedVpaDetails = new VpaTxnInfo();
		String db = "select * from vpa_txn_info where id = ?";
		try {
			return jdbcTemplate.query(db, new PreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement ps) throws SQLException {
					ps.setInt(1, id);
				}
			}, new ResultSetExtractor<VpaTxnInfo>() {
				@Override
				public VpaTxnInfo extractData(ResultSet resultSet) throws SQLException {
					if (resultSet.next()) {
						blockedVpaDetails.setId(resultSet.getInt("ID"));
						blockedVpaDetails.setUpiRequestId(resultSet.getString("upi_request_id"));
						return blockedVpaDetails;
					} else {
						return null;
					}
				}

			});

		} catch (EmptyResultDataAccessException e) {
			log.error("Error accur in VpaTxnDAOImpl : fetchById {}", e.getMessage());
			throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);

		}
	}

	@Override
	public boolean updateVpaTxnInfo(VpaTxnInfo vpaTxnInfo) {
		int cnt = jdbcTemplate.update(UPDATE_QUERY, 
				vpaTxnInfo.getMerchantRequestId(), vpaTxnInfo.getMerchantCustomerId(), vpaTxnInfo.getCustomerMobileNumber(), vpaTxnInfo.getPayerVpa(), vpaTxnInfo.getPayeeMcc(), vpaTxnInfo.getPayeeMerchantCustomerId(), vpaTxnInfo.getPayeeName(), vpaTxnInfo.getPayeeVpa(), vpaTxnInfo.getRefUrl(), vpaTxnInfo.getBankAccountUniqueId(), vpaTxnInfo.getBankCode(), vpaTxnInfo.getMaskedAccountNumber(), vpaTxnInfo.getAmount(), vpaTxnInfo.getTransactionType(), vpaTxnInfo.getTransactionTimestamp(), vpaTxnInfo.getOriginalTxnId(), vpaTxnInfo.getGatewayTxnId(), vpaTxnInfo.getGatewayResponseStatus(), vpaTxnInfo.getGatewayReferenceId(), vpaTxnInfo.getGatewayResponseCode(), vpaTxnInfo.getGatewayResponseMessage(), vpaTxnInfo.getStatus(), vpaTxnInfo.getMessage(),
				vpaTxnInfo.getId());
		return cnt == 1;
	}

	@Override
	public List<VpaTxnInfo> fetchPendingVpaTxnsByVPA(String vpa) {
		try {
			return jdbcTemplate.query(FETCH_PENDING_VPA_TXNS_BY_VPA,
					new PreparedStatementSetter() {
						public void setValues(PreparedStatement preparedStatement) throws SQLException {
							preparedStatement.setString(1, vpa);
							preparedStatement.setString(2, Constants.REQUEST_MONEY_PENDING);
						}
					}, new ResultSetExtractor<List<VpaTxnInfo>>() {
						@Override
						public List<VpaTxnInfo> extractData(ResultSet rs) throws SQLException {
							List<VpaTxnInfo> pendingList = new ArrayList<>();
							while (rs.next()) {
								VpaTxnInfo vpaTxnInfo = new VpaTxnInfo();
								setVpaTxnInfo(vpaTxnInfo, rs);
								pendingList.add(vpaTxnInfo);
							}
							return pendingList;
						}
					});
		} catch (DataAccessException e) {
			log.error("Error occured in fetchPendingVpaTxns {}", e.getMessage());
			throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);
		}
	}

	@Override
	public void updateVpaTxnInfoByTxnId(String gatewayStatus, String status, String gatewayTransactionId,String gatewayResponseMessage,String upiRequestId,  long id) {
		try {
			jdbcTemplate.update(UPDATE_TXN_STATUS, gatewayStatus, status, gatewayTransactionId, gatewayResponseMessage,upiRequestId, id);
		} catch (DataAccessException e) {
			log.info("Error occurred in UpiRegistrationDAOImpl : updateVpaRegLogByRefID  {}", e.getMessage());
			throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);
		}
	}

	private void setVpaTxnInfo(VpaTxnInfo vpaTxnInfo, ResultSet rs) throws SQLException {
		vpaTxnInfo.setId(rs.getInt("ID"));
		vpaTxnInfo.setMerchantRequestId(rs.getString("merchant_request_id"));
		vpaTxnInfo.setMerchantCustomerId(rs.getString("merchant_customer_id"));
		vpaTxnInfo.setCustomerMobileNumber(rs.getString("customer_mobile_number"));
		vpaTxnInfo.setPayerVpa(rs.getString("payer_vpa"));
		vpaTxnInfo.setPayeeMcc(rs.getString("payee_mcc"));
		vpaTxnInfo.setPayeeMerchantCustomerId(rs.getString("payee_merchant_customer_id"));
		vpaTxnInfo.setPayeeName(rs.getString("payee_name"));
		vpaTxnInfo.setPayeeVpa(rs.getString("payee_vpa"));
		vpaTxnInfo.setRefUrl(rs.getString("ref_url"));
		vpaTxnInfo.setBankAccountUniqueId(rs.getString("bankAccountUniqueId"));
		vpaTxnInfo.setBankCode(rs.getString("bank_code"));
		vpaTxnInfo.setMaskedAccountNumber(rs.getString("masked_account_number"));
		vpaTxnInfo.setAmount(rs.getDouble("amount"));
		vpaTxnInfo.setTransactionType(rs.getString("transaction_type"));
		vpaTxnInfo.setTransactionTimestamp(rs.getTimestamp("transaction_timestamp"));
		vpaTxnInfo.setOriginalTxnId(rs.getString("original_txn_id"));
		vpaTxnInfo.setGatewayTxnId(rs.getString("gateway_txn_id"));
		vpaTxnInfo.setGatewayResponseStatus(rs.getString("gateway_response_status"));
		vpaTxnInfo.setGatewayReferenceId(rs.getString("gateway_reference_id"));
		vpaTxnInfo.setGatewayResponseCode(rs.getString("gateway_response_code"));
		vpaTxnInfo.setGatewayResponseMessage(rs.getString("gateway_response_message"));
		vpaTxnInfo.setStatus(rs.getString("status"));
		vpaTxnInfo.setMessage(rs.getString("message"));
		vpaTxnInfo.setUpdatedTs(rs.getTimestamp("updated_ts"));
		vpaTxnInfo.setCreatedTs(rs.getTimestamp("created_ts"));
		vpaTxnInfo.setUpiRequestId(rs.getString("upi_request_id"));
	}
	@Override
	public VpaTxnInfo fetchByGatewayTxnId(String gatewayTxnId) {
		VpaTxnInfo vpaTxnInfo = new VpaTxnInfo();
		String db = "select * from vpa_txn_info where gateway_txn_id = ?";
		try {
			return jdbcTemplate.query(db, new PreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement ps) throws SQLException {
					ps.setString(1, gatewayTxnId);
				}
			}, new ResultSetExtractor<VpaTxnInfo>() {
				@Override
				public VpaTxnInfo extractData(ResultSet rs) throws SQLException {
					if (rs.next()) {
						setVpaTxnInfo(vpaTxnInfo, rs);
						return vpaTxnInfo;
					} else {
						return null;
					}
				}

			});

		} catch (EmptyResultDataAccessException e) {
			log.error("Error occurred in VpaTxnDAOImpl : fetchByGatewayTxnId {}", e);
		}
		return vpaTxnInfo;
	}

	@Override
	public void updateVpaTxnInfoById(VpaTxnInfo vpaTxnInfo) {
		log.debug("VpaTxnDAOImpl : updateVpaTxnInfoById : vpaTxnInfo :{}", vpaTxnInfo);
		try {
			jdbcTemplate.update(UPDATE_STATUS_BY_ID, vpaTxnInfo.getStatus(), vpaTxnInfo.getUpdatedTs(),  vpaTxnInfo.getId());
		} catch (DataAccessException e) {
			log.error(EXCEPTION_MSG_UPDATE_STATUS_BY_ID, e);
			throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);
		}
	}

}
