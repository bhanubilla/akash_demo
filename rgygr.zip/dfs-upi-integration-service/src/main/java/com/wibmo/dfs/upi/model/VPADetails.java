package com.wibmo.dfs.upi.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
public class VPADetails {
    @Id
    private Long id;
    private Long accountNumber;
    private String mobileNumber;
    private Long upiCustomerId;// This is merchant_customer_id.
    private String deviceId;
    private String ssid;
    private String deviceFingerprint;
    private String vpa;
    private Boolean isPrimaryVpa;
    private Long linkedAccountId;
    private String status;
    private Boolean active;
    private Long walletId;
    private Timestamp updatedAt;
    private Timestamp createdAt;

}
