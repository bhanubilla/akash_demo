package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayRaiseComplaintUdirRequest {

    private String merchantCustomerId;
    private String merchantRequestId;
    private String upiRequestId;
    private String originalUpiRequestId;
    private String remarks;
    private String adjAmount;
    private String adjFlag;
    private String adjCode;
    private String initiationMode;
    private String purpose;
    private String type;
    private String refUrl;
    private String refCategory;
    private String udfParameters;
}
