package com.wibmo.dfs.upi.model.request;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FetchAccountsRequest {
    private String customerId;
    private String category;
    private int id;
    private boolean lcGrouping;
}
