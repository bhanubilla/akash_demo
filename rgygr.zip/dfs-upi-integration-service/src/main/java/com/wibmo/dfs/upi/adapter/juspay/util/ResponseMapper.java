package com.wibmo.dfs.upi.adapter.juspay.util;

import com.wibmo.dfs.upi.adapter.juspay.model.JuspayRequestMoneyResponse;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayRequestMoneyResponsePayload;
import com.wibmo.dfs.upi.model.response.RequestMoneyResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class ResponseMapper {

    public RequestMoneyResponse map(JuspayRequestMoneyResponse jusPayResponse){
        log.info("== Mapping JuspayRequestMoneyResponse to RequestMoneyResponse ==");
        RequestMoneyResponse requestMoneyResponse = new RequestMoneyResponse();
        setStatusCode(requestMoneyResponse, jusPayResponse.getPayload());
        requestMoneyResponse.setTxnDesc(jusPayResponse.getPayload().getRemarks());
        requestMoneyResponse.setPayerVPA(jusPayResponse.getPayload().getPayerVpa());
        requestMoneyResponse.setPayeeVPA(jusPayResponse.getPayload().getPayeeVpa());
        requestMoneyResponse.setTxnAmount(impliedDecimalString(jusPayResponse.getPayload().getAmount()));
        requestMoneyResponse.setTxnDate(jusPayResponse.getPayload().getTransactionTimestamp());
        return requestMoneyResponse;
    }
    private void setStatusCode(RequestMoneyResponse requestMoneyResponse, JuspayRequestMoneyResponsePayload payload){
        log.info("response code is :: {}",payload.getGatewayResponseCode());
        switch(payload.getGatewayResponseCode())
        {
            case "00":
            case "96":
                requestMoneyResponse.setWibmoResCode(200);
                requestMoneyResponse.setWibmoResDesc("SUCCESS");
                break;
            case "PENDING":
                requestMoneyResponse.setWibmoResCode(150);
                requestMoneyResponse.setWibmoResDesc("PENDING");
                requestMoneyResponse.setWibmoErrorMessage("Request money is in pending");
                break;
            case "Else":
                requestMoneyResponse.setWibmoResCode(100);
                requestMoneyResponse.setWibmoResDesc("FAILURE");
                requestMoneyResponse.setWibmoErrorMessage("Sending collect request failed");
                break;
            default:
                requestMoneyResponse.setWibmoResCode(100);
                requestMoneyResponse.setWibmoResDesc("FAILURE");
                requestMoneyResponse.setWibmoErrorMessage("Something wrong ...");
        }
    }
    private String impliedDecimalString(String decimalValue){
        try{
            decimalValue = decimalValue.replace(".", "");
            log.info("impliedDecimalString :: {}",decimalValue);
            return decimalValue;
        }catch (Exception ex){
            log.info("Exception ex :: {}",ex);
            return null;
        }
    }
}
