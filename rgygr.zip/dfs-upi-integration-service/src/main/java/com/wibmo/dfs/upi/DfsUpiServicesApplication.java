package com.wibmo.dfs.upi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication(scanBasePackages = { "com.wibmo.dfs" })
@Slf4j
public class DfsUpiServicesApplication {

	@Autowired
	private BuildProperties buildProperties;

	@EventListener
	public void handleContextRefresh(ContextRefreshedEvent event) {

	    log.info("Build Version : {}" , buildProperties.getVersion());
	    log.info("Build Release Time: {}" , buildProperties.get("buildReleaseTime"));
	}

	public static void main(String[] args) {
		
		SpringApplication.run(DfsUpiServicesApplication.class, args);
	}
	
	
}
