package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayCommon {
    private String bankCode;
    private String bankName;
    private String maskedAccountNumber;
    private String mpinLength;
    private String mpinSet;
    private String otpLength;
    private String atmPinLength;
    private String type;
    private String ifsc;
    private String name;
    private String bankAccountUniqueId;
}
