package com.wibmo.dfs.upi.model;

import com.wibmo.dfs.upi.adapter.juspay.model.JuspayIncomingCollectPayload;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspaySendMoneyResponsePayload;
import com.wibmo.dfs.upi.adapter.juspay.model.UpiIncomingCollectResponse;
import com.wibmo.dfs.upi.constants.UpiGatewayStatusConstants;

import org.apache.commons.lang3.EnumUtils;
import org.springframework.stereotype.Component;

import com.wibmo.dfs.upi.adapter.juspay.model.JuspaySendMoneyResponse;
import com.wibmo.dfs.upi.model.response.SendMoneyResponse;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SendMoneyResponseMapper {
	public SendMoneyResponse map(JuspaySendMoneyResponse juspaySendMoneyResponse) {
		log.info("Mapping JuspaySendMoney Response to SendMoney Response..");
		SendMoneyResponse response = new SendMoneyResponse();
		response.setStatus(juspaySendMoneyResponse.getStatus());
		response.setResponseCode(juspaySendMoneyResponse.getResponseCode());
		response.setResponseMessage(juspaySendMoneyResponse.getResponseMessage());
		response.setMerchantId(juspaySendMoneyResponse.getPayload().getMerchantId());
		response.setMerchantChannelId(juspaySendMoneyResponse.getPayload().getMerchantChannelId());
		response.setMerchantCustomerId(juspaySendMoneyResponse.getPayload().getMerchantCustomerId());
		response.setMerchantRequestId(juspaySendMoneyResponse.getPayload().getMerchantRequestId());
		String mobileNumber = juspaySendMoneyResponse.getPayload().getCustomerMobileNumber();
		response.setCustomerMobileNumber(mobileNumber.length()==12 ? mobileNumber.substring(2) : mobileNumber);
		response.setPayerVpa(juspaySendMoneyResponse.getPayload().getPayerVpa());
		response.setPayeeMcc(juspaySendMoneyResponse.getPayload().getPayeeMcc());
		response.setPayeeMerchantCustomerId(juspaySendMoneyResponse.getPayload().getPayeeMerchantCustomerId());
		response.setPayeeName(juspaySendMoneyResponse.getPayload().getPayeeName());
		response.setPayeeVpa(juspaySendMoneyResponse.getPayload().getPayeeVpa());
		response.setRefUrl(juspaySendMoneyResponse.getPayload().getRefUrl());
		response.setBankAccountUniqueId(juspaySendMoneyResponse.getPayload().getBankAccountUniqueId());
		response.setBankCode(juspaySendMoneyResponse.getPayload().getBankCode());
		response.setMaskedAccountNumber(juspaySendMoneyResponse.getPayload().getMaskedAccountNumber());
		String amount = juspaySendMoneyResponse.getPayload().getAmount().replace(".","");
		response.setAmount(amount);
		response.setTransactionType(juspaySendMoneyResponse.getPayload().getTransactionType());
		response.setTransactionTimestamp(juspaySendMoneyResponse.getPayload().getTransactionTimestamp());
		response.setGatewayTransactionId(juspaySendMoneyResponse.getPayload().getGatewayTransactionId());
		response.setGatewayReferenceId(juspaySendMoneyResponse.getPayload().getGatewayReferenceId());
		response.setGatewayResponseStatus(juspaySendMoneyResponse.getPayload().getGatewayResponseStatus());
		response.setGatewayResponseCode(juspaySendMoneyResponse.getPayload().getGatewayResponseCode());
		response.setGatewayResponseMessage(juspaySendMoneyResponse.getPayload().getGatewayResponseMessage());
		response.setUdfParameters(juspaySendMoneyResponse.getPayload().getUdfParameters());
		setWibmoStatus(response,juspaySendMoneyResponse.getPayload());
		
		return response;
	}

	private void setWibmoStatus(SendMoneyResponse response , JuspaySendMoneyResponsePayload payload){
		log.info("gateway response is :: {}", payload.getGatewayResponseCode());
		
		String gatewayStatusCode = "SEND_MONEY_" + payload.getGatewayResponseCode();
		
		boolean isEnumExist = EnumUtils.isValidEnum(UpiGatewayStatusConstants.class, gatewayStatusCode);
        if (isEnumExist) {
        	response.setWibmoRespCode(UpiGatewayStatusConstants.valueOf(gatewayStatusCode).getStatusCode());
            response.setWibmoResDesc(UpiGatewayStatusConstants.valueOf(gatewayStatusCode).getStatusMsg());
        } else {
        	response.setWibmoRespCode(UpiGatewayStatusConstants.SEND_MONEY_ELSE.getStatusCode());
            response.setWibmoResDesc(UpiGatewayStatusConstants.SEND_MONEY_ELSE.getStatusMsg());
            
        }
		
	}
}
