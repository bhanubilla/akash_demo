package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class JuspayDeviceBindingRequest {
	private String merchantCustomerId;
	private String smsContent;
	private String deviceId;
	private String manufacturer;
	private String model;
	private String version;
	private String os;
	private String ssid;
	private String mobileNumber;
	private String packageName;
	private String deregisterOldCustomer;
	private String udfParameters;
}
