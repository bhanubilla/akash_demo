package com.wibmo.dfs.upi.constants;

public class RegistrationConstants {

	private RegistrationConstants() {
	}

	public static final String DB_REQUEST_COULD_NOT_BE_PROCESSED = "Database Request could not be processed";

	public static final String REQUEST_COULD_NOT_BE_PROCESSED = "Request could not be processed";

	public static final String MOBILE_MANDATORY = "Mobile number is mandatory";

	public static final String USER_MOBILE_REGISTERED = "User mobile already registered!";

	public static final String ACCOUNT_NUMBER_MANDATORY = "Account Number is mandatory";

	public static final String DEVICE_ID_MANDATORY = "Device id is mandatory";

	public static final String DEVICE_ALREADY_EXISTS = "Device info already exists for deviceId ";

	public static final String DEVICE_MODEL_MANDATORY = "Device model is mandatory";

	public static final String OS_TYPE_MANDATORY = "OS Type is mandatory";

	public static final String OS_VERSION_MANDATORY = "OD Version is mandatory";

	public static final int DAYS_IN_CACHE = 30 * 24 * 60 * 60;

	public static final int ZERO = 0;

	public static final String ERROR ="ERROR : ";

	public static final int APP_LOGOUT = 1;

	public static final int SESSION_LOGOUT = 2;

	public static final int FORCE_LOGOUT = 3;

	public static final String USER_LOGIN_SESSION = "USER_LOGIN|";

	public static final int APP_LOGIN_FOR_AUTH = 1;

	public static final int TXN_LOGIN_FOR_AUTH = 2;

	public static final String ALREADY_LOGGED_IN = "User is Already logged-in ";

	public static final String REQUEST_EMPTY = "REQUEST_EMPTY";

	public static final String REQUEST_VALIDATION_SUCCESS = "Request validation success";

	public static final String REQUEST_VALIDATION_FAILED = "Request validation failed because ";

	public static final String NO_DETAILS_FOUND = " NO details found for the account";

	public static final String INVALID_MOBILE = "Invalid Mobile Number";

	public static final String INVALID_MOBILE_LENGTH = "Mobile Number length should be ";

	public static final int DEVICE_LOCK_ENABLE = 1;

	public static final int DEVICE_LOCK_DISABLE = 0;

	public static final String DEVICE_LOCK_NOT_EXISTS = "Device Lock is not yet enabled for disabling";

	public static final String LOGIN_REGISTERED_DEVICE = "Please logout from previous device and login again !";

	public static final int INVALID_ACCOUNT_NUMBER_CODE = 302;

	public static final String INVALID_ACCOUNT_NUMBER_DESC = "Invalid account number";

	public static final String NOT_LOGGED_IN = "User has not yet logged in";

	public static final String ALGORITHM = "RSA";

	public static final String INVALID_KEYREF = "Invalid Key Ref";

	public static final String SUCCESS = "SUCCESS";

	public static final String FAILURE = "FAILURE";
	
	public static final String INPROCESS = "INPROCESS";
	
	public static final String NOTFOUND = "NOT FOUND";
	
	public static final String YES = "Y";
	
	public static final String NO = "N";
	
	public static final String EMPTY_STRING = "";
	
	public static final String PENDING_DEVICE_BINDING = "PENDING_DEVICE_BINDING";
	
	public static final String PENDING_VPA_CREATION = "PENDING_VPA_CREATION";
	
	public static final String EMPTY_JSON_STRING = "{}";
	
	public static final String TRUE = "true";
	
	public static final String FALSE = "false";
	
	public static final String IND_CURRENCY = "INR";

	public static final int MIN_KYC_LEVEL = 30;
}
