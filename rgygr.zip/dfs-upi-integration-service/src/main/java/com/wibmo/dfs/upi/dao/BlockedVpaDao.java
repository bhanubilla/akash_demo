package com.wibmo.dfs.upi.dao;

import com.wibmo.dfs.upi.entity.BlockedVpaDetails;
import com.wibmo.dfs.upi.model.request.BlockedVpaRequest;
import com.wibmo.dfs.upi.model.request.BlockedVpasRequest;

import java.util.List;

public interface BlockedVpaDao {
      int insertBlockedVpaAccountNumber(String accountNumber, BlockedVpaRequest request, String name);

      void deleteUnblockedVpaByAccountNumber(String accountNumber, BlockedVpaRequest request);

      BlockedVpaDetails fetchBlockedVPA(String accountNumber, BlockedVpaRequest request);

     List<BlockedVpaDetails> fetchBlockedVpaListByAccountNumber(String accountNumber, BlockedVpasRequest request);

    List<BlockedVpaDetails> fetchAllBlockedVpaListByAccNo(String accountNumber);
}
