package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class JuspayDeclineDeviceBindingPayload implements Serializable {
    private String merchantId;
    private String merchantChannelId;
    private String merchantCustomerId;
    private String gatewayResponseCode;
    private String gatewayResponseMessage;
    private String udfParameters;
}
