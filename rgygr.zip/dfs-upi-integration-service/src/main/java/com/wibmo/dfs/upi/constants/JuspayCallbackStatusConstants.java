package com.wibmo.dfs.upi.constants;

import io.swagger.annotations.ApiModelProperty;

public enum JuspayCallbackStatusConstants {
    CBS_CALLBACK_FAILURE_UB("UB","This error will be returned by CBS when CBS Transaction Flow APIs are unavailable or under maintenance"),
    CBS_CALLBACK_FAILURE_PS("PS","This error will be returned by the CBS when the balance of an account on which the credit operation is supposed to be performed will go over prescribed limit");
    @ApiModelProperty(notes = "Status Code", name = "statusCode")
    private final String statusCode;
    @ApiModelProperty(notes = "Status message", name = "statusMsg")
    private final String statusMsg;

    JuspayCallbackStatusConstants(String statusCode, String statusMsg) {
        this.statusCode = statusCode;
        this.statusMsg = statusMsg;
    }

    /**
     * Return the statusCode.
     */
    public String getStatusCode() {
        return this.statusCode;
    }

    /**
     * Return the status msg.
     */
    public String getStatusMsg() {
        return this.statusMsg;
    }
}
