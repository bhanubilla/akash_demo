package com.wibmo.dfs.upi.controller;

import com.wibmo.dfs.upi.model.request.AddVpaRequest;
import com.wibmo.dfs.upi.model.request.DeleteVpaRequest;
import com.wibmo.dfs.upi.model.response.WibmoResponse;
import com.wibmo.dfs.upi.service.UpiService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/upi/account")
@Slf4j
public class UpiAccountManagementController {

    @Autowired
    private UpiService upiService;

    @PostMapping("/v1/addvpa")
    public WibmoResponse accountAddVpa(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber, @RequestBody AddVpaRequest request) {
        log.debug(" calling accountAddVpa method() : ::::::: ");
        return upiService.accountAddVpa(programId, accountNumber, request);
    }

    @PostMapping("/v1/deletevpa")
    public WibmoResponse accountDeleteVpa(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber, @RequestBody DeleteVpaRequest request) {
        log.debug(" calling accountDeleteVpa method() : ::::::: ");
        return upiService.accountDeleteVpa(programId, accountNumber, request);
    }
}
