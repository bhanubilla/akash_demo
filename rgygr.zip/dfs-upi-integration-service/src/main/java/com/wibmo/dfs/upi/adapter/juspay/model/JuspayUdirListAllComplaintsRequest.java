package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayUdirListAllComplaintsRequest {

    private String merchantCustomerId;
    private String startDate;
    private String limit;
    private String offSet;
    private String udfParameters;

}
