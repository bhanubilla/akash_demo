package com.wibmo.dfs.upi.adapter.onboarding;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.upi.entity.TrackingTxnStatus;
import com.wibmo.dfs.upi.model.response.UserProfileResponse;
import com.wibmo.dfs.upi.model.response.WibmoResponse;
import lombok.extern.slf4j.Slf4j;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Component
@Slf4j
public class TxnHistoryMSAdapter {
    public static final String X_PROGRAM_ID = "X-PROGRAM-ID";
    public static final String TXN_ID = "TXN-ID";
    private static final String TXN_TRACKING_URL = "/txnHistory/fetchTxnTrackingDetails";
    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    public DozerBeanMapper dozerBeanMapper;
    @Value("${resource.url.txnHistory}")
    private String txnHistoryBaseUrl;
    public Object fetchUserProfile(String programId, String txnId) {
        try {
            if(txnId.indexOf("PUO")==0){
                txnId = txnId.substring(3);
            }
            String url = txnHistoryBaseUrl + TXN_TRACKING_URL;
            MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
            custHeader.add(X_PROGRAM_ID, programId);
            custHeader.add(TXN_ID, txnId);
            HttpEntity<Object> entity = new HttpEntity<>(custHeader);
            ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(url, HttpMethod.GET, entity,
                    WibmoResponse.class);
            WibmoResponse apiResponse = responseEntity.getBody();
            if (null != apiResponse && apiResponse.getResCode() == 200) {
                return  apiResponse.getData();
            }
        } catch (Exception ex) {
            log.info("Exception in fetchUserProfile :: ",ex);
        }
        return null;
    }
}
