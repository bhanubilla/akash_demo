package com.wibmo.dfs.upi.dao.impl;

import com.wibmo.dfs.upi.constants.RegistrationConstants;
import com.wibmo.dfs.upi.dao.VpaUnblockLogDao;
import com.wibmo.dfs.upi.exception.InternalServerException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.*;

@Repository
@Slf4j
public class VpaUnblockLogDaoImpl implements VpaUnblockLogDao {

    private static final String INSERT_SQL = "INSERT INTO VPA_UNBLOCK_AUDIT_LOG (account_number,vpa,blocked_ts) VALUES(?,?,?)";
    @Autowired
    private JdbcTemplate jdbcTemplate;



    @Override
    public int insertVpaUnblock(String accountNumber, String vpa, Timestamp blockedTs) {
        KeyHolder holder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection->{
                try{
                    PreparedStatement ps = connection.prepareStatement(INSERT_SQL, Statement.RETURN_GENERATED_KEYS);
                    ps.setString(1, accountNumber);
                    ps.setString(2, vpa);
                    ps.setTimestamp(3, blockedTs);

                    return ps;
                }catch (DataAccessException e) {
                    log.error("Error occurred in VpaUnblockLogDaoImpl : insertVpaUnblock {}", e.getMessage());
                    throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);
                }

        },holder);

        int newUserId = 0;
        var userId=holder.getKey();
        if(userId != null){
            newUserId=userId.intValue();
        }

        return newUserId;
    }
}
