package com.wibmo.dfs.upi.validator;
import com.wibmo.dfs.upi.constants.UpiStatusConstants;
import com.wibmo.dfs.upi.model.request.*;
import com.wibmo.dfs.upi.model.response.WibmoResponse;

import lombok.extern.slf4j.Slf4j;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@RefreshScope
public class RequestValidator {

	private String requestEmpty = "request is empty";
	public WibmoResponse validateRequestMoney(RequestMoneyRequest request) {
		WibmoResponse response = null;
		if (StringUtils.isEmpty(request.getPayeeVPA())) {
			log.error("RequestValidation.validatePayeeVpa(), payeeVpa is empty");
			return new WibmoResponse(UpiStatusConstants.PAYEE_VPA_MANDATORY,"PayeeVpa is mandatory");
		}
		if (StringUtils.isEmpty(request.getPayerVPA())) {
			log.error("RequestValidation.validatePayerVpa(), payerVpa is empty");
			return new WibmoResponse(UpiStatusConstants.PAYER_VPA_MANDATORY, "PayerVpa is mandatory");
		}
		if (request.getTxnAmount().isBlank())
			return new WibmoResponse(UpiStatusConstants.INVALID_AMOUNT, "Amount is invalid");
		return response;
	}
	
	public void validateCheckDeviceStatus(CheckDeviceStatusRequest checkDeviceStatusRequest, WibmoResponse response) {
		if (null == checkDeviceStatusRequest) {
			response.setResCode(400);
			response.setResDesc(requestEmpty);
			return;
		} 
		if(response.getResCode() == 0)
			validateDeviceId(checkDeviceStatusRequest.getDeviceId(),  response);
		if (response.getResCode() == 0)
			validateSsid(checkDeviceStatusRequest.getSsid(), response);
		
	}
	
	private void validateDeviceId(String deviceId, WibmoResponse response) {
		if (StringUtils.isBlank(deviceId)) {
			response.setResCode(41);
			response.setResDesc(UpiStatusConstants.DEVICE_ID_IS_EMPTY.getStatusMsg());
		}
	}
	private void validateSsid(List<String> ssid, WibmoResponse response) {
		if (ssid.isEmpty()) {
			response.setResCode(42);
			response.setResDesc(UpiStatusConstants.SSID_IS_EMPTY.getStatusMsg());
		}
	}
	
	public void validateDeviceBinding(DeviceBindingRequest deviceBindingRequest, WibmoResponse response) {
		if (null == deviceBindingRequest) {
			response.setResCode(400);
			response.setResDesc(requestEmpty);
			return;
		}
		
		if (StringUtils.isBlank(deviceBindingRequest.getMobileNumber())) {
			response.setResCode(45);
			response.setResDesc(UpiStatusConstants.MOBILE_NUMBER_IS_EMPTY.getStatusMsg());
		}
	}
	
	public void validateIsVpaAvailable(VpaValidRequest vpaValidRequest, WibmoResponse response) {
		if (null == vpaValidRequest) {
			response.setResCode(400);
			response.setResDesc(requestEmpty);
			return;
		}
		
		if(response.getResCode() == 0)
			validateVpa(vpaValidRequest.getVpa(),  response);
	}
	
	private void validateVpa(String vpa, WibmoResponse response) {
		if (StringUtils.isBlank(vpa)) {
			response.setResCode(44);
			response.setResDesc(UpiStatusConstants.VPA_IS_EMPTY.getStatusMsg());
		}
	}
	
	public void validateLinkVPA(LinkVPARequest linkVPARequest, WibmoResponse response) {
		if (null == linkVPARequest) {
			response.setResCode(400);
			response.setResDesc(requestEmpty);
			return;
		}
		
		if(response.getResCode() == 0)
			validateMobileNumber(linkVPARequest.getMobileNumber(),  response);
	}
	
	private void validateMobileNumber(String mobileNumber, WibmoResponse response) {
		if (StringUtils.isBlank(mobileNumber)) {
			response.setResCode(45);
			response.setResDesc(UpiStatusConstants.MOBILE_NUMBER_IS_EMPTY.getStatusMsg());
		}
	}
	
	public void validateVerifyVpa(VerifyVpaRequest verifyVpaRequest, WibmoResponse response) {
		if (null == verifyVpaRequest) {
			response.setResCode(400);
			response.setResDesc(requestEmpty);
			return;
		}
		
		if(response.getResCode() == 0)
			validateVpa(verifyVpaRequest.getVpa(),  response);
	}

	public void  validateUPITransactionRequest(UPITransactionRequest request, WibmoResponse response){
		if (null == request) {
			response.setResCode(400);
			response.setResDesc(requestEmpty);
		}
	}
	
	
}
