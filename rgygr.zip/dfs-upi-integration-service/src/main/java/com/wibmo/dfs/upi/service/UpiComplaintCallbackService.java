package com.wibmo.dfs.upi.service;

import com.wibmo.dfs.upi.model.response.WibmoResponse;

public interface UpiComplaintCallbackService {
    public WibmoResponse complaintRaiseCallback(String programId, String request);
    public WibmoResponse complaintResolvedCallback(String programId, String request);
    public WibmoResponse cbsComplaintStatusUpdateCallback(String programId, String request);
}
