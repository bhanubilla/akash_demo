package com.wibmo.dfs.upi.controller;

import com.wibmo.dfs.upi.model.response.WibmoResponse;
import com.wibmo.dfs.upi.service.UpiComplaintCallbackService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/upi/callback")
@Slf4j
public class UpiComplaintCallbackController {

    public static final String PROGRAM_ID_REQUEST = "programId :: {}, request :: {}";
    public static final String SUCCESS = "SUCCESS";
    @Autowired
    private UpiComplaintCallbackService upiComplaintCallbackService;
    @PostMapping("/raise")
    public WibmoResponse complaintRaiseCallback(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestBody String request ){
    log.info(PROGRAM_ID_REQUEST,programId,request);
    return upiComplaintCallbackService.complaintRaiseCallback(programId,request);
    }
    @PostMapping("/resolved")
    public WibmoResponse complaintResolvedCallback(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestBody String request ){
        log.info(PROGRAM_ID_REQUEST,programId,request);
        return upiComplaintCallbackService.complaintResolvedCallback(programId,request);
    }

    @PostMapping("/cbsComplaintStatusUpdate")
    public WibmoResponse cbsComplaintStatusUpdateCallback(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestBody String request ){
        log.info(PROGRAM_ID_REQUEST,programId,request);
       return upiComplaintCallbackService.cbsComplaintStatusUpdateCallback(programId, request);
    }

}
