package com.wibmo.dfs.upi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CheckUdirComplaints {

    private String type;
    private String fromDate;
    private String toDate;
    private String status;
    private String offset;
    private String limit;
}
