package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayDeregisterCustomerPayload {
    private String merchantId;
    private String merchantChannelId;
    private String merchantCustomerId;
    private String customerMobileNumber;
}
