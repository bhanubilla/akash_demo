package com.wibmo.dfs.upi.dao;

import java.util.Map;

public interface ProgramParamsDAO {
	
	Map<String, String> getAllProgramParams();
	String fetchParamValueByParamName(String programId, String paramName);
	boolean reloadProgParamValues(String programId, String paramName);

}
