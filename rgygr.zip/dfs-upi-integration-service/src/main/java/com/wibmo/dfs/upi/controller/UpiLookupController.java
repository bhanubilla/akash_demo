package com.wibmo.dfs.upi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wibmo.dfs.upi.model.response.WibmoResponse;
import com.wibmo.dfs.upi.service.UpiService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/upi/lookup")
@Slf4j
public class UpiLookupController {

	@Autowired
	private UpiService upiService;
	
	@GetMapping("/v1/search")
	public WibmoResponse getVpaDetails(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber, @RequestHeader(value="X-MOBILE-NUMBER") String mobileNumber) {
    	log.info("requestMoney method");
    	return upiService.retrieveVpaDetails(programId, accountNumber, mobileNumber);
    }

}
