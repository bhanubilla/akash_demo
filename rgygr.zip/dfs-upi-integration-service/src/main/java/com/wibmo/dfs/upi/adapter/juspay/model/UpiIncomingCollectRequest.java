package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UpiIncomingCollectRequest {
    private String merchantCustomerId;
    private String deviceFingerPrint;
    private String merchantRequestId;
    private String payeeVpa;
    private String payerVpa;
    private String payeeName;
    private String collectType;
    private String amount;
    private String upiRequestId;
    private String requestType;
    private String bankAccountUniqueId;
    private Boolean isAmountBlocked;
    private String currency;
    private String udfParameters;

}
