package com.wibmo.dfs.upi.model.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PendingCollectResponse {
    private String payeeMobileNumber;
    private String payeeVPA;
    private String payeeName;
    private String txnRefNumber;
    private long requestedDate;
    private long expiryDate;
    private String txnMode;
    private String txnAmount;
    private String desc;
}
