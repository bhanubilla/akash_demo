package com.wibmo.dfs.upi.constants;

import io.swagger.annotations.ApiModelProperty;

public enum UpiGatewayStatusConstants {

    VERIFY_VPA_00(510, "Vpa is Verified."),
    VERIFY_VPA_ZH(511, "Invalid vpa"),
    VERIFY_VPA_UX(512, "Expired vpa."),
    VERIFY_VPA_ZE(513, "Transaction not permitted to the vpa by PSP."),
    VERIFY_VPA_ZG(514, "Vpa restricted by the customer."),
    VERIFY_VPA_U17(515, "PSP is not registered i.e invalid vpa handle suffix."),
    VERIFY_VPA_ELSE(516, "Any other reason."),
    SEND_MONEY_00(517, "Payment Success"),
    SEND_MONEY_01(518, "Transaction is in pending state"),
    SEND_MONEY_96(519, "Response timeout (DEEMED APPROVED)"),
    SEND_MONEY_Z9(520, "Insufficient funds in customer (remitter) account.)"),
    SEND_MONEY_Z8(521, "Per transaction limit exceeded as set by remitting member."),
    SEND_MONEY_Z7(522, "Transaction frequency limit exceeded as set by remitting member."),
    SEND_MONEY_Z6(523, "Number of pin tries exceeded."),
    SEND_MONEY_ZM(524, "Invalid mpin."),
    SEND_MONEY_ELSE(525, "Any other reason."),
    REQUEST_MONEY_00(526, "Collect sent successfully."),
    REQUEST_MONEY_01(527, "Transaction is in pending state"),
    REQUEST_MONEY_96(528, "Response timeout (DEEMED APPROVED)"),
    REQUEST_MONEY_ELSE(529, "Sending collect request failed."),
    REQUEST_MONEY_JPCL(555, "Sending collect request failed."),
    TRANSACTION_CALLBACK_00(530, "Payment Success.."),
    TRANSACTION_CALLBACK_01(531, "Payment is in pending state."),
    TRANSACTION_CALLBACK_ZA(532, "Decline Success."),
    TRANSACTION_CALLBACK_U69(533, "Collect request expired."),
    TRANSACTION_CALLBACK_Z9(534, "Insufficient funds in customer (remitter) account."),
    TRANSACTION_CALLBACK_Z8(535, "Per transaction limit exceeded as set by remitting member."),
    TRANSACTION_CALLBACK_Z7(536, "Transaction frequency limit exceeded as set by remitting member."),
    TRANSACTION_CALLBACK_Z6(537, "Number of pin tries exceeded."),
    TRANSACTION_CALLBACK_ZM(538, "Invalid mpin."),
    TRANSACTION_CALLBACK_RB(539, "Transaction went into deemed state."),
    TRANSACTION_CALLBACK_96(540, "Transaction failed."),
    TRANSACTION_CALLBACK_ELSE(541, "Any other reason"),
    SEND_MONEY_JPFL(542, "First transaction limit exceeds 5,000"),
    SEND_MONEY_JPFP(543, "Total transaction in last 24hrs exceeds 5,000"),
    SEND_MONEY_JPPL(544, "Total P2P transaction exceeds 10"),
    SEND_MONEY_JPCL(545, "Total Collect transaction exceeds 5"),
    SEND_MONEY_JPZ8(546, "Per transaction amount for normal case exceeds 1,00,000. / Per transaction amount for P2P Collect exceeds 100000"),
    SEND_MONEY_JPZU(547, " Total Daily Amount per User exceeds / Total P2M Daily Amount per User exceeds"),
    SEND_MONEY_JPML(548, "Total Monthly Amount per User exceeds 10,000. / Total P2M Monthly Amount per User exceeds 20,000")
    ;

    @ApiModelProperty(notes = "Status Code", name = "statusCode")
    private final int statusCode;
    @ApiModelProperty(notes = "Status message", name = "statusMsg")
    private final String statusMsg;

    UpiGatewayStatusConstants(int statusCode, String statusMsg) {
        this.statusCode = statusCode;
        this.statusMsg = statusMsg;
    }

    /**
     * Return the integer statusCode.
     */
    public int getStatusCode() {
        return this.statusCode;
    }

    /**
     * Return the status msg.
     */
    public String getStatusMsg() {
        return this.statusMsg;
    }
}
