package com.wibmo.dfs.upi.adapter.juspay.model;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspaySendMoneyResponse extends JuspayBaseResponse implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private JuspaySendMoneyResponsePayload payload;

}
