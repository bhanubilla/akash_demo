package com.wibmo.dfs.upi.model.request;

import java.io.Serializable;

import lombok.Data;

@Data
public class WalletId implements Serializable {
	private int id;
}
