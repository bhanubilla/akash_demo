package com.wibmo.dfs.upi.dao.impl;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.wibmo.dfs.upi.adapter.juspay.model.JuspayRaiseComplaintUdirPayload;
import com.wibmo.dfs.upi.constants.RegistrationConstants;
import com.wibmo.dfs.upi.dao.UpiDisputeManagementDAO;
import com.wibmo.dfs.upi.entity.DisputeComplaints;
import com.wibmo.dfs.upi.entity.VpaTxnInfoDetails;
import com.wibmo.dfs.upi.exception.InternalServerException;
import com.wibmo.dfs.upi.helper.CommonHelper;
import com.wibmo.dfs.upi.model.CheckUdirComplaints;
import com.wibmo.dfs.upi.model.CheckUdirComplaintStatus;
import com.wibmo.dfs.upi.model.response.UdirComplaintStatusResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.*;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;


@Repository
@Slf4j
public class UpiDisputeManagementDAOImpl implements UpiDisputeManagementDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;
    private static final String INSERT_RAISE_COMPLAINT = "INSERT into dispute_txn_info(account_number,payer_vpa,payee_vpa,merchant_id,merchant_channel_id," +
            "merchant_customer_id,customer_mobile_number,merchant_request_id,req_adj_amount,req_adj_flag,req_adj_code,crn," +
            "gateway_reference_id,gateway_complaint_id,gateway_response_code,gateway_response_status,gateway_response_message,inserted_ts,txn_id)" +
            "values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String RAISE_COMPLAINT_TIME ="select inserted_ts from dispute_txn_info where crn=?";

    @Override
    public int addComplaints(String accountNumber,JuspayRaiseComplaintUdirPayload juspayRaiseComplaintUdirPayload) {
        KeyHolder holder = new GeneratedKeyHolder();
        Timestamp currentDateTime = new Timestamp(new Date().getTime());
        try{
            jdbcTemplate.update(connection -> {
                PreparedStatement ps = connection.prepareStatement(INSERT_RAISE_COMPLAINT, Statement.RETURN_GENERATED_KEYS);
                ps.setString(1, accountNumber);
                ps.setString(2, juspayRaiseComplaintUdirPayload.getPayerVpa());
                ps.setString(3, juspayRaiseComplaintUdirPayload.getPayeeVpa());
                ps.setString(4, juspayRaiseComplaintUdirPayload.getMerchantId());
                ps.setString(5, juspayRaiseComplaintUdirPayload.getMerchantChannelId());
                ps.setString(6, juspayRaiseComplaintUdirPayload.getMerchantCustomerId());
                ps.setString(7, juspayRaiseComplaintUdirPayload.getCustomerMobileNumber());
                ps.setString(8, juspayRaiseComplaintUdirPayload.getMerchantRequestId());
                ps.setDouble(9, Double.parseDouble(juspayRaiseComplaintUdirPayload.getReqAdjAmount()) * 100);
                ps.setString(10, juspayRaiseComplaintUdirPayload.getReqAdjFlag());
                ps.setString(11, juspayRaiseComplaintUdirPayload.getReqAdjCode());
                ps.setString(12, juspayRaiseComplaintUdirPayload.getCrn());
                ps.setString(13, juspayRaiseComplaintUdirPayload.getGatewayReferenceId());
                ps.setString(14, juspayRaiseComplaintUdirPayload.getGatewayComplaintId());
                ps.setString(15, juspayRaiseComplaintUdirPayload.getGatewayResponseCode());
                ps.setString(16, juspayRaiseComplaintUdirPayload.getGatewayResponseStatus());
                ps.setString(17, juspayRaiseComplaintUdirPayload.getGatewayResponseMessage());
                ps.setTimestamp(18, currentDateTime);
                ps.setString(19, juspayRaiseComplaintUdirPayload.getTxnId());
                return ps;
            }, holder);
        }catch (DataAccessException e) {
            log.error("Error occurred in UpiDisputeManagementDAOImpl : addComplaints {}", e.getMessage());
            throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);
        }
        int newUserId =0;
        var userId=holder.getKey();
        if(userId != null)
            newUserId=userId.intValue();
        return newUserId;
    }

    @Override
    public DisputeComplaints fetchComplaintByTxnId(String txnId) {
        try{
            DisputeComplaints disputeComplaints = new DisputeComplaints();
            return jdbcTemplate.query("select * from dispute_txn_info where txn_id = ?", new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setString(1, txnId);
                }
            }, new ResultSetExtractor<DisputeComplaints>() {
                @Override
                public DisputeComplaints extractData(ResultSet rs) throws SQLException {
                    if (rs.next()) {
                        disputeComplaints.setId(rs.getLong("id"));
                        disputeComplaints.setAccountNumber(rs.getString("account_number"));
                        disputeComplaints.setGatewayComplaintId(rs.getString("gateway_complaint_id"));
                        disputeComplaints.setCrn(rs.getString("crn"));
                        return disputeComplaints;
                    } else {
                        return null;
                    }
                }
            });
        }catch(Exception ex){
            log.error("Exception while fetching complaint details by txn id:: {}",ex);
            return null;
        }
    }

    public DisputeComplaints fetchComplaintByGatewayComplaintId(String gatewayComplaintId) {
        try{
            DisputeComplaints disputeComplaints = new DisputeComplaints();
            return jdbcTemplate.query("select * from dispute_txn_info where gateway_complaint_id= ?", new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setString(1, gatewayComplaintId);
                }
            }, new ResultSetExtractor<DisputeComplaints>() {
                @Override
                public DisputeComplaints extractData(ResultSet rs) throws SQLException {
                    if (rs.next()) {
                        disputeComplaints.setId(rs.getLong("id"));
                        disputeComplaints.setAccountNumber(rs.getString("account_number"));
                        disputeComplaints.setTxnId(rs.getString("txn_id"));
                        disputeComplaints.setCrn(rs.getString("crn"));
                        return disputeComplaints;
                    } else {
                        return null;
                    }
                }
            });
        }catch(Exception ex){
            log.error("Exception while fetching complaint details by complaint id:: {}",ex);
            return null;
        }
    }

    @Override
    public Timestamp fetchInsertedTimestamp(String crn) {
        try{
            final Timestamp[] timestamp = new Timestamp[1];
            return jdbcTemplate.query(RAISE_COMPLAINT_TIME, new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setString(1, crn);
                }
            }, new ResultSetExtractor<Timestamp>() {
                @Override
                public Timestamp extractData(ResultSet rs) throws SQLException {
                    if (rs.next()) {
                        timestamp[0] =rs.getTimestamp("inserted_ts");
                        return timestamp[0];
                    } else {
                        return null;
                    }
                }
            });
        }catch(Exception ex){
            log.error("Exception while fetching time details :: {}",ex);
            return null;
        }
    }

}
