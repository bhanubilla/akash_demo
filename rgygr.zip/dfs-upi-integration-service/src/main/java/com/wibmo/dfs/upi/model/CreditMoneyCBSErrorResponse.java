package com.wibmo.dfs.upi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CreditMoneyCBSErrorResponse {

	private static final long serialVersionUID = 1L;
	private String cbsStatus;
	private String cbsResponseCode;
	private String cbsResponseMessage;

}
