package com.wibmo.dfs.upi.adapter.juspay.util;

import java.io.IOException;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.wibmo.dfs.upi.constants.ProgramParamConstants;
import com.wibmo.dfs.upi.dao.ProgramParamsDAO;
import com.wibmo.dfs.upi.exception.UnAuthorizedException;
import com.wibmo.dfs.upi.exception.UpiGenericException;
import com.wibmo.dfs.upi.model.request.VpaValidRequest;
import com.wibmo.dfs.upi.model.response.VpaValidResponse;
import com.wibmo.dfs.upi.model.response.WibmoResponse;
import com.wibmo.dfs.upi.service.UpiService;
import com.wibmo.dfs.upi.service.UpiServiceFactory;

@Component
@Slf4j
public class JusPayUtils {
    public static final String AUTO_VPA_TRY_COUNT = "AUTO_VPA_TRY_COUNT";
    public static final String AGENT_NAME = "AGENT_NAME";
    @Autowired
    ProgramParamsDAO programParamsDAO;
    @Autowired
    UpiServiceFactory upiServiceFactory;
    @Autowired
    UpiService upiService;
    @Value("${vpa-max-try-count:30}")
    private int maxTryCount;

    public String prepareVPA(String programId, String accountNumber,String mobileNumber) throws UnAuthorizedException, UpiGenericException, IOException{
        log.info("JusPayUtils::prepareVPA for programId {}, account number {}, mobile number {}",programId,accountNumber,mobileNumber);
        String vpaString = null;
        String maxTryCountStr = programParamsDAO.fetchParamValueByParamName(programId,AUTO_VPA_TRY_COUNT);
        try{
            maxTryCount = Integer.parseInt(maxTryCountStr);
        }catch (Exception ex){
            log.info("Exception while parsing :: {}",ex);
        }
        for(int tryCount = 0; tryCount < maxTryCount; tryCount++){
            vpaString = checkVPAAvailability(programId, accountNumber, mobileNumber, tryCount);
            if(vpaString != null)
                break;
        }
        log.info("vpaString {}", vpaString);
        return  vpaString;
    }

    private String checkVPAAvailability(String programId, String accountNumber,String mobileNumber, int tryCount){

        String agentName = programParamsDAO.fetchParamValueByParamName(programId, AGENT_NAME);
        String vpaString = null;

        String vpaCitrusAddress = programParamsDAO.fetchParamValueByParamName(programId, ProgramParamConstants.VPA_ADDRESS_PAYU.name());
        if (tryCount == 0)
            vpaString = mobileNumber + "." + agentName + vpaCitrusAddress;
        else if(tryCount < maxTryCount){
            vpaString = mobileNumber + "." + agentName + tryCount + vpaCitrusAddress;
        }else{
            log.info("Max try count reached..");
            return null;
        }
        VpaValidRequest vpaRequest = new VpaValidRequest();
        vpaRequest.setVpa(vpaString);
        WibmoResponse response = upiService.isVpaAvailable(programId,accountNumber,vpaRequest);
        if(response.getResCode()==200) {
            log.info("response is success");
            VpaValidResponse vpaValidResponse = (VpaValidResponse) response.getData();
            if(null!=vpaValidResponse) {
                log.info("vpaValidResponse.isVpaValid {}",vpaValidResponse.isVpaValid());
                if(vpaValidResponse.isVpaValid()){
                    log.info("VPA is available :: {}",vpaString);
                    return vpaString;
                }else {
                    log.info("vpa is invalid :: {} ",vpaString);
                }
            }else{
                log.info("getting null vpaValidResponse");
            }
        }
        return null;
    }

}