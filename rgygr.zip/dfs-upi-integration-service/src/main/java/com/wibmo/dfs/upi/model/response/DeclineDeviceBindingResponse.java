package com.wibmo.dfs.upi.model.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DeclineDeviceBindingResponse {
    private String status;
    private String responseDesc;
}
