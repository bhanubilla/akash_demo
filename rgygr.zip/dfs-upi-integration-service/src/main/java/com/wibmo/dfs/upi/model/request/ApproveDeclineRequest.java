package com.wibmo.dfs.upi.model.request;


import com.wibmo.dfs.upi.adapter.juspay.model.JuspayIncomingOutgoingCommon;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ApproveDeclineRequest extends JuspayIncomingOutgoingCommon {

    private String smsContent;



}
