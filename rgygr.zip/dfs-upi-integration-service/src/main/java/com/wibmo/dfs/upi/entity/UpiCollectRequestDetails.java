package com.wibmo.dfs.upi.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class UpiCollectRequestDetails {
    private long id;
    private String amount;
    private String customResponse;
    private Timestamp expiry;
    private String gatewayReferenceId;
    private String gatewayTransactionId;
    private String isVerifiedPayee;
    private String isMarkedSpam;
    private String merchantCustomerId;
    private String merchantId;
    private String payeeMcc;
    private String payeeMerchantCustomerId;
    private String payeeName;
    private String payeeVpa;
    private String payerMerchantCustomerId;
    private String payerVpa;
    private String collectType;
    private String seqNumber;
    private String refUrl;
    private String remarks;
    private Timestamp transactionTimestamp;
    private String type;
    @JsonIgnore
    private String status;
    @JsonIgnore
    private String createdBy;
    @JsonIgnore
    private String updatedBy;
    @JsonIgnore
    private Timestamp updateTs;
    @JsonIgnore
    private Timestamp createdTs;
    @JsonIgnore
    private String accountNumber;
    @JsonIgnore
    private String payeeMobileNumber;
}
