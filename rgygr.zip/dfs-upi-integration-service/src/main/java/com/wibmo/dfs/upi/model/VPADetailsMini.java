package com.wibmo.dfs.upi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class VPADetailsMini {
	private String vpa;
	private int isPrimaryVpa;
	
}
