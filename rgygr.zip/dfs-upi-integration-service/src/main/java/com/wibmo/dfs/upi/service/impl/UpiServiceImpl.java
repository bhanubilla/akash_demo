package com.wibmo.dfs.upi.service.impl;

import static com.wibmo.dfs.upi.constants.UpiStatusConstants.UPI_REGISTRATION_MINKYC_USER;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import com.wibmo.dfs.upi.adapter.juspay.util.CallbackRequestValidator;
import org.dozer.DozerBeanMapper;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.platform.service.notification.NotificationServiceCall;
import com.wibmo.dfs.platform.service.notification.model.NotificationRequest;
import com.wibmo.dfs.upi.adapter.juspay.util.CommonUtil;
import com.wibmo.dfs.upi.adapter.juspay.util.JusPayUtils;
import com.wibmo.dfs.upi.adapter.onboarding.OnboardingMSAdapter;
import com.wibmo.dfs.upi.constants.Constants;
import com.wibmo.dfs.upi.constants.EventConstants;
import com.wibmo.dfs.upi.constants.ProgramParamConstants;
import com.wibmo.dfs.upi.constants.RegistrationConstants;
import com.wibmo.dfs.upi.constants.UpiGatewayStatusConstants;
import com.wibmo.dfs.upi.constants.UpiStatusConstants;
import com.wibmo.dfs.upi.dao.ProgramParamsDAO;
import com.wibmo.dfs.upi.dao.UpiCollectRequestDAO;
import com.wibmo.dfs.upi.dao.UpiRegistrationDAO;
import com.wibmo.dfs.upi.dao.UpiTransactionDAO;
import com.wibmo.dfs.upi.dao.VPADetailsDAO;
import com.wibmo.dfs.upi.dao.VPALinkedAccountDAO;
import com.wibmo.dfs.upi.entity.UpiCollectRequestDetails;
import com.wibmo.dfs.upi.entity.VpaBasicDetails;
import com.wibmo.dfs.upi.entity.VpaDetails;
import com.wibmo.dfs.upi.exception.UpiGenericException;
import com.wibmo.dfs.upi.model.AlertRequest;
import com.wibmo.dfs.upi.model.MerchantDetails;
import com.wibmo.dfs.upi.model.UserProfileResponse;
import com.wibmo.dfs.upi.model.VPADetails;
import com.wibmo.dfs.upi.model.VPADetailsMini;
import com.wibmo.dfs.upi.model.VPALinkedAccount;
import com.wibmo.dfs.upi.model.VpaRegistrationAudit;
import com.wibmo.dfs.upi.model.request.AddVpaRequest;
import com.wibmo.dfs.upi.model.request.CheckDeviceStatusRequest;
import com.wibmo.dfs.upi.model.request.CheckWalletCardRequest;
import com.wibmo.dfs.upi.model.request.CreateWalletAndLinkRequest;
import com.wibmo.dfs.upi.model.request.DeclineDeviceBindingRequest;
import com.wibmo.dfs.upi.model.request.DeleteVpaRequest;
import com.wibmo.dfs.upi.model.request.DeregisterCustomerRequest;
import com.wibmo.dfs.upi.model.request.DeviceBindingRequest;
import com.wibmo.dfs.upi.model.request.LinkVPARequest;
import com.wibmo.dfs.upi.model.request.PollingRequest;
import com.wibmo.dfs.upi.model.request.RequestMoneyRequest;
import com.wibmo.dfs.upi.model.request.SmsTokenRequest;
import com.wibmo.dfs.upi.model.request.UPITransactionRequest;
import com.wibmo.dfs.upi.model.request.VerifyVpaRequest;
import com.wibmo.dfs.upi.model.request.VpaValidRequest;
import com.wibmo.dfs.upi.model.response.AddVpaResponse;
import com.wibmo.dfs.upi.model.response.CheckDeviceStatusResponse;
import com.wibmo.dfs.upi.model.response.CreateWalletAndLinkResponse;
import com.wibmo.dfs.upi.model.response.DeleteVpaResponse;
import com.wibmo.dfs.upi.model.response.DeregisterCustomerResponse;
import com.wibmo.dfs.upi.model.response.DeviceBindingCallbackResponse;
import com.wibmo.dfs.upi.model.response.DeviceBindingResponse;
import com.wibmo.dfs.upi.model.response.PendingCollectResponse;
import com.wibmo.dfs.upi.model.response.PollingResponse;
import com.wibmo.dfs.upi.model.response.RequestMoneyResponse;
import com.wibmo.dfs.upi.model.response.SendMoneyResponse;
import com.wibmo.dfs.upi.model.response.SmsTokenResponse;
import com.wibmo.dfs.upi.model.response.TransactionStatusCallbackResponse;
import com.wibmo.dfs.upi.model.response.VPADetailsMiniResponse;
import com.wibmo.dfs.upi.model.response.VerifyVpaResponse;
import com.wibmo.dfs.upi.model.response.VpaStatus;
import com.wibmo.dfs.upi.model.response.VpaValidResponse;
import com.wibmo.dfs.upi.model.response.WibmoResponse;
import com.wibmo.dfs.upi.service.UpiService;
import com.wibmo.dfs.upi.service.UpiServiceAdapter;
import com.wibmo.dfs.upi.service.UpiServiceFactory;
import com.wibmo.dfs.upi.validator.RequestValidator;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UpiServiceImpl implements UpiService {

	@Autowired	private UpiServiceFactory upiServiceFactory;
	@Autowired	private UpiRegistrationDAO upiRegistrationDAO;
	@Autowired	private ProgramParamsDAO progParamDao;
	@Autowired	private OnboardingMSAdapter onboardingMSAdapter;
	@Autowired	private JusPayUtils jusPayUtils;
	@Autowired	private VPADetailsDAO vpaDetailsDAO;
	@Autowired	private UpiTransactionDAO upiTransactionDAO;
	@Autowired	private VPALinkedAccountDAO vpaLinkedAccountDAO;
	@Autowired	private RequestValidator requestValidator;
	@Autowired	private DozerBeanMapper dozzerBeanMapper;
	@Autowired	private RestTemplate restTemplate;
	@Autowired	private UpiCollectRequestDAO upiCollectRequestDAO;

	@Autowired
	private CallbackRequestValidator callbackRequestValidator;

	@Value("${resource.url.notification}")
	private String notificationUrl;

	@Value("${resource.url.onboarding}")
	private String onboardingUrl;
	
	@Value("${resource.url.checkWalletCardUrl}")
	private String checkWalletCardUrl;
	
	@Value("${resource.url.wallet}")
	private String walletServiceUrl;
	public static final String FETCH_USER_PROFILE_DETAILS_API_V1 = "/onboarding/userProfile/fetchDetails/v1";


	@Override
	public WibmoResponse isVpaAvailable(String programId, String accountNum, VpaValidRequest request) {
		log.debug("UpiServiceImpl : isVpaAvailable : programId - {} : accountNum - {}", programId, accountNum);
		UpiServiceAdapter upiServiceAdapter = upiServiceFactory.getUpiService(programId);
		WibmoResponse wibmoResponse = null;
		VpaValidResponse vpaValidResponse = new VpaValidResponse();

		try {
			String merchantId = progParamDao.fetchParamValueByParamName(programId, ProgramParamConstants.MERCHANT_ID.getValue());
			String merchantChannelId = progParamDao.fetchParamValueByParamName(programId, ProgramParamConstants.MERCHANT_CHANNEL_ID.getValue());
			String privateKey = progParamDao.fetchParamValueByParamName(programId, ProgramParamConstants.PRIVATE_KEY.getValue());
			MerchantDetails merDetails = new MerchantDetails();
			merDetails.setMerchantId(merchantId);
			merDetails.setMerchantChannelId(merchantChannelId);
			vpaValidResponse = upiServiceAdapter.isVpaAvailable(programId, accountNum, request, merDetails, privateKey);
			if (null != vpaValidResponse) {
				wibmoResponse = new WibmoResponse(200, UpiStatusConstants.SUCCESS.getStatusMsg(), vpaValidResponse);
			}
		} catch (Exception ex) {
			log.error("UpiServiceImpl : isVpaAvailable : accountNumber - {} : Error - {}", accountNum, ex.getMessage());
			if (ex.getMessage().contains(Constants.UNAUTHORIZED)) {
				return new WibmoResponse(UpiStatusConstants.VENDOR_TOKEN_API_UNAUTHORIZED);
			} else if (ex.getMessage().contains("BAD_REQUEST")) {
				return new WibmoResponse(UpiStatusConstants.BAD_REQUEST, vpaValidResponse);
			}
			return new WibmoResponse(UpiStatusConstants.INVALID_DATA, vpaValidResponse);
		}
		return wibmoResponse;
	}

	@Override
	public WibmoResponse getSmsToken(String programId, String accountNum, SmsTokenRequest request) {
		log.debug("UpiServiceImpl : getSmsToken : programId -{} : accountNum -{}", programId, accountNum);
		UpiServiceAdapter upiServiceAdapter = upiServiceFactory.getUpiService(programId);
		WibmoResponse wibmoResponse = null;
		SmsTokenResponse smsTokenResponse = null;
		try {
			com.wibmo.dfs.upi.model.response.UserProfileResponse userProfileResponse = fetchUserProfile(programId, accountNum);
			if(userProfileResponse.getKycLevel()== RegistrationConstants.MIN_KYC_LEVEL) {
				log.debug("User is MinKyc user");
				return new WibmoResponse(UPI_REGISTRATION_MINKYC_USER);
			}
			String merchantId = progParamDao.fetchParamValueByParamName(programId, ProgramParamConstants.MERCHANT_ID.getValue());
			String merchantChannelId = progParamDao.fetchParamValueByParamName(programId, ProgramParamConstants.MERCHANT_CHANNEL_ID.getValue());
			String privateKey = progParamDao.fetchParamValueByParamName(programId, ProgramParamConstants.PRIVATE_KEY.getValue());
			MerchantDetails merDetails = new MerchantDetails();
			merDetails.setMerchantId(merchantId);
			merDetails.setMerchantChannelId(merchantChannelId);
			smsTokenResponse = upiServiceAdapter.getSmsToken(programId, accountNum, request, merDetails, privateKey);
			if (null != smsTokenResponse) {
				wibmoResponse = new WibmoResponse(200, UpiStatusConstants.SUCCESS.getStatusMsg(), smsTokenResponse);
			}
		} catch (Exception ex) {
			log.error("UpiServiceImpl : getSmsToken : accountNumber - {} : Error - {}", accountNum, ex.getMessage());
			if (ex.getMessage().contains(Constants.UNAUTHORIZED)) {
				return new WibmoResponse(UpiStatusConstants.VENDOR_TOKEN_API_UNAUTHORIZED, smsTokenResponse);
			}
			return new WibmoResponse(UpiStatusConstants.VENDOR_TOKEN_API_INTERNAL_SERVER, smsTokenResponse);
		}
		return wibmoResponse;
	}

	public com.wibmo.dfs.upi.model.response.UserProfileResponse fetchUserProfile(String programId, String accountNumber){
		log.info("START OnboardingAdapter:fetchUserProfile===");
		try {
			String url = onboardingUrl + FETCH_USER_PROFILE_DETAILS_API_V1;
			MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
			custHeader.add(Constants.X_PROGRAM_ID, programId);
			custHeader.add(Constants.X_ACCOUNT_NUMBER, accountNumber);
			HttpEntity<Object> entity = new HttpEntity<>(custHeader);
			ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(url, HttpMethod.GET, entity,
					WibmoResponse.class);
			WibmoResponse apiResponse = responseEntity.getBody();
			if (null != apiResponse && apiResponse.getResCode() == 200) {
				return dozzerBeanMapper.map(apiResponse.getData(), com.wibmo.dfs.upi.model.response.UserProfileResponse.class);
			}
		}catch (Exception ex){
			log.error("Exception while fetching user profiles :: ",ex);
		}
		log.info("END OnboardingAdapter:fetchUserProfile===");
		return null;
	}

	@Override
	public WibmoResponse checkDeviceBindingStatus(String programId, int accountNumber,
			CheckDeviceStatusRequest checkDeviceStatusRequest) {
		log.info("UpiServiceImpl : checkDeviceBindingStatus : programId-{}, accountNumber-{}, request- {}", programId, accountNumber, checkDeviceStatusRequest);
		WibmoResponse wibmoResponse = new WibmoResponse();
		try {

			VPALinkedAccount vpaLinkedAccount = vpaLinkedAccountDAO.findByAccountNumber(Long.valueOf(accountNumber));
			List<VpaStatus> list = new ArrayList<>();
			VpaStatus vpaStatus = null;
			List<VpaBasicDetails> vpaBasicDetailsList = upiRegistrationDAO.fetchVpaDetailsBasedOnAccountNo(programId, accountNumber);
			CheckDeviceStatusResponse response = new CheckDeviceStatusResponse();
			int flag = 0;
			for (VpaBasicDetails basicDetails : vpaBasicDetailsList) {
				vpaStatus = new VpaStatus();
				for (String ssid : checkDeviceStatusRequest.getSsid()) {
					if (basicDetails.getDeviceId().equals(checkDeviceStatusRequest.getDeviceId())
							&& basicDetails.getSsid().equals(ssid) && flag == 0) {
						response.setIsValidateDeviceBinding(true);
						flag = 1;
						break;
					}
				}
				vpaStatus.setVpa(basicDetails.getVpa());
				vpaStatus.setIsPrimary(basicDetails.getIsPrimaryVpa() == 1);
				list.add(vpaStatus);
			}

			if(vpaLinkedAccount != null) {
				log.info(" vpaLinkedAccount is present for account :: {}",accountNumber);
				response.setBankAccountNumber(vpaLinkedAccount.getBankAccountNumber());
				response.setBankIfsc(vpaLinkedAccount.getBankIfsc());
			}
			response.setVpaStatus(list);
			wibmoResponse.setResCode(200);
			wibmoResponse.setResDesc(Constants.SUCCESS);
			wibmoResponse.setData(response);
			log.info("UpiServiceImpl : request- {}", response);
		}catch (Exception e){
			log.info("UpiServiceImpl : checkDeviceBindingStatus : Error - {}",e.getMessage());
			wibmoResponse.setResCode(100);
			wibmoResponse.setResDesc("Please try again after sometime");
		}
		return wibmoResponse;
	}

	@Override
	public WibmoResponse deviceBinding(String programId, int accountNumber, DeviceBindingRequest deviceBindingRequest)
			throws UpiGenericException {
		log.debug("UpiServiceImpl : deviceBinding : programId -{} : accountNum -{}", programId, accountNumber);

		UpiServiceAdapter upiServiceAdapter = upiServiceFactory.getUpiService(programId);
		WibmoResponse wibmoResponse = null;
		DeviceBindingResponse deviceBindingResponse = null;
		
		try {
			String merchantId = progParamDao.fetchParamValueByParamName(programId, ProgramParamConstants.MERCHANT_ID.getValue());
			String merchantChannelId = progParamDao.fetchParamValueByParamName(programId, ProgramParamConstants.MERCHANT_CHANNEL_ID.getValue());
			String privateKey = progParamDao.fetchParamValueByParamName(programId, ProgramParamConstants.PRIVATE_KEY.getValue());
			MerchantDetails merDetails = new MerchantDetails();
			merDetails.setMerchantId(merchantId);
			merDetails.setMerchantChannelId(merchantChannelId);
			deviceBindingResponse = upiServiceAdapter.deviceBinding(programId, String.valueOf(accountNumber), deviceBindingRequest, merDetails, privateKey);
			if (null != deviceBindingResponse) {
				wibmoResponse = new WibmoResponse(203, UpiStatusConstants.DEVICE_BINDING_SUCCESS.getStatusMsg(), deviceBindingResponse);
			}

		} catch (Exception ex) {
			log.error("UpiServiceImpl : deviceBinding : accountNumber - {} : Error - {}", accountNumber, ex.getMessage(), ex);
			if (ex.getMessage().contains(UpiStatusConstants.SMS_VERIFICATION_EXPIRED.toString())) {
				return new WibmoResponse(UpiStatusConstants.SMS_VERIFICATION_EXPIRED);
			}
			if (ex.getMessage().contains(UpiStatusConstants.SMS_VERIFICATION_PENDING.toString())) {
				return new WibmoResponse(UpiStatusConstants.SMS_VERIFICATION_PENDING);
			}
			if (ex.getMessage().contains(Constants.UNAUTHORIZED)) {
				return new WibmoResponse(UpiStatusConstants.VENDOR_TOKEN_API_UNAUTHORIZED);
			}
			if (ex.getMessage().contains(UpiStatusConstants.INVALID_SMS_CONTENT.getStatusMsg())) {
				return new WibmoResponse(UpiStatusConstants.INVALID_SMS_CONTENT);
			}
			if (ex.getMessage().contains(UpiStatusConstants.SMS_VERIFICATION_MISMATCH.toString())) {
				return new WibmoResponse(UpiStatusConstants.SMS_VERIFICATION_MISMATCH);
			}

			return new WibmoResponse(UpiStatusConstants.FAILURE);
		}
		return wibmoResponse;
	}

	@Override
	public WibmoResponse createAndLink(String programId, String accountNumber, LinkVPARequest linkVPARequest)
			throws UpiGenericException {
		WibmoResponse wibmoResponse = null;
		try {
			CreateWalletAndLinkRequest request = new CreateWalletAndLinkRequest();
			
			
			String mobileNo = linkVPARequest.getMobileNumber();
			String updatedMobileNo = null;
			if (mobileNo.length() == 12 && mobileNo.subSequence(0, 2).equals("91")) {
				updatedMobileNo = mobileNo.substring(2);
				linkVPARequest.setMobileNumber(updatedMobileNo);
			}
			
			com.wibmo.dfs.upi.model.response.UserProfileResponse userProfileResponse = onboardingMSAdapter.fetchUserProfile(programId, accountNumber);
			
			String vpaName = jusPayUtils.prepareVPA(programId, accountNumber, linkVPARequest.getMobileNumber());
			if(vpaName==null) {
				return new WibmoResponse(UpiStatusConstants.FAILURE);
			}
			request.setCustomerVpa(vpaName);
			request.setAccountNumber(accountNumber);
			request.setKycStatus(userProfileResponse.getKycLevel() == 100 ? "FULL" : "MIN");
			request.setName(userProfileResponse.getFirstName() + userProfileResponse.getLastName());
			request.setType(Constants.WALLET_TYPE_PPIWALLET);
			if (linkVPARequest.getUdfParams() == null || linkVPARequest.getUdfParams().isEmpty()) {
				request.setUdfParameters(new JSONObject().toString());
			} else
				request.setUdfParameters(linkVPARequest.getUdfParams());

			UpiServiceAdapter upiServiceAdapter = upiServiceFactory.getUpiService(programId);
			CreateWalletAndLinkResponse createWalletAndLinkResponse = upiServiceAdapter.createAndLink(programId, accountNumber, request);
			ObjectMapper obj = new ObjectMapper();
			String reqJson = obj.writeValueAsString(createWalletAndLinkResponse);
			log.info("createWalletAndLinkResponse: {}", reqJson);
			if (createWalletAndLinkResponse.getStatus().equals("SUCCESS")) {
				log.info("calling notification service to send notification alert to user regarding upi registration success");
				Map<String, String> placeHolder = new HashMap<>();
		        placeHolder.put("OTP_VALUE", "");
				NotificationRequest aRequest = NotificationRequest.builder()
		                .mobileNumber(mobileNo)
		                .programId(Integer.valueOf(programId))
		                .eventId(EventConstants.UPI_REGISTRATION_ALERT_EVENT)
		                .emailId(userProfileResponse.getEmailId())
		                .whatsappEnabled(false)
		                .placeHolders(placeHolder).build();
				NotificationServiceCall notificationServiceCall = new NotificationServiceCall();
		        notificationServiceCall.send(aRequest, notificationUrl);
				return new WibmoResponse(200, UpiStatusConstants.SUCCESS.getStatusMsg(), createWalletAndLinkResponse);
			} else
				return wibmoResponse;
		} catch (Exception ex) {
			log.error("UpiServiceImpl : createAndLink : accountNumber - {} : Error - {}", accountNumber, ex.getMessage());
			return new WibmoResponse(UpiStatusConstants.FAILURE);
		}
	}

	@Override
	public WibmoResponse pollingForVPAStatus(String programId, int accountNumber, PollingRequest pollingRequest)
			throws UpiGenericException {
		WibmoResponse wibmoResponse = new WibmoResponse();
		log.info("UpiServiceImpl : pollingForVPAStatus : programId-{}, accountNumber-{}, request- {}", programId, accountNumber, pollingRequest);
		VpaRegistrationAudit vpaRegistrationAudit = upiRegistrationDAO.fetchVpaRegistrationLogInfoByRefId(pollingRequest.getRefNumber());
		PollingResponse response = new PollingResponse();
		response.setVpa(vpaRegistrationAudit.getVpa());
		if (vpaRegistrationAudit.getStatus() != null) {
			wibmoResponse.setResCode(UpiStatusConstants.valueOf(vpaRegistrationAudit.getStatus()).getStatusCode());
			wibmoResponse.setResDesc(UpiStatusConstants.valueOf(vpaRegistrationAudit.getStatus()).getStatusMsg());
		}
		wibmoResponse.setData(response);
		log.info("UpiServiceImpl : pollingForVPAStatus : response- {}", response);
		return wibmoResponse;
	}

	@Override
	public WibmoResponse declineDeviceBinding(String programId, String accountNumber,
			DeclineDeviceBindingRequest declineDeviceBinding) {
		log.debug("UpiServiceImpl : declineDeviceBinding : programId -{} : accountNum -{}", programId, accountNumber);
		WibmoResponse wibmoResponse = null;
		try {
			wibmoResponse = new WibmoResponse(UpiStatusConstants.SUCCESS.getStatusCode(), UpiStatusConstants.SUCCESS.name());
		} catch (Exception ex) {
			log.error("UpiServiceImpl : declineDeviceBinding : accountNumber - {} : Error - {}", accountNumber, ex.getMessage(), ex);
			wibmoResponse = new WibmoResponse();
			wibmoResponse.setResCode(100);
			wibmoResponse.setResDesc(ex.getMessage());
			if (null != ex.getCause() && null != ex.getCause().getMessage())
				wibmoResponse.setErrorMessage(ex.getCause().getMessage());
			return wibmoResponse;
		}
		return wibmoResponse;
	}

	@Override
	public WibmoResponse deviceStatusCallback(String programId, String request) {
		log.debug("UpiServiceImpl : deviceStatus : programId -{}", programId);
		WibmoResponse validation  = callbackRequestValidator.validateCustomerDeviceBinding(request);
		if (null != validation) {
			log.info("Bad request received from vendor");
			return validation;
		}
		UpiServiceAdapter upiServiceAdapter = upiServiceFactory.getUpiService(programId);
		if (upiServiceAdapter == null) {
			return new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), UpiStatusConstants.FAILURE.name(), Constants.UPI_VENDOR_NOT_FOUND_ERROR);
		}
		WibmoResponse wibmoResponse = null;
		try {
			DeviceBindingCallbackResponse deviceBindingCallbackResponse = upiServiceAdapter.handleDeviceBindingCallback(programId, request);
			log.info("..... deviceBindingCallbackResponse ....{} :: ",deviceBindingCallbackResponse);
			if (null != deviceBindingCallbackResponse) {
				processByStatus(programId, deviceBindingCallbackResponse);
				wibmoResponse = new WibmoResponse(UpiStatusConstants.SUCCESS.getStatusCode(), UpiStatusConstants.SUCCESS.name(), deviceBindingCallbackResponse);
			} else {
				wibmoResponse = new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), UpiStatusConstants.FAILURE.name(), Constants.UPI_VENDOR_ISSUE);
			}
		} catch (Exception ex) {
			log.error("UpiServiceImpl : deviceStatus : Error - {}", ex.getMessage());
			wibmoResponse = new WibmoResponse();
			wibmoResponse.setResCode(150);
			wibmoResponse.setResDesc(ex.getMessage());
			if (null != ex.getCause() && null != ex.getCause().getMessage())
				wibmoResponse.setErrorMessage(ex.getCause().getMessage());
			return wibmoResponse;
		}

		return wibmoResponse;
	}

	/**
	 *
	 * @param programId
	 * @param deviceBindingCallbackResponse If status is Verified then we are
	 *                                      creating VPA Details
	 */
	private void processByStatus(String programId, DeviceBindingCallbackResponse deviceBindingCallbackResponse) {
		try {
			log.info(" processByStatus :: {}",deviceBindingCallbackResponse);
			if (UpiStatusConstants.VERIFIED.name().equalsIgnoreCase(deviceBindingCallbackResponse.getStatus())) {
				VPADetails vpaDetails = vpaDetailsDAO
						.fetchVpaDetailsInfoByAccnoAndMobileAndMerchantcustid(deviceBindingCallbackResponse.getRefId());
				log.info("vpaDetails :: {}",vpaDetails);
				if (vpaDetails.getId() != null) {
					vpaDetailsDAO.updateVpaDetails(deviceBindingCallbackResponse.getSsid(),
							deviceBindingCallbackResponse.getDeviceFingerPrint(), deviceBindingCallbackResponse.getDeviceId(),
							vpaDetails.getId());
				} else {
					log.debug("inside processByStatus : verified");
					VpaRegistrationAudit logTable = null;
					LinkVPARequest linkVPARequest = new LinkVPARequest();
					String mobileNo = deviceBindingCallbackResponse.getMobileNumber();
					String updatedMobileNo = null;
					if (mobileNo.length() == 12 && mobileNo.subSequence(0, 2).equals("91")) {
						updatedMobileNo = mobileNo.substring(2);
						deviceBindingCallbackResponse.setMobileNumber(updatedMobileNo);
					}
					linkVPARequest.setMobileNumber(deviceBindingCallbackResponse.getMobileNumber());
					WibmoResponse response = createAndLink(programId, deviceBindingCallbackResponse.getAccountNumber(),
							linkVPARequest);
					CreateWalletAndLinkResponse createWalletAndLinkResponse = (CreateWalletAndLinkResponse) response
							.getData();
					VPADetails vpaDetail = null;
					// updating VPA
					upiRegistrationDAO.updateVpaRegistrationLogByRefID(createWalletAndLinkResponse.getVpa(),
							deviceBindingCallbackResponse.getRefId());
					// fetching VPA_REG
					logTable = upiRegistrationDAO
							.fetchVpaRegistrationLogInfoByRefId(deviceBindingCallbackResponse.getRefId());
					// inserting records in VPA_Details
					vpaDetail = vpaDetailsDAO.findByUpiCustomerId(logTable.getAccountNumber());
					if (vpaDetail == null) {
						saveVpaDetailsInDB(deviceBindingCallbackResponse, createWalletAndLinkResponse, logTable, programId);
					}

				}
			} else {
				log.debug("inside processByStatus : other status that Success");
				// updating VPA Reg Log Status
				upiRegistrationDAO.updateVpaRegLogByRefID(deviceBindingCallbackResponse.getStatus(),
						deviceBindingCallbackResponse.getRefId());
			}
		} catch (Exception e) {
			log.error("Exception while processByStatus : {}", e);
		}
	}

	/**
	 *
	 * @param deviceBindingCallbackResponse
	 * @param createWalletAndLinkResponse   saving vpa details in DB
	 */
	private void saveVpaDetailsInDB(DeviceBindingCallbackResponse deviceBindingCallbackResponse,
			CreateWalletAndLinkResponse createWalletAndLinkResponse, VpaRegistrationAudit vpaRegLog, String programId) {
		VPADetails vpaDetails = new VPADetails();
		VPALinkedAccount vpaLinkedAccount = null;
		// populating vpaDetails info
		vpaDetails.setAccountNumber(Long.valueOf(deviceBindingCallbackResponse.getAccountNumber()));
		vpaDetails.setMobileNumber(deviceBindingCallbackResponse.getMobileNumber());
		vpaDetails.setUpiCustomerId(Long.valueOf(deviceBindingCallbackResponse.getAccountNumber()));
		vpaDetails.setDeviceId(vpaRegLog != null ? vpaRegLog.getDeviceId() : null);
		vpaDetails.setSsid(vpaRegLog != null ? vpaRegLog.getSsid() : null);
		vpaDetails.setDeviceFingerprint(vpaRegLog != null ? vpaRegLog.getDeviceFingerPrint() : null);
		vpaDetails.setVpa(createWalletAndLinkResponse.getVpa());
		vpaDetails.setIsPrimaryVpa(Boolean.TRUE);
		vpaDetails.setStatus(deviceBindingCallbackResponse.getStatus());
		// Query to fetch vpaLinkedAccount details
		vpaLinkedAccount = vpaLinkedAccountDAO.fetchVpaLinkedByBankId(createWalletAndLinkResponse.getBankUniqueId());
		vpaDetails.setLinkedAccountId(vpaLinkedAccount != null ? vpaLinkedAccount.getId() : null);
		vpaDetails.setActive(Boolean.TRUE);
		
		// Query to fetch walletId details
		CheckWalletCardRequest checkWalletCardRequest = new CheckWalletCardRequest();
		checkWalletCardRequest.setMobile(deviceBindingCallbackResponse.getMobileNumber());
		checkWalletCardRequest.setCustomerId(deviceBindingCallbackResponse.getAccountNumber());
		checkWalletCardRequest.setProductType("RW");
		
		String url = walletServiceUrl + checkWalletCardUrl;
		MultiValueMap<String, String> customHeader = new LinkedMultiValueMap<>();
		customHeader.add("Content-Type", "application/json");
		customHeader.add("X-PROGRAM-ID", programId);
		customHeader.add("X-ACCOUNT-NUMBER", deviceBindingCallbackResponse.getAccountNumber());
		log.info("wallet url :: {}",url);
		HttpEntity<Object> entity = new HttpEntity<>(checkWalletCardRequest, customHeader);
		long walId = 0;
		try {
			ObjectMapper obj = new ObjectMapper();
			String reqJson = obj.writeValueAsString(checkWalletCardRequest);
			log.debug("sending request to get wallet id details from Wallet MS : ", reqJson );
			ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(url, HttpMethod.POST, entity,
					WibmoResponse.class);
			WibmoResponse wibmoResponse = responseEntity.getBody();
			log.info(" wibmoResponse for wallet id :: {}",responseEntity.getBody());
			if (wibmoResponse!=null && wibmoResponse.getData() != null) {
				walId= Long.valueOf(wibmoResponse.getData().toString());
				if (walId != 0) {
					vpaDetails.setWalletId(walId);
				}
			}
			log.info("response from wallet ms : wallet id : ", walId );
		} catch (Exception e) {
			log.error("error in fetching walletId details from walletService");
		}
		log.info("saving data into vpa_details DB");
		vpaDetailsDAO.saveVpaDetails(vpaDetails);
	}

	@Override
	public WibmoResponse verifyVpa(String programId, VerifyVpaRequest verifyVpaRequest) {
		log.debug("UpiServiceImpl : verifyVpa : programId -{}, verifyVpaRequest -{} ", programId, verifyVpaRequest);
		UpiServiceAdapter upiServiceAdapter = upiServiceFactory.getUpiService(programId);
		WibmoResponse wibmoResponse = new WibmoResponse();
		try {
			VerifyVpaResponse verifyVpaResponse = upiServiceAdapter.verifyVpa(programId, verifyVpaRequest);
			wibmoResponse.setResCode(UpiGatewayStatusConstants.valueOf(verifyVpaResponse.getCustomGatewayStatusCode()).getStatusCode());
			wibmoResponse.setResDesc(UpiGatewayStatusConstants.valueOf(verifyVpaResponse.getCustomGatewayStatusCode()).getStatusMsg());
			wibmoResponse.setData(verifyVpaResponse);
			ObjectMapper obj = new ObjectMapper();
			String reqJson = obj.writeValueAsString(verifyVpaResponse);
			log.debug("UpiServiceImpl : verifyVpa : VerifyVpaResponse : {}",reqJson);
		} catch (Exception ex) {
			log.error("UpiServiceImpl : verifyVpa : Error - {}", ex.getMessage(), ex);
			wibmoResponse = new WibmoResponse();
			wibmoResponse.setResCode(150);
			if (null != ex.getCause() && null != ex.getCause().getMessage())
				wibmoResponse.setResDesc(ex.getCause().getMessage());
		}
		return wibmoResponse;
	}

	@Override
	public WibmoResponse sendMoney(String programId, String accountNumber, UPITransactionRequest req) {
		log.debug("UpiServiceImpl : sendMoney : programId -{} ", programId);
		UpiServiceAdapter upiServiceAdapter = upiServiceFactory.getUpiService(programId);
		SendMoneyResponse sendMoneyResponse = null;
		WibmoResponse wibmoResponse = new WibmoResponse();

		try {
			String merchantId = progParamDao.fetchParamValueByParamName(programId, ProgramParamConstants.MERCHANT_ID.getValue());
			String merchantChannelId = progParamDao.fetchParamValueByParamName(programId, ProgramParamConstants.MERCHANT_CHANNEL_ID.getValue());
			String privateKey = progParamDao.fetchParamValueByParamName(programId, ProgramParamConstants.PRIVATE_KEY.getValue());
			MerchantDetails merDetails = new MerchantDetails();
			merDetails.setMerchantId(merchantId);
			merDetails.setMerchantChannelId(merchantChannelId);

			VPALinkedAccount vpaLinkedAccount = vpaLinkedAccountDAO.findByAccountNumber(Long.valueOf(accountNumber));
			if (vpaLinkedAccount == null) {
				wibmoResponse.setResCode(511);
				log.error("linked account not exists for this account");
				wibmoResponse.setData(Constants.LINKED_ACCOUNT_NOT_FOUND);
				return wibmoResponse;
			}
			VPADetails vpaDetails = vpaDetailsDAO.findByUpiCustomerId(Long.valueOf(accountNumber));
			if (vpaDetails == null) {
				log.error("VPA details not found for this mobile");
				wibmoResponse.setResCode(511);
				wibmoResponse.setData(Constants.VPA_DETAILS_NOT_FOUND_FOR_MOBILE);
				return wibmoResponse;
			}
			req.setDeviceFingerprint(vpaDetails.getDeviceFingerprint());
			req.setBankAccountUniqueId(vpaLinkedAccount.getBankAccUniqueId());
			req.setPayerVpa(vpaDetails.getVpa());

			sendMoneyResponse = upiServiceAdapter.sendMoney(programId, accountNumber, req, merDetails, privateKey);

			wibmoResponse.setResCode(sendMoneyResponse.getWibmoRespCode());
			wibmoResponse.setResDesc(sendMoneyResponse.getWibmoResDesc());
			wibmoResponse.setData(sendMoneyResponse);
			ObjectMapper obj = new ObjectMapper();
			String reqJson = obj.writeValueAsString(wibmoResponse);
			log.info("UpiServiceImpl :: sendMoney : WibmoResponse : {}", reqJson);
		} catch (Exception ex) {
			log.error("UpiServiceImpl : sendMoney : accountNumber - {} : Error - {}", accountNumber, ex);
			wibmoResponse.setResCode(100);
			wibmoResponse.setResDesc("Send money failed");
			return wibmoResponse;

		}

		return wibmoResponse;
	}

	@Override
	public WibmoResponse requestMoney(String programId, String accountNumber, RequestMoneyRequest request) {
		long startTime  = new Date().getTime();
		log.info("===== requestMoney ======");
		UpiServiceAdapter upiServiceAdapter = upiServiceFactory.getUpiService(programId);
		WibmoResponse wibmoResponse = new WibmoResponse();
		WibmoResponse validateResponse = requestValidator.validateRequestMoney(request);
		if(validateResponse!=null)
			return validateResponse;
		VerifyVpaRequest verifyPayeeVpaRequest = new VerifyVpaRequest();
		verifyPayeeVpaRequest.setVpa(request.getPayeeVPA());
		WibmoResponse payeeResponse = verifyVpa(programId,verifyPayeeVpaRequest);
		if(payeeResponse.getResCode()!=UpiGatewayStatusConstants.VERIFY_VPA_00.getStatusCode())
			return new WibmoResponse(UpiStatusConstants.INVALID_PAYEE_VPA, "Payee VPA verification failed");
		VerifyVpaResponse verifyVpaResponse = VerifyVpaResponse.class.cast(payeeResponse.getData());
		request.setPayeeName(verifyVpaResponse.getName());
		VerifyVpaRequest verifyPayerVpaRequest = new VerifyVpaRequest();
		verifyPayerVpaRequest.setVpa(request.getPayerVPA());
		WibmoResponse payerResponse = verifyVpa(programId, verifyPayerVpaRequest);
		VPADetails vpaDetails = vpaDetailsDAO.findByAccountNumber(Long.parseLong(accountNumber));
		if (payerResponse.getResCode() != UpiGatewayStatusConstants.VERIFY_VPA_00.getStatusCode()
				|| !request.getPayeeVPA().equals(vpaDetails.getVpa()))
			return new WibmoResponse(UpiStatusConstants.INVALID_PAYER_VPA, "Invalid Payee VPA passed");
		verifyVpaResponse = VerifyVpaResponse.class.cast(payerResponse.getData());
		log.info("Payer VPA name :: {}", verifyVpaResponse.getName());
		request.setPayerName(verifyVpaResponse.getName());
		try {
			String agentName = progParamDao.fetchParamValueByParamName(programId, ProgramParamConstants.AGENT_NAME.getValue());
			String vpaAddress = progParamDao.fetchParamValueByParamName(programId, ProgramParamConstants.VPA_ADDRESS_PAYU.name());
			RequestMoneyResponse response = upiServiceAdapter.requestMoney(programId, accountNumber, request);
			wibmoResponse.setResCode(response.getWibmoResCode());
			wibmoResponse.setResDesc(response.getWibmoResDesc());
			if (response.getWibmoResCode() == 200) {
				wibmoResponse.setData(response);
			}
			else
				wibmoResponse.setErrorMessage(response.getWibmoErrorMessage());
		} catch (Exception ex) {
			log.error("UpiServiceImpl : requestMoney : Error - {}", ex.getMessage(), ex);
			wibmoResponse.setResCode(100);
			wibmoResponse.setResDesc(ex.getMessage());
			if (null != ex.getCause() && null != ex.getCause().getMessage())
				wibmoResponse.setErrorMessage(ex.getCause().getMessage());
			return wibmoResponse;
		}
		long endTime  = new Date().getTime();
		log.info("time taken :: {}",endTime-startTime);
		return wibmoResponse;
	}

	@Override
	public WibmoResponse listPendingCollectRequests(String programId, String accountNumber) {
		log.debug("UpiServiceImpl : listPendingCollectRequests : programId -{}, accNo -{} ", programId, accountNumber);
		WibmoResponse wibmoResponse = new WibmoResponse();
		try {
			List<PendingCollectResponse> pendingCollectResponses = new ArrayList<>();
			VPADetails vpaDetails = vpaDetailsDAO.findByAccountNumber(Long.parseLong(accountNumber));
			String programParams = progParamDao.fetchParamValueByParamName(programId, Constants.COLLECT_REQ_EXP_MINUTES);
			long expiryTimeInMin = Long.parseLong(programParams);
			log.info("expiryTimeInMin :: {}", expiryTimeInMin);
			String vpa = vpaDetails.getVpa();
			List<UpiCollectRequestDetails> upiCollectRequestDetails = upiCollectRequestDAO.fetchPendingCollectRequest(vpa);
			List<UpiCollectRequestDetails> upiList;
			if (upiCollectRequestDetails != null && !upiCollectRequestDetails.isEmpty()) {
				log.info("Iterating txn list");
				upiList = upiCollectRequestDetails.stream().
						collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(
								Comparator.comparing(UpiCollectRequestDetails::getGatewayTransactionId)
						)), ArrayList::new));
				upiList.stream().sorted((o1, o2) -> o2.getCreatedTs().compareTo(o1.getCreatedTs())).forEach(upiCollectRequestRow -> {
					PendingCollectResponse pendingCollectResponse = new PendingCollectResponse();
					pendingCollectResponse.setTxnRefNumber(upiCollectRequestRow.getGatewayTransactionId());
					pendingCollectResponse.setDesc(upiCollectRequestRow.getRemarks());
					Timestamp createTimeStamp = upiCollectRequestRow.getCreatedTs();
					pendingCollectResponse.setRequestedDate(createTimeStamp.getTime());
					pendingCollectResponse.setExpiryDate(createTimeStamp.getTime() + (expiryTimeInMin * 60 * 1000));
					pendingCollectResponse.setPayeeName(upiCollectRequestRow.getPayeeName());
					pendingCollectResponse.setPayeeVPA(upiCollectRequestRow.getPayeeVpa());
					pendingCollectResponse.setTxnAmount(upiCollectRequestRow.getAmount());
					pendingCollectResponse.setTxnMode(Constants.TXN_TYPE_UPI);
					if (!checkExpiredRecord(upiCollectRequestRow, expiryTimeInMin)) {
						pendingCollectResponses.add(pendingCollectResponse);
					} else {
						upiCollectRequestDAO.updateStatusRemarksByGatewayTxnId(Constants.DECLINE, Constants.EXPIRED, upiCollectRequestRow.getGatewayTransactionId());
					}
				});
			}
			wibmoResponse.setResCode(200);
			wibmoResponse.setResDesc("SUCCESS");
			wibmoResponse.setData(pendingCollectResponses);
			log.debug("UpiServiceImpl : listPendingCollectRequests : Response - {}", pendingCollectResponses);
		} catch (Exception ex) {
			log.error("UpiServiceImpl : listPendingCollectRequests : Error - {}", ex);
			wibmoResponse = new WibmoResponse();
			wibmoResponse.setResCode(100);
			wibmoResponse.setResDesc(Constants.FETCH_FAILED_FOR_PENDING_COLLECT_REQUEST);
			if (null != ex.getCause() && null != ex.getCause().getMessage())
				wibmoResponse.setErrorMessage(ex.getCause().getMessage());
			return wibmoResponse;
		}
		return wibmoResponse;
	}

	@Override
	public WibmoResponse transactionStatusCallback(String programId, String request) {
		log.debug("UpiServiceImpl : transactionStatusCallback : programId -{}, request -{}", programId, request);
		WibmoResponse validation  = callbackRequestValidator.validateTransactionStatusCallback(request);
		if (null != validation) {
			log.info("Bad request received from vendor");
			return validation;
		}
		UpiServiceAdapter upiServiceAdapter = upiServiceFactory.getUpiService(programId);
		if (upiServiceAdapter == null) {
			return new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), UpiStatusConstants.FAILURE.name(),
					Constants.UPI_VENDOR_NOT_FOUND_ERROR);
		}
		WibmoResponse wibmoResponse = null;
		try {
			TransactionStatusCallbackResponse transactionStatus = upiServiceAdapter.handleTransactionStatusCallback(programId, request);
			if (transactionStatus != null) {
				wibmoResponse = new WibmoResponse(UpiStatusConstants.SUCCESS.getStatusCode(), UpiStatusConstants.SUCCESS.name());
			} else {
				wibmoResponse = new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), UpiStatusConstants.FAILURE.name());
			}
		} catch (Exception ex) {
			log.error("UpiServiceImpl : transactionStatus : Error - {}", ex.getMessage());
			wibmoResponse = new WibmoResponse();
			wibmoResponse.setResCode(150);
			wibmoResponse.setResDesc(ex.getMessage());
			if (null != ex.getCause() && null != ex.getCause().getMessage())
				wibmoResponse.setErrorMessage(ex.getCause().getMessage());
			return wibmoResponse;
		}

		return wibmoResponse;
	}

	@Override
	public WibmoResponse retrieveVpaDetails(String programId, String accountNumber, String mobileNumber) {
		WibmoResponse wibmoResponse = new WibmoResponse();
		log.debug("UpiServiceImpl : retrieveVpaDetails : programId -{}, accountNo -{}, mobileNumber -{}", programId, accountNumber, mobileNumber);
		List<VPADetailsMini> vpaDetailsList = upiTransactionDAO.findByMobileNumber(programId,
				Integer.valueOf(accountNumber), mobileNumber);
		List<VPADetailsMiniResponse> vpaDetailsListRespList = new ArrayList<>();
		for (VPADetailsMini vpaDetailsMini : vpaDetailsList) {
			VPADetailsMiniResponse vPADetailsMiniResponse = new VPADetailsMiniResponse();
			vPADetailsMiniResponse.setVpa(vpaDetailsMini.getVpa());
			vPADetailsMiniResponse.setIsPrimaryVpa(vpaDetailsMini.getIsPrimaryVpa() == 1 ? "true" : "false");
			vpaDetailsListRespList.add(vPADetailsMiniResponse);
		}
		if (!vpaDetailsListRespList.isEmpty()) {
			log.info("vpa details fetched successfully");
			wibmoResponse.setResCode(200);
			wibmoResponse.setResDesc(Constants.FETCH_VPA_DETAILS_SUCCESSFUL);
			wibmoResponse.setData(vpaDetailsListRespList);
		} else {
			wibmoResponse.setResCode(100);
			wibmoResponse.setResDesc(Constants.VPA_DETAILS_NOT_FOUND_FOR_MOBILE);
			wibmoResponse.setData(vpaDetailsListRespList);
		}
		return wibmoResponse;
	}


	/**
	 *
	 * @param programId
	 * @param accountNumber
	 * @param request
	 * account add vpa method
	 * fetch available vpas
	 * check max count for vpa
	 * mobile # vpa check
	 * adding new vpa
	 * @return
	 */
	@Override
	public WibmoResponse accountAddVpa(String programId, String accountNumber, AddVpaRequest request) {
		log.debug("UpiServiceImpl : accountAddVpa : programId -{} request : {}", programId, request);
		WibmoResponse wibmoResponse = null;
		VPADetails vpaDetailsRow = new VPADetails();
		try {
			//fetch vpa rows
			List<VPADetails> availableVpas = vpaDetailsDAO.findVpaByAccountNumberAndActive(Long.valueOf(accountNumber));
			//fetching default count for VPA from DB
			String maxNoOfVpaCount = progParamDao.fetchParamValueByParamName(programId, ProgramParamConstants.MAX_NUMBER_OF_VPA.getValue());
			if (availableVpas != null && !availableVpas.isEmpty()) {
				for (VPADetails vpaDetails : availableVpas) {
					if (Boolean.TRUE.equals(vpaDetails.getIsPrimaryVpa())) {
						vpaDetailsRow = dozzerBeanMapper.map(vpaDetails, VPADetails.class);
					}
				}
				// Checking max vpa count validation
				if (validationCheckForVpaCount(availableVpas, maxNoOfVpaCount)) {
					return new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), ProgramParamConstants.MAX_COUNT_EXCEEDED.getValue());
				}
			}
			// Starting Juspay Adapter call
			UpiServiceAdapter upiServiceAdapter = upiServiceFactory.getUpiService(programId);
			if (upiServiceAdapter == null) {
				return new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), UpiStatusConstants.FAILURE.name(),
						Constants.UPI_VENDOR_NOT_FOUND_ERROR);
			}
			AddVpaResponse addVpaResponse = upiServiceAdapter.addVpaAccount(programId, accountNumber, request, vpaDetailsRow);
			wibmoResponse = gettingResponseFromJuspayStatus(addVpaResponse);
			log.debug("UpiServiceImpl : accountAddVpa : programId -{} response {}", programId, addVpaResponse);
		} catch (Exception e) {
			log.error("Exception in accountAddVpa method : {} ", e);
		}
		return wibmoResponse;
	}

	/**
	 *
	 * @param availableVpas
	 * @param maxNoOfVpaCount
	 * validation for vpa max count
	 * @return
	 */
	private boolean validationCheckForVpaCount(List<VPADetails> availableVpas, String maxNoOfVpaCount) {
		return (availableVpas.size() >= (maxNoOfVpaCount == null ? Constants.THREE : Integer.parseInt(maxNoOfVpaCount)));
	}

	/**
	 *
	 * @param programId
	 * @param accountNumber
	 * @param request
	 * api deletes a customer vpa and its mapping to corresponding accounts.
	 * @return
	 */
	@Override
	public WibmoResponse accountDeleteVpa(String programId, String accountNumber, DeleteVpaRequest request) {
		log.debug("UpiServiceImpl : accountDeleteVpa : programId -{} request : {}", programId, request);
		WibmoResponse wibmoResponse = null;
		List<VPADetails> vpaDetailList = new ArrayList<>();
		try {
			//fetch vpa rows
			List<VPADetails> availableVpas = vpaDetailsDAO.findVpaByAccountNumberAndActive(Long.valueOf(accountNumber));
			String customerPrimaryVpa = null;
			for (VPADetails vpaDetails : availableVpas) {
				if (request.getCustomerVpa().equals(vpaDetails.getVpa()) && vpaDetails.getIsPrimaryVpa()) {
					return new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), Constants.PRIMARY_VPA_CANT_BE_DELETED);
				}
				if (request.getCustomerVpa().equals(vpaDetails.getVpa())) {
					vpaDetailList.add(vpaDetails);
				}
				if (vpaDetails.getIsPrimaryVpa()) {
					customerPrimaryVpa = vpaDetails.getVpa();
				}
			}
			// Starting Juspay Adapter call
			UpiServiceAdapter upiServiceAdapter = upiServiceFactory.getUpiService(programId);
			if (upiServiceAdapter == null) {
				return new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), UpiStatusConstants.FAILURE.name(),
						Constants.UPI_VENDOR_NOT_FOUND_ERROR);
			}
			DeleteVpaResponse deleteVpaResponse = upiServiceAdapter.deleteVpaAccount(programId, accountNumber, request, vpaDetailList, customerPrimaryVpa);
			if (deleteVpaResponse != null && deleteVpaResponse.getStatus() !=null && deleteVpaResponse.getStatus().equals(UpiStatusConstants.SUCCESS.getStatusMsg())) {
				wibmoResponse = new WibmoResponse(UpiStatusConstants.SUCCESS.getStatusCode(), Constants.VPA_DELETED_SUCCESSFULLY);
			} else if (deleteVpaResponse != null && UpiStatusConstants.FAILURE.name().equalsIgnoreCase(deleteVpaResponse.getStatus())) {
				wibmoResponse = new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), deleteVpaResponse.getResponseMessage());
			} else {
				wibmoResponse = new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), Constants.VPA_DELETION_FAILED);
			}
			log.debug("UpiServiceImpl : accountDeleteVpa : response :{}", wibmoResponse);
		} catch (Exception e) {
			log.error("Exception in accountDeleteVpa method :::: {} ", e);
		}
		return wibmoResponse;
	}

	@Override
	public WibmoResponse deRegisterCustomer(String programId, String accountNumber, DeregisterCustomerRequest request) {
		log.debug("UpiServiceImpl : deRegisterCustomer : programId -{} accountNumber : {} request : {}", programId, accountNumber, request);
		WibmoResponse wibmoResponse = null;
		try {
			// Starting Juspay Adapter call
			UpiServiceAdapter upiServiceAdapter = upiServiceFactory.getUpiService(programId);
			if (upiServiceAdapter == null) {
				return new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), UpiStatusConstants.FAILURE.name(),
						Constants.UPI_VENDOR_NOT_FOUND_ERROR);
			}
			DeregisterCustomerResponse deregisterCustomerResponse = upiServiceAdapter.deRegisterCustomer(programId, accountNumber, request);
			if (deregisterCustomerResponse != null && deregisterCustomerResponse.getStatus() != null && deregisterCustomerResponse.getStatus().equals(UpiStatusConstants.SUCCESS.getStatusMsg())) {
				wibmoResponse = new WibmoResponse(UpiStatusConstants.SUCCESS.getStatusCode(), Constants.UPI_DEREGISTER_SUCCESS);
			}
			else if(deregisterCustomerResponse !=null && Constants.VPA_DETAILS_NOT_AVAILABLE.equalsIgnoreCase(deregisterCustomerResponse.getResponseMessage())) {
				wibmoResponse = new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), Constants.VPA_DETAILS_NOT_AVAILABLE);
			}else {
				wibmoResponse = new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), Constants.UPI_DEREGISTER_FAILED);
			}
			log.debug("UpiServiceImpl : deRegisterCustomer : response :{}", wibmoResponse);
		} catch (Exception e) {
			log.error("Exception in deRegisterCustomer method :::: {} ", e);
		}
		return wibmoResponse;
	}

	public void sendPushNotification(String programId, String accountNumber, RequestMoneyRequest request, String payeeMobileNumber, String payeeVpa, String payeeName, String txnId){
		UserProfileResponse userProfileResponse = null;
        log.debug(" UpiServiceImpl : sendPushNotification : programId :{} , accountNumber : {}, request : {}", programId, accountNumber, request);
		try{
			MultiValueMap<String, String> userProfileDetailsHeader = new LinkedMultiValueMap<>();
			VpaDetails vpaDetails = upiRegistrationDAO.fetchVpaDetailsBasesOnVpa(request.getPayerVPA());
			String payerAccountNumber = vpaDetails.getAccountNmber()+"";
			userProfileDetailsHeader.add("Content-Type", String.valueOf(MediaType.APPLICATION_JSON));
			userProfileDetailsHeader.add("X-PROGRAM-ID", programId);
			userProfileDetailsHeader.add("X-ACCOUNT-NUMBER", payerAccountNumber);
			HttpEntity<String> entity = new HttpEntity<>(userProfileDetailsHeader);
			ResponseEntity<UserProfileResponse> result = this.restTemplate.exchange(onboardingUrl + "/onboarding/userProfile/fetchUserProfileDetails/v1", HttpMethod.GET, entity, UserProfileResponse.class, new Object[0]);
			userProfileResponse = result.getBody();
			//fetch account number
			VPADetails vpaInfo = vpaDetailsDAO.findByVpa(request.getPayerVPA());
			if ( userProfileResponse != null) {
				String programParams = progParamDao.fetchParamValueByParamName(programId, Constants.COLLECT_REQ_EXP_MINUTES);
				long expiryTimeInMin = Long.parseLong(programParams);
				Timestamp createTimeStamp = new Timestamp( new Date().getTime());
				//creation of data object
				Map<String, String> data = new HashMap<>();
				data.put("txnRefNumber" ,txnId);
				data.put("payeeMobileNumber", payeeMobileNumber);
				data.put("payeeVpa", payeeVpa);
				data.put("payeeName", payeeName);
				data.put("txnMode", "UPI");
				data.put("amount", request.getTxnAmount());
				data.put("requestedDate", String.valueOf(createTimeStamp.getTime()));
				data.put("expiryDate",String.valueOf(createTimeStamp.getTime() + (expiryTimeInMin * 60 * 1000)));
				data.put("desc", "PushNotification");

				Map<String, String> placeHolder = new HashMap<>();
				placeHolder.put("XYZ", request.getPayeeName());
				placeHolder.put("AMOUNT", Constants.CURRENCY_IND+ CommonUtil.decimalFormat(Long.parseLong(request.getTxnAmount())));

				AlertRequest alertRequest = new AlertRequest();
				alertRequest.setEventId(Integer.parseInt(Constants.RECEIVE_MONEY_EVENT_ID));
				alertRequest.setFcmToken(userProfileResponse.getFcmId());
				alertRequest.setAccountNumber(vpaInfo.getAccountNumber());
				alertRequest.setDeviceId(userProfileResponse.getDeviceId());
				alertRequest.setWhatsappEnabled(false);
				alertRequest.setPlaceHolders(placeHolder);
				//fix for RequestMoney sms alert
				alertRequest.setMobileNumber(userProfileResponse.getMobile());
				log.info("alert request : {}", alertRequest);
				callToNotificationSendAlert(programId, alertRequest);
			}
		}
		catch (Exception ex) {
			log.error("Issue while fetching userProfileDetails " + ex.getMessage());
		}
	}

	private WibmoResponse gettingResponseFromJuspayStatus(AddVpaResponse addVpaResponse) {
		WibmoResponse wibmoResponse = null;
		if (addVpaResponse != null && addVpaResponse.getStatus().equals(UpiStatusConstants.SUCCESS.getStatusMsg())) {
			wibmoResponse = new WibmoResponse(UpiStatusConstants.SUCCESS.getStatusCode(), Constants.VPA_ADDED_SUCCESS);
		} else if (addVpaResponse != null && Constants.VPA_NOT_AVAILABLE.equals(addVpaResponse.getResponseMessage())) {
			wibmoResponse = new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), Constants.VPA_NOT_AVAILABLE);
		} else if (addVpaResponse != null && Constants.ADD_VPA_JUSPAY_CALL_FAILURE.equals(addVpaResponse.getResponseMessage())) {
			wibmoResponse = new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), Constants.ADD_VPA_JUSPAY_CALL_FAILURE);
		} else {
			wibmoResponse = new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), Constants.VPA_ADDITION_FAILED);
		}
		return wibmoResponse;
	}

	private void callToNotificationSendAlert(String programId, AlertRequest alertRequest) {
		try {
			MultiValueMap<String, String> customNotificationHeader = new LinkedMultiValueMap<>();
			customNotificationHeader.add(Constants.CONTENT_TYPE, String.valueOf(MediaType.APPLICATION_JSON));
			customNotificationHeader.add(Constants.X_PROGRAM_ID, programId);
			HttpEntity<Object> notificationEntity = new HttpEntity<>(alertRequest, customNotificationHeader);
			ResponseEntity<WibmoResponse> resp = this.restTemplate.exchange(notificationUrl + "/notification-service/notification/sendAlert", HttpMethod.POST, notificationEntity, WibmoResponse.class);
			if (resp.getBody()!=null && (resp.getStatusCodeValue()!= 200)) {
				log.debug("Notification sending failed: {}", (resp.getBody()).getErrorMessage());
			}
		} catch (Exception var6) {
			log.error("Issue while sending notification " + var6.getMessage());
		}
	}

	/**
	 * check record is expired or not
	 * @param upiCollectRequestRow
	 * @param expiryTimeInMin
	 * @return
	 */
	private boolean checkExpiredRecord(UpiCollectRequestDetails upiCollectRequestRow, long expiryTimeInMin) {
		boolean flag = false;
		long timeInMillis = new Timestamp(new Date().getTime()).getTime();
		long timeDifferenceInMillis = timeInMillis - upiCollectRequestRow.getCreatedTs().getTime();
		long expiryTimeInMillis = expiryTimeInMin * 60 * 1000;
		long timeDiffInSeconds = TimeUnit.MILLISECONDS.toSeconds(timeDifferenceInMillis);
		long expiryInSeconds = TimeUnit.MILLISECONDS.toSeconds(expiryTimeInMillis);
		if (timeDiffInSeconds > expiryInSeconds) {
			flag = Boolean.TRUE;
		}
		return flag;
	}
}
