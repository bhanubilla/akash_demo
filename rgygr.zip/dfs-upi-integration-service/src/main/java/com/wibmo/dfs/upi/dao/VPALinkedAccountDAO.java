package com.wibmo.dfs.upi.dao;

import com.wibmo.dfs.upi.model.VPALinkedAccount;

import java.util.List;

public interface VPALinkedAccountDAO {
    public void save(VPALinkedAccount vpaLinkedAccount);
    public VPALinkedAccount findByAccountNumber(Long accountNumber);
    public VPALinkedAccount findByBankAccountNumber(String bankAccountNumber);
    VPALinkedAccount fetchVpaLinkedByBankId(String bankUniqueId);
    VPALinkedAccount fetchVpaLinkedById(Long id);
    void deleteVpaLinkedAccount(List<Long> ids);
}
