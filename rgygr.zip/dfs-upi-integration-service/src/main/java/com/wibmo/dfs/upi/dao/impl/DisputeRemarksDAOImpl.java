package com.wibmo.dfs.upi.dao.impl;

import com.wibmo.dfs.upi.constants.RegistrationConstants;
import com.wibmo.dfs.upi.dao.DisputeRemarksDAO;
import com.wibmo.dfs.upi.entity.BlockedVpaDetails;
import com.wibmo.dfs.upi.entity.DisputeRemarksDetails;
import com.wibmo.dfs.upi.exception.InternalServerException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@Repository
@Slf4j
public class DisputeRemarksDAOImpl implements DisputeRemarksDAO {

    private static final String DISPUTE_REMARKS_DETAILS="Select * from dispute_remarks_info where adj_code = ?";
    public static final String NAME = "NAME";
    public static final String INITIATION_MODE = "INITIATION_MODE";
    public static final String ADJ_FLAG = "ADJ_FLAG";
    public static final String ADJ_CODE = "ADJ_CODE";

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public DisputeRemarksDetails fetchDisputeAdjCode(String adjCode) {
        DisputeRemarksDetails disputeRemarksDetails=new DisputeRemarksDetails();
        try {
            return jdbcTemplate.query(DISPUTE_REMARKS_DETAILS, new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setString(1, adjCode);
                }
            }, new ResultSetExtractor<DisputeRemarksDetails>() {

                @Override
                public DisputeRemarksDetails extractData(ResultSet resultSet) throws SQLException {
                    if (resultSet.next()) {
                        disputeRemarksDetails.setName(resultSet.getString(NAME));
                        disputeRemarksDetails.setInitiationMode(resultSet.getString(INITIATION_MODE));
                        disputeRemarksDetails.setAdjFlag(resultSet.getString(ADJ_FLAG));
                        disputeRemarksDetails.setAdjCode(resultSet.getString(ADJ_CODE));
                        return disputeRemarksDetails;
                    } else {
                        return null;
                    }


                }

            });


        } catch (EmptyResultDataAccessException e) {
            log.error("Error accur in BloackedVpaDaoImpl : fetchDisputeAdjCode {}", e.getMessage());
            throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);

        }
    }
}
