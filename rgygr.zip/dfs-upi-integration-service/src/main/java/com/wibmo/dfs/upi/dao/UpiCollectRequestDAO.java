package com.wibmo.dfs.upi.dao;

import com.wibmo.dfs.upi.entity.UpiCollectRequestDetails;

import java.math.BigInteger;
import java.util.List;

public interface UpiCollectRequestDAO {
    BigInteger saveUpiCollectRequestData(UpiCollectRequestDetails upiCollectRequestDetails);

    void updateUpiCollectRequestData(UpiCollectRequestDetails upiCollectRequestDetails);

    void updateUpiCollectRequestStatusByTxnId(String status, String gatewayTxnId);

    UpiCollectRequestDetails fetchUpiCollectRequestData(long id);

    List<UpiCollectRequestDetails> fetchPendingCollectRequest(String vpa);

    List<UpiCollectRequestDetails> fetchPendingUpiCollectRequestData(String payeeVpa, String payerVpa, String status);

    void updateStatusRemarksByGatewayTxnId(String status,String remarks, String gatewayTxnId);
}
