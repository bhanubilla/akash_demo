package com.wibmo.dfs.upi.model.request;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ListUdirComplaintsRequest {

    private String type;
    private String fromDate;
    private String toDate;
    private String status;
    private String offSet;
    private String limit;

}
