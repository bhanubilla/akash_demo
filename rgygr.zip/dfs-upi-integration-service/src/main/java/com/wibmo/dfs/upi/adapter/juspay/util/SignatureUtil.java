package com.wibmo.dfs.upi.adapter.juspay.util;

import java.io.IOException;
import java.security.*;
import java.util.Base64;
import java.security.spec.*;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public final class SignatureUtil {

    public static final String RSA = "RSA";
    public static final String SHA256_WITH_RSA = "SHA256withRSA";

    public String calculateSignature(String input, String privKey) throws IOException {
    	log.info("SignatureUtil : calculateSignature()");
    	String finalSign = "";

        try {
        	PrivateKey privateKey = getEncodedPrivateKey(privKey);
        	
        	 byte[] dataBytes = input.getBytes();
             Signature signInstance = Signature.getInstance("SHA256WithRSA/PSS", new BouncyCastleProvider());
             signInstance.initSign(privateKey);
             signInstance.update(dataBytes);
             byte[] signature = signInstance.sign();
             finalSign = byteArrayToHex(signature);
             return  finalSign;

        }
        
        catch (NoSuchAlgorithmException e){
            log.error("Error!!! NoSuchAlgorithmException");
        } catch (SignatureException | InvalidKeyException | InvalidKeySpecException e) {
            log.error("Error!!! ",e);
        }
		return finalSign;
        
    }
    
    private static PrivateKey getEncodedPrivateKey(String pspPrivateKey)
            throws InvalidKeySpecException, NoSuchAlgorithmException {
        pspPrivateKey = pspPrivateKey.replace("-----BEGIN PRIVATE KEY-----", "");
        pspPrivateKey = pspPrivateKey.replace("-----END PRIVATE KEY-----", "");
        pspPrivateKey = pspPrivateKey.replaceAll("\\s+", "");

        byte[] pkcs8EncodedBytes = Base64.getDecoder().decode(pspPrivateKey);

        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(pkcs8EncodedBytes);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        return kf.generatePrivate(keySpec);

    }
    
    public static String byteArrayToHex(byte[] a) {
        StringBuilder sb = new StringBuilder(a.length * 2);
        for (byte b : a) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
    

}