package com.wibmo.dfs.upi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class VPALinkedAccount {
    private Long id;
    private Long accountNumber;
    private String bankName;
    private String bankAccountNumber;
    private String bankIfsc;
    private String bankCode;
    private String type;
    private String bankAccUniqueId;
}
