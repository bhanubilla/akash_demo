package com.wibmo.dfs.upi.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Data
public class CbsComplaintStatusUpdateCallback {
    private String approvalNumber;
    private String merchantChannelId;
    private String gatewayResponseStatus;
    private String merchantId;
    private String gatewayComplaintId;
    private String reqAdjAmount;
    private String orgSettRespCode;
    private String gatewayResponseMessage;
    private String payerVpa;
    private String originalTransactionTimestamp;
    private String gatewayResponseCode;
    private String gatewayReferenceId;
    private String reqAdjCode;
    private String crn;
    private String payeeVpa;
    private String reqAdjFlag;
    private String transactionAmount;
    private String type;
    private String originalGatewayTransactionId;
    private String currCycle;
    private String remarks;
}

