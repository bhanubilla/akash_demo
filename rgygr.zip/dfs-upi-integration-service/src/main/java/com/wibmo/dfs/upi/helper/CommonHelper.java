package com.wibmo.dfs.upi.helper;

import lombok.extern.slf4j.Slf4j;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.jdbc.support.KeyHolder;

import java.util.regex.Matcher;

@Slf4j
public class CommonHelper {
    public static final String NUMBER_REGEX = ".*[0-9].*";
    public static final String ALPHABET_REGEX = ".*[A-Z].*";
    public static final String BANKEZY = "bankezy";
    private CommonHelper() {
    }

    public static boolean checkOnUs(String vpa, String agentName, String vpaAddress) {
        boolean flag;
        if ((vpa.contains(agentName)  || vpa.contains(BANKEZY)) && vpa.endsWith(vpaAddress)) {
            log.debug("payee vpa belongs to on-us");
            flag = Boolean.TRUE;
        } else {
            log.debug("payee vpa not belongs to off-us");
            flag = Boolean.FALSE;
        }
        return flag;
    }

    public static boolean checkTxnIdHasAlphabet(String txnId) {
        String number = NUMBER_REGEX;
        String alphabet = ALPHABET_REGEX;
        return txnId.matches(number) && txnId.matches(alphabet);
    }
    public static String juspayExpectedDate() {
        DateTimeZone timeZone = DateTimeZone.forID("Asia/Kolkata");
        DateTime dateTimet = new DateTime(timeZone);
        return dateTimet.toString();
    }

    public static int getKeyHolderValue(KeyHolder holder){
        int newUserId =0;
        var userId=holder.getKey();
        if(userId != null)
            newUserId=userId.intValue();
        return newUserId;
    }
}
