package com.wibmo.dfs.upi.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.wibmo.dfs.platform.fw.multitenantconfig.ThreadLocalStorage;
import com.wibmo.dfs.platform.service.notification.NotificationServiceCall;
import com.wibmo.dfs.platform.service.notification.model.NotificationRequest;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayIncomingMoneyToCustomerPay;
import com.wibmo.dfs.upi.adapter.juspay.util.CommonUtil;
import com.wibmo.dfs.upi.adapter.juspay.util.CallbackRequestValidator;
import com.wibmo.dfs.upi.constants.*;
import com.wibmo.dfs.upi.dao.*;
import com.wibmo.dfs.upi.entity.*;
import com.wibmo.dfs.upi.exception.InternalServerException;
import com.wibmo.dfs.upi.helper.ApiManagerUtil;
import com.wibmo.dfs.upi.helper.CommonHelper;
import com.wibmo.dfs.upi.kafka.KafkaProducer;
import com.wibmo.dfs.upi.kafka.model.CreditMoneyTxnDetailsRequest;
import com.wibmo.dfs.upi.kafka.model.CreditStatusTxnDetailsRequest;
import com.wibmo.dfs.upi.kafka.model.TxnDetails;
import com.wibmo.dfs.upi.kafka.model.UpdtTxnDetails;
import com.wibmo.dfs.upi.model.*;
import com.wibmo.dfs.upi.model.request.*;
import com.wibmo.dfs.upi.model.response.JuspayCallbackResponse;
import com.wibmo.dfs.upi.model.response.VerifyVpaResponse;
import com.wibmo.dfs.upi.model.response.WibmoResponse;
import com.wibmo.dfs.upi.service.CollectRequestService;
import com.wibmo.dfs.upi.service.UpiService;
import com.wibmo.dfs.upi.service.UpiServiceCallbacks;

import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpHeaders;
import org.dozer.DozerBeanMapper;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class UpiServiceCallbacksImpl implements UpiServiceCallbacks {

    public static final String LOAD_FUND_IS_NOT_SUCCESSFUL = "load fund is not successful";
    public static final String TXN_UPDATE = "TXN_UPDATE";
    public static final String D = "D";
    public static final String I = "I";
    @Autowired
    RestTemplate restTemplate;

    @Autowired
    private CallbackRequestValidator requestValidator;

    @Autowired
    private UpiRegistrationDAO upiRegistrationDAO;

    @Autowired
    private UpiCollectRequestDAO upiCollectRequestDAO;

    @Autowired
    private BlockedVpaDao blockedVpaDao;

    @Autowired
    private CollectRequestService collectRequestService;

    @Autowired
    private UpiService upiService;

    @Autowired
    private DozerBeanMapper dozerBeanMapper;

    @Autowired
    KafkaProducer kafkaProducer;

    @Autowired
    private VPADetailsDAO vpaDetailsDAO;

    @Autowired
    private ProgramParamsDAO programParamsDAO;

    @Value("${resource.url.txnHistory}")
    private String txnHistoryUrl;

    @Value("${resource.url.wallet}")
    private String walletUrl;

    @Value("${resource.merchantVpa:1000111002233}")
    private String merchantVpa;

    @Value("${resource.convertedMerchantVpa:8951851037.citrus4@payu}")
    private String convertedMerchantVpa;

    @Autowired
    VpaTxnDAO vpaTxnDAO;

    @Autowired
    ProgramParamsDAO progParamDao;
    
    @Autowired
	private ApiManagerUtil apiManagerUtil;
    
    @Value("${resource.url.notification}")
	private String notificationUrl;

    private static final String SUCCESS = "SUCCESS";
    private static final String FAILURE = "FAILURE";
    public static final String EXCEPTION_MSG_CALLBACK_INCOMING_COLLECT_REQUEST = "Exception in incomingCollectRequestToCustomer {}";

    @Override
    public JuspayCallbackResponse creditMoneyCBSCallback(String programId, String request) {
        log.info("UpiServiceCallbackImpl: creditMoneyCBSCallback method : programId-{}, request-{}", programId, request);
        JuspayCallbackResponse response = new JuspayCallbackResponse();
        CBSRequest cbsRequest = new CBSRequest();
        ObjectMapper obj = new ObjectMapper();
        try {
            WibmoResponse validation = requestValidator.validateCreditMoneyCBS(request);
            if(validation != null )
            {
                log.info("Bad request received from vendor");
                response.setResponseCode("400");
                response.setResponseMessage("BAD_REQUEST");
                return response;
            }
            cbsRequest = obj.readValue(request.getBytes(), CBSRequest.class);

        } catch (IOException e) {
            log.error("Exception while parsing :: {}",e);
        }
        String cbsAmount = cbsRequest.getAmount().replace(".","");
        log.info("cbsRequest.getGatewayTransactionId :: {},cbsRequest.getGatewayTransactionRefId :: {}, amount:: {}",cbsRequest.getGatewayTransactionId(),cbsRequest.getGatewayReferenceId(),cbsAmount);
        VpaTxnInfoDetails vpaTxnInfoDetails = upiRegistrationDAO.fetchVpaTxnInfoBasesOnGatewayTxnIdGatewayRefId(cbsRequest.getGatewayTransactionId(),cbsRequest.getGatewayReferenceId(),cbsAmount);

        if(cbsRequest.getType().equalsIgnoreCase("DEBIT_REVERSAL")){
            handleDebitReversal(programId,vpaTxnInfoDetails,cbsRequest,response);
        }else if(vpaTxnInfoDetails == null) {
            // Send Money event received from another system like gpay,phonepay and amazon pay
            log.info("Callback for off-us user since credit txn details not found in our database");
            //one record should be insert in vpa_txn_info
            VpaBasicDetails basicVpaDetails = getVpaBasicDetails(programId, cbsRequest.getAccountIdentifier());
            VpaDetails vpaDetails = upiRegistrationDAO.fetchVpaDetailsBasesOnVpa(basicVpaDetails.getVpa());
            int customerId = vpaDetails.getAccountNmber();
            int walletId = vpaDetails.getWalletId();
            VpaTxnInfo vpaTxnInfo = new VpaTxnInfo();
            //Here account identifier is nothing but payee account number
            vpaTxnInfo.setPayeeMerchantCustomerId(cbsRequest.getAccountIdentifier());
            vpaTxnInfo.setUpiRequestId(cbsRequest.getGatewayTransactionId());
            vpaTxnInfo.setGatewayTxnId(cbsRequest.getGatewayTransactionId());
            vpaTxnInfo.setGatewayReferenceId(cbsRequest.getGatewayReferenceId());
            vpaTxnInfo.setGatewayResponseMessage(cbsRequest.getRemarks());
            vpaTxnInfo.setPayeeVpa(basicVpaDetails.getVpa());
            vpaTxnInfo.setMessage(cbsRequest.getRemarks());
            vpaTxnInfo.setOriginalTxnId(cbsRequest.getGatewayTransactionId());
            vpaTxnInfo.setMerchantCustomerId("0");//Indicates off-us
            vpaTxnInfo.setAmount(Double.parseDouble(cbsAmount));
            vpaTxnDAO.save(vpaTxnInfo);
            //Credit fund
            FundResponse fundResponse = loadFunds(programId, String.valueOf(customerId), cbsAmount, walletId);
            if(fundResponse!=null) {
                CBSRequest finalCbsRequest = cbsRequest;
                Runnable creditSuccessStatus = () -> kafkaProducer.publishUpiTxnTracking(finalCbsRequest.getGatewayTransactionId(), TxnTrackingConstants.CREDIT_MONEY_SUCCESS);
                new Thread(creditSuccessStatus).start();
                log.info("Loaded amount");
                response.setResponseCode(SUCCESS);
                response.setResponseMessage(SUCCESS);
                response.setStatus(SUCCESS);
                CreditMoneyCBSResponse cbsResponse = new CreditMoneyCBSResponse();
                cbsResponse.setGatewayReferenceId(cbsRequest.getGatewayReferenceId());
                cbsResponse.setAccountIdentifier(cbsRequest.getAccountIdentifier());
                cbsResponse.setRemarks(fundResponse.getRemarks());
                cbsResponse.setCbsStatus(fundResponse.getPpResponseMessage());
                cbsResponse.setCbsResponseCode(fundResponse.getPpResponseCode());
                cbsResponse.setAmount(cbsRequest.getAmount());
                cbsResponse.setGatewayTransactionId(cbsRequest.getGatewayTransactionId());
                cbsResponse.setCbsReferenceId(fundResponse.getRefNumber());
                cbsResponse.setUpdatedAt(CommonHelper.juspayExpectedDate());
                response.setPayload(cbsResponse);
                // UPDATE VPA TXN table
                // Insert in txnHistory as debit entry in callbacks
                log.info("Insert in txn history from callbacks");
            }
            else{
                log.info(LOAD_FUND_IS_NOT_SUCCESSFUL);
                CBSRequest finalCbsRequest1 = cbsRequest;
                Runnable creditMoneyFailStatus = () -> kafkaProducer.publishUpiTxnTracking(finalCbsRequest1.getGatewayTransactionId(), TxnTrackingConstants.CREDIT_MONEY_FAILURE);
                new Thread(creditMoneyFailStatus).start();
                prepareCBSFailureResponse(response, JuspayCallbackStatusConstants.CBS_CALLBACK_FAILURE_UB);
            }


        }else if("UPI_RM".equalsIgnoreCase(vpaTxnInfoDetails.getTxnType())) {
            handleRequestMoneyCBS(programId, cbsRequest, vpaTxnInfoDetails, response);
        }else{
            handleSentMoneyCBS(programId,cbsRequest,vpaTxnInfoDetails,response);
        }

        log.info("CBS response :: {}",response);
        return response;
    }

    /**
     * @param programId
     * @param request       callback is given when a customer receives a collect request from any UPI user.
     * @return
     */
    @Override
    public WibmoResponse incomingCollectRequestToCustomer(String programId, String request) {
        log.debug("UpiServiceCallbacksImpl : incomingCollectRequestToCustomer : request : {}", request);
        WibmoResponse validation = requestValidator.validateIncomingCollectRequestToCustomer(request);
        if(validation != null){
            log.info("Bad request from vendor");
            return validation;
        }
        WibmoResponse response = new WibmoResponse();
        JSONObject jsonObject = new JSONObject(request);
        ObjectMapper objectMapper = new ObjectMapper();
        UpiCollectRequestDetails upiCollectRequestDetails = new UpiCollectRequestDetails();
        BlockedVpaDetails blockedVpaDetails = null;
        List<UpiCollectRequestDetails> fetchedPendingBlockedVpaList = null;
        try {
            upiCollectRequestDetails = buildUpiCollectRequestData(jsonObject, objectMapper);
            // inserting record in upi_collect_request table from request
            BigInteger id = upiCollectRequestDAO.saveUpiCollectRequestData(upiCollectRequestDetails);
            if (BigInteger.ZERO == id) {
                log.error("Error occurred in inserting records in upi collect request table id :{}", id);
                throw new InternalServerException(RegistrationConstants.REQUEST_COULD_NOT_BE_PROCESSED);
            }

            //check payeeVpa is in blockedVpa table
            blockedVpaDetails = blockedVpaDao.fetchBlockedVPA(upiCollectRequestDetails.getAccountNumber(), buildBlockedVpaRequest(upiCollectRequestDetails.getPayeeVpa()));
            if (blockedVpaDetails != null) {
                log.debug("UpiServiceCallbacksImpl : incomingCollectRequestToCustomer : inside blockedVpaDetails : {}", blockedVpaDetails);
                fetchedPendingBlockedVpaList = upiCollectRequestDAO.fetchPendingUpiCollectRequestData(upiCollectRequestDetails.getPayeeVpa(), upiCollectRequestDetails.getPayerVpa(), Constants.PENDING);
                if (fetchedPendingBlockedVpaList != null && !fetchedPendingBlockedVpaList.isEmpty()) {
                    log.info("UpiServiceCallbacksImpl : incomingCollectRequestToCustomer : inside fetchedPendingBlockedVpaList if block");
                    for (UpiCollectRequestDetails row : fetchedPendingBlockedVpaList) {
                        row.setStatus(Constants.DECLINE);
                        row.setId(row.getId());
                        //update status as decline in upi_collect_request table
                        upiCollectRequestDAO.updateUpiCollectRequestData(row);
                        //Kafka call to update status as D in txn_history for incoming flow
                        String upiRequestIdPrefix = progParamDao.fetchParamValueByParamName(programId, ProgramParamConstants.UPI_REQUEST_ID_PREFIX.getValue());
                        if(upiCollectRequestDetails.getGatewayTransactionId().startsWith(upiRequestIdPrefix)){
                            log.info("Considering payee also belongs to us updating status in txn history");
                            TxnDetails txnDetls = new TxnDetails();
                            txnDetls.setTxnType(TXN_UPDATE);
                            txnDetls.setProgramId(programId);
                            UpdtTxnDetails updtTxnDetails = new UpdtTxnDetails();
                            String originalTxnId = upiCollectRequestDetails.getGatewayTransactionId().substring(upiRequestIdPrefix.length());
                            updtTxnDetails.setOriginalTxnId(originalTxnId);
                            updtTxnDetails.setTxnStatus(D);
                            updtTxnDetails.setTxnFlow(I);
                            txnDetls.setData(updtTxnDetails);
                            Runnable statusRunnable = () -> kafkaProducer.publishUpiTxn(txnDetls);
                            new Thread(statusRunnable).start();
                        }
                        //call jus-pay api having request type as DECLINE
                        response = collectRequestService.incomingCollectRequest(programId, upiCollectRequestDetails.getAccountNumber(), buildIncomingCollectRequest(row, programId));
                    }
                } else {
                    log.info("UpiServiceCallbacksImpl : incomingCollectRequestToCustomer : inside fetchedPendingBlockedVpaList else block");
                    buildWibmoResponse(response, UpiStatusConstants.FAILURE.getStatusCode(), Constants.ERROR_MSG_FETCH_PENDING_BLOCKED_VPA_LIST);
                }
            } else {
                String agentName = programParamsDAO.fetchParamValueByParamName(programId, ProgramParamConstants.AGENT_NAME.getValue());
                String vpaAddress = programParamsDAO.fetchParamValueByParamName(programId, ProgramParamConstants.VPA_ADDRESS_PAYU.name());
                //fetch payer vpa name
                String vpaName = fetchVpaName(upiCollectRequestDetails.getPayerVpa(), programId);
                log.debug("UpiServiceCallbacksImpl : incomingCollectRequestToCustomer : else blockedVpaDetails vpaName : {}", vpaName);
                //sendPushNotification to payer
                	upiService.sendPushNotification(programId, upiCollectRequestDetails.getAccountNumber(), buildPushNotificationRequest(vpaName, upiCollectRequestDetails.getPayerVpa(), upiCollectRequestDetails.getAmount(), upiCollectRequestDetails.getPayeeName()), upiCollectRequestDetails.getPayeeMobileNumber(), upiCollectRequestDetails.getPayeeVpa(), upiCollectRequestDetails.getPayeeName(), upiCollectRequestDetails.getGatewayTransactionId());
                buildWibmoResponse(response, UpiStatusConstants.SUCCESS.getStatusCode(), Constants.CALLBACK_PAYER_SEND_PUSH_NOTIFICATION_SUCCESS);
            }
        } catch (Exception e) {
            log.error(EXCEPTION_MSG_CALLBACK_INCOMING_COLLECT_REQUEST, e);
            response = buildWibmoResponse(response, UpiStatusConstants.FAILURE.getStatusCode(), UpiStatusConstants.FAILURE.name());
        }
        return response;
    }

    @Override
    public WibmoResponse incomingMoneyToCustomerCsCallback(String programId, String request) {
        log.info("incomingMoneyToCustomerCsCallback method : programId-{}, request-{}", programId, request);
        ObjectMapper objectMapper = new ObjectMapper();
        JuspayIncomingMoneyToCustomerPay reqFromJuspay = null;
        try {
            WibmoResponse validate = requestValidator.validateIncomingCollectRequestToCustomer(request);
            if(validate != null){
                log.info("BAD_REQUEST from vendor");
                return validate;
            }
            reqFromJuspay = objectMapper.readValue(request, JuspayIncomingMoneyToCustomerPay.class);
        } catch (JsonProcessingException e) {
            log.error("Exception while parsing :: ",e);
        }
        String upiRequestIdPrefix = progParamDao.fetchParamValueByParamName(programId, ProgramParamConstants.UPI_REQUEST_ID_PREFIX.getValue());
        if(reqFromJuspay != null && ("CUSTOMER_CREDITED_VIA_PAY").equalsIgnoreCase(reqFromJuspay.getType()) && !reqFromJuspay.getGatewayTransactionId().startsWith(upiRequestIdPrefix)){
            log.info("It is considering as send money event comes from external vpa so need to update payer details in txn_history table");
            StringBuilder txnDesc = new StringBuilder();
            CreditMoneyTxnDetailsRequest cm = new CreditMoneyTxnDetailsRequest();
            cm.setCustomerId(reqFromJuspay.getPayeeMerchantCustomerId());
            cm.setOriginalTxnId(reqFromJuspay.getGatewayTransactionId());
            cm.setSourceAccount(reqFromJuspay.getPayerVpa());
            cm.setDestAccount(reqFromJuspay.getPayeeVpa());
            cm.setTxnCategory("RMC");
            cm.setRemarks("Received from external vpa");// Actual remarks need to get it from vpa_txn_info table
            cm.setTxnStatus("S");
            String cbsAmount = reqFromJuspay.getAmount().replaceAll(".","");
            log.info("cbsAmount :: {}",cbsAmount);
            cm.setTxnAmount(Long.parseLong(cbsAmount));
            cm.setTxnType("P2P");
            cm.setTxnFlow(I);
            cm.setPaymentMode("RW");
            log.info("RMC INFLOW setTxnShortDesc payer name");
            cm.setTxnDate(new Timestamp(System.currentTimeMillis()));
            txnDesc.append(Constants.SENT).append(Constants.RS_SYMBOL).append(CommonUtil.decimalFormat(Long.parseLong(cbsAmount))).append(Constants.TO).append("Non citrus payer");
            cm.setTxnDesc(txnDesc.toString());
            cm.setTxnShortDesc(reqFromJuspay.getPayerName());
            TxnDetails txnDetails = new TxnDetails();
            txnDetails.setProgramId(programId);
            txnDetails.setTxnType("CREDIT_MONEY_CBS_OFFUS");
            txnDetails.setData(cm);

            Runnable runnable = () -> kafkaProducer.publishUpiTxn(txnDetails);
            new Thread(runnable).start();

        }
        return new WibmoResponse(200,SUCCESS);
    }

    @Override
    public WibmoResponse outgoingCollectRequestFromCustomerCallback(String programId, String request) {
        WibmoResponse validateResponse = requestValidator.validateCollectRequestSent(request);
        if(null != validateResponse){
            return validateResponse;
        }
        return new WibmoResponse(200, "SUCCESS");
    }

    /**
     * fetchingVpaName
     * @param payerVpa
     * @param programId
     * @return
     */
    private String fetchVpaName(String payerVpa, String programId) {
        String vpaName = "";
        VerifyVpaRequest vpaRequest = new VerifyVpaRequest();
        vpaRequest.setVpa(payerVpa);
        WibmoResponse verifyVpaResponse = upiService.verifyVpa(programId, vpaRequest);
        VerifyVpaResponse vpaResponse = (VerifyVpaResponse) verifyVpaResponse.getData();
        if (vpaResponse != null && vpaResponse.getVpa() != null) {
            vpaName = vpaResponse.getName();
        } else {
            log.debug("verifyVpa response is null , not able to fetch vpa name ");
        }
        return vpaName;
    }

    private RequestMoneyRequest buildPushNotificationRequest(String payerName, String payerVpa, String amount, String payeeName) {
        RequestMoneyRequest request = new RequestMoneyRequest();
        request.setPayerName(payerName);
        request.setTxnAmount(amount);
        request.setPayerVPA(payerVpa);
        request.setPayeeName(payeeName);
        return request;
    }

    private UpiIncomingCollectRequest buildIncomingCollectRequest(UpiCollectRequestDetails upiCollectRequestDetails, String programId) {
        UpiIncomingCollectRequest row = null;
        row = dozerBeanMapper.map(upiCollectRequestDetails, UpiIncomingCollectRequest.class);
        row.setApprovalStatus(upiCollectRequestDetails.getStatus());
        log.info("upiCollectRequestDetails.getAmount()::{}",upiCollectRequestDetails.getAmount());
        String amount = upiCollectRequestDetails.getAmount().replace(".","");
        log.info("buildIncomingCollectRequest : amount : {}", amount);
        row.setTxnAmount(amount);
        row.setTxnId(upiCollectRequestDetails.getGatewayTransactionId());
        row.setPayerName(fetchVpaName(upiCollectRequestDetails.getPayerVpa(), programId));
        return row;
    }

    /**
     * preparing blocked vpa request for checking vpa is blocked or not
     * @param payeeVpa
     * @return
     */
    private BlockedVpaRequest buildBlockedVpaRequest(String payeeVpa) {
        BlockedVpaRequest request = new BlockedVpaRequest();
        request.setVpa(payeeVpa);
        return request;
    }

    /**
     * @param jsonObject
     * @param objectMapper
     * @return
     * @throws IOException
     */
    private UpiCollectRequestDetails buildUpiCollectRequestData(JSONObject jsonObject, ObjectMapper objectMapper) throws IOException {
        UpiCollectRequestDetails row = null;
        VPADetails payerVpaDetails = new VPADetails();
        VPADetails payeeVpaDetails = new VPADetails();
        byte[] jsonData = jsonObject.toString().getBytes();
        row = objectMapper.readValue(jsonData, UpiCollectRequestDetails.class);
        row.setStatus(Constants.PENDING);
        //fetching vpa details on the basis of payer vpa
        try {
            payerVpaDetails = vpaDetailsDAO.findByVpa(row.getPayerVpa());
        } catch (Exception e) {
            log.error("Exception in UpiServiceCallbacksImpl : buildUpiCollectRequestData :{}", e);
        }
        row.setAccountNumber(payerVpaDetails == null ? null : String.valueOf(payerVpaDetails.getAccountNumber()));
        String amount = row.getAmount().replace(".","");
        log.info("amount :: {}",amount);
        row.setAmount(amount);
        row.setCreatedBy(row.getAccountNumber());
        row.setUpdatedBy(row.getAccountNumber());
        //fetching vpa details on the basis of payee vpa
        try {
            payeeVpaDetails = vpaDetailsDAO.findByVpa(row.getPayeeVpa());
        } catch (Exception e) {
            log.error("Exception in UpiServiceCallbacksImpl : buildUpiCollectRequestData :{}", e);
        }
        row.setPayeeMobileNumber(payeeVpaDetails == null ? null : payeeVpaDetails.getMobileNumber());
        return row;
    }

    public FundResponse loadFunds(String programId, String accountNumber, String amount, int walletId){
        FundResponse response = null;
        MultiValueMap<String, String> customFundHeader = null;
        ResponseEntity<WibmoResponse> responseEntity = null;
        String wibmoTxnId = CommonUtil.generateWibmoTxnId();
        FundRequest fundRequest = new FundRequest();
        fundRequest.setAmount(Integer.parseInt(amount));
        fundRequest.setTxnType(Constants.P2P_CREDIT);
        fundRequest.setCustId(accountNumber);
        fundRequest.setRrn(wibmoTxnId);
        fundRequest.setWalletId(walletId);
        fundRequest.setSendMoneyTransactionType("W2UPI");
        log.info("cbs funds load SendMoneyTransactionType :: {}",fundRequest.getSendMoneyTransactionType());
        customFundHeader = new LinkedMultiValueMap<>();
        customFundHeader.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
        customFundHeader.add("X-PROGRAM-ID", programId);
        customFundHeader.add("X-ACCOUNT-NUMBER", accountNumber);
        HttpEntity<Object> fundLoadEntity = new HttpEntity<>(fundRequest, customFundHeader);
        try {
            responseEntity = restTemplate.exchange(walletUrl + Constants.CREDIT_FUND_EP, HttpMethod.POST, fundLoadEntity, WibmoResponse.class);
            WibmoResponse apiResponse = responseEntity.getBody();
            if (null != apiResponse && apiResponse.getResCode() == 1) {
                response = dozerBeanMapper.map(apiResponse.getData(), FundResponse.class);
                return response;
            }else {
                log.info("amount not credited! Error occurred in load fund process");
                log.error("{}",apiResponse);
            }
        }catch (Exception ex){
            log.error("Exception while loadFunds :: {}",ex);
        }
        return response;
    }

    private WibmoResponse buildWibmoResponse(WibmoResponse response, int respCode, String respDesc) {
        response.setResCode(respCode);
        response.setResDesc(respDesc);
        return response;
    }

    @Override
    public String buildRequestPayload(int programId, String request) {
        log.info("buildRequestPayload request : {}", request);
        VpaTxnInfo vpaTxnInfo = null;
        VPADetails vpaDetails = null;
        String result = "";
        Timestamp currentTime = new Timestamp(new Date().getTime());
        try {
            ThreadLocalStorage.setTenantId(programId);
            vpaTxnInfo = vpaTxnDAO.fetchByGatewayTxnId(request);
            UpiCollectRequestDetails upiCollectRequestDetails = new UpiCollectRequestDetails();
            upiCollectRequestDetails.setAmount(new DecimalFormat("0.##").format(vpaTxnInfo.getAmount()));
            upiCollectRequestDetails.setExpiry(new Timestamp(new Date().getTime() + 10 * 10 * 1000));
            upiCollectRequestDetails.setCustomResponse("{}");
            upiCollectRequestDetails.setGatewayReferenceId(vpaTxnInfo.getGatewayReferenceId());
            upiCollectRequestDetails.setGatewayTransactionId(vpaTxnInfo.getGatewayTxnId());
            upiCollectRequestDetails.setIsVerifiedPayee("true");
            upiCollectRequestDetails.setIsMarkedSpam("true");
            ThreadLocalStorage.setTenantId(programId);
            vpaDetails = vpaDetailsDAO.findByVpa(vpaTxnInfo.getPayerVpa());
            upiCollectRequestDetails.setMerchantCustomerId(vpaDetails == null ? null : String.valueOf(vpaDetails.getAccountNumber()));
            upiCollectRequestDetails.setPayerMerchantCustomerId(vpaDetails == null ? null : String.valueOf(vpaDetails.getAccountNumber()));

            upiCollectRequestDetails.setPayeeMerchantCustomerId(vpaTxnInfo.getMerchantCustomerId());
            upiCollectRequestDetails.setMerchantId(vpaTxnInfo.getMerchantRequestId());
            upiCollectRequestDetails.setPayeeMcc(vpaTxnInfo.getPayeeMcc());
            upiCollectRequestDetails.setPayeeName(vpaTxnInfo.getPayeeName());
            upiCollectRequestDetails.setPayeeVpa(vpaTxnInfo.getPayeeVpa());
            upiCollectRequestDetails.setPayerVpa(vpaTxnInfo.getPayerVpa());
            upiCollectRequestDetails.setCollectType("MANDATE");
            upiCollectRequestDetails.setSeqNumber("1");
            upiCollectRequestDetails.setRefUrl("https://www.abcxyz.com/");
            upiCollectRequestDetails.setRemarks("This is remarks");
            upiCollectRequestDetails.setTransactionTimestamp(currentTime);
            upiCollectRequestDetails.setType("COLLECT_REQUEST_RECEIVED");
            log.info("test");

            ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
            result = ow.writeValueAsString(upiCollectRequestDetails);
            log.info("buildRequestPayload result : {}", request);
        } catch (Exception e) {
            log.error("Exception in TestController : buildRequestPayload {}", e);
        }
        return result;
    }

    public TxnHistory fetchTxnHistory(TxnCreditDetailRequest txnDetailRequest, String programId){
        TxnHistory txnHistory = null;
        try {
            MultiValueMap<String, String> customTxnHistoryHeader = new LinkedMultiValueMap<>();
            customTxnHistoryHeader.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
            customTxnHistoryHeader.add(Constants.X_PROGRAM_ID, programId);
            HttpEntity<Object> txnHistoryEntity = new HttpEntity<>(txnDetailRequest, customTxnHistoryHeader);
            ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(txnHistoryUrl + "/txnHistory/creditdetail/v1", HttpMethod.POST, txnHistoryEntity, WibmoResponse.class);
            WibmoResponse apiResponse = responseEntity.getBody();

            if (apiResponse != null && apiResponse.getData() != null) {
                txnHistory = dozerBeanMapper.map(apiResponse.getData(), TxnHistory.class);
            }
        }catch (Exception ex){
            log.info("Exception while getting txnDetails :: {}",ex);
        }
        return txnHistory;
    }
    public void updateRMCTxnDetails(String programId,int customerId,String gatewayTransactionId,String cbsAmount, VpaTxnInfoDetails vpaTxnInfoDetails){
        String agentName = programParamsDAO.fetchParamValueByParamName(programId, Constants.AGENT_NAME);
        String vpaAddress = programParamsDAO.fetchParamValueByParamName(programId, Constants.VPA_ADDRESS_PAYU);
        if ((vpaTxnInfoDetails.getPayeeVpa().contains(agentName) || vpaTxnInfoDetails.getPayeeVpa().contains("bankezy")) && vpaTxnInfoDetails.getPayeeVpa().contains(vpaAddress)) {
            log.info("payee belongs to citrus");
            VerifyVpaRequest verifyVpaRequest = new VerifyVpaRequest();
            verifyVpaRequest.setVpa(vpaTxnInfoDetails.getPayerVpa());
            WibmoResponse wibmoResponse = upiService.verifyVpa(programId, verifyVpaRequest);

            VerifyVpaResponse vpaResponse = wibmoResponse !=null ? (VerifyVpaResponse) wibmoResponse.getData() : null;

            // update txn history
            StringBuilder txnDesc = new StringBuilder();
            CreditStatusTxnDetailsRequest cs = new CreditStatusTxnDetailsRequest();
            cs.setOriginalTxnId(gatewayTransactionId);
            cs.setTxnCategory("RMC");
            cs.setTxnStatus("S");
            txnDesc.append(Constants.RECEIVED).append(Constants.RS_SYMBOL).append(CommonUtil.decimalFormat(Long.parseLong(cbsAmount))).append(Constants.FROM).append(vpaResponse!=null ? vpaResponse.getName():vpaTxnInfoDetails.getPayerVpa());
            cs.setTxnDesc(txnDesc.toString());
            log.info(" txn desc creditMoneyCBSCallback : {} ", cs.getTxnDesc());
            cs.setTxnShortDesc(vpaResponse != null ? vpaResponse.getName():vpaTxnInfoDetails.getPayerVpa());
            cs.setMerCategory("Request Accepted");
            TxnDetails txnDetails = new TxnDetails();
            txnDetails.setProgramId(programId);
            txnDetails.setTxnType(Constants.CREDIT_MONEY_CBS_ONUS);
            txnDetails.setData(cs);
            log.info("updating details in txnHistory");
            Runnable runnable = () -> kafkaProducer.publishUpiTxn(txnDetails);
            new Thread(runnable).start();
        } else {
            log.info("payee not belongs to citrus");
            // insert into txn history
            CreditMoneyTxnDetailsRequest cm = new CreditMoneyTxnDetailsRequest();
            cm.setCustomerId(customerId + "");
            cm.setOriginalTxnId(gatewayTransactionId);
            cm.setTxnCategory("RMC");
            cm.setTxnStatus("S");
            cm.setTxnAmount(Long.parseLong(cbsAmount));
            cm.setTxnType("RM");
            cm.setPaymentMode("RW");
            cm.setTxnDate(new Timestamp(System.currentTimeMillis()));
            cm.setTxnFlow("O");
            cm.setMerCategory("Request Accepted");
            TxnDetails txnDetails = new TxnDetails();
            txnDetails.setProgramId(programId);
            txnDetails.setTxnType(Constants.CREDIT_MONEY_CBS_OFFUS);
            txnDetails.setData(cm);

            Runnable runnable = () -> kafkaProducer.publishUpiTxn(txnDetails);
            new Thread(runnable).start();

        }

    }
    public void prepareCBSSuccessResponse(JuspayCallbackResponse response,CBSRequest cbsRequest,CreditMoneyCBSResponse cbsResponse )
    {
        String gatewayTransactionId = cbsRequest.getGatewayTransactionId();
        String accountIdentifier = cbsRequest.getAccountIdentifier();
        String amount = cbsRequest.getAmount();
        String gatewayReferenceId = cbsRequest.getGatewayReferenceId();
        response.setResponseCode(SUCCESS);
        response.setStatus(SUCCESS);
        response.setResponseMessage(SUCCESS);
        cbsResponse.setCbsStatus(SUCCESS);
        cbsResponse.setCbsResponseCode(SUCCESS);
        cbsResponse.setAmount(amount);
        cbsResponse.setGatewayTransactionId(gatewayTransactionId);
        cbsResponse.setGatewayReferenceId(gatewayReferenceId);
        cbsResponse.setAccountIdentifier(accountIdentifier);
        cbsResponse.setUpdatedAt(CommonHelper.juspayExpectedDate());
    }

    public void prepareCBSSuccessResponse(JuspayCallbackResponse response,CBSRequest cbsRequest,TxnHistory txnHistory){
        log.info("prepareCBSSuccessResponse");
        CreditMoneyCBSResponse cbsResponse = new CreditMoneyCBSResponse();
        prepareCBSSuccessResponse(response, cbsRequest,cbsResponse);
        cbsResponse.setCbsReferenceId(txnHistory.getPpTxnId());
        cbsResponse.setRemarks(txnHistory.getRemarks());
        response.setPayload(cbsResponse);
    }

    public void prepareCBSFailureResponse(JuspayCallbackResponse response, JuspayCallbackStatusConstants cbsCallbackFailureUb){
        response.setResponseCode(FAILURE);
        response.setResponseMessage(FAILURE);
        response.setStatus(FAILURE);
        CreditMoneyCBSResponse cbsResponse = new CreditMoneyCBSResponse();
        cbsResponse.setCbsStatus(FAILURE);
        cbsResponse.setCbsResponseCode(cbsCallbackFailureUb.getStatusCode());
        cbsResponse.setCbsResponseMessage(cbsCallbackFailureUb.getStatusMsg());
        response.setPayload(cbsResponse);
    }
    private void handleDebitReversal(String programId,VpaTxnInfoDetails vpaTxnInfoDetails,CBSRequest cbsRequest,JuspayCallbackResponse response) {
        log.info("Debit reversal ");
        String cbsAmount = cbsRequest.getAmount().replace(".","");
        String payeeVpa = vpaTxnInfoDetails.getPayeeVpa();
        VpaDetails vpaDetails = upiRegistrationDAO.fetchVpaDetailsBasesOnVpa(payeeVpa);
        int customerId = vpaDetails.getAccountNmber();
        int walletId = vpaDetails.getWalletId();
        FundResponse fundResponse = loadFunds(programId, customerId + "", cbsAmount, walletId);

        if(fundResponse!=null) {
            Runnable creditSuccessStatus = () -> kafkaProducer.publishUpiTxnTracking(cbsRequest.getGatewayTransactionId(), TxnTrackingConstants.CREDIT_MONEY_SUCCESS);
            new Thread(creditSuccessStatus).start();
            log.info("Debit reversal done....");

            CreditMoneyCBSResponse cbsResponse = new CreditMoneyCBSResponse();
            prepareCBSSuccessResponse(response, cbsRequest,cbsResponse);
            cbsResponse.setRemarks("Amount Reversed");
            response.setPayload(cbsResponse);
            String gatewayTransactionId = cbsRequest.getGatewayTransactionId();
            Runnable txnTracking = () -> kafkaProducer.publishUpiTxnTracking(gatewayTransactionId, TxnTrackingConstants.DEBIT_REVERSAL_SUCCESS);
            new Thread(txnTracking).start();
        }else{
            log.info("Debit reversal failed....");
            String gatewayTransactionId = cbsRequest.getGatewayTransactionId();
            Runnable txnTracking = () -> kafkaProducer.publishUpiTxnTracking(gatewayTransactionId, TxnTrackingConstants.DEBIT_REVERSAL_FAILURE);
            new Thread(txnTracking).start();
        }
    }
    private void handleRequestMoneyCBS(String programId,CBSRequest cbsRequest, VpaTxnInfoDetails vpaTxnInfoDetails,JuspayCallbackResponse response){
        log.info("Considering this callback for request money event...");
        TxnCreditDetailRequest txnDetailRequest = new TxnCreditDetailRequest();
        txnDetailRequest.setCategory("RMC");
        txnDetailRequest.setOriginalTxnId(cbsRequest.getGatewayTransactionId());
        txnDetailRequest.setStatus("S");

        try {
            String cbsAmount = cbsRequest.getAmount().replace(".","");
            TxnHistory txnHistory = fetchTxnHistory(txnDetailRequest,programId);
            if (txnHistory != null) {
                log.info("already credit happened");
                prepareCBSSuccessResponse(response,cbsRequest,txnHistory);
            } else {
                log.info("Amount is not credited to payee so trying to send");
                String payeeVpa = vpaTxnInfoDetails.getPayeeVpa();
                VpaDetails vpaDetails = upiRegistrationDAO.fetchVpaDetailsBasesOnVpa(payeeVpa);
                int customerId = vpaDetails.getAccountNmber();
                int walletId = vpaDetails.getWalletId();
                log.info("Loading amount");

                FundResponse fundResponse = loadFunds(programId, customerId + "", cbsAmount, walletId);

                if(fundResponse!=null) {
                    Runnable creditSuccessStatus = () -> kafkaProducer.publishUpiTxnTracking(cbsRequest.getGatewayTransactionId(), TxnTrackingConstants.CREDIT_MONEY_SUCCESS);
                    new Thread(creditSuccessStatus).start();
                    log.info("Loaded amount");
                    response.setResponseCode(SUCCESS);
                    response.setResponseMessage(SUCCESS);
                    response.setStatus(SUCCESS);
                    CreditMoneyCBSResponse cbsResponse = new CreditMoneyCBSResponse();
                    cbsResponse.setCbsStatus(fundResponse.getPpResponseMessage());
                    cbsResponse.setCbsResponseCode(fundResponse.getPpResponseCode());
                    cbsResponse.setAmount(cbsRequest.getAmount());
                    cbsResponse.setGatewayTransactionId(cbsRequest.getGatewayTransactionId());
                    cbsResponse.setGatewayReferenceId(cbsRequest.getGatewayReferenceId());
                    cbsResponse.setAccountIdentifier(cbsRequest.getAccountIdentifier());
                    cbsResponse.setCbsReferenceId(fundResponse.getRefNumber());
                    cbsResponse.setUpdatedAt(CommonHelper.juspayExpectedDate());
                    cbsResponse.setRemarks(fundResponse.getRemarks());
                    response.setPayload(cbsResponse);
                    updateRMCTxnDetails(programId,customerId,cbsRequest.getGatewayTransactionId(),cbsAmount,vpaTxnInfoDetails);
                }
                else{
                    log.info(LOAD_FUND_IS_NOT_SUCCESSFUL);
                    Runnable txnFailureStatus = () -> kafkaProducer.publishUpiTxnTracking(cbsRequest.getGatewayTransactionId(), TxnTrackingConstants.CREDIT_MONEY_FAILURE);
                    new Thread(txnFailureStatus).start();
                    prepareCBSFailureResponse(response, JuspayCallbackStatusConstants.CBS_CALLBACK_FAILURE_UB);
                }
            }
        }
        catch (Exception ex){
            log.error("Exception in cbs :: {}",ex);
            Runnable txnCreditMoneyFailureStatus = () -> kafkaProducer.publishUpiTxnTracking(cbsRequest.getGatewayTransactionId(), TxnTrackingConstants.CREDIT_MONEY_FAILURE);
            new Thread(txnCreditMoneyFailureStatus).start();
            prepareCBSFailureResponse(response, JuspayCallbackStatusConstants.CBS_CALLBACK_FAILURE_UB);

        }

    }
    private void handleSentMoneyCBS(String programId,CBSRequest cbsRequest,VpaTxnInfoDetails vpaTxnInfoDetails,JuspayCallbackResponse response){

        log.info("Considering this callback for send money event ");
        TxnCreditDetailRequest txnDetailRequest = new TxnCreditDetailRequest();
        String gatewayTransactionId = cbsRequest.getGatewayTransactionId();
        String accountIdentifier = cbsRequest.getAccountIdentifier();
        String amount = cbsRequest.getAmount();
        String type = cbsRequest.getType();
        String complaintUpiRequestId = cbsRequest.getComplaintUpiRequestId();
        log.info("credit type :: {}",type);
        log.info("complaint id :: {}",complaintUpiRequestId);
        String cbsAmount = amount.replace(".", "");
        log.info("creditMoneyCBSCallback : cbsAmount : {}", cbsAmount);
        String gatewayReferenceId = cbsRequest.getGatewayReferenceId();
        String upiRequestIdPrefix = progParamDao.fetchParamValueByParamName(programId, ProgramParamConstants.UPI_REQUEST_ID_PREFIX.getValue());
        int lengthOfupiRequestIdPrefix = upiRequestIdPrefix.length();
        String originalTxnId = gatewayTransactionId.substring(lengthOfupiRequestIdPrefix);
        txnDetailRequest.setCategory("W2UPIC");
        txnDetailRequest.setOriginalTxnId(originalTxnId);
        txnDetailRequest.setStatus("S");
        try {

            TxnHistory txnHistory = fetchTxnHistory(txnDetailRequest,programId);
            if (txnHistory != null) {
                log.info("already credit happened");
                prepareCBSSuccessResponse(response,cbsRequest,txnHistory);
            } else {
                log.info("Amount is not credited to payee so trying to send");
                String destinationAccount = vpaTxnInfoDetails.getPayeeVpa();
                String payeeVpa = getVPA(programId,destinationAccount,accountIdentifier);
                log.info("destinationAccount :: {}",destinationAccount);
                log.info("payeeVpa :: {}",payeeVpa);
                VpaDetails vpaDetails = upiRegistrationDAO.fetchVpaDetailsBasesOnVpa(payeeVpa);
                int customerId = vpaDetails.getAccountNmber();
                int walletId = vpaDetails.getWalletId();

                FundResponse fundResponse = loadFunds(programId, customerId + "", cbsAmount, walletId);
                if(fundResponse!=null) {
                    Runnable txnTracking = () -> kafkaProducer.publishUpiTxnTracking(gatewayTransactionId, TxnTrackingConstants.CREDIT_MONEY_SUCCESS);
                    new Thread(txnTracking).start();
                        // insert into txn history
                        StringBuilder txnDesc = new StringBuilder();
                        CreditMoneyTxnDetailsRequest cm = new CreditMoneyTxnDetailsRequest();
                        cm.setPaymentTxnId(fundResponse.getRefNumber());
                        cm.setPpTxnId(fundResponse.getPpTxnId());
                        cm.setCustomerId(customerId + "");
                        cm.setDestAccount(destinationAccount);
                        cm.setSourceAccount(vpaTxnInfoDetails.getPayerVpa());
                        cm.setOriginalTxnId(originalTxnId);
                        cm.setTxnCategory("W2UPIC");
                        cm.setTxnStatus("S");
                        cm.setTxnAmount(Long.parseLong(cbsAmount));
                        cm.setTxnType("W2UPI");
                        cm.setPaymentMode("RW");
                        cm.setRemarks(vpaTxnInfoDetails.getMessage());
                        cm.setTxnDate(new Timestamp(System.currentTimeMillis()));
                        cm.setTxnFlow(I);

                        String payerName = getVPAName(programId,vpaTxnInfoDetails.getPayerVpa());
                        String payeeName = getVPAName(programId,vpaTxnInfoDetails.getPayeeVpa());
                        txnDesc.append(Constants.RECEIVED).append(Constants.RS_SYMBOL).append(CommonUtil.decimalFormat(Long.parseLong(cbsAmount))).append(Constants.FROM).append(payerName);
                        cm.setTxnDesc(txnDesc.toString());
                        log.info("txn desc creditMoneyCBSCallback : {} ", cm.getTxnDesc());
                        cm.setTxnShortDesc(payerName);
                        
                        CustomerMiniProfile payerMinProfile = apiManagerUtil.fetchUserProfile(programId, vpaTxnInfoDetails.getMerchantCustomerId(), null);
                        
                        //send notification alert to payer informing sendMoney event success
                        log.info("sending notification alert to payer informing sendMoney event success");
                        Map<String, String> placeHolder = new HashMap<>();
            			placeHolder.put("PAYER", payerName);
            			placeHolder.put("PAYEE", ((payeeName!=null)? payeeName : "PAYEE"));
            			placeHolder.put("CURRENCY", Constants.CURRENCY_IND);
            			placeHolder.put("AMOUNT", CommonUtil.decimalFormat(Long.parseLong(cbsAmount)));
                        NotificationRequest aRequest = NotificationRequest.builder()
                		        .mobileNumber(payerMinProfile.getMobileNo())
                		        .programId(Integer.valueOf(programId))
                		        .eventId(Integer.valueOf(Constants.RM_PAYER_ALERT_EVENT_ID))
                		        .emailId(payerMinProfile.getEmailId())
                		        .whatsappEnabled(false)
                		        .placeHolders(placeHolder).build();
                		NotificationServiceCall notificationServiceCall = new NotificationServiceCall();
                		notificationServiceCall.send(aRequest, notificationUrl);
                        
                        TxnDetails txnDetails = new TxnDetails();
                        txnDetails.setProgramId(programId);
                        txnDetails.setTxnType(Constants.CREDIT_MONEY_CBS_OFFUS);
                        txnDetails.setData(cm);

                        Runnable runnable = () -> kafkaProducer.publishUpiTxn(txnDetails);
                        new Thread(runnable).start();
                        
                        TxnDetails txnDetls = new TxnDetails();
                        txnDetls.setTxnType(TXN_UPDATE);
                        txnDetls.setProgramId(programId);
                        UpdtTxnDetails updtTxnDetails = new UpdtTxnDetails();
                        updtTxnDetails.setOriginalTxnId(originalTxnId);
                        updtTxnDetails.setTxnStatus("S");
                        updtTxnDetails.setTxnFlow("O");
                        txnDetls.setData(updtTxnDetails);
                        Runnable statusrunnable = () -> kafkaProducer.publishUpiTxn(txnDetls);
                        new Thread(statusrunnable).start();
                    response.setResponseCode(SUCCESS);
                    response.setResponseMessage(SUCCESS);
                    response.setStatus(SUCCESS);
                    CreditMoneyCBSResponse cbsResponse = new CreditMoneyCBSResponse();
                    cbsResponse.setCbsStatus(fundResponse.getPpResponseMessage());
                    cbsResponse.setCbsResponseCode(fundResponse.getPpResponseCode());
                    cbsResponse.setAmount(amount);
                    cbsResponse.setGatewayTransactionId(gatewayTransactionId);
                    cbsResponse.setGatewayReferenceId(gatewayReferenceId);
                    cbsResponse.setAccountIdentifier(accountIdentifier);
                    cbsResponse.setCbsReferenceId(fundResponse.getRefNumber());
                    cbsResponse.setUpdatedAt(CommonHelper.juspayExpectedDate());
                    cbsResponse.setRemarks(fundResponse.getRemarks());
                    response.setPayload(cbsResponse);
                }
                else{
                    log.info(LOAD_FUND_IS_NOT_SUCCESSFUL);
                    Runnable txnTracking = () -> kafkaProducer.publishUpiTxnTracking(gatewayTransactionId, TxnTrackingConstants.CREDIT_MONEY_FAILURE);
                    new Thread(txnTracking).start();
                    prepareCBSFailureResponse(response, JuspayCallbackStatusConstants.CBS_CALLBACK_FAILURE_UB);
                    
                    //write one kafka call passing originallTxnId, and status like failure in data
                    TxnDetails txnDetls = new TxnDetails();
                    txnDetls.setTxnType(TXN_UPDATE);
                    txnDetls.setProgramId(programId);
                    UpdtTxnDetails updtTxnDetails = new UpdtTxnDetails();
                    updtTxnDetails.setOriginalTxnId(originalTxnId);
                    updtTxnDetails.setTxnStatus("F");
                    updtTxnDetails.setTxnFlow("O");
                    txnDetls.setData(updtTxnDetails);
                    Runnable statusRunnable = () -> kafkaProducer.publishUpiTxn(txnDetls);
                    new Thread(statusRunnable).start();
                }
            }
        }
        catch (Exception ex){
            log.error("Exception in cbs :: {}",ex);
            Runnable creditFailStatus = () -> kafkaProducer.publishUpiTxnTracking(gatewayTransactionId, TxnTrackingConstants.CREDIT_MONEY_FAILURE);
            new Thread(creditFailStatus).start();
            prepareCBSFailureResponse(response, JuspayCallbackStatusConstants.CBS_CALLBACK_FAILURE_UB);

        }

    }
    private String getVPA(String programId,String destinationAccount, String accountIdentifier){
        log.info("programId :: {}, destinationAccount :: {},accountIdentifier :: {}",programId, destinationAccount, accountIdentifier);
        if(destinationAccount==null || destinationAccount.contains("ifsc.npci")){
            return getVpaBasicDetails(programId,accountIdentifier).getVpa();
        }else if(accountIdentifier.equalsIgnoreCase(merchantVpa)){
            return convertedMerchantVpa;
        }else
            return destinationAccount;
    }
    private VpaBasicDetails getVpaBasicDetails(String programId,String accountIdentifier){
        log.info("Crediting amount to using account number");
        if(accountIdentifier.length() > 8){
            log.info("account identifier :: {}",accountIdentifier.substring(8));
            accountIdentifier = accountIdentifier.substring(8); //extracting customerId or x-account-number
        }
        return upiRegistrationDAO.fetchVpaDetailsBasedOnAccountNo(programId, Integer.parseInt(accountIdentifier)).get(0);
    }
    private String getVPAName(String programId,String vpa){
        VerifyVpaRequest verifyVpaRequest = new VerifyVpaRequest();
        verifyVpaRequest.setVpa(vpa);
        WibmoResponse wibmoResponse = upiService.verifyVpa(programId, verifyVpaRequest);
        VerifyVpaResponse vpaResponse = wibmoResponse !=null ? (VerifyVpaResponse) wibmoResponse.getData() : null;
        String payerName = null;
        if(vpaResponse!=null){
            payerName = vpaResponse.getName();
        }
        return payerName;
    }
}
