package com.wibmo.dfs.upi.dao.impl;

import com.wibmo.dfs.upi.constants.Constants;
import com.wibmo.dfs.upi.dao.UpiCollectRequestDAO;
import com.wibmo.dfs.upi.entity.UpiCollectRequestDetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

@Repository
@Slf4j
public class UpiCollectRequestDAOImpl implements UpiCollectRequestDAO {
    public static final String EXCEPTION_MSG_SAVING_UPI_COLLECT_REQUEST = "Error occurred while saving UpiCollectRequestDAOImpl : saveUpiCollectRequestData {}";
    public static final String EXCEPTION_MSG_UPDATING_UPI_COLLECT_REQUEST = "Error occurred while updating UpiCollectRequestDAOImpl : updateUpiCollectRequestData {}";
    public static final String EXCEPTION_MSG_UPDATING_UPI_COLLECT_REQUEST_BY_TXN_ID = "Error occurred while updating UpiCollectRequestDAOImpl : updateUpiCollectRequestStatusByTxnId {}";
    public static final String EXCEPTION_MSG_UPDATING_STATUS_REMARKS_BY_GATEWAY_TXN_ID = "Error occurred while updating UpiCollectRequestDAOImpl : updateStatusRemarksByGatewayTxnId {}";
    public static final String EXCEPTION_MSG_FETCHING_UPI_COLLECT_REQUEST = "Error occurred while fetching UpiCollectRequestDAOImpl : fetchUpiCollectRequestData {}";
    public static final String EXCEPTION_MSG_FETCHING_UPI_COLLECT_REQUEST_PENDING = "Error occurred while fetching UpiCollectRequestDAOImpl : fetchPendingUpiCollectRequestData {}";
    public static final String EXCEPTION_MSG_FETCHING_PENDING_COLLECT_REQUEST = "Error occurred while fetching Pending List : fetchPendingCollectReques {}";
    private static final String SAVE_UPI_COLLECT_REQUEST_DETAILS = "INSERT INTO upi_collect_request (amount, expiry, gateway_reference_id, gateway_transaction_id, is_verified_payee, is_marked_spam, merchant_customer_id, merchant_id, payee_mcc, payee_merchant_customer_id, payee_name, payee_vpa, payer_merchant_customer_id, payer_vpa, collect_type, seq_number, ref_url, remarks, transaction_timestamp, status, created_by, updated_by, request_type) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    private static final String UPDATE_UPI_COLLECT_REQUEST_DETAILS = "update  upi_collect_request set status = ? where id = ?";
    private static final String UPDATE_UPI_COLLECT_REQUEST_DETAILS_BY_ID = "update  upi_collect_request set status = ? where gateway_transaction_id = ?";
    private static final String UPDATE_STATUS_REMARKS_BY_GATEWAY_TXN_ID = "update  upi_collect_request set status = ?, remarks = ? where gateway_transaction_id = ?";
    private static final String FETCHING_UPI_COLLECT_REQUEST_DETAILS = "select * from upi_collect_request where id = ?";
    private static final String FETCHING_PENDING_UPI_COLLECT_REQUEST_DETAILS_BLOCKED_VPA = "select * from upi_collect_request where payee_vpa = ?  and  payer_vpa = ? and status = ?";
    private static final String FETCHING_PENDING_LIST_BY_VPA = "select * from upi_collect_request where status = ? and payer_vpa = ?";
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public BigInteger saveUpiCollectRequestData(UpiCollectRequestDetails row) {
        log.debug("UpiCollectRequestDAOImpl : saveUpiCollectRequestData : row : {} ", row);
        KeyHolder keyHolder = null;
        try {
            keyHolder = new GeneratedKeyHolder();
            jdbcTemplate.update(connection -> {
                PreparedStatement ps = connection.prepareStatement(SAVE_UPI_COLLECT_REQUEST_DETAILS, Statement.RETURN_GENERATED_KEYS);
                int i = 1;
                ps.setString(i++, row.getAmount());
                ps.setTimestamp(i++, row.getExpiry());
                ps.setString(i++, row.getGatewayReferenceId());
                ps.setString(i++, row.getGatewayTransactionId());
                ps.setString(i++, row.getIsVerifiedPayee());
                ps.setString(i++, row.getIsMarkedSpam());
                ps.setString(i++, row.getMerchantCustomerId());
                ps.setString(i++, row.getMerchantId());
                ps.setString(i++, row.getPayeeMcc());
                ps.setString(i++, row.getPayeeMerchantCustomerId());
                ps.setString(i++, row.getPayeeName());
                ps.setString(i++, row.getPayeeVpa());
                ps.setString(i++, row.getPayerMerchantCustomerId());
                ps.setString(i++, row.getPayerVpa());
                ps.setString(i++, row.getCollectType());
                ps.setString(i++, row.getSeqNumber());
                ps.setString(i++, row.getRefUrl());
                ps.setString(i++, row.getRemarks());
                ps.setTimestamp(i++, row.getTransactionTimestamp());
                ps.setString(i++, row.getStatus());
                ps.setString(i++, row.getCreatedBy());
                ps.setString(i++, row.getUpdatedBy());
                ps.setString(i++, row.getType());
                return ps;
            }, keyHolder);
            if(keyHolder.getKey() != null){
                return (BigInteger) keyHolder.getKey();
            }
        } catch (DataAccessException e) {
            log.error(EXCEPTION_MSG_SAVING_UPI_COLLECT_REQUEST, e);
        }
        return BigInteger.ZERO;
    }

    @Override
    public void updateUpiCollectRequestData(UpiCollectRequestDetails row) {
        log.debug("UpiCollectRequestDAOImpl : updateUpiCollectRequestData : row : {} ", row);
        String sql = UPDATE_UPI_COLLECT_REQUEST_DETAILS;
        try {
            jdbcTemplate.update(sql, row.getStatus(), row.getId());
        } catch (DataAccessException e) {
            log.error(EXCEPTION_MSG_UPDATING_UPI_COLLECT_REQUEST, e);
        }
    }

    @Override
    public void updateUpiCollectRequestStatusByTxnId(String status, String gatewayTxnId) {
        log.debug("UpiCollectRequestDAOImpl : updateUpiCollectRequestData : id : {} ", gatewayTxnId);
        String sql = UPDATE_UPI_COLLECT_REQUEST_DETAILS_BY_ID;
        try {
            jdbcTemplate.update(sql, status, gatewayTxnId);
        } catch (DataAccessException e) {
            log.error(EXCEPTION_MSG_UPDATING_UPI_COLLECT_REQUEST_BY_TXN_ID, e);
        }
    }

    @Override
    public UpiCollectRequestDetails fetchUpiCollectRequestData(long id) {
        log.debug("UpiCollectRequestDAOImpl : fetchUpiCollectRequestData : id : {} ", id);
        UpiCollectRequestDetails row = new UpiCollectRequestDetails();
        try {
            String db = FETCHING_UPI_COLLECT_REQUEST_DETAILS;
            return jdbcTemplate.query(db, new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setLong(1, id);
                }
            }, new ResultSetExtractor<UpiCollectRequestDetails>() {
                @Override
                public UpiCollectRequestDetails extractData(ResultSet rs) throws SQLException {
                    if (rs.next()) {
                        row.setId(rs.getLong("id"));
                        row.setAmount(rs.getString("amount"));
                        row.setExpiry(rs.getTimestamp("expiry"));
                        row.setGatewayReferenceId(rs.getString("gateway_reference_id"));
                        row.setGatewayTransactionId(rs.getString("gateway_transaction_id"));
                        row.setIsVerifiedPayee(rs.getString("is_verified_payee"));
                        row.setIsMarkedSpam(rs.getString("is_marked_spam"));
                        row.setMerchantCustomerId(rs.getString("merchant_customer_id"));
                        row.setMerchantId(rs.getString("merchant_id"));
                        row.setPayeeMcc(rs.getString("payee_mcc"));
                        row.setPayeeMerchantCustomerId(rs.getString("payee_merchant_customer_id"));
                        row.setPayeeName(rs.getString("payee_name"));
                        row.setPayeeVpa(rs.getString("payee_vpa"));
                        row.setPayerVpa(rs.getString("payer_vpa"));
                        row.setPayerMerchantCustomerId(rs.getString("payer_merchant_customer_id"));
                        row.setCollectType(rs.getString("collect_type"));
                        row.setSeqNumber(rs.getString("seq_number"));
                        row.setRefUrl(rs.getString("ref_url"));
                        row.setRemarks(rs.getString("remarks"));
                        row.setTransactionTimestamp(rs.getTimestamp("transaction_timestamp"));
                        row.setStatus(rs.getString("status"));
                        row.setCreatedBy(rs.getString("created_by"));
                        row.setUpdatedBy(rs.getString("updated_by"));
                        row.setUpdateTs(rs.getTimestamp("updated_ts"));
                        row.setCreatedTs(rs.getTimestamp("created_ts"));
                        row.setType(rs.getString("request_type"));
                        return row;
                    } else {
                        return null;
                    }
                }
            });
        } catch (DataAccessException e) {
            log.error(EXCEPTION_MSG_FETCHING_UPI_COLLECT_REQUEST, e);
        }
        return row;
    }

    @Override
    public List<UpiCollectRequestDetails> fetchPendingCollectRequest(String vpa) {
        log.debug("UpiCollectRequestDAOImpl : fetchPendingCollectRequest : vpa : {} ", vpa);
        List<UpiCollectRequestDetails> row = new ArrayList<>();
        try {
            BeanPropertyRowMapper<UpiCollectRequestDetails> rowMapper = BeanPropertyRowMapper.newInstance(UpiCollectRequestDetails.class);
            row = jdbcTemplate.query(FETCHING_PENDING_LIST_BY_VPA, new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setString(1, Constants.PENDING);
                    ps.setString(2, vpa);
                }
            }, rowMapper);
        } catch (Exception e) {
            log.error(EXCEPTION_MSG_FETCHING_PENDING_COLLECT_REQUEST, e);
        }
        return row;
    }

    @Override
    public List<UpiCollectRequestDetails> fetchPendingUpiCollectRequestData(String payeeVpa, String payerVpa, String status) {
        log.debug("UpiCollectRequestDAOImpl : fetchPendingUpiCollectRequestData : payeeVpa : {} payerVpa : {} status : {} ", payeeVpa, payerVpa, status);
        List<UpiCollectRequestDetails> row = new ArrayList<>();
        try {
            BeanPropertyRowMapper<UpiCollectRequestDetails> rowMapper = BeanPropertyRowMapper.newInstance(UpiCollectRequestDetails.class);
            row = jdbcTemplate.query(FETCHING_PENDING_UPI_COLLECT_REQUEST_DETAILS_BLOCKED_VPA, new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setString(1, payeeVpa);
                    ps.setString(2, payerVpa);
                    ps.setString(3, status);
                }
            }, rowMapper);
        } catch (Exception e) {
            log.error(EXCEPTION_MSG_FETCHING_UPI_COLLECT_REQUEST_PENDING, e);
        }
        return row;
    }

    @Override
    public void updateStatusRemarksByGatewayTxnId(String status,String remarks,  String gatewayTxnId) {
        log.debug("UpiCollectRequestDAOImpl : updateStatusRemarksByGatewayTxnId : id : {} status : {} remarks : {} ", gatewayTxnId, status, remarks);
        String sql = UPDATE_STATUS_REMARKS_BY_GATEWAY_TXN_ID;
        try {
            jdbcTemplate.update(sql, status, remarks, gatewayTxnId);
        } catch (DataAccessException e) {
            log.error(EXCEPTION_MSG_UPDATING_STATUS_REMARKS_BY_GATEWAY_TXN_ID, e);
        }
    }
}
