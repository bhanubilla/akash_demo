package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayRaiseComplaintUdirPayload {

    private String payerVpa;
    private String payeeVpa;
    private String merchantId;
    private String merchantChannelId;
    private String merchantCustomerId;
    private String customerMobileNumber;
    private String merchantRequestId;
    private String reqAdjAmount;
    private String reqAdjFlag;
    private String reqAdjCode;
    private String crn;
    private String gatewayReferenceId;
    private String gatewayComplaintId;
    private String gatewayResponseCode;
    private String gatewayResponseStatus;
    private String gatewayResponseMessage;
    private String txnId;
}
