package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayDeleteVpaAccount {
    private JuspayDeleteAccount account;
    private String vpa;
    private String isDefault;
}
