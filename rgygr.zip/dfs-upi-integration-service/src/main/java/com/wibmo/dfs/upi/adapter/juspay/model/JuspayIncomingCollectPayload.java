package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class JuspayIncomingCollectPayload extends JuspayIncomingCommonPayload {
    private String merchantId;
    private String merchantChannelId;
    private String merchantCustomerId;
    private String merchantRequestId;
    private String customerMobileNumber;
    private String payeeMerchantCustomerId;
    private String payeeVpa;
    private String payeeMcc;
    private String payerVpa;
    private String payeeName;
    private String requestType;
    private String collectType;
    private String seqNumber;
}
