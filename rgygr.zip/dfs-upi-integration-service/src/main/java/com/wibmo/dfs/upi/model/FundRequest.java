package com.wibmo.dfs.upi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FundRequest {
	@ApiModelProperty(required = false, dataType="String", hidden = true)
	private String custId;

	@ApiModelProperty(required = true, dataType="int")
	private int walletId;
	
	@ApiModelProperty(required = true, dataType="long")
	private long amount;
	
	@ApiModelProperty(required = false, dataType="String")
	private String mcc;
	
	@ApiModelProperty(required = false, dataType="String")
	private String rrn;
	
	@ApiModelProperty(required = true, dataType="String", example="Load Money", notes="possible values are Load Money, P2M, W2A, P2P Credit and P2P Debit, etc")
	private String txnType;

	@ApiModelProperty(required = true, dataType="String")
	private String merchantId;

	@ApiModelProperty(hidden = true, required = false, dataType="String")
	private String sourceAccount;

	@ApiModelProperty(required = false, dataType="String", notes = "Required for refund transactions")
	private String originalRRN;

	@ApiModelProperty(required = false, dataType="String", notes = "Required for refund transactions")
	private String beneficiaryName;

	private String sendMoneyTransactionType;

}