package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayDeclineDeviceBindingRequest {
    private String merchantCustomerId;
    private String smsContent;
    private String udfParameters;
}
