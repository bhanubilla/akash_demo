package com.wibmo.dfs.upi.model.response;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AddVpaResponse {
    private String status;
    private String responseCode;
    private String responseMessage;
    private AddVpaPayload payload;
    private String udfParameters;
}
