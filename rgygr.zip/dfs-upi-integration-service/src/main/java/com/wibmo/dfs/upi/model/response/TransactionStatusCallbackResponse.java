package com.wibmo.dfs.upi.model.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class TransactionStatusCallbackResponse {

    private String gatewayResponseCode;
    private String gatewayResponseStatus;
}
