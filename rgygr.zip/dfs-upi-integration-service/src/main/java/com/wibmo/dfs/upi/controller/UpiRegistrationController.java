package com.wibmo.dfs.upi.controller;

import com.wibmo.dfs.upi.constants.UpiStatusConstants;
import com.wibmo.dfs.upi.model.request.*;
import com.wibmo.dfs.upi.model.response.WibmoResponse;
import com.wibmo.dfs.upi.service.UpiService;
import com.wibmo.dfs.upi.validator.RequestValidator;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/upi/registration")
@Slf4j
public class UpiRegistrationController {
	
	private static final String ERROR_DESC = "Error Desc : {}";
	public static final String ERR_DESC = "Error Occurred {}";
	
	@Autowired
	private UpiService upiService;
	
	@Autowired
	private RequestValidator validator;
    
	@PostMapping("/v1/status")
    public WibmoResponse checkDeviceStatus(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber, @RequestBody CheckDeviceStatusRequest request) {
        log.info("UpiRegistrationController : checkDeviceStatus : programId-{}, accountNumber-{}, request- {}", programId, accountNumber, request);
        WibmoResponse response = new WibmoResponse();
        try {
		    validator.validateCheckDeviceStatus(request, response);
			if (response.getResCode() > 0) {
				log.info(ERROR_DESC, response.getResDesc());
				response = new WibmoResponse(response.getResCode(), response.getResDesc());
			} else {
				response = upiService.checkDeviceBindingStatus(programId, Integer.parseInt(accountNumber), request);
			}
        } catch(Exception e) {
        	log.error(ERR_DESC, e.getMessage());
            response = new WibmoResponse(UpiStatusConstants.BAD_REQUEST, response.getResDesc());
        }
        return response;
    }
	
	@PostMapping("/v1/smstoken")
    public WibmoResponse getSMSToken(@RequestBody SmsTokenRequest request, @RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber) {
        log.info("getSMSToken for programId : {} - account Number : {} - provider : {}", programId, accountNumber, request.getServiceProvider());
        return upiService.getSmsToken(programId, accountNumber, request);
    }

    @PostMapping("/v1/deviceBinding")
    public WibmoResponse deviceBinding(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber, @RequestBody DeviceBindingRequest request) {
        log.info("check device binding status");
        WibmoResponse response = new WibmoResponse();
        try {
		    validator.validateDeviceBinding(request, response);
			if (response.getResCode() > 0) {
				log.info(ERROR_DESC, response.getResDesc());
				response = new WibmoResponse(response.getResCode(), response.getResDesc());
			} else {
				response = upiService.deviceBinding(programId, Integer.parseInt(accountNumber), request);
			}
        } catch(Exception e) {
        	log.error(ERR_DESC, e.getMessage());
            response = new WibmoResponse(UpiStatusConstants.BAD_REQUEST, response.getResDesc());
        }
        return response;
    }
    
	@PostMapping("/v1/vpaValid")
  public WibmoResponse isVpaAvailable(@RequestBody VpaValidRequest request, @RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber) {
      log.info("isVpaAvailable for programId : {} - account Number : {}- vpa : {}", programId, accountNumber, request.getVpa());
      
      WibmoResponse response = new WibmoResponse();
      try {
		    validator.validateIsVpaAvailable(request, response);
			if (response.getResCode() > 0) {
				log.info(ERROR_DESC, response.getResDesc());
				response = new WibmoResponse(response.getResCode(), response.getResDesc());
			} else {
				response = upiService.isVpaAvailable(programId, accountNumber, request);
			}
      } catch(Exception e) {
      	log.error(ERR_DESC, e.getMessage());
          response = new WibmoResponse(UpiStatusConstants.BAD_REQUEST, response.getResDesc());
      }
      return response;
  }

    @PostMapping("/v1/decline/deviceBinding")
    public WibmoResponse declineDeviceBinding(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber, @RequestBody DeclineDeviceBindingRequest request) {
        log.info("check decline device binding status");
        return upiService.declineDeviceBinding(programId, accountNumber, request);
    }

    @PostMapping("/v1/link/vpa")
    public WibmoResponse linkVPA(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber,@RequestBody LinkVPARequest request){
        log.info("link vpa");
        WibmoResponse response = new WibmoResponse();
        try {
  		    validator.validateLinkVPA(request, response);
  			if (response.getResCode() > 0) {
  				log.info(ERROR_DESC, response.getResDesc());
  				response = new WibmoResponse(response.getResCode(), response.getResDesc());
  			} else {
  				response = upiService.createAndLink(programId, accountNumber, request);
  			}
        } catch(Exception e) {
        	log.error(ERR_DESC, e.getMessage());
            response = new WibmoResponse(UpiStatusConstants.BAD_REQUEST, response.getResDesc());
        }
        return response;
        
    }

    @PostMapping("/v1/polling")
    public WibmoResponse pollingForVPAStatus(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber, @RequestBody PollingRequest request) {
        log.info("UpiRegistrationController : pollingForVPAStatus : programId-{}, accountNumber-{}, request- {}", programId, accountNumber, request);
        return upiService.pollingForVPAStatus(programId, Integer.parseInt(accountNumber), request);
    }

    @PostMapping("/v1/deregister")
    public WibmoResponse deRegisterCustomer(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber, @RequestBody DeregisterCustomerRequest request) {
        log.info("de register vpa from upi eco system");
        return upiService.deRegisterCustomer(programId, accountNumber, request);
    }

}
