package com.wibmo.dfs.upi.adapter.juspay.model;

import com.wibmo.dfs.upi.model.Identifier;
import com.wibmo.dfs.upi.model.MerchantType;
import com.wibmo.dfs.upi.model.Name;
import com.wibmo.dfs.upi.model.Ownership;
import com.wibmo.dfs.upi.model.response.VerifyVpaResponse;
import org.springframework.stereotype.Component;

@Component
public class JuspayVerifyVpaResponseMapper {
	public VerifyVpaResponse map(JuspayVerifyVpaResponse res) {
		VerifyVpaResponse response = new VerifyVpaResponse();

		response.setMerchantId(res.getPayload().getMerchantId());
		response.setMerchantChannelId(res.getPayload().getMerchantChannelId());
		response.setGatewayTransactionId(res.getPayload().getGatewayTransactionId());
		response.setGatewayResponseCode(res.getPayload().getGatewayResponseCode());
		response.setGatewayResponseStatus(res.getPayload().getGatewayResponseStatus());
		response.setGatewayResponseMessage(res.getPayload().getGatewayResponseMessage());
		response.setVpa(res.getPayload().getVpa());
		if (res.getPayload().getGatewayResponseCode().equals("00")) {
			response.setName(res.getPayload().getName());
			response.setIfsc(res.getPayload().getIfsc());
			response.setIin(res.getPayload().getIin());
		}
		response.setMandateSupported(res.getPayload().isMandateSupported());
		response.setIsMerchant(res.getPayload().getIsMerchant());
		if (Boolean.parseBoolean(res.getPayload().getIsMerchant())) {
			response.setIsMerchantVerified(res.getPayload().getIsMerchantVerified());
			response.setMcc(res.getPayload().getMcc());
			MerchantType merchantType = new MerchantType();
			Identifier identifier = new Identifier();
			Name name = new Name();
			Ownership ownership = new Ownership();
			if(res.getPayload().getMerchantType().getIdentifier() != null ){
				identifier.setSubCode(res.getPayload().getMerchantType().getIdentifier().getSubCode());
				identifier.setMid(res.getPayload().getMerchantType().getIdentifier().getMid());
				identifier.setSid(res.getPayload().getMerchantType().getIdentifier().getSid());
				identifier.setTid(res.getPayload().getMerchantType().getIdentifier().getTid());
				identifier.setMerchantType(res.getPayload().getMerchantType().getIdentifier().getMerchantType());
			}
			if(res.getPayload().getMerchantType().getName() != null) {
				name.setBrand(res.getPayload().getMerchantType().getName().getBrand());
				name.setLegal(res.getPayload().getMerchantType().getName().getLegal());
				name.setFranchise(res.getPayload().getMerchantType().getName().getFranchise());
			}
			if(res.getPayload().getMerchantType().getOwnership() != null)
				ownership.setType(res.getPayload().getMerchantType().getOwnership().getType());

			merchantType.setIdentifier(identifier);
			merchantType.setName(name);
			merchantType.setOwnership(ownership);
			response.setMerchantType(merchantType);

		}
		return response;
	}
}
