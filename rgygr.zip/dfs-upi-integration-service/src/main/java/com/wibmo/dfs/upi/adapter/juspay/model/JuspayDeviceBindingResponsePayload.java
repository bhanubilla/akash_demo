package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class JuspayDeviceBindingResponsePayload implements Serializable {
	private String merchantId;
	private String merchantChannelId;
	private String merchantCustomerId;
	private String customerMobileNumber;
	private String deviceFingerPrint;
}
