package com.wibmo.dfs.upi.dao.impl;

import com.wibmo.dfs.upi.constants.Constants;
import com.wibmo.dfs.upi.dao.VPALinkedAccountDAO;
import com.wibmo.dfs.upi.model.VPALinkedAccount;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
@Slf4j
public class VPALinkedAccountDAOImpl implements VPALinkedAccountDAO {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public void save(VPALinkedAccount vpaLinkedAccount) {
        try {
            jdbcTemplate.update("INSERT INTO vpa_linked_account(account_number,bank_name,bank_account_number,bank_ifsc,bank_code,type,bankAccUniqueId)" +
                    " VALUES (?, ?, ?, ?, ?, ?, ?) ", vpaLinkedAccount.getAccountNumber(), vpaLinkedAccount.getBankName(), vpaLinkedAccount.getBankAccountNumber(), vpaLinkedAccount.getBankIfsc(), vpaLinkedAccount.getBankCode(), vpaLinkedAccount.getType(), vpaLinkedAccount.getBankAccUniqueId());
        }catch(Exception exception){
        log.error("Exception while saving vpa details :: ",exception);
        }
    }

    @Override
    public VPALinkedAccount findByAccountNumber(Long accountNumber) {
        try{
           return jdbcTemplate.queryForObject("SELECT * FROM vpa_linked_account where account_number = ? order by id desc limit 1", new RowMapper<VPALinkedAccount>() {
                @Override
                public VPALinkedAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
                    var row = new VPALinkedAccount();
                    row.setId(rs.getLong(Constants.ID));
                    row.setAccountNumber(rs.getLong(Constants.ACCOUNT_NUMBER));
                    row.setBankName(Constants.BANK_NAME);
                    row.setBankAccountNumber(rs.getString(Constants.BANK_ACCOUNT_NUMBER));
                    row.setBankIfsc(rs.getString(Constants.BANK_IFSC));
                    row.setBankCode(rs.getString(Constants.BANK_CODE));
                    row.setType(rs.getString(Constants.TYPE));
                    row.setBankAccUniqueId(rs.getString(Constants.BANK_ACC_UNIQUE_ID));
                    return row;
                }
            },accountNumber);
        }catch (Exception exception){
            log.error("Exception while getting vpa linked account details :: ",exception);
        }
        return null;
    }

    @Override
    public VPALinkedAccount findByBankAccountNumber(String bankAccountNumber) {
        VPALinkedAccount row = new VPALinkedAccount();
        try {
            return jdbcTemplate.query("SELECT * FROM vpa_linked_account where bank_account_number = ?", new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setString(1, bankAccountNumber);
                }
            }, new ResultSetExtractor<VPALinkedAccount>() {
                @Override
                public VPALinkedAccount extractData(ResultSet rs) throws SQLException {
                    if (rs.next()) {
                        setVPALinkAccountDetails(row, rs);
                        return row;
                    } else {
                        return null;
                    }
                }
            });
        }catch (Exception exception) {
            log.error("Exception while executing findByBankAccountNumber :: {}", exception);
        }
        return null;
    }

    @Override
    public VPALinkedAccount fetchVpaLinkedByBankId(String bankUniqueId) {
        VPALinkedAccount row = new VPALinkedAccount();
        try {
            return jdbcTemplate.query("SELECT * FROM vpa_linked_account where bankAccUniqueId = ?", new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setString(1, bankUniqueId);
                }
            }, new ResultSetExtractor<VPALinkedAccount>() {
                @Override
                public VPALinkedAccount extractData(ResultSet rs) throws SQLException {
                    if (rs.next()) {
                        setVPALinkAccountDetails(row, rs);
                        return row;
                    } else {
                        return null;
                    }
                }
            });
        } catch (Exception exception) {
            log.error("Exception while fetchVpaLinkedByBankId account details :: {}", exception);
        }
        return null;
    }

    @Override
    public VPALinkedAccount fetchVpaLinkedById(Long id) {
        VPALinkedAccount row = new VPALinkedAccount();
        try {
            return jdbcTemplate.query("SELECT * FROM vpa_linked_account where id = ?", new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setLong(1, id);
                }
            }, new ResultSetExtractor<VPALinkedAccount>() {
                @Override
                public VPALinkedAccount extractData(ResultSet rs) throws SQLException {
                    if (rs.next()) {
                        setVPALinkAccountDetails(row, rs);
                        return row;
                    } else {
                        return null;
                    }
                }
            });
        } catch (Exception exception) {
            log.error("Exception while fetchVpaLinkedById method :: {}", exception);
        }
        return null;
    }

    private void setVPALinkAccountDetails(VPALinkedAccount row, ResultSet rs) throws SQLException {
        row.setId(rs.getLong("id"));
        row.setAccountNumber(rs.getLong("account_number"));
        row.setBankAccountNumber(rs.getString("bank_account_number"));
        row.setBankIfsc(rs.getString("bank_ifsc"));
        row.setBankCode(rs.getString("bank_code"));
        row.setType(rs.getString("type"));
        row.setBankAccUniqueId(rs.getString("bankAccUniqueId"));
    }

    @Override
    public void deleteVpaLinkedAccount(List<Long> ids) {
        String params = ids.toString().substring(1,ids.toString().length()-1);
        StringBuilder sql = new StringBuilder("DELETE from vpa_linked_account where id in ("+params+")");
        try {
            jdbcTemplate.update(sql.toString());
        } catch (DataAccessException e) {
            log.error("Error occurred in VPADetailsDAOImpl : vpa_linked_account {}", e.getMessage());
        }
    }
}
