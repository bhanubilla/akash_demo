package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayVerifyVpaRequest {

	private String vpa;
	private String upiRequestId;
	private String udfParameters;
}
