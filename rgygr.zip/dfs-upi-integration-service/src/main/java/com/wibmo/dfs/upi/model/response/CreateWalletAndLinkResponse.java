package com.wibmo.dfs.upi.model.response;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CreateWalletAndLinkResponse {
	private String status;
	private String description;
	private String vpa;
	private String bankUniqueId;
}
