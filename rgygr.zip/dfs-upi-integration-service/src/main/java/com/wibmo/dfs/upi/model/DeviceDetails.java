package com.wibmo.dfs.upi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DeviceDetails {
	private String deviceId;
	private String manufacturer;
	private String model;
	private String version;
	private String os;
	private String ssid;
	private String packageName;
	private boolean deregisterOldCustomer;
}
