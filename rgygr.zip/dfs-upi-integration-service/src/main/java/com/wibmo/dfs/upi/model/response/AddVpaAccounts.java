package com.wibmo.dfs.upi.model.response;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AddVpaAccounts {
    private VpaAccount account;
    private String vpa;
    private String isDefault;
}
