package com.wibmo.dfs.upi.dao;

import com.wibmo.dfs.upi.model.VPADetails;

import java.math.BigInteger;
import java.util.List;

public interface VPADetailsDAO {
    public VPADetails findByAccountNumber(Long accountNumber);
    void saveVpaDetails(VPADetails vpaDetails);
    VPADetails findByUpiCustomerId(Long upiCustomerId);
    List<VPADetails> findVpaByAccountNumber(Long accountNumber);
    void updateVpaDetails(VPADetails vpaDetails);
    void deleteVpaDetails(List<Long> ids);
    void updateVpaDetails(String ssid, String deviceFingerPrint, String deviceId, Long refId);
    VPADetails fetchVpaDetailsInfoByAccnoAndMobileAndMerchantcustid(BigInteger refId);
    List<VPADetails> findVpaByAccountNumberAndActive(Long accountNumber);
    VPADetails findByVpa(String vpa);
}
