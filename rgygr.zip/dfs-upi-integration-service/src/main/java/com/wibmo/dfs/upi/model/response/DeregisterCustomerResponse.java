package com.wibmo.dfs.upi.model.response;

import com.wibmo.dfs.upi.adapter.juspay.model.JuspayDeregisterCustomerPayload;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DeregisterCustomerResponse {
    private String status;
    private String responseCode;
    private String responseMessage;
    private JuspayDeregisterCustomerPayload payload;
    private String udfParameters;
}
