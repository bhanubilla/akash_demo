package com.wibmo.dfs.upi.kafka.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
public class CreditMoneyTxnDetailsRequest{
    private String originalTxnId;
    private String ppTxnId;
    private String sourceAccount;
    private String destAccount;
    private String paymentTxnId;
    private Timestamp txnDate;
    private String customerId;
    private String mobile;
    private String paymentMode;
    private String txnDesc;
    private String merCategory;
    private String txnCategory;
    private String txnType;
    private long txnAmount;
    private String txnDateStr;
    private String txnStatus;
    private String remarks;
    private String txnFlow;
    private String txnShortDesc;
    // meta data
    private int tryCount;
    private String failureReason;
    private long closingBalance;
}
