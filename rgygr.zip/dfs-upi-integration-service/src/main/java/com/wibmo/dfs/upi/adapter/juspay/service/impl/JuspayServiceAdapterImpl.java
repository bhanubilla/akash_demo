package com.wibmo.dfs.upi.adapter.juspay.service.impl;

import java.io.IOException;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpHeaders;
import org.dozer.DozerBeanMapper;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.platform.service.notification.NotificationServiceCall;
import com.wibmo.dfs.platform.service.notification.model.NotificationRequest;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayAddVpaRequest;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayAddVpaResponse;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayApproveDeclineRequest;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayCreateAndLinkRequest;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayCreateAndLinkRequestMapper;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayCreateAndLinkResponse;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayDeclineDeviceBindingRequestMapper;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayDeclineDeviceBindingResponse;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayDeleteVpaRequest;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayDeleteVpaResponse;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayDeregisterCustomerRequest;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayDeregisterCustomerResponse;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayDeviceBindingRequest;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayDeviceBindingRequestMapper;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayDeviceBindingResponse;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayIncomingCollectRequest;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayIncomingCollectRequestMapper;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayIncomingCollectResponse;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayRaiseComplaintUdirRequest;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayRequestMoneyRequest;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayRequestMoneyResponse;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspaySMSTokenRequest;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspaySMSTokenResponse;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspaySMSTokenResponsePayload;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspaySendMoneyRequest;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspaySendMoneyResponse;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspaySendMoneyResponsePayload;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayUdirCheckComplaintsRequest;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayUdirListAllComplaintsRequest;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayVerifyVpaRequest;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayVerifyVpaRequestMapper;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayVerifyVpaResponse;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayVerifyVpaResponseMapper;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayVpaAccountResponse;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayVpaValidRequest;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayVpaValidResponse;
import com.wibmo.dfs.upi.adapter.juspay.model.UpiIncomingCollectResponse;
import com.wibmo.dfs.upi.adapter.juspay.util.CommonUtil;
import com.wibmo.dfs.upi.adapter.juspay.util.ResponseMapper;
import com.wibmo.dfs.upi.adapter.juspay.util.SignatureUtil;
import com.wibmo.dfs.upi.adapter.onboarding.TxnHistoryMSAdapter;
import com.wibmo.dfs.upi.constants.Constants;
import com.wibmo.dfs.upi.constants.ProgramParamConstants;
import com.wibmo.dfs.upi.constants.RegistrationConstants;
import com.wibmo.dfs.upi.constants.TxnTrackingConstants;
import com.wibmo.dfs.upi.constants.UpiGatewayStatusConstants;
import com.wibmo.dfs.upi.constants.UpiStatusConstants;
import com.wibmo.dfs.upi.dao.DisputeRemarksDAO;
import com.wibmo.dfs.upi.dao.ProgramParamsDAO;
import com.wibmo.dfs.upi.dao.UpiDeregisterCustInfoDAO;
import com.wibmo.dfs.upi.dao.UpiDisputeManagementDAO;
import com.wibmo.dfs.upi.dao.UpiRegistrationDAO;
import com.wibmo.dfs.upi.dao.VPADetailsDAO;
import com.wibmo.dfs.upi.dao.VPALinkedAccountDAO;
import com.wibmo.dfs.upi.dao.VpaTxnDAO;
import com.wibmo.dfs.upi.entity.DisputeComplaints;
import com.wibmo.dfs.upi.entity.DisputeRemarksDetails;
import com.wibmo.dfs.upi.entity.JuspayCallbackStatusCodes;
import com.wibmo.dfs.upi.entity.VpaDetails;
import com.wibmo.dfs.upi.entity.VpaTxnInfoDetails;
import com.wibmo.dfs.upi.exception.UnAuthorizedException;
import com.wibmo.dfs.upi.exception.UpiGenericException;
import com.wibmo.dfs.upi.helper.ApiManagerUtil;
import com.wibmo.dfs.upi.helper.CommonHelper;
import com.wibmo.dfs.upi.kafka.KafkaProducer;
import com.wibmo.dfs.upi.kafka.model.CreditMoneyTxnDetailsRequest;
import com.wibmo.dfs.upi.kafka.model.TxnDetails;
import com.wibmo.dfs.upi.kafka.model.UpdtTxnDetails;
import com.wibmo.dfs.upi.model.CheckUdirComplaintStatus;
import com.wibmo.dfs.upi.model.CheckUdirComplaints;
import com.wibmo.dfs.upi.model.CustomerMiniProfile;
import com.wibmo.dfs.upi.model.FetchCardBalanceRequest;
import com.wibmo.dfs.upi.model.FundRequest;
import com.wibmo.dfs.upi.model.MerchantDetails;
import com.wibmo.dfs.upi.model.SendMoneyResponseMapper;
import com.wibmo.dfs.upi.model.SmsTokenResponseMapper;
import com.wibmo.dfs.upi.model.UpiDeregisteredCustInfo;
import com.wibmo.dfs.upi.model.VPADetails;
import com.wibmo.dfs.upi.model.VPALinkedAccount;
import com.wibmo.dfs.upi.model.VpaRegistrationAudit;
import com.wibmo.dfs.upi.model.VpaResponseMapper;
import com.wibmo.dfs.upi.model.VpaTxnInfo;
import com.wibmo.dfs.upi.model.VpaTxnInfoMapper;
import com.wibmo.dfs.upi.model.VpaTxnInfoRequestMoneyMapper;
import com.wibmo.dfs.upi.model.request.AddVpaRequest;
import com.wibmo.dfs.upi.model.request.ApproveDeclineRequest;
import com.wibmo.dfs.upi.model.request.CreateWalletAndLinkRequest;
import com.wibmo.dfs.upi.model.request.DeleteVpaRequest;
import com.wibmo.dfs.upi.model.request.DeregisterCustomerRequest;
import com.wibmo.dfs.upi.model.request.DeviceBindingRequest;
import com.wibmo.dfs.upi.model.request.RaiseUdirComplaintRequest;
import com.wibmo.dfs.upi.model.request.RequestMoneyRequest;
import com.wibmo.dfs.upi.model.request.SmsTokenRequest;
import com.wibmo.dfs.upi.model.request.UPITransactionRequest;
import com.wibmo.dfs.upi.model.request.UpiIncomingCollectRequest;
import com.wibmo.dfs.upi.model.request.VerifyVpaRequest;
import com.wibmo.dfs.upi.model.request.VpaValidRequest;
import com.wibmo.dfs.upi.model.response.AddVpaResponse;
import com.wibmo.dfs.upi.model.response.CreateWalletAndLinkResponse;
import com.wibmo.dfs.upi.model.response.DeclineDeviceBindingResponse;
import com.wibmo.dfs.upi.model.response.DeleteVpaResponse;
import com.wibmo.dfs.upi.model.response.DeregisterCustomerResponse;
import com.wibmo.dfs.upi.model.response.DeviceBindingCallbackResponse;
import com.wibmo.dfs.upi.model.response.DeviceBindingResponse;
import com.wibmo.dfs.upi.model.response.FetchCardBalanceResponse;
import com.wibmo.dfs.upi.model.response.RaiseUdirComplaintResponse;
import com.wibmo.dfs.upi.model.response.RequestMoneyResponse;
import com.wibmo.dfs.upi.model.response.SendMoneyResponse;
import com.wibmo.dfs.upi.model.response.SmsTokenResponse;
import com.wibmo.dfs.upi.model.response.TransactionStatusCallbackResponse;
import com.wibmo.dfs.upi.model.response.UdirComplaintStatusResponse;
import com.wibmo.dfs.upi.model.response.UdirComplaintsListResponse;
import com.wibmo.dfs.upi.model.response.VerifyVpaResponse;
import com.wibmo.dfs.upi.model.response.VpaValidResponse;
import com.wibmo.dfs.upi.model.response.WibmoResponse;
import com.wibmo.dfs.upi.service.UpiService;
import com.wibmo.dfs.upi.service.UpiServiceAdapter;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class JuspayServiceAdapterImpl implements UpiServiceAdapter {

	private static final String SUCCESS = "SUCCESS";
	private static final String TXN_UPDATE = "TXN_UPDATE";
	private static final String JUSPAY_REMARKS = "Payment for order";

	private String CONCATENATED_URL = "CONCATENATED_URL : {} ";
	private String sendingRequestJustpay = "Sending request to Juspay url : {}";
	private String retryMessage = "Sorry something went wrong. Please try again later";
	private String justpayResponse = "JuspayResponse :ResponseCode: {}, ResponseMsg: {}, ResponseStatus: {}";

	@Value("${resource.url.juspay.isVpaAvailable}")
	private String vpaValidUrl;
	@Value("${resource.url.juspay.getSmsToken}")
	private String getSmsTokenUrl;
	@Value("${resource.url.juspay.deviceBinding}")
	private String deviceBindingUrl;
	@Value("${resource.url.juspay.declineDeviceBinding}")
	private String declineDeviceBindingUrl;
	@Value("${resource.url.juspay.creatWalletAndLink}")
	private String createWalletAndLinkUrl;
	@Value("${resource.url.juspay.verifyVpa}")
	private String verifyVpaUrl;
	@Value("${resource.url.juspay.sendMoney}")
	private String sendMoneyUrl;
	@Value("${resource.url.juspay.requestMoney}")
	private String requestMoneyUrl;
	@Value("${resource.url.juspay.listPending}")
	private String listPendingUrl;
	@Value("${resource.url.wallet}")
	private String walletUrl;
	@Value("${resource.url.fetchCardBal}")
	private String fetchCardBalanceUrl;
	@Value("${resource.url.juspay.incomingRequest}")
	private String incomingRequestUrl;
	@Value("${resource.url.juspay.addVpa}")
	private String addVpaUrl;
	@Value("${resource.url.juspay.deleteVpa}")
	private String deleteVpaUrl;
	@Value("${resource.url.juspay.deregisterCustomer}")
	private String deregisterCustomerUrl;
	@Value("${resource.url.notification}")
	private String notificationUrl;
	@Value("${resource.url.juspay.udirRaiseComplaint}")
	private String udirRaiseComplaintUrl;
	@Value("${resource.url.juspay.udirListAllComplaints}")
	private String udirListAllComplaints;
	@Value("${resource.url.juspay.udirCheckStatusComplaint}")
	private String udirCheckStatusComplaint;

	@Autowired
	private VpaTxnDAO vpaTxnDAO;
	@Autowired
	private UpiService upiService;
	@Autowired
	private SignatureUtil signUtil;
	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private VPADetailsDAO vpaDetailsDAO;
	@Autowired
	private KafkaProducer kafkaProducer;
	@Autowired
	private ResponseMapper responseMapper;
	@Autowired
	private ApiManagerUtil apiManagerUtil;
	@Autowired
	private ProgramParamsDAO progParamDao;
	@Autowired
	private DozerBeanMapper dozzerBeanMapper;
	@Autowired
	private ProgramParamsDAO programParamsDAO;
	@Autowired
	private VpaTxnInfoMapper vpaTxnInfoMapper;
	@Autowired
	private DisputeRemarksDAO disputeRemarksDAO;
	@Autowired
	private VpaResponseMapper vpaResponseMapper;
	@Autowired
	private UpiRegistrationDAO upiRegistrationDAO;
	@Autowired
	private VPALinkedAccountDAO vpaLinkedAccountDAO;
	@Autowired
	private TxnHistoryMSAdapter txnHistoryMSAdapter;
	@Autowired
	private SmsTokenResponseMapper smsTokenResponseMapper;
	@Autowired
	private UpiDisputeManagementDAO upiDisputeManagementDAO;
	@Autowired
	private SendMoneyResponseMapper sendMoneyResponseMapper;
	@Autowired
	private UpiDeregisterCustInfoDAO upiDeregisterCustInfoDAO;
	@Autowired
	private VpaTxnInfoRequestMoneyMapper vpaTxnInfoRequestMoneyMapper;
	@Autowired
	private JuspayVerifyVpaRequestMapper juspayVerifyVpaRequestMapper;
	@Autowired
	private JuspayVerifyVpaResponseMapper juspayVerifyVpaResponseMapper;
	@Autowired
	private JuspayDeviceBindingRequestMapper juspayDeviceBindingRequestMapper;
	@Autowired
	private JuspayCreateAndLinkRequestMapper juspayCreateAndLinkRequestMapper;
	@Autowired
	private JuspayIncomingCollectRequestMapper juspayIncomingCollectRequestMapper;
	@Autowired
	private JuspayDeclineDeviceBindingRequestMapper juspayDeclineDeviceBindingRequestMapper;

	@Override
	public String getVendorId(String programId) {
		return ProgramParamConstants.JUSPAY_UPI_VENDOR.getValue();
	}

	@Override
	public VpaValidResponse isVpaAvailable(String programId, String accountNum, VpaValidRequest req,
			MerchantDetails merDetails, String privateKey) throws UpiGenericException, IOException {
		log.info("JuspayServiceAdapterImpl : isVpaAvailable()");

		VpaValidResponse vpaValidResponse = null;
		JuspayVpaValidResponse juspayVpaValidResponse = null;

		String baseUrl = progParamDao.fetchParamValueByParamName(programId,
				ProgramParamConstants.JUSPAY_BASE_URL.getValue());
		final String juspayUrl = baseUrl + vpaValidUrl;
		log.info(CONCATENATED_URL, juspayUrl);

		JuspayVpaValidRequest juspayVpaValidRequest = new JuspayVpaValidRequest();
		juspayVpaValidRequest.setMerchantCustomerId(accountNum);
		juspayVpaValidRequest.setCustomerVpa(req.getVpa());
		if (req.getUdfParameters() == null || req.getUdfParameters().isEmpty()) {
			juspayVpaValidRequest.setUdfParameters(new JSONObject().toString());
		} else
			juspayVpaValidRequest.setUdfParameters(req.getUdfParameters());

		// creating httpEntity with custom headers

		HttpEntity<String> httpEntity = createHttpEntityWithHeaders(merDetails, privateKey, juspayVpaValidRequest);
		log.info("{} ", juspayVpaValidRequest);
		log.info("Sending request to juspay vendor: ", juspayUrl);
		try {
			ResponseEntity<JuspayVpaValidResponse> result = restTemplate.exchange(juspayUrl, HttpMethod.POST,
					httpEntity, JuspayVpaValidResponse.class);
			Optional<JuspayVpaValidResponse> optJuspayVpaValidResponse = Optional.ofNullable(result.getBody());
			if (optJuspayVpaValidResponse.isPresent()) {

				String respCode = optJuspayVpaValidResponse.get().getResponseCode();
				String respMsg = optJuspayVpaValidResponse.get().getResponseMessage();
				String respStatus = optJuspayVpaValidResponse.get().getStatus();
				log.info("JuspayResponse - ResponseCode: {}, ResponseMsg: {}, ResponseStatus: {}", respCode, respMsg,
						respStatus);
				if (!respCode.equals(RegistrationConstants.SUCCESS)) {
					throw new UpiGenericException(respCode, new Throwable(respMsg));
				} else {
					juspayVpaValidResponse = result.getBody();
					if (juspayVpaValidResponse != null && juspayVpaValidResponse.getPayload() != null) {
						vpaValidResponse = vpaResponseMapper.map(juspayVpaValidResponse);
					}
				}
			}
		} catch (Exception e) {
			log.error("error in isVpaAvailable:", e);
		}
		return vpaValidResponse;
	}

	@Override
	public SmsTokenResponse getSmsToken(String programId, String accountNumber, SmsTokenRequest req,
			MerchantDetails merDetails, String privateKey) throws UnAuthorizedException, IOException {

		log.debug("JuspayServiceAdapterImpl : getSmsToken : {}", req);
		SmsTokenResponse smsTokenResponse = null;

		String baseUrl = progParamDao.fetchParamValueByParamName(programId,
				ProgramParamConstants.JUSPAY_BASE_URL.getValue());
		final String juspayUrl = baseUrl + getSmsTokenUrl;
		log.info(CONCATENATED_URL, juspayUrl);

		// request
		JuspaySMSTokenRequest juspaySMSTokenRequest = new JuspaySMSTokenRequest();
		juspaySMSTokenRequest.setMerchantCustomerId(accountNumber);
		juspaySMSTokenRequest.setProvider(req.getServiceProvider());
		if (req.getUdfParameters() == null || req.getUdfParameters().isEmpty()) {
			juspaySMSTokenRequest.setUdfParameters(new JSONObject().toString());
		} else
			juspaySMSTokenRequest.setUdfParameters(req.getUdfParameters());

		// create HttpEntity with custom headers
		HttpEntity<String> httpEntity = createHttpEntityWithHeaders(merDetails, privateKey, juspaySMSTokenRequest);
		ObjectMapper obj = new ObjectMapper();
		String juspaySMSTokenRequestReqJson = obj.writeValueAsString(juspaySMSTokenRequest);
		log.debug("juspaySMSTokenRequest Obj : {}", juspaySMSTokenRequestReqJson);
		log.info("sending request to juspay vendor: {}", juspayUrl);
		ResponseEntity<JuspaySMSTokenResponse> result = restTemplate.exchange(juspayUrl, HttpMethod.POST, httpEntity,
				JuspaySMSTokenResponse.class);

		Optional<JuspaySMSTokenResponse> optJuspaySMSTokenResponse = Optional.ofNullable(result.getBody());
		if (optJuspaySMSTokenResponse.isPresent()) {
			String resuBodyStatus = optJuspaySMSTokenResponse.get().getStatus();
			String respCode = optJuspaySMSTokenResponse.get().getResponseCode();
			String respMsg = optJuspaySMSTokenResponse.get().getResponseMessage();
			log.info("JuspayResponse - ResponseCode: {}, ResponseMsg: {}, Status: {}", respCode, respMsg,
					resuBodyStatus);
			Optional<JuspaySMSTokenResponsePayload> optJuspaySMSTokenResponsePayload = Optional
					.ofNullable(optJuspaySMSTokenResponse.get().getPayload());
			if (optJuspaySMSTokenResponsePayload.isPresent()) {
				String juspaySMSTokenResponsePayloadReqJson = obj.writeValueAsString(optJuspaySMSTokenResponsePayload);
				log.debug("payload response from juspay for smsTokenRequest: {}", juspaySMSTokenResponsePayloadReqJson);
				VpaRegistrationAudit vpaAudit = new VpaRegistrationAudit();
				vpaAudit.setAccountNumber(Long.parseLong(accountNumber));
				vpaAudit.setMerchantCustomerId(
						Long.parseLong(optJuspaySMSTokenResponsePayload.get().getMerchantCustomerId()));
				vpaAudit.setSmsToken(optJuspaySMSTokenResponsePayload.get().getSmsContent());
				vpaAudit.setStatus(RegistrationConstants.PENDING_DEVICE_BINDING);
				vpaAudit.setMobileNumber("");
				vpaAudit.setWalletUrn("");
				vpaAudit.setDeviceFingerPrint("");
				vpaAudit.setDeviceId("");
				vpaAudit.setSsid("");
				vpaAudit.setVpa("");

				log.info("updating vpa_registraion_log table with status {}",
						RegistrationConstants.PENDING_DEVICE_BINDING);
				BigInteger refId = upiRegistrationDAO.saveVpaRegistrationLogDetails(vpaAudit);
				smsTokenResponse = smsTokenResponseMapper.map(optJuspaySMSTokenResponsePayload, refId);
				String smsTokenResponseReqJson = obj.writeValueAsString(smsTokenResponse);
				log.debug("smsTokenResponse: {}", smsTokenResponseReqJson);

			}
			if (resuBodyStatus.equals(RegistrationConstants.FAILURE)) {
				throw new UpiGenericException(respCode, new Throwable(respMsg));
			}
		}
		return smsTokenResponse;
	}

	@Override
	public DeviceBindingResponse deviceBinding(String programId, String accountNumber, DeviceBindingRequest request,
			MerchantDetails merDetails, String privateKey) throws UpiGenericException, IOException {

		log.debug("JuspayServiceAdapterImpl : deviceBindig");
		DeviceBindingResponse deviceBindingResponse = null;

		String baseUrl = progParamDao.fetchParamValueByParamName(programId,
				ProgramParamConstants.JUSPAY_BASE_URL.getValue());
		final String juspayUrl = baseUrl + deviceBindingUrl;
		log.info(CONCATENATED_URL, juspayUrl);

		String smsContent = upiRegistrationDAO.fetchSmsToken(String.valueOf(request.getRefNumber()));
		if (smsContent == null) {
			log.info("smsContent is null");
			throw new UpiGenericException(UpiStatusConstants.INVALID_SMS_CONTENT.toString(),
					new Throwable(UpiStatusConstants.INVALID_SMS_CONTENT.getStatusMsg()));
		}
		JuspayDeviceBindingRequest juspayDeviceBindingRequest = juspayDeviceBindingRequestMapper.map(request,
				accountNumber, smsContent);

		// create HttpEntity with custom headers
		HttpEntity<String> httpEntity = createHttpEntityWithHeaders(merDetails, privateKey, juspayDeviceBindingRequest);
		log.info(sendingRequestJustpay, juspayUrl);
		ResponseEntity<JuspayDeviceBindingResponse> result = restTemplate.exchange(juspayUrl, HttpMethod.POST,
				httpEntity, JuspayDeviceBindingResponse.class);
		JuspayDeviceBindingResponse juspayDeviceBindingResponse = result.getBody();
		String resuBodyStatus = null;
		String respCode = null;
		String respMsg = null;
		if (juspayDeviceBindingResponse != null) {
			resuBodyStatus = juspayDeviceBindingResponse.getStatus();
			respCode = juspayDeviceBindingResponse.getResponseCode();
			respMsg = juspayDeviceBindingResponse.getResponseMessage();
		}
		log.debug(justpayResponse, respCode, respMsg, resuBodyStatus);

		if (respCode != null && respCode.equals(UpiStatusConstants.SUCCESS.getStatusMsg())
				&& juspayDeviceBindingResponse.getPayload() != null
				&& juspayDeviceBindingResponse.getPayload().getDeviceFingerPrint() != null) {
			log.info("device binding successful : {}", juspayDeviceBindingResponse.getPayload().getDeviceFingerPrint());
			upiRegistrationDAO.updateVpaRegistrationLogDetails(UpiStatusConstants.DEVICE_BINDING_SUCCESS.name(),
					request, juspayDeviceBindingResponse.getPayload().getDeviceFingerPrint());

			deviceBindingResponse = new DeviceBindingResponse();
			deviceBindingResponse.setRefNumber(request.getRefNumber());
			deviceBindingResponse.setStatus((UpiStatusConstants.DEVICE_BINDING_SUCCESS.getStatusMsg()));
			// Call to CallBack API
			String callbackRequest = buildCallBackRequest(UpiStatusConstants.VERIFIED.name(), request.getMobileNumber(),
					merDetails.getMerchantId(), merDetails.getMerchantChannelId(), accountNumber, smsContent,
					Constants.CUSTOMER_DEVICE_BINDING);
			upiService.deviceStatusCallback(programId, callbackRequest);
			return deviceBindingResponse;
		}

		if (respCode != null && respCode.equals(UpiStatusConstants.SMS_VERIFICATION_PENDING.toString())) {
			upiRegistrationDAO.updateVpaRegistrationLogDetails(UpiStatusConstants.SMS_VERIFICATION_PENDING.toString(),
					request);
			// Call to CallBack API
			String callbackRequest = buildCallBackRequest(UpiStatusConstants.SMS_VERIFICATION_PENDING.name(),
					request.getMobileNumber(), merDetails.getMerchantId(), merDetails.getMerchantChannelId(),
					accountNumber, smsContent, Constants.CUSTOMER_DEVICE_BINDING);
			upiService.deviceStatusCallback(programId, callbackRequest);
			throw new UpiGenericException(UpiStatusConstants.SMS_VERIFICATION_PENDING.toString(),
					new Throwable(UpiStatusConstants.SMS_VERIFICATION_PENDING.getStatusMsg()));
		}

		if (respCode != null && respCode.equals(UpiStatusConstants.SMS_VERIFICATION_EXPIRED.toString())) {
			upiRegistrationDAO.updateVpaRegistrationLogDetails(UpiStatusConstants.SMS_VERIFICATION_EXPIRED.toString(),
					request);
			String callbackRequest = buildCallBackRequest(UpiStatusConstants.SMS_VERIFICATION_EXPIRED.name(),
					request.getMobileNumber(), merDetails.getMerchantId(), merDetails.getMerchantChannelId(),
					accountNumber, smsContent, Constants.CUSTOMER_DEVICE_BINDING);
			upiService.deviceStatusCallback(programId, callbackRequest);
			throw new UpiGenericException(UpiStatusConstants.SMS_VERIFICATION_EXPIRED.toString(),
					new Throwable(UpiStatusConstants.SMS_VERIFICATION_EXPIRED.getStatusMsg()));
		}

		if (respCode != null && respCode.equals(UpiStatusConstants.SMS_VERIFICATION_MISMATCH.toString())) {
			upiRegistrationDAO.updateVpaRegistrationLogDetails(UpiStatusConstants.SMS_VERIFICATION_MISMATCH.toString(),
					request);
			String callbackRequest = buildCallBackRequest(UpiStatusConstants.SMS_VERIFICATION_MISMATCH.name(),
					request.getMobileNumber(), merDetails.getMerchantId(), merDetails.getMerchantChannelId(),
					accountNumber, smsContent, Constants.CUSTOMER_DEVICE_BINDING);
			upiService.deviceStatusCallback(programId, callbackRequest);
			throw new UpiGenericException(UpiStatusConstants.SMS_VERIFICATION_MISMATCH.toString(),
					new Throwable(UpiStatusConstants.SMS_VERIFICATION_MISMATCH.getStatusMsg()));
		}

		else {
			throw new UpiGenericException(respCode, new Throwable(respMsg));
		}
	}

	@Override
	public CreateWalletAndLinkResponse createAndLink(String programId, String accountNumber,
			CreateWalletAndLinkRequest request) throws UpiGenericException, IOException {

		log.debug("JuspayServiceAdapterImpl : createAndLink");
		CreateWalletAndLinkResponse createWalletAndLinkResponse = null;
		JuspayCreateAndLinkResponse juspayCreateAndLinkResponse = null;

		String baseUrl = progParamDao.fetchParamValueByParamName(programId,
				ProgramParamConstants.JUSPAY_BASE_URL.getValue());
		final String juspayUrl = baseUrl + createWalletAndLinkUrl;
		log.info(CONCATENATED_URL, juspayUrl);

		String merchantId = progParamDao.fetchParamValueByParamName(programId,
				ProgramParamConstants.MERCHANT_ID.getValue());
		String merchantChannelId = progParamDao.fetchParamValueByParamName(programId,
				ProgramParamConstants.MERCHANT_CHANNEL_ID.getValue());
		String privateKey = progParamDao.fetchParamValueByParamName(programId,
				ProgramParamConstants.PRIVATE_KEY.getValue());

		// headers
		String timestamp = String.valueOf(new Date().getTime());
		MultiValueMap<String, String> customHeaders = setHeaders(merchantId, merchantChannelId, timestamp);

		// request
		JuspayCreateAndLinkRequest juspayCreateAndLinkRequest = juspayCreateAndLinkRequestMapper.map(request,
				accountNumber);
		ObjectMapper obj = new ObjectMapper();
		String reqJson = obj.writeValueAsString(juspayCreateAndLinkRequest);
		String input = merchantId + merchantChannelId + timestamp + reqJson;
		String signature = signUtil.calculateSignature(input, privateKey);
		customHeaders.add(Constants.X_MERCHANT_SIGNATURE, signature);

		HttpEntity<String> httpEntity = new HttpEntity<>(reqJson, customHeaders);
		log.info("{} ", juspayCreateAndLinkRequest);
		log.info(sendingRequestJustpay, juspayUrl);
		ResponseEntity<JuspayCreateAndLinkResponse> result = restTemplate.exchange(juspayUrl, HttpMethod.POST,
				httpEntity, JuspayCreateAndLinkResponse.class);
		juspayCreateAndLinkResponse = result.getBody();
		String resuBodyRespCode = null;
		String resuBodyMsg = null;
		String resuBodyStatus = null;
		if (juspayCreateAndLinkResponse != null) {
			resuBodyRespCode = juspayCreateAndLinkResponse.getResponseCode();
			resuBodyMsg = juspayCreateAndLinkResponse.getResponseMessage();
			resuBodyStatus = juspayCreateAndLinkResponse.getStatus();
		}
		log.info(justpayResponse, resuBodyRespCode, resuBodyMsg, resuBodyStatus);
		log.info("juspayCreateAndLinkResponse - {}", juspayCreateAndLinkResponse);
		if (juspayCreateAndLinkResponse != null && juspayCreateAndLinkResponse.getPayload() != null) {
			if (resuBodyRespCode.equals("BAD_REQUEST")) {
				throw new UpiGenericException(UpiStatusConstants.BAD_REQUEST.toString(),
						new Throwable(UpiStatusConstants.BAD_REQUEST.getStatusMsg()));
			}
			createWalletAndLinkResponse = new CreateWalletAndLinkResponse();
			createWalletAndLinkResponse.setVpa(juspayCreateAndLinkRequest.getCustomerVpa());

			VPALinkedAccount vpaLinkedAccount = null;
			createWalletAndLinkResponse.setStatus(juspayCreateAndLinkResponse.getStatus());
			createWalletAndLinkResponse.setDescription(juspayCreateAndLinkResponse.getResponseMessage());
			createWalletAndLinkResponse.setBankUniqueId(juspayCreateAndLinkResponse.getPayload().getVpaAccounts().get(0)
					.getAccount().getBankAccountUniqueId());
			vpaLinkedAccount = vpaLinkedAccountDAO
					.fetchVpaLinkedByBankId(createWalletAndLinkResponse.getBankUniqueId());
			if (vpaLinkedAccount == null) {
				saveVpaLinkedAccounts(juspayCreateAndLinkRequest,
						juspayCreateAndLinkResponse.getPayload().getVpaAccounts().get(0));
			}

		} else {
			throw new UpiGenericException(resuBodyRespCode, new Throwable(resuBodyMsg));
		}

		return createWalletAndLinkResponse;
	}

	/**
	 * @param request
	 * @param response Saving VpaLinkedAccount details into DB
	 */
	private void saveVpaLinkedAccounts(JuspayCreateAndLinkRequest request, JuspayVpaAccountResponse response) {
		VPALinkedAccount vpaLinkedAccount = new VPALinkedAccount();
		vpaLinkedAccount.setAccountNumber(Long.parseLong(request.getMerchantCustomerId()));
		vpaLinkedAccount.setBankName(response.getAccount().getBankName());
		vpaLinkedAccount.setBankAccountNumber(request.getAccount().getAccountNumber());
		vpaLinkedAccount.setBankIfsc(response.getAccount().getIfsc());
		vpaLinkedAccount.setBankCode(response.getAccount().getBankCode());
		vpaLinkedAccount.setType(response.getAccount().getType());
		vpaLinkedAccount.setBankAccUniqueId(response.getAccount().getBankAccountUniqueId());
		vpaLinkedAccountDAO.save(vpaLinkedAccount);
	}

	private MultiValueMap<String, String> setHeaders(String merchantId, String merchantChannelId, String timestamp) {
		// headers
		MultiValueMap<String, String> customHeaders = new LinkedMultiValueMap<>();
		customHeaders.add(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON);
		customHeaders.add(Constants.ACCEPT, Constants.APPLICATION_JSON);
		customHeaders.add(Constants.X_MERCHANT_ID, merchantId);
		customHeaders.add(Constants.X_MERCHANT_CHANNEL_ID, merchantChannelId);
		customHeaders.add(Constants.X_TIMESTAMP, timestamp);
		return customHeaders;
	}

	@Override
	public DeclineDeviceBindingResponse declineDeviceBinding(String programId, String accountNumber,
			ApproveDeclineRequest request) throws UpiGenericException, IOException {

		log.debug("JuspayServiceAdapterImpl : declineDeviceBinding ");
		DeclineDeviceBindingResponse response = new DeclineDeviceBindingResponse();

		String baseUrl = progParamDao.fetchParamValueByParamName(programId,
				ProgramParamConstants.JUSPAY_BASE_URL.getValue());
		final String juspayUrl = baseUrl + declineDeviceBindingUrl;
		log.info(CONCATENATED_URL, juspayUrl);

		String merchantId = progParamDao.fetchParamValueByParamName(programId,
				ProgramParamConstants.MERCHANT_ID.getValue());
		String merchantChannelId = progParamDao.fetchParamValueByParamName(programId,
				ProgramParamConstants.MERCHANT_CHANNEL_ID.getValue());
		String privateKey = progParamDao.fetchParamValueByParamName(programId,
				ProgramParamConstants.PRIVATE_KEY.getValue());
		String timestamp = String.valueOf(new Date().getTime());
		MultiValueMap<String, String> customHeaders = setHeaders(merchantId, merchantChannelId, timestamp);

		// request
		JuspayApproveDeclineRequest juspayDeclineDeviceBindingRequest = juspayDeclineDeviceBindingRequestMapper
				.map(accountNumber);
		ObjectMapper obj = new ObjectMapper();
		String reqJson = obj.writeValueAsString(juspayDeclineDeviceBindingRequest);
		String input = merchantId + merchantChannelId + timestamp + reqJson;
		String signature = signUtil.calculateSignature(input, privateKey);
		customHeaders.add(Constants.X_MERCHANT_SIGNATURE, signature);

		HttpEntity<String> httpEntity = new HttpEntity<>(reqJson, customHeaders);
		log.info("{} ", juspayDeclineDeviceBindingRequest);
		log.info(sendingRequestJustpay, juspayUrl);
		ResponseEntity<JuspayDeclineDeviceBindingResponse> result = null;
		result = restTemplate.exchange(juspayUrl, HttpMethod.POST, httpEntity,
				JuspayDeclineDeviceBindingResponse.class);
		JuspayDeclineDeviceBindingResponse juspayDeclineDeviceBindingResponse = result.getBody();
		String resuBodyStatus = null;
		String respCode = null;
		String respMsg = null;
		if (juspayDeclineDeviceBindingResponse != null) {
			resuBodyStatus = juspayDeclineDeviceBindingResponse.getStatus();
			respCode = juspayDeclineDeviceBindingResponse.getResponseCode();
			respMsg = juspayDeclineDeviceBindingResponse.getResponseMessage();
			log.info(justpayResponse, respCode, respMsg, resuBodyStatus);
			if (juspayDeclineDeviceBindingResponse.getPayload() != null) {
				response.setStatus(resuBodyStatus);
				response.setResponseDesc(respMsg);
			} else {
				throw new UpiGenericException(respCode, new Throwable(Constants.BAD_REQUEST_ERROR_DESC));
			}
		}
		return response;
	}

	@Override
	public DeviceBindingCallbackResponse handleDeviceBindingCallback(String programId, String request) {
		DeviceBindingCallbackResponse response = null;
		JSONObject jsonObject = new JSONObject(request);
		String mobileNumber = (String) jsonObject.get(Constants.CUSTOMER_MOBILE_NUMBER);
		String smsContent = (String) jsonObject.get(Constants.SMS_CONTENT);
		String status = (String) jsonObject.get(Constants.STATUS);

		// Query to fetch details from vpa reg table
		VpaRegistrationAudit vpaRegistrationAudit = upiRegistrationDAO.fetchVpaRegInfoBySmsAndMobile(smsContent,
				mobileNumber);
		if (null != vpaRegistrationAudit) {
			// updating status
			upiRegistrationDAO.updateVpaRegLogByRefID(status, BigInteger.valueOf(vpaRegistrationAudit.getId()));
			response = new DeviceBindingCallbackResponse();
			response.setRefId(BigInteger.valueOf(vpaRegistrationAudit.getId()));
			response.setAccountNumber(String.valueOf(vpaRegistrationAudit.getAccountNumber()));
			response.setStatus(status);
			response.setDeviceId(vpaRegistrationAudit.getDeviceId());
			response.setSsid(vpaRegistrationAudit.getSsid());
			response.setDeviceFingerPrint(vpaRegistrationAudit.getDeviceFingerPrint());
			response.setMobileNumber(mobileNumber);
		}
		return response;
	}

	@Override
	public VerifyVpaResponse verifyVpa(String programId, VerifyVpaRequest request)
			throws UpiGenericException, IOException {

		log.debug("JuspayServiceAdapterImpl : verifyVpa");
		VerifyVpaResponse response = null;

		String baseUrl = progParamDao.fetchParamValueByParamName(programId,
				ProgramParamConstants.JUSPAY_BASE_URL.getValue());
		final String juspayUrl = baseUrl + verifyVpaUrl;
		log.info(CONCATENATED_URL, juspayUrl);

		String merchantId = progParamDao.fetchParamValueByParamName(programId,
				ProgramParamConstants.MERCHANT_ID.getValue());
		String merchantChannelId = progParamDao.fetchParamValueByParamName(programId,
				ProgramParamConstants.MERCHANT_CHANNEL_ID.getValue());
		String privateKey = progParamDao.fetchParamValueByParamName(programId,
				ProgramParamConstants.PRIVATE_KEY.getValue());
		String upiRequestIdPrefix = progParamDao.fetchParamValueByParamName(programId,
				ProgramParamConstants.UPI_REQUEST_ID_PREFIX.getValue());

		// headers
		MultiValueMap<String, String> customHeaders = new LinkedMultiValueMap<>();
		customHeaders.add(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON);
		customHeaders.add(Constants.ACCEPT, Constants.APPLICATION_JSON);
		customHeaders.add(Constants.X_MERCHANT_ID, merchantId);
		customHeaders.add(Constants.X_MERCHANT_CHANNEL_ID, merchantChannelId);
		String timestamp = String.valueOf(new Date().getTime());
		customHeaders.add(Constants.X_TIMESTAMP, timestamp);
		// request
		JuspayVerifyVpaRequest juspayVerifyVpaRequest = juspayVerifyVpaRequestMapper.map(request);
		int lengthOfPrefixId = upiRequestIdPrefix.length();
		String upiRequestId = upiRequestIdPrefix + RandomStringUtils.randomAlphanumeric(35 - lengthOfPrefixId);
		juspayVerifyVpaRequest.setUpiRequestId(upiRequestId);

		ObjectMapper obj = new ObjectMapper();
		String reqJson = obj.writeValueAsString(juspayVerifyVpaRequest);
		String input = merchantId + merchantChannelId + timestamp + reqJson;
		String signature = signUtil.calculateSignature(input, privateKey);
		customHeaders.add(Constants.X_MERCHANT_SIGNATURE, signature);
		JuspayVerifyVpaResponse res = null;
		try {
			HttpEntity<String> httpEntity = new HttpEntity<>(reqJson, customHeaders);
			log.info(sendingRequestJustpay, juspayUrl);
			log.info("juspayVerifyVpaRequest : {} ", juspayVerifyVpaRequest);
			ResponseEntity<JuspayVerifyVpaResponse> result = null;
			result = restTemplate.exchange(juspayUrl, HttpMethod.POST, httpEntity, JuspayVerifyVpaResponse.class);
			res = result.getBody();
		} catch (Exception e) {
			log.error("Error occured in VerifyVpa: {}", e);
		}
		if (res != null) {
			String respCode = res.getResponseCode();
			String respMsg = res.getResponseMessage();
			log.info("JuspayVerifyVpaResponse :ResponseCode: {}, ResponseMsg: {}, ResponseBody: {}", respCode, respMsg,
					res);
			if (res.getPayload() != null) {
				response = juspayVerifyVpaResponseMapper.map(res);
				String gatewayStatusCode = "VERIFY_VPA_" + res.getPayload().getGatewayResponseCode();
				response.setCustomGatewayStatusCode(gatewayStatusCode);

			} else {
				if (respCode.equals("SERVICE_UNAVAILABLE_NPCI_503")) {
					throw new UpiGenericException(respCode, new Throwable(Constants.SERVICE_UNAVAILABLE_NPCI_503));
				} else
					throw new UpiGenericException(respCode, new Throwable(respCode));
			}
		}
		return response;
	}

	@SneakyThrows
	@Override
	public UpiIncomingCollectResponse incomingRequest(String programId, String accountNumber,
			UpiIncomingCollectRequest request) {
		log.info("JuspayServiceAdapterImpl : incomingRequest for {}", request.getTxnId());
		UpiIncomingCollectResponse response = new UpiIncomingCollectResponse();
		try {

			String baseUrl = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.JUSPAY_BASE_URL.getValue());
			final String juspayUrl = baseUrl + incomingRequestUrl;
			log.info(CONCATENATED_URL, juspayUrl);

			String merchantId = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.MERCHANT_ID.getValue());
			String merchantChannelId = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.MERCHANT_CHANNEL_ID.getValue());
			String privateKey = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.PRIVATE_KEY.getValue());
			VpaTxnInfo vpaTxnInfo = vpaTxnDAO.fetchByGatewayTxnId(request.getTxnId());
			String upiRequestId = null;
			if (vpaTxnInfo == null) {
				log.info("Request from external vpa's");
				upiRequestId = request.getTxnId();
			} else {
				log.info("Request from internal vpa's");
				upiRequestId = vpaTxnInfo.getUpiRequestId();
			}
			// headers
			MultiValueMap<String, String> customHeaders = new LinkedMultiValueMap<>();
			customHeaders.add(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON);
			customHeaders.add(Constants.ACCEPT, Constants.APPLICATION_JSON);
			customHeaders.add(Constants.X_MERCHANT_ID, merchantId);
			customHeaders.add(Constants.X_MERCHANT_CHANNEL_ID, merchantChannelId);
			String timestamp = String.valueOf(new Date().getTime());
			customHeaders.add(Constants.X_TIMESTAMP, timestamp);
			// request
			JuspayIncomingCollectRequest juspayIncomingCollectRequest = juspayIncomingCollectRequestMapper.map(request,
					accountNumber);
			juspayIncomingCollectRequest.setPayeeName(request.getPayeeName());
			juspayIncomingCollectRequest.setAmount(impliedDecimalTo(juspayIncomingCollectRequest.getAmount()));
			juspayIncomingCollectRequest.setUpiRequestId(upiRequestId);
			ObjectMapper objectMapper = new ObjectMapper();
			String reqJson = objectMapper.writeValueAsString(juspayIncomingCollectRequest);
			String input = merchantId + merchantChannelId + timestamp + reqJson;
			String signature = signUtil.calculateSignature(input, privateKey);
			customHeaders.add(Constants.X_MERCHANT_SIGNATURE, signature);
			HttpEntity<String> httpEntity = new HttpEntity<>(reqJson, customHeaders);
			log.info("{}", juspayIncomingCollectRequest);
			log.info(sendingRequestJustpay, juspayUrl);
			ResponseEntity<JuspayIncomingCollectResponse> result = null;
			String finalUpiRequestId = upiRequestId;
			Runnable txnCreditPendingStatus = () -> kafkaProducer.publishUpiTxnTracking(finalUpiRequestId,
					TxnTrackingConstants.CREDIT_MONEY_PENDING);
			new Thread(txnCreditPendingStatus).start();
			result = restTemplate.exchange(juspayUrl, HttpMethod.POST, httpEntity, JuspayIncomingCollectResponse.class);
			JuspayIncomingCollectResponse res = result.getBody();
			if (res != null) {
				String respCode = res.getResponseCode();
				String respMsg = res.getResponseCode();
				log.info("JuspayResponse : ResponseCode : {}, ResponseStatus : {}", respCode, respMsg, res);
				if (res.getPayload() != null) {
					response = juspayIncomingCollectRequestMapper.map(res);
					if (vpaTxnInfo != null) {
						vpaTxnDAO.updateVpaTxnInfoByTxnId(res.getPayload().getGatewayResponseStatus(),
								"REQUEST_MONEY_" + request.getApprovalStatus(),
								res.getPayload().getGatewayTransactionId(),
								res.getPayload().getGatewayResponseMessage(),
								juspayIncomingCollectRequest.getUpiRequestId(), vpaTxnInfo.getId());
					} else {
						// TODO INSERT FOR EXTERNAL VPA REQUEST MONEY DETAILS
						log.info("Insert record ");
					}

				} else {
					log.info("Juspay payload is null....");
					response.setWibmoRespCode(100);
					response.setWibmoResDesc(retryMessage);
					response.setWibmoErrorMessage(respMsg);
				}

			}
		} catch (Exception ex) {
			log.info("Exception while communicating jusyPay :: {}", ex);
			response.setWibmoRespCode(100);
			response.setWibmoResDesc(retryMessage);
			response.setWibmoErrorMessage("Exception while communicating to jusPay.");
		}
		updateTxnTrackingDetailsForOffUs(programId, request.getTxnId(), request.getPayeeVpa(),
				response.getWibmoResDesc());
		// HERE YOU NEED TO CALL TXN_HIS API TO FETCH TXN TRACKING DETAILS
		return response;
	}

	private String buildCallBackRequest(String status, String mobileNumber, String merchantId, String merchantChannelId,
			String accountId, String smsContent, String customerDeviceBinding) {
		JSONObject object = new JSONObject();
		object.put("customerMobileNumber", mobileNumber);
		object.put("customResponse", "{}");
		object.put("merchantChannelId", merchantChannelId);
		object.put("merchantCustomerId", accountId);
		object.put("merchantId", merchantId);
		object.put("smsContent", smsContent);
		object.put("status", status);
		object.put("type", customerDeviceBinding);
		return object.toString();
	}

	/**
	 * Juspay Call for send Money
	 */
	@Override
	public SendMoneyResponse sendMoney(String programId, String accountNumber, UPITransactionRequest req,
			MerchantDetails merDetails, String privateKey) throws UnAuthorizedException, IOException {

		String upiRequestIdPrefix = progParamDao.fetchParamValueByParamName(programId,
				ProgramParamConstants.UPI_REQUEST_ID_PREFIX.getValue());
		int lengthOfupiRequestIdPrefix = upiRequestIdPrefix.length();
		log.debug("JuspayServiceAdapterImpl : sendMoney");

		setProgramIdAndUpiTrnsRequest(programId, req);

		SendMoneyResponse sendMoneyResponse = new SendMoneyResponse();
		JuspaySendMoneyResponse juspaySendMoneyResponse = new JuspaySendMoneyResponse();

		String baseUrl = progParamDao.fetchParamValueByParamName(programId,
				ProgramParamConstants.JUSPAY_BASE_URL.getValue());
		final String juspayUrl = baseUrl + sendMoneyUrl;
		log.info(CONCATENATED_URL, juspayUrl);

		// request
		JuspaySendMoneyRequest juspaySendMoneyRequest = getJuspaySendMoneyRequest(req, upiRequestIdPrefix,
				lengthOfupiRequestIdPrefix);

		String upiRemarks = req.getRemarks();
		juspaySendMoneyRequest.setRemarks(StringUtils.isBlank(upiRemarks) ? JUSPAY_REMARKS : upiRemarks);
		juspaySendMoneyRequest.setAmountBlocked(req.isAmountBlocked());
		juspaySendMoneyRequest.setMerchantCustomerId(accountNumber);
		juspaySendMoneyRequest.setMerchantRequestId(RandomStringUtils.randomAlphanumeric(35).toUpperCase());
		juspaySendMoneyRequest.setBankAccountUniqueId(req.getBankAccountUniqueId());
		juspaySendMoneyRequest.setDeviceFingerPrint(req.getDeviceFingerprint());
		juspaySendMoneyRequest.setPayerVpa(req.getPayerVpa());

		if (req.getUdfParameters() == null || req.getUdfParameters().isEmpty()) {
			juspaySendMoneyRequest.setUdfParameters(new JSONObject().toString());
		} else
			juspaySendMoneyRequest.setUdfParameters(req.getUdfParameters());

		// create HttpEntity with custom headers
		HttpEntity<String> httpEntity = createHttpEntityWithHeaders(merDetails, privateKey, juspaySendMoneyRequest);
		log.info("sending request to juspay vendor: {}", juspayUrl);
		ObjectMapper obj = new ObjectMapper();
		String reqJson = obj.writeValueAsString(juspaySendMoneyRequest);
		log.debug("juspaySendMoneyRequestObj: {}", reqJson);
		log.info("sending sendMoney request to juspay");
		int id = vpaTxnDAO.saveSendMoneyRequestDetails(juspaySendMoneyRequest);
		log.info("sendMoney id and kafka call :: {}", id);

		Runnable txnTracking = () -> kafkaProducer.publishUpiTxnTracking(juspaySendMoneyRequest.getUpiRequestId(),
				TxnTrackingConstants.CREDIT_MONEY_PENDING);
		new Thread(txnTracking).start();
		ResponseEntity<JuspaySendMoneyResponse> result = restTemplate.exchange(juspayUrl, HttpMethod.POST, httpEntity,
				JuspaySendMoneyResponse.class);
		log.info("actual response from juspay {}", result);
		JuspaySendMoneyResponse juspaySMResponse = result.getBody();
		log.info("actual response from juspay.body {}", obj.writeValueAsString(juspaySMResponse));
		if (juspaySMResponse != null) {
			String respCode = juspaySMResponse.getResponseCode();
			String respMsg = juspaySMResponse.getResponseMessage();
			String respBodyStatus = juspaySMResponse.getStatus();
			log.info("Juspay responseCode :: {}, Juspay responseMessage :: {}", respCode, respMsg);
			if (juspaySMResponse.getPayload() != null) {
				JuspaySendMoneyResponsePayload juspaySendMoneyResponsePayload = juspaySMResponse.getPayload();
				juspaySendMoneyResponse.setPayload(juspaySendMoneyResponsePayload);
				juspaySendMoneyResponse.setResponseCode(respCode);
				juspaySendMoneyResponse.setResponseMessage(respMsg);
				juspaySendMoneyResponse.setStatus(respBodyStatus);
				juspaySendMoneyResponse.setUdfParameters(juspaySMResponse.getUdfParameters());
				sendMoneyResponse = sendMoneyResponseMapper.map(juspaySendMoneyResponse);
				String gatewayStatusCode = "SEND_MONEY_" + juspaySendMoneyResponsePayload.getGatewayResponseCode();
				sendMoneyResponse.setCustomGatewayStatusCode(gatewayStatusCode);
				VpaTxnInfo vpaTxnInfo = vpaTxnInfoMapper.map(juspaySendMoneyResponse);
				vpaTxnInfo.setOriginalTxnId(req.getOriginalTxnId());
				log.info("updating send money data into vpa_txn_info DB");
				vpaTxnInfo.setTransactionType("W2UPI");
				vpaTxnInfo.setStatus("SEND_MONEY_" + juspaySendMoneyResponsePayload.getGatewayResponseCode());
				vpaTxnDAO.updateSuccessRespRequestMoneyDetails(vpaTxnInfo);
				// txn_history
			} else if (respCode.contains("SERVICE_UNAVAILABLE_NPCI")) {
				log.info("Issue from NPCI hence status becomes pending.");
				log.info("Actual status will get in callbacks");
				sendMoneyResponse.setWibmoRespCode(UpiGatewayStatusConstants.SEND_MONEY_01.getStatusCode());
				sendMoneyResponse.setWibmoResDesc(UpiGatewayStatusConstants.SEND_MONEY_01.getStatusMsg());
				sendMoneyResponse.setPayeeVpa(juspaySendMoneyRequest.getPayeeVpa());
				sendMoneyResponse.setPayerVpa(juspaySendMoneyRequest.getPayerVpa());
				sendMoneyResponse.setMerchantRequestId(juspaySendMoneyRequest.getMerchantRequestId());
				sendMoneyResponse.setTransactionTimestamp(String.valueOf(new Date().getTime()));
				sendMoneyResponse.setTransactionType(juspaySendMoneyRequest.getTransactionType());
				sendMoneyResponse.setStatus("PENDING");
				sendMoneyResponse.setGatewayResponseCode("01");
				sendMoneyResponse.setGatewayResponseStatus("PENDING");
				sendMoneyResponse.setWibmoErrorMessage(respCode);
				sendMoneyResponse.setGatewayTransactionId(juspaySendMoneyRequest.getUpiRequestId());
				log.info("sendMoneyResponse :: {}", sendMoneyResponse);
			} else {
				log.info("Payload is null from juspay");
				sendMoneyResponse.setWibmoRespCode(100);
				sendMoneyResponse.setWibmoResDesc(retryMessage);
				sendMoneyResponse.setWibmoErrorMessage(respMsg);
			}
		}
		// update in txn history
		sendMoneyTxnHistoryForOutflow(programId, sendMoneyResponse, lengthOfupiRequestIdPrefix);
		// notification alert to sender for successful sendMoney P2M_PAY transaction
		if (sendMoneyResponse.getGatewayResponseCode().equals(Constants.GATEWAY_STATUSCODE_ZERO_ZERO)
				&& sendMoneyResponse.getTransactionType().equals(Constants.P2M_PAY)) {
			log.info("sending notification alert to sender regarding P2M_PAY send money successfull");
			notificationAlertForP2MTransaction(programId, sendMoneyResponse, Constants.SM_P2M_ALERT_SUCCESS_EVENT_ID);
		}
		updateTxnTrackingDetailsForOffUs(programId, juspaySendMoneyRequest.getUpiRequestId(),
				juspaySendMoneyRequest.getPayeeVpa(), sendMoneyResponse.getGatewayResponseStatus());
		// Call API in txn_history to get txn tracking details fetchTrackingTxnDetails
		sendMoneyResponse.setTrackingTxnStatus(
				txnHistoryMSAdapter.fetchUserProfile(programId, sendMoneyResponse.getGatewayTransactionId()));
		log.info("sendMoneyResponse :: {}", sendMoneyResponse);
		return sendMoneyResponse;
	}

	private void updateTxnTrackingDetailsForOffUs(String programId, String upiRequestId, String payeeVpa,
			String status) {
		log.info("updateTxnTrackingDetailsForOffUs :: status :: {}", status);
		String agentName = programParamsDAO.fetchParamValueByParamName(programId,
				ProgramParamConstants.AGENT_NAME.getValue());
		String vpaAddress = programParamsDAO.fetchParamValueByParamName(programId,
				ProgramParamConstants.VPA_ADDRESS_PAYU.name());
		if (!CommonHelper.checkOnUs(payeeVpa, agentName, vpaAddress)) {
			if (status.equals(Constants.SUCCESS)) {
				Runnable txnTracking = () -> kafkaProducer.publishUpiTxnTracking(upiRequestId,
						TxnTrackingConstants.CREDIT_MONEY_SUCCESS);
				new Thread(txnTracking).start();
			} else if (status.equals(Constants.FAILURE)) {
				Runnable txnTracking = () -> kafkaProducer.publishUpiTxnTracking(upiRequestId,
						TxnTrackingConstants.CREDIT_MONEY_FAILURE);
				new Thread(txnTracking).start();
			}
		}
	}

	private void sendMoneyTxnHistoryForOutflow(String programId, SendMoneyResponse sendMoneyResponse,
			int lengthOfupiRequestIdPrefix) {
		if (sendMoneyResponse.getGatewayResponseCode().equals(Constants.GATEWAY_STATUSCODE_ZERO_ZERO)) {
			log.info("send money successful update details in txn history");
			TxnDetails txnDetls = new TxnDetails();
			txnDetls.setTxnType(TXN_UPDATE);
			txnDetls.setProgramId(programId);
			UpdtTxnDetails updtTxnDetails = new UpdtTxnDetails();
			updtTxnDetails.setOriginalTxnId(
					sendMoneyResponse.getGatewayTransactionId().substring(lengthOfupiRequestIdPrefix));
			updtTxnDetails.setTxnStatus("S");
			updtTxnDetails.setTxnFlow("O");
			txnDetls.setData(updtTxnDetails);
			Runnable statusrunnable = () -> kafkaProducer.publishUpiTxn(txnDetls);
			new Thread(statusrunnable).start();
		} else if (sendMoneyResponse.getGatewayResponseCode().equals(Constants.GATEWAY_STATUSCODE_ZERO_ONE)
				|| sendMoneyResponse.getGatewayResponseCode().equals(Constants.GATEWAY_STATUSCODE_NINE_SIX)) {
			log.info("sending money went to deemed / pending state so no need to update status in txn history");
		} else {
			log.info("send money failure update details in txn history");
			TxnDetails txnDetls = new TxnDetails();
			txnDetls.setTxnType(TXN_UPDATE);
			txnDetls.setProgramId(programId);
			UpdtTxnDetails updtTxnDetails = new UpdtTxnDetails();
			updtTxnDetails.setOriginalTxnId(
					sendMoneyResponse.getGatewayTransactionId().substring(lengthOfupiRequestIdPrefix));
			updtTxnDetails.setTxnStatus("F");
			updtTxnDetails.setTxnFlow("O");
			txnDetls.setData(updtTxnDetails);
			Runnable statusrunnable = () -> kafkaProducer.publishUpiTxn(txnDetls);
			new Thread(statusrunnable).start();
		}
	}

	private void notificationAlertForP2MTransaction(String programId, SendMoneyResponse sendMoneyResponse,
			String eventId) {
		CustomerMiniProfile payerMinProfile = apiManagerUtil.fetchUserProfile(programId,
				sendMoneyResponse.getMerchantCustomerId(), null);
		log.info("payerMinProfile : {}", payerMinProfile);

		// To fetch payer balance details
		log.info("fetching payer account balance details");
		MultiValueMap<String, String> customHeader = null;
		FetchCardBalanceRequest fetchCardBalanceRequest = new FetchCardBalanceRequest();
		fetchCardBalanceRequest.setCustomerId(payerMinProfile.getCustomerId());
		fetchCardBalanceRequest.setProductType(Constants.PRODUCT_TYPE_RW);
		customHeader = new LinkedMultiValueMap<>();
		customHeader.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
		customHeader.add("X-PROGRAM-ID", programId);
		customHeader.add("X-ACCOUNT-NUMBER", payerMinProfile.getCustomerId());
		HttpEntity<Object> cardBalanceEntity = new HttpEntity<>(fetchCardBalanceRequest, customHeader);
		ObjectMapper obj = new ObjectMapper();
		ResponseEntity<WibmoResponse> fetchCardBalanceResponseEntity = null;
		FetchCardBalanceResponse fetchCardBalanceResponse = null;
		double dPayerBalance = 0;
		try {
			String reqJson = obj.writeValueAsString(fetchCardBalanceRequest);
			log.info("fetchCardBalanceRequest: {}", reqJson);
			fetchCardBalanceResponseEntity = restTemplate.exchange(walletUrl + fetchCardBalanceUrl, HttpMethod.POST,
					cardBalanceEntity, WibmoResponse.class);
			WibmoResponse wibmoResponse = fetchCardBalanceResponseEntity.getBody();
			if (null != wibmoResponse && wibmoResponse.getResCode() == 1) {
				fetchCardBalanceResponse = dozzerBeanMapper.map(wibmoResponse.getData(),
						FetchCardBalanceResponse.class);
				log.info("fetchCardBalanceResponse : {}", obj.writeValueAsString(fetchCardBalanceResponse));
				dPayerBalance = (double) fetchCardBalanceResponse.getBalance() / 100;
			}
		} catch (Exception ex) {
			log.error("Exception in fetchCardBalance :: {}", ex);
		}

		Map<String, String> placeHolder = new HashMap<>();
		placeHolder.put("PAYER", payerMinProfile.getFirstName());
		placeHolder.put("AMOUNT", sendMoneyResponse.getAmount());
		placeHolder.put("BALANCE", Constants.CURRENCY_IND + String.format("%.2f", dPayerBalance));
		placeHolder.put("PAYEE", sendMoneyResponse.getPayeeName());
		NotificationRequest aRequest = NotificationRequest.builder().mobileNumber(payerMinProfile.getMobileNo())
				.programId(Integer.valueOf(programId)).eventId(Integer.valueOf(eventId))
				.emailId(payerMinProfile.getEmailId()).whatsappEnabled(false).placeHolders(placeHolder).build();
		NotificationServiceCall notificationServiceCall = new NotificationServiceCall();
		notificationServiceCall.send(aRequest, notificationUrl);
	}

	private void setProgramIdAndUpiTrnsRequest(String programId, UPITransactionRequest req) {
		if (StringUtils.isEmpty(req.getTransacType()))
			req.setTransacType(Constants.P2P_PAY);

		VerifyVpaRequest verifyVpaRequest = new VerifyVpaRequest();
		verifyVpaRequest.setUdfParameters(req.getUdfParameters());
		verifyVpaRequest.setVpa(req.getPayeeVpa());
		VerifyVpaResponse verifyVpaResponse = null;
		try {

			if (!req.getPayeeVpa().contains("ifsc.npci")) {
				verifyVpaResponse = verifyVpa(programId, verifyVpaRequest);
				String gatewayResponseStatus = verifyVpaResponse.getGatewayResponseStatus();
				if (gatewayResponseStatus.equals(Constants.FAILURE)) {
					throw new UpiGenericException(verifyVpaResponse.getCustomGatewayStatusCode(),
							new Throwable(verifyVpaResponse.getGatewayResponseMessage()));
				}
				String handler = StringUtils.substringAfterLast(verifyVpaResponse.getVpa(), "@");
				if (Boolean.parseBoolean(verifyVpaResponse.getIsMerchant()) && handler.equals(Constants.PAYU)) {
					req.setTransacType(Constants.P2M_PAY);
					req.setMcc(verifyVpaResponse.getMcc());
				}
			}
		} catch (Exception e) {
			log.error("exception in verifying payeeVpa");
		}
	}

	private JuspaySendMoneyRequest getJuspaySendMoneyRequest(UPITransactionRequest req, String upiRequestIdPrefix,
			int lengthOfupiRequestIdPrefix) {
		String upiRequestId;
		JuspaySendMoneyRequest juspaySendMoneyRequest = new JuspaySendMoneyRequest();
		upiRequestId = getUpiRequestId(req, upiRequestIdPrefix, lengthOfupiRequestIdPrefix);
		juspaySendMoneyRequest.setUpiRequestId(upiRequestId);
		String transacType = req.getTransacType();
		juspaySendMoneyRequest.setTransactionType(transacType);
		juspaySendMoneyRequest.setPayeeVpa(req.getPayeeVpa());
		juspaySendMoneyRequest.setPayeeName(req.getPayeeName());

		if (StringUtils.isNotBlank(req.getPayeeVpa()))
			juspaySendMoneyRequest.setPayeeVpa(req.getPayeeVpa());
		else
			throw new UpiGenericException(UpiStatusConstants.PAYEE_VPA_IS_EMPTY.toString());

		if (req.getAmount() > 0)
			juspaySendMoneyRequest.setAmount(impliedDecimalTo(String.valueOf(req.getAmount())));
		else
			throw new UpiGenericException(UpiStatusConstants.AMOUNT_IS_EMPTY.toString());

		switch (transacType) {

		case (Constants.P2P_PAY):
			juspaySendMoneyRequest.setCurrency(RegistrationConstants.IND_CURRENCY);
			break;
		case (Constants.P2M_PAY):
			juspaySendMoneyRequest.setCurrency(RegistrationConstants.IND_CURRENCY);
			if (StringUtils.isNotBlank(req.getMcc()))
				juspaySendMoneyRequest.setMcc(req.getMcc());
			else
				throw new UpiGenericException(UpiStatusConstants.MCC_IS_EMPTY.toString());
			break;
		case (Constants.INTENT_PAY), (Constants.SCAN_PAY):
			juspaySendMoneyRequest.setRemarks(req.getRemarks());
			juspaySendMoneyRequest.setRefUrl(req.getRefUrl());
			juspaySendMoneyRequest.setRefCategory(req.getRefCategory());
			juspaySendMoneyRequest.setMcc(req.getMcc());
			juspaySendMoneyRequest.setTransactionReference(req.getTransacationReference());
			juspaySendMoneyRequest.setRefCategory(req.getRefCategory());
			if (StringUtils.isBlank(req.getCurrency())) {
				juspaySendMoneyRequest.setCurrency(RegistrationConstants.IND_CURRENCY);
			} else
				juspaySendMoneyRequest.setCurrency(req.getCurrency());
			if (StringUtils.isBlank(req.getMcc())) {
				juspaySendMoneyRequest.setMcc(Constants.MCC_DEFAULT);
			} else
				juspaySendMoneyRequest.setMcc(req.getMcc());

			break;
		default:
			break;
		}
		return juspaySendMoneyRequest;
	}

	private static String getUpiRequestId(UPITransactionRequest req, String upiRequestIdPrefix,
			int lengthOfupiRequestIdPrefix) {
		String upiRequestId;
		Optional<String> checkRefNo = Optional.ofNullable(req.getOriginalTxnId());
		if (checkRefNo.isPresent()) {
			upiRequestId = upiRequestIdPrefix + req.getOriginalTxnId();
		} else {
			upiRequestId = upiRequestIdPrefix + RandomStringUtils.randomAlphanumeric(35 - lengthOfupiRequestIdPrefix);
		}
		return upiRequestId;
	}

	@Override
	/**
	 * Juspay Call for Request Money
	 */
	public RequestMoneyResponse requestMoney(String programId, String accountNumber, RequestMoneyRequest request)
			throws IOException {
		log.debug("JuspayServiceAdapterImpl : requestMoney ");
		RequestMoneyResponse response = null;

		try {

			String baseUrl = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.JUSPAY_BASE_URL.getValue());
			final String juspayUrl = baseUrl + requestMoneyUrl;
			log.info(CONCATENATED_URL, juspayUrl);

			String merchantId = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.MERCHANT_ID.getValue());
			String merchantChannelId = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.MERCHANT_CHANNEL_ID.getValue());
			String privateKey = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.PRIVATE_KEY.getValue());
			String collectReqExpMinutes = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.COLLECT_REQ_EXP_MINUTES.name());
			String upiRequestIdPrefix = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.UPI_REQUEST_ID_PREFIX.getValue());

			// headers
			MultiValueMap<String, String> customHeaders = new LinkedMultiValueMap<>();
			String timestamp = String.valueOf(new Date().getTime());
			customHeaders = juspayHeadersCreation(customHeaders, merchantId, merchantChannelId, timestamp);

			// Juspay Request Build
			JuspayRequestMoneyRequest juspayRequestMoneyRequest = dozzerBeanMapper.map(request,
					JuspayRequestMoneyRequest.class);
			juspayRequestMoneyRequest.setAmount(impliedDecimalTo(request.getTxnAmount()));
			VPALinkedAccount vpaLinkedAccount = vpaLinkedAccountDAO.findByAccountNumber(Long.valueOf(accountNumber));
			VPADetails vpaDetails = vpaDetailsDAO.findByAccountNumber(Long.parseLong(accountNumber));
			juspayRequestMoneyRequest.setMerchantCustomerId(accountNumber);
			juspayRequestMoneyRequest.setDeviceFingerPrint(vpaDetails.getDeviceFingerprint());
			juspayRequestMoneyRequest
					.setBankAccountUniqueId(vpaLinkedAccount != null ? vpaLinkedAccount.getBankAccUniqueId() : null);
			juspayRequestMoneyRequest.setMerchantRequestId(RandomStringUtils.randomAlphanumeric(35).toUpperCase());
			String random = upiRequestIdPrefix + new Date().getTime() + accountNumber;
			juspayRequestMoneyRequest.setUpiRequestId(random);
			juspayRequestMoneyRequest.setCollectRequestExpiryMinutes(collectReqExpMinutes);
			juspayRequestMoneyRequest.setCurrency(RegistrationConstants.IND_CURRENCY);
			if (request.getUdfParameters() == null || request.getUdfParameters().isEmpty()) {
				juspayRequestMoneyRequest.setUdfParameters(new JSONObject().toString());
			} else
				juspayRequestMoneyRequest.setUdfParameters(request.getUdfParameters());
			juspayRequestMoneyRequest.setRemarks(request.getRemarks() == null ? "" : request.getRemarks());
			log.info("Saving request details");
			long insertedId = vpaTxnDAO.insertRequestMoneyDetails(juspayRequestMoneyRequest);
			Runnable txnInitSuccessStatus = () -> kafkaProducer.publishUpiTxnTracking(
					juspayRequestMoneyRequest.getUpiRequestId(), TxnTrackingConstants.PAYMENT_INITIATION_SUCCESS);
			new Thread(txnInitSuccessStatus).start();
			log.info("kafka call initiated to insert txn traction status details");
			if (insertedId == 0) {
				log.info("Unable to save details into our details");
				response = new RequestMoneyResponse();
				response.setWibmoResCode(100);
				response.setWibmoResDesc("Failure");
				response.setWibmoErrorMessage("Failed to save request money details");
				return response;
			}
			ObjectMapper obj = new ObjectMapper();
			String reqJson = obj.writeValueAsString(juspayRequestMoneyRequest);

			// calculate Signature
			String input = merchantId + merchantChannelId + timestamp + reqJson;
			String signature = signUtil.calculateSignature(input, privateKey);

			customHeaders.add(Constants.X_MERCHANT_SIGNATURE, signature);

			HttpEntity<String> httpEntity = new HttpEntity<>(reqJson, customHeaders);
			log.info("{} ", juspayRequestMoneyRequest);
			log.info(sendingRequestJustpay, juspayUrl);
			ResponseEntity<JuspayRequestMoneyResponse> result = null;
			result = restTemplate.exchange(juspayUrl, HttpMethod.POST, httpEntity, JuspayRequestMoneyResponse.class);
			JuspayRequestMoneyResponse res = result.getBody();
			if (res != null) {
				String respCode = res.getResponseCode();
				String respMsg = res.getResponseMessage();
				log.info(justpayResponse, respCode, respMsg, res);
				if (res.getPayload() != null) {
					response = responseMapper.map(res);
					response.setPayeeName(request.getPayeeName());
					response.setTxnDate(timestamp);
					VpaTxnInfo vpaTxnInfo = vpaTxnInfoRequestMoneyMapper.map(res);
					vpaTxnInfo.setUpiRequestId(juspayRequestMoneyRequest.getUpiRequestId());
					vpaTxnInfo.setPayeeName(request.getPayeeName());
					vpaTxnInfo.setOriginalTxnId(juspayRequestMoneyRequest.getMerchantRequestId());
					vpaTxnInfo.setId(insertedId);
					vpaTxnInfo.setTransactionType("UPI_RM");
					vpaTxnInfo.setStatus("REQUEST_MONEY_PENDING");
					vpaTxnDAO.updateSuccessRespRequestMoneyDetails(vpaTxnInfo);
					response.setTxnRefNum(vpaTxnInfo.getGatewayTxnId());
					response.setPayeeMobileNumber(vpaTxnInfo.getCustomerMobileNumber());
					// Kafka call to insert details txn_details
					// insert into txn history
					StringBuilder txnDesc = new StringBuilder();
					CreditMoneyTxnDetailsRequest cm = new CreditMoneyTxnDetailsRequest();
					cm.setCustomerId(accountNumber);// payeeCustomerId
					cm.setOriginalTxnId(vpaTxnInfo.getGatewayTxnId());
					cm.setSourceAccount(vpaTxnInfo.getPayerVpa());
					cm.setDestAccount(vpaTxnInfo.getPayeeVpa());
					cm.setTxnCategory("RMC");
					cm.setRemarks(juspayRequestMoneyRequest.getRemarks());
					cm.setTxnStatus("P");
					long amount = Math.round(vpaTxnInfo.getAmount() * 100);
					cm.setTxnAmount(amount);
					cm.setTxnType("RM");
					cm.setTxnFlow("I");
					cm.setPaymentMode("RW");
					log.info("RMC INFLOW setTxnShortDesc payer name: {}", request.getPayerName());
					cm.setTxnDate(new Timestamp(System.currentTimeMillis()));
					txnDesc.append(Constants.REQUESTED).append(Constants.RS_SYMBOL)
							.append(CommonUtil.decimalFormat(amount)).append(Constants.TO)
							.append(request.getPayerName());
					cm.setTxnDesc(txnDesc.toString());
					cm.setTxnShortDesc(request.getPayerName());
					cm.setMerCategory("Waiting for payer");
					TxnDetails txnDetails = new TxnDetails();
					txnDetails.setProgramId(programId);
					txnDetails.setTxnType("RMI");
					txnDetails.setData(cm);

					Runnable runnable = () -> kafkaProducer.publishUpiTxn(txnDetails);
					new Thread(runnable).start();
				} else {
					response = new RequestMoneyResponse();
					response.setWibmoResCode(100);
					response.setWibmoResDesc(res.getStatus());
					response.setWibmoErrorMessage(res.getResponseMessage());
					vpaTxnDAO.updateFailRespRequestMoneyDetails(insertedId, "REQUEST_MONEY_FAILED");
					log.error("Error message from Juspay :: {}", res.getResponseMessage());
				}
			}
		} catch (Exception e) {
			log.error("Error occurred in RequestMoney: {}", e);
			response = new RequestMoneyResponse();
			response.setWibmoResCode(100);
			response.setWibmoResDesc(Constants.FAILURE);
			response.setWibmoErrorMessage("Exception while communicating with justPay");
		}

		return response;
	}

	@Override
	public TransactionStatusCallbackResponse handleTransactionStatusCallback(String programId, String request) {
		log.debug("JuspayServiceAdapterImpl : handleTransactionStatusCallback : programId -{}, request -{}", programId,
				request);
		TransactionStatusCallbackResponse response = new TransactionStatusCallbackResponse();
		int flag = 0;

		try {
			JSONObject jsonObject = new JSONObject(request);
			String type = (String) jsonObject.get("type");
			String reqCode = (String) jsonObject.get(Constants.GATEWAY_RESPONSE_CODE);
			String gatewayTransactionId = (String) jsonObject.get(Constants.GATEWAY_TXN_ID);
			String codes = programParamsDAO.fetchParamValueByParamName(programId, "JUSPAY_CALLBACK_STATUS_CODES");
			ObjectMapper objectMapper = new ObjectMapper();
			List<JuspayCallbackStatusCodes> codesObjs = objectMapper.readValue(codes,
					new TypeReference<List<JuspayCallbackStatusCodes>>() {
					});
			JuspayCallbackStatusCodes statusCode = codesObjs.stream().filter(c -> c.getCode().equals(reqCode))
					.findFirst().orElse(null);
			log.info("statusCode :: {}", statusCode);
			switch (type) {
			// We have debit amount both got deed/pending state from juspay in that case we
			// receive this type of callback
			case "CUSTOMER_DEBITED_VIA_PAY":
				// update txn_history if we receive final state(Failed / Success / Declined /
				// Expired).
				if (statusCode != null && Boolean.parseBoolean(statusCode.getTerminalState())) {
					log.info("update status with {}", statusCode.getStatus());
					TxnDetails txnDetls = new TxnDetails();
					txnDetls.setTxnType(TXN_UPDATE);
					txnDetls.setProgramId(programId);
					UpdtTxnDetails updtTxnDetails = new UpdtTxnDetails();
					updtTxnDetails.setOriginalTxnId(gatewayTransactionId.substring(3));
					updtTxnDetails.setTxnStatus(String.valueOf(statusCode.getStatus().charAt(0)));
					updtTxnDetails.setTxnFlow("O");
					txnDetls.setData(updtTxnDetails);
					Runnable updateStatus = () -> kafkaProducer.publishUpiTxn(txnDetls);
					new Thread(updateStatus).start();

				} else
					log.info("not in terminal state {} :: {}", reqCode, gatewayTransactionId);
				break;

			default:
				log.info("{}", type);

			}
			String payeeMerchantCustomerId = (String) jsonObject.get(Constants.PAYEE_MERCHANT_CUSTOMER_ID);
			String reqStatus = (String) jsonObject.get(Constants.GATEWAY_RESPONSE_STATUS);

			VpaTxnInfoDetails vpaTxnInfoDetails = upiRegistrationDAO
					.fetchStatusBasesOnGatewayTxnId(gatewayTransactionId, payeeMerchantCustomerId);

			if (vpaTxnInfoDetails.getStatus().equals(SUCCESS) || vpaTxnInfoDetails.getStatus().equals("FAILURE")
					|| vpaTxnInfoDetails.getStatus().equals("DECLINED")
					|| vpaTxnInfoDetails.getStatus().equals("EXPIRED")) {

				response.setGatewayResponseCode(reqCode);
				response.setGatewayResponseStatus(reqStatus);
				log.debug("Status is already in terminal state");
			} else {
				flag = getFlag(programId, flag, reqStatus, vpaTxnInfoDetails);
				if (flag == 1)
					upiRegistrationDAO.updateVpaTxnInfoByTxnId(reqStatus, Constants.REFUND_STATUS, gatewayTransactionId,
							payeeMerchantCustomerId);
				else
					upiRegistrationDAO.updateVpaTxnInfoByTxnId(reqStatus, reqStatus, gatewayTransactionId,
							payeeMerchantCustomerId);
				response = new TransactionStatusCallbackResponse();
				response.setGatewayResponseCode(reqCode);
				response.setGatewayResponseStatus(reqStatus);
				log.debug("Status updated successfully in table");
			}
		} catch (Exception ex) {
			log.error("Failed to update table! {}", ex);
			response.setGatewayResponseCode("500");
			response.setGatewayResponseStatus("Failure");
		}
		return response;
	}

	private int getFlag(String programId, int flag, String reqStatus, VpaTxnInfoDetails vpaTxnInfoDetails) {
		if (reqStatus.equals("FAILURE") || reqStatus.equals("DECLINED") || reqStatus.equals("EXPIRED")) {

			VpaDetails vpaDetails = upiRegistrationDAO.fetchVpaDetailsBasesOnMerchantCustId(
					vpaTxnInfoDetails.getMerchantCustomerId(), vpaTxnInfoDetails.getPayerVpa());

			// call load money
			String wibmoTxnId = CommonUtil.generateWibmoTxnId();
			FundRequest fundRequest = new FundRequest();
			fundRequest.setAmount(Long.parseLong(vpaTxnInfoDetails.getAmount()));
			fundRequest.setTxnType(Constants.P2P_CREDIT);
			fundRequest.setCustId(vpaDetails.getAccountNmber() + "");
			fundRequest.setRrn(wibmoTxnId);
			fundRequest.setWalletId(vpaDetails.getWalletId());

			MultiValueMap<String, String> customFundHeader = new LinkedMultiValueMap<>();
			customFundHeader.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
			customFundHeader.add("X-PROGRAM-ID", programId);
			customFundHeader.add("X-ACCOUNT-NUMBER", vpaDetails.getAccountNmber() + "");// bankEzy accno form vpa
																						// details
			HttpEntity<Object> fundLoadEntity = new HttpEntity<>(fundRequest, customFundHeader);
			ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(walletUrl + Constants.CREDIT_FUND_EP,
					HttpMethod.POST, fundLoadEntity, WibmoResponse.class);
			WibmoResponse resp = responseEntity.getBody();
			if (resp != null && resp.getResCode() == 1) {
				log.debug("amount refunded");
			} else {
				flag = 1;
				log.debug("amount not refunded! Error occurred in load fund process");
			}
		}
		return flag;
	}

	private MultiValueMap<String, String> juspayHeadersCreation(MultiValueMap<String, String> customHeaders,
			String merchantId, String merchantChannelId, String timestamp) {
		customHeaders.add(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON);
		customHeaders.add(Constants.ACCEPT, Constants.APPLICATION_JSON);
		customHeaders.add(Constants.X_MERCHANT_ID, merchantId);
		customHeaders.add(Constants.X_MERCHANT_CHANNEL_ID, merchantChannelId);
		customHeaders.add(Constants.X_TIMESTAMP, timestamp);
		return customHeaders;
	}

	private HttpEntity<String> createHttpEntityWithHeaders(MerchantDetails merDetails, String privateKey,
			Object juspayRequestObject) throws IOException {
		MultiValueMap<String, String> customHeaders = new LinkedMultiValueMap<>();
		customHeaders.add(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON);
		customHeaders.add(Constants.ACCEPT, Constants.APPLICATION_JSON);
		customHeaders.add(Constants.X_MERCHANT_ID, merDetails.getMerchantId());
		customHeaders.add(Constants.X_MERCHANT_CHANNEL_ID, merDetails.getMerchantChannelId());
		String timestamp = String.valueOf(new Date().getTime());
		customHeaders.add(Constants.X_TIMESTAMP, timestamp);

		ObjectMapper obj = new ObjectMapper();
		String reqJson = obj.writeValueAsString(juspayRequestObject);
		String input = merDetails.getMerchantId() + merDetails.getMerchantChannelId() + timestamp + reqJson;
		String signature = signUtil.calculateSignature(input, privateKey);
		customHeaders.add(Constants.X_MERCHANT_SIGNATURE, signature);

		return new HttpEntity<>(reqJson, customHeaders);
	}

	/**
	 *
	 * @param programId
	 * @param accountNumber
	 * @param request
	 * @param vpaDetailsRow
	 * @return
	 * @throws IOException
	 */
	@Override
	public AddVpaResponse addVpaAccount(String programId, String accountNumber, AddVpaRequest request,
			VPADetails vpaDetailsRow) throws IOException {
		log.debug("JuspayServiceAdapterImpl : addVpaAccount ");
		AddVpaResponse response = new AddVpaResponse();
		try {

			String baseUrl = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.JUSPAY_BASE_URL.getValue());
			final String juspayUrl = baseUrl + addVpaUrl;
			log.info(CONCATENATED_URL, juspayUrl);

			String merchantId = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.MERCHANT_ID.getValue());
			String merchantChannelId = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.MERCHANT_CHANNEL_ID.getValue());
			String privateKey = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.PRIVATE_KEY.getValue());

			// headers
			MultiValueMap<String, String> customHeaders = new LinkedMultiValueMap<>();
			String timestamp = String.valueOf(new Date().getTime());
			customHeaders = juspayHeadersCreation(customHeaders, merchantId, merchantChannelId, timestamp);

			VpaValidRequest vpaValidRequest = new VpaValidRequest();
			vpaValidRequest.setVpa(request.getCustomerVpa());
			vpaValidRequest.setUdfParameters(request.getUdfParameters());

			// Check VPA is available
			WibmoResponse vpaAvailableResponse = upiService.isVpaAvailable(programId, accountNumber, vpaValidRequest);
			if (vpaAvailableResponse != null && vpaAvailableResponse.getData() != null) {
				VpaValidResponse vpaValidResponse = (VpaValidResponse) vpaAvailableResponse.getData();
				if (vpaValidResponse != null && vpaValidResponse.isVpaValid()) {
					// request
					JuspayAddVpaRequest juspayAddVpaRequest = new JuspayAddVpaRequest();
					juspayAddVpaRequest.setMerchantCustomerId(accountNumber);
					juspayAddVpaRequest.setCustomerVpa(request.getCustomerVpa());
					juspayAddVpaRequest.setCustomerPrimaryVpa(vpaDetailsRow.getVpa());
					juspayAddVpaRequest.setDeleteCustomerPrimaryVpa(Constants.FALSE);
					juspayAddVpaRequest.setUdfParameters(request.getUdfParameters());
					ObjectMapper obj = new ObjectMapper();
					String reqJson = obj.writeValueAsString(juspayAddVpaRequest);
					String input = merchantId + merchantChannelId + timestamp + reqJson;
					String signature = signUtil.calculateSignature(input, privateKey);
					customHeaders.add(Constants.X_MERCHANT_SIGNATURE, signature);

					HttpEntity<String> httpEntity = new HttpEntity<>(reqJson, customHeaders);
					log.info("{} ", juspayAddVpaRequest);
					log.info(sendingRequestJustpay, juspayUrl);
					ResponseEntity<JuspayAddVpaResponse> result = null;
					result = restTemplate.exchange(juspayUrl, HttpMethod.POST, httpEntity, JuspayAddVpaResponse.class);
					JuspayAddVpaResponse res = result.getBody();
					if (res != null) {
						String respCode = res.getResponseCode();
						String respMsg = res.getResponseMessage();
						log.info(justpayResponse, respCode, respMsg, res);
						return handleSuccess(res, response, accountNumber, request, vpaDetailsRow);
					}
				} else {
					log.debug(Constants.VPA_VALID_FALSE_FLAG);
					response.setStatus(UpiStatusConstants.FAILURE.getStatusMsg());
					response.setResponseMessage(Constants.VPA_NOT_AVAILABLE);
					return response;
				}
			} else {
				return null;
			}
		} catch (Exception e) {
			log.debug("Error occurred in addVpaAccount: {}", e);
		}
		return response;
	}

	private AddVpaResponse handleSuccess(JuspayAddVpaResponse res, AddVpaResponse response, String accountNumber,
			AddVpaRequest request, VPADetails vpaDetailsRow) {
		if (res.getPayload() != null) {
			response = dozzerBeanMapper.map(res, AddVpaResponse.class);
			// Store vpa_details
			savingVpaDetailsOnSuccessMsg(accountNumber, request, vpaDetailsRow, response);
			response.setStatus(UpiStatusConstants.SUCCESS.getStatusMsg());
			response.setResponseMessage(Constants.VPA_ADDED_SUCCESS);
		} else {
			log.error(Constants.ADD_VPA_JUSPAY_CALL_FAILURE);
			response.setStatus(UpiStatusConstants.FAILURE.getStatusMsg());
			response.setResponseMessage(Constants.ADD_VPA_JUSPAY_CALL_FAILURE);
		}
		return response;
	}

	/**
	 *
	 * @param response
	 * @param request
	 * @param accountNumber
	 * @param vpaDetailsRow storing vpa detail for new VPA
	 */
	private void saveVpaDetailsInDBFromAddVpa(AddVpaResponse response, AddVpaRequest request, String accountNumber,
			VPADetails vpaDetailsRow) {
		VPADetails vpaDetails = new VPADetails();
		VPALinkedAccount vpaLinkedAccount = null;
		// populating vpaDetails info
		vpaDetails.setAccountNumber(Long.parseLong(accountNumber));
		vpaDetails.setMobileNumber(vpaDetailsRow.getMobileNumber());
		vpaDetails.setUpiCustomerId(Long.parseLong(accountNumber));
		vpaDetails.setDeviceId(vpaDetailsRow.getDeviceId());
		vpaDetails.setSsid(vpaDetailsRow.getSsid());
		vpaDetails.setDeviceFingerprint(vpaDetailsRow.getDeviceFingerprint());
		vpaDetails.setVpa(request.getCustomerVpa());
		vpaDetails.setIsPrimaryVpa(Boolean.FALSE);
		vpaDetails.setStatus(vpaDetailsRow.getStatus());
		// Query to fetch vpaLinkedAccount details
		log.info("fetching walletId from wallet_cards DB in Wallet MS");
		vpaLinkedAccount = vpaLinkedAccountDAO.fetchVpaLinkedByBankId(
				response.getPayload().getVpaAccounts().get(0).getAccount().getBankAccountUniqueId());
		vpaDetails.setLinkedAccountId(vpaLinkedAccount != null ? vpaLinkedAccount.getId() : null);
		vpaDetails.setActive(vpaDetailsRow.getActive());
		vpaDetails.setWalletId(vpaDetailsRow.getWalletId());
		vpaDetailsDAO.saveVpaDetails(vpaDetails);
	}

	/**
	 *
	 * @param programId
	 * @param accountNumber
	 * @param request
	 * @return deleting Vpa account
	 */
	@Override
	public DeleteVpaResponse deleteVpaAccount(String programId, String accountNumber, DeleteVpaRequest request,
			List<VPADetails> vpaDetailsRow, String customerPrimaryVpa) {
		log.debug("JuspayServiceAdapterImpl : deleteVpaAccount ");
		DeleteVpaResponse response = new DeleteVpaResponse();
		try {

			String baseUrl = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.JUSPAY_BASE_URL.getValue());
			final String juspayUrl = baseUrl + deleteVpaUrl;
			log.info(CONCATENATED_URL, juspayUrl);

			String merchantId = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.MERCHANT_ID.getValue());
			String merchantChannelId = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.MERCHANT_CHANNEL_ID.getValue());
			String privateKey = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.PRIVATE_KEY.getValue());

			// headers
			MultiValueMap<String, String> customHeaders = new LinkedMultiValueMap<>();
			String timestamp = String.valueOf(new Date().getTime());
			customHeaders = juspayHeadersCreation(customHeaders, merchantId, merchantChannelId, timestamp);

			// Juspay request
			JuspayDeleteVpaRequest juspayDeleteVpaRequest = new JuspayDeleteVpaRequest();
			juspayDeleteVpaRequest.setMerchantCustomerId(accountNumber);
			juspayDeleteVpaRequest.setCustomerVpa(request.getCustomerVpa());
			juspayDeleteVpaRequest.setCustomerPrimaryVpa(customerPrimaryVpa);
			juspayDeleteVpaRequest.setUdfParameters(request.getUdfParameters());
			ObjectMapper obj = new ObjectMapper();
			String reqJson = obj.writeValueAsString(juspayDeleteVpaRequest);
			String input = merchantId + merchantChannelId + timestamp + reqJson;
			String signature = signUtil.calculateSignature(input, privateKey);
			customHeaders.add(Constants.X_MERCHANT_SIGNATURE, signature);

			HttpEntity<String> httpEntity = new HttpEntity<>(reqJson, customHeaders);
			log.info("{} ", juspayDeleteVpaRequest);
			log.info(sendingRequestJustpay, juspayUrl);
			ResponseEntity<JuspayDeleteVpaResponse> result = null;
			result = restTemplate.exchange(juspayUrl, HttpMethod.POST, httpEntity, JuspayDeleteVpaResponse.class);
			JuspayDeleteVpaResponse res = result.getBody();
			if (res != null) {
				String respCode = res.getResponseCode();
				String respMsg = res.getResponseMessage();
				log.info(justpayResponse, respCode, respMsg, res);
				if (res.getPayload() != null) {
					response = dozzerBeanMapper.map(res, DeleteVpaResponse.class);
					// update vpa_details
					if (UpiStatusConstants.SUCCESS.getStatusMsg().equals(response.getStatus())) {
						if (vpaDetailsRow != null && !vpaDetailsRow.isEmpty()) {
							vpaDetailsRow.stream().forEach(row -> {
								row.setActive(Boolean.FALSE);
								vpaDetailsDAO.updateVpaDetails(row);
							});
						} else {
							log.info(Constants.VPA_LIST_EMPTY);
						}
					}
				} else {
					response.setStatus(UpiStatusConstants.FAILURE.name());
					response.setResponseMessage(respMsg);
				}
			}

		} catch (Exception e) {
			log.debug("Error occurred in deleteVpaAccount: {}", e);
			response = null;
		}
		return response;
	}

	/**
	 *
	 * @param programId
	 * @param accountNumber
	 * @param request
	 * @return de-register upi from eco system
	 */
	@Override
	public DeregisterCustomerResponse deRegisterCustomer(String programId, String accountNumber,
			DeregisterCustomerRequest request) {
		log.debug("JuspayServiceAdapterImpl : deRegisterCustomer ");
		DeregisterCustomerResponse response = new DeregisterCustomerResponse();
		try {

			String baseUrl = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.JUSPAY_BASE_URL.getValue());
			final String juspayUrl = baseUrl + deregisterCustomerUrl;
			log.info(CONCATENATED_URL, juspayUrl);

			String merchantId = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.MERCHANT_ID.getValue());
			String merchantChannelId = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.MERCHANT_CHANNEL_ID.getValue());
			String privateKey = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.PRIVATE_KEY.getValue());

			// headers
			MultiValueMap<String, String> customHeaders = new LinkedMultiValueMap<>();
			String timestamp = String.valueOf(new Date().getTime());
			customHeaders = juspayHeadersCreation(customHeaders, merchantId, merchantChannelId, timestamp);

			// Juspay request
			JuspayDeregisterCustomerRequest juspayDeregisterCustomerRequest = new JuspayDeregisterCustomerRequest();
			juspayDeregisterCustomerRequest.setMerchantCustomerId(accountNumber);
			juspayDeregisterCustomerRequest.setUdfParameters(request.getUdfParameters());
			setUdfParameters(request, juspayDeregisterCustomerRequest);
			ObjectMapper obj = new ObjectMapper();
			String reqJson = obj.writeValueAsString(juspayDeregisterCustomerRequest);
			String input = merchantId + merchantChannelId + timestamp + reqJson;
			String signature = signUtil.calculateSignature(input, privateKey);
			customHeaders.add(Constants.X_MERCHANT_SIGNATURE, signature);

			HttpEntity<String> httpEntity = new HttpEntity<>(reqJson, customHeaders);
			log.info("{} ", juspayDeregisterCustomerRequest);
			log.info(sendingRequestJustpay, juspayUrl);
			ResponseEntity<JuspayDeregisterCustomerResponse> result = null;
			result = restTemplate.exchange(juspayUrl, HttpMethod.POST, httpEntity,
					JuspayDeregisterCustomerResponse.class);
			JuspayDeregisterCustomerResponse res = result.getBody();
			if (res != null) {
				String respCode = res.getResponseCode();
				String respMsg = res.getResponseMessage();
				log.info(justpayResponse, respCode, respMsg, res);
				if (res.getPayload() != null) {
					response = dozzerBeanMapper.map(res, DeregisterCustomerResponse.class);
					if (UpiStatusConstants.SUCCESS.getStatusMsg().equals(response.getStatus())) {
						// fetch the vpa details from account number
						List<VPADetails> vpaDetails = vpaDetailsDAO.findVpaByAccountNumber(Long.valueOf(accountNumber));
						List<Long> vpaDetailIds;
						Set<VPALinkedAccount> vpaLinkedAccounts;
						if (vpaDetails != null && !vpaDetails.isEmpty()) {
							vpaDetailIds = vpaDetails.stream().map(VPADetails::getId).collect(Collectors.toList());
							vpaLinkedAccounts = vpaDetails.stream().filter(vpa -> vpa.getLinkedAccountId() != null)
									.map(vpa -> vpaLinkedAccountDAO.fetchVpaLinkedById(vpa.getLinkedAccountId()))
									.collect(Collectors.toSet());
						} else {
							log.info(Constants.VPA_DETAILS_NOT_AVAILABLE);
							response.setStatus(UpiStatusConstants.FAILURE.name());
							response.setResponseMessage(Constants.VPA_DETAILS_NOT_AVAILABLE);
							return response;
						}
						log.info("vpaDetails {}", vpaDetails);
						log.info("vpaLinkedAccounts {}", vpaLinkedAccounts);
						// delete customer vpa
						deleteCustomerVpaDetails(vpaDetailIds, vpaLinkedAccounts);
						Map<Long, VPALinkedAccount> map = vpaLinkedAccounts.stream()
								.collect(Collectors.toMap(VPALinkedAccount::getId, Function.identity()));
						// save de-register customer info in tbl
						saveDataInDeregisterCustInfo(vpaDetails, map);
					}
				} else {
					response = null;
				}
			}

		} catch (Exception e) {
			log.debug("Error occurred in deRegisterCustomer Account: {}", e);
			response = null;
		}
		return response;
	}

	@Override
	public RaiseUdirComplaintResponse raiseComplaint(String programId, String accountNumber,
			RaiseUdirComplaintRequest raiseUdirComplaintRequest) {

		log.debug("JuspayServiceAdapterImpl : raiseComplaint :{}", raiseUdirComplaintRequest);
		RaiseUdirComplaintResponse raiseUdirComplaintResponse = new RaiseUdirComplaintResponse();

		String baseUrl = progParamDao.fetchParamValueByParamName(programId,
				ProgramParamConstants.JUSPAY_BASE_URL.getValue());
		String jusPayUrl = baseUrl + udirRaiseComplaintUrl;
		log.info(CONCATENATED_URL, jusPayUrl);

		try {
			String merchantId = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.MERCHANT_ID.getValue());
			String merchantChannelId = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.MERCHANT_CHANNEL_ID.getValue());
			String privateKey = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.PRIVATE_KEY.getValue());
			String upiRequestIdPrefix = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.UPI_REQUEST_ID_PREFIX.getValue());

			// headers
			MultiValueMap<String, String> customHeaders = new LinkedMultiValueMap<>();
			String timestamp = String.valueOf(new Date().getTime());
			customHeaders = juspayHeadersCreation(customHeaders, merchantId, merchantChannelId, timestamp);
			JuspayRaiseComplaintUdirRequest juspayRaiseComplaintUdirRequest = new JuspayRaiseComplaintUdirRequest();
			juspayRaiseComplaintUdirRequest.setMerchantCustomerId(accountNumber);
			juspayRaiseComplaintUdirRequest
					.setMerchantRequestId(RandomStringUtils.randomAlphanumeric(35).toUpperCase());
			int lengthOfPrefixId = upiRequestIdPrefix.length();
			String upiRequestId = upiRequestIdPrefix + RandomStringUtils.randomAlphanumeric(35 - lengthOfPrefixId);
			juspayRaiseComplaintUdirRequest.setUpiRequestId(upiRequestId);
			String txnId = null;
			if (Boolean.parseBoolean(raiseUdirComplaintRequest.getIsMerchantTxn())) {
				DisputeRemarksDetails disputeRemarksDetails = disputeRemarksDAO
						.fetchDisputeAdjCode(raiseUdirComplaintRequest.getReasonCode());
				if (disputeRemarksDetails != null) {
					juspayRaiseComplaintUdirRequest.setAdjFlag(disputeRemarksDetails.getAdjFlag());
					juspayRaiseComplaintUdirRequest.setAdjCode(disputeRemarksDetails.getAdjCode());
					juspayRaiseComplaintUdirRequest.setInitiationMode(disputeRemarksDetails.getInitiationMode());
					txnId = upiRequestIdPrefix + raiseUdirComplaintRequest.getTxnId();
					juspayRaiseComplaintUdirRequest.setOriginalUpiRequestId(txnId);
					juspayRaiseComplaintUdirRequest.setRemarks(raiseUdirComplaintRequest.getRemarks());
				}
			} else {
				juspayRaiseComplaintUdirRequest.setAdjFlag("PBRB");
				juspayRaiseComplaintUdirRequest.setAdjCode("U010");
				juspayRaiseComplaintUdirRequest.setInitiationMode("U3");
				txnId = upiRequestIdPrefix + raiseUdirComplaintRequest.getTxnId();
				juspayRaiseComplaintUdirRequest.setOriginalUpiRequestId(txnId);
				juspayRaiseComplaintUdirRequest.setRemarks("pending or timeout transaction");
			}

			juspayRaiseComplaintUdirRequest.setPurpose("00");
			VpaTxnInfo vpaTxnInfo = vpaTxnDAO.fetchByGatewayTxnId(txnId);
			if (vpaTxnInfo != null) {
				juspayRaiseComplaintUdirRequest
						.setAdjAmount(impliedDecimalTo(String.valueOf((int) vpaTxnInfo.getAmount())));
				juspayRaiseComplaintUdirRequest.setRefUrl(vpaTxnInfo.getRefUrl());
				juspayRaiseComplaintUdirRequest.setRefCategory("00");
				juspayRaiseComplaintUdirRequest.setUdfParameters("{}");
			}
			juspayRaiseComplaintUdirRequest.setType(Constants.COMPLAINT);

			ObjectMapper obj = new ObjectMapper();
			String reqJson = obj.writeValueAsString(juspayRaiseComplaintUdirRequest);
			String input = merchantId + merchantChannelId + timestamp + reqJson;
			String signature = signUtil.calculateSignature(input, privateKey);
			customHeaders.add(Constants.X_MERCHANT_SIGNATURE, signature);
			HttpEntity<String> httpEntity = new HttpEntity<>(reqJson, customHeaders);

			log.info("{} ", juspayRaiseComplaintUdirRequest);
			log.info(sendingRequestJustpay, jusPayUrl);
			ResponseEntity<RaiseUdirComplaintResponse> result = null;
			result = restTemplate.exchange(jusPayUrl, HttpMethod.POST, httpEntity, RaiseUdirComplaintResponse.class);
			raiseUdirComplaintResponse = result.getBody();
			if (raiseUdirComplaintResponse != null) {
				String respCode = raiseUdirComplaintResponse.getResponseCode();
				String respMsg = raiseUdirComplaintResponse.getResponseMessage();
				log.info(justpayResponse, respCode, respMsg, raiseUdirComplaintResponse);
				if (raiseUdirComplaintResponse.getPayload() != null
						&& UpiStatusConstants.SUCCESS.getStatusMsg().equals(raiseUdirComplaintResponse.getStatus())) {
					raiseUdirComplaintResponse.getPayload().setTxnId(raiseUdirComplaintRequest.getTxnId());
					upiDisputeManagementDAO.addComplaints(accountNumber, raiseUdirComplaintResponse.getPayload());
					return raiseUdirComplaintResponse;
				}
			} else {
				raiseUdirComplaintResponse = null;
			}

		} catch (Exception e) {
			log.debug("Error occurred in raiseComplaint Account: {}", e);
			raiseUdirComplaintResponse = null;
		}
		return raiseUdirComplaintResponse;
	}

	@Override
	public UdirComplaintStatusResponse checkComplaint(String programId, String accountNumber,
			CheckUdirComplaintStatus checkUdirComplaints) {
		log.debug("JuspayServiceAdapterImpl : checkComplaint :{}", checkUdirComplaints);
		UdirComplaintStatusResponse udirComplaintStatusResponse = new UdirComplaintStatusResponse();

		String baseUrl = progParamDao.fetchParamValueByParamName(programId,
				ProgramParamConstants.JUSPAY_BASE_URL.getValue());
		String jusPayUrl = baseUrl + udirCheckStatusComplaint;
		log.info(CONCATENATED_URL, jusPayUrl);

		try {
			String merchantId = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.MERCHANT_ID.getValue());
			String merchantChannelId = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.MERCHANT_CHANNEL_ID.getValue());
			String privateKey = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.PRIVATE_KEY.getValue());
			String upiRequestIdPrefix = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.UPI_REQUEST_ID_PREFIX.getValue());

			// headers
			MultiValueMap<String, String> customHeaders = new LinkedMultiValueMap<>();
			String timestamp = String.valueOf(new Date().getTime());
			customHeaders = juspayHeadersCreation(customHeaders, merchantId, merchantChannelId, timestamp);
			JuspayUdirCheckComplaintsRequest juspayUdirCheckComplaintsRequest = new JuspayUdirCheckComplaintsRequest();
			if (checkUdirComplaints.getComplaintType() != null)
				juspayUdirCheckComplaintsRequest.setType(checkUdirComplaints.getComplaintType());
			else
				juspayUdirCheckComplaintsRequest.setType("DISPUTE");
			DisputeComplaints disputeComplaints = upiDisputeManagementDAO
					.fetchComplaintByGatewayComplaintId(checkUdirComplaints.getComplaintRefNo());
			juspayUdirCheckComplaintsRequest.setMerchantCustomerId(accountNumber);
			juspayUdirCheckComplaintsRequest.setOriginalUpiRequestId(checkUdirComplaints.getComplaintRefNo());
			juspayUdirCheckComplaintsRequest
					.setOriginalTransactionUpiRequestId(upiRequestIdPrefix + disputeComplaints.getTxnId());
			ObjectMapper obj = new ObjectMapper();
			String reqJson = obj.writeValueAsString(juspayUdirCheckComplaintsRequest);
			String input = merchantId + merchantChannelId + timestamp + reqJson;
			String signature = signUtil.calculateSignature(input, privateKey);
			customHeaders.add(Constants.X_MERCHANT_SIGNATURE, signature);
			HttpEntity<String> httpEntity = new HttpEntity<>(reqJson, customHeaders);

			log.info("{} ", juspayUdirCheckComplaintsRequest);
			log.info(sendingRequestJustpay, jusPayUrl);
			ResponseEntity<UdirComplaintStatusResponse> result = null;
			result = restTemplate.exchange(jusPayUrl, HttpMethod.POST, httpEntity, UdirComplaintStatusResponse.class);
			udirComplaintStatusResponse = result.getBody();
			if (udirComplaintStatusResponse != null) {
				String respCode = udirComplaintStatusResponse.getResponseCode();
				String respMsg = udirComplaintStatusResponse.getResponseMessage();
				log.info(justpayResponse, respCode, respMsg, udirComplaintStatusResponse);
				if (udirComplaintStatusResponse.getPayload() != null
						&& UpiStatusConstants.SUCCESS.getStatusMsg().equals(udirComplaintStatusResponse.getStatus())) {
					return udirComplaintStatusResponse;
				}
			} else {
				udirComplaintStatusResponse = null;
			}

		} catch (Exception e) {
			log.debug("Error occurred in checkComplaint Account: {}", e);
			udirComplaintStatusResponse = null;
		}
		return udirComplaintStatusResponse;
	}

	@Override
	public UdirComplaintsListResponse listComplaint(String programId, String accountNumber,
			CheckUdirComplaints checkUdirComplaints) {
		log.debug("JuspayServiceAdapterImpl : listComplaint :{}", checkUdirComplaints);
		UdirComplaintsListResponse udirComplaintsListResponse = new UdirComplaintsListResponse();

		String baseUrl = progParamDao.fetchParamValueByParamName(programId,
				ProgramParamConstants.JUSPAY_BASE_URL.getValue());
		String jusPayUrl = baseUrl + udirListAllComplaints;
		log.info(CONCATENATED_URL, jusPayUrl);

		try {
			String merchantId = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.MERCHANT_ID.getValue());
			String merchantChannelId = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.MERCHANT_CHANNEL_ID.getValue());
			String privateKey = progParamDao.fetchParamValueByParamName(programId,
					ProgramParamConstants.PRIVATE_KEY.getValue());

			// headers
			MultiValueMap<String, String> customHeaders = new LinkedMultiValueMap<>();
			String timestamp = String.valueOf(new Date().getTime());
			customHeaders = juspayHeadersCreation(customHeaders, merchantId, merchantChannelId, timestamp);
			JuspayUdirListAllComplaintsRequest juspayUdirListAllComplaintsRequest = new JuspayUdirListAllComplaintsRequest();
			juspayUdirListAllComplaintsRequest.setMerchantCustomerId(accountNumber);
			juspayUdirListAllComplaintsRequest.setStartDate(checkUdirComplaints.getFromDate());
			juspayUdirListAllComplaintsRequest.setLimit(checkUdirComplaints.getLimit());
			juspayUdirListAllComplaintsRequest.setOffSet(checkUdirComplaints.getOffset());
			juspayUdirListAllComplaintsRequest.setUdfParameters("{}");

			ObjectMapper obj = new ObjectMapper();
			String reqJson = obj.writeValueAsString(juspayUdirListAllComplaintsRequest);
			String input = merchantId + merchantChannelId + timestamp + reqJson;
			String signature = signUtil.calculateSignature(input, privateKey);
			customHeaders.add(Constants.X_MERCHANT_SIGNATURE, signature);
			HttpEntity<String> httpEntity = new HttpEntity<>(reqJson, customHeaders);

			log.info("{} ", juspayUdirListAllComplaintsRequest);
			log.info(sendingRequestJustpay, jusPayUrl);
			ResponseEntity<UdirComplaintsListResponse> result = null;
			result = restTemplate.exchange(jusPayUrl, HttpMethod.POST, httpEntity, UdirComplaintsListResponse.class);
			udirComplaintsListResponse = result.getBody();
			if (udirComplaintsListResponse != null) {
				String respCode = udirComplaintsListResponse.getResponseCode();
				String respMsg = udirComplaintsListResponse.getResponseMessage();
				log.info(justpayResponse, respCode, respMsg, udirComplaintsListResponse);
				if (udirComplaintsListResponse.getPayload() != null
						&& UpiStatusConstants.SUCCESS.getStatusMsg().equals(udirComplaintsListResponse.getStatus())) {
					return udirComplaintsListResponse;
				}
			} else {
				udirComplaintsListResponse = null;
			}

		} catch (Exception e) {
			log.debug("Error occurred in listAllComplaint Account: {}", e);
			udirComplaintsListResponse = null;
		}
		return udirComplaintsListResponse;
	}

	/**
	 * save Data into Upi de-register Cust info tbl
	 * 
	 * @param vpaDetails
	 * @param map
	 */
	private void saveDataInDeregisterCustInfo(List<VPADetails> vpaDetails, Map<Long, VPALinkedAccount> map) {
		StringBuilder aliasVpa = new StringBuilder();
		String delimiter = "";
		if (vpaDetails != null && !vpaDetails.isEmpty()) {
			for (VPADetails vpaRow : vpaDetails) {
				if (vpaRow != null) {
					UpiDeregisteredCustInfo row = new UpiDeregisteredCustInfo();
					row.setAccountNumber(vpaRow.getAccountNumber());
					row.setMobileNumber(vpaRow.getMobileNumber());
					row.setUpiCustomerId(vpaRow.getUpiCustomerId());
					row.setDeviceId(vpaRow.getDeviceId());
					row.setSsid(vpaRow.getSsid());
					row.setDeviceFingerprint(vpaRow.getDeviceFingerprint());
					row.setVpa(vpaRow.getVpa());
					if (vpaRow.getIsPrimaryVpa().booleanValue()) {
						aliasVpa.append(delimiter);
						delimiter = ",";
						aliasVpa.append(vpaRow.getVpa());
					}
					row.setAliasVpa(aliasVpa.toString());
					row.setLinkedAccountId(vpaRow.getLinkedAccountId());
					row.setStatus(vpaRow.getStatus());
					row.setActive(vpaRow.getActive());
					row.setWalletId(vpaRow.getWalletId());
					// fetch vpa linked account table details
					VPALinkedAccount vpaLinkedRow = map.get(vpaRow.getLinkedAccountId());
					setUpiDeregisteredCustInfo(vpaRow, row, vpaLinkedRow);
					upiDeregisterCustInfoDAO.saveDetail(row);
					log.debug("UpiDeregisteredCustInfo insertion done");
				}
			}
		}
	}

	private static void setUpiDeregisteredCustInfo(VPADetails vpaRow, UpiDeregisteredCustInfo row,
			VPALinkedAccount vpaLinkedRow) {
		if (vpaLinkedRow != null) {
			row.setBankName(vpaLinkedRow.getBankName());
			row.setBankAccountNumber(vpaLinkedRow.getBankAccountNumber());
			row.setBankIfsc(vpaLinkedRow.getBankIfsc());
			row.setBankCode(vpaLinkedRow.getBankCode());
			row.setType(vpaLinkedRow.getType());
			row.setBankAccUniqueId(vpaLinkedRow.getBankAccUniqueId());
		} else {
			row.setBankAccountNumber(String.valueOf(vpaRow.getAccountNumber()));
			row.setBankIfsc("");
			row.setBankCode("");
			row.setType("");
		}
	}

	private void deleteCustomerVpaDetails(List<Long> ids, Set<VPALinkedAccount> vpaLinkedAccounts) {
		// delete vpa details
		List<Long> vpaLinkedAccountIds = new ArrayList<>();
		if (ids != null && !ids.isEmpty()) {
			vpaDetailsDAO.deleteVpaDetails(ids);
			log.debug("Vpa details deletion done");
		}
		// delete vpa linked account
		if (vpaLinkedAccounts != null && !vpaLinkedAccounts.isEmpty()) {
			vpaLinkedAccountIds = vpaLinkedAccounts.stream().filter(Objects::nonNull).map(VPALinkedAccount::getId)
					.collect(Collectors.toList());
		}
		if (vpaLinkedAccountIds != null && !vpaLinkedAccountIds.isEmpty()) {
			vpaLinkedAccountDAO.deleteVpaLinkedAccount(vpaLinkedAccountIds);
			log.debug("vpaLinkedAccount deletion done");
		}
	}

	private String impliedDecimalTo(String amount) {
		long lAmount = Long.parseLong(amount);
		double dAmount = (double) lAmount / 100;
		return String.format("%.2f", dAmount);
	}

	private void savingVpaDetailsOnSuccessMsg(String accountNumber, AddVpaRequest request, VPADetails vpaDetailsRow,
			AddVpaResponse response) {
		if (UpiStatusConstants.SUCCESS.getStatusMsg().equals(response.getStatus())) {
			saveVpaDetailsInDBFromAddVpa(response, request, accountNumber, vpaDetailsRow);
		}
	}

	private void setUdfParameters(DeregisterCustomerRequest request,
			JuspayDeregisterCustomerRequest juspayDeregisterCustomerRequest) {
		if (request.getUdfParameters() == null || request.getUdfParameters().isEmpty())
			juspayDeregisterCustomerRequest.setUdfParameters(new JSONObject().toString());
		else
			juspayDeregisterCustomerRequest.setUdfParameters(request.getUdfParameters());
	}

}
