package com.wibmo.dfs.upi.adapter.juspay.model;


import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayApproveDeclineRequest extends JuspayIncomingOutgoingCommon {

    private String merchantCustomerId;
    private String collectType;
    private String requestType;
    private String merchantId;
    private String isAmountBlocked;

}
