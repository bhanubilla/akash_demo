package com.wibmo.dfs.upi.constants;

public enum ProgramParamConstants {
	
	MERCHANT_ID("MERCHANT_ID"), MERCHANT_CHANNEL_ID("MERCHANT_CHANNEL_ID"), UPI_VENDOR("UPI_VENDOR"), JUSPAY_UPI_VENDOR("JUSPAY"), X_MERCHANT_ID("X-MERCHANT-ID"), X_MERCHANT_CHANNEL_ID("X-MERCHANT-CHANNEL-ID"), PRIVATE_KEY("private_key"), VPA_ADDRESS_PAYU("@payu"),COLLECT_REQ_EXP_MINUTES("COLLECT_REQ_EXP_MINUTES"),MAX_COUNT_EXCEEDED("MAX_COUNT_EXCEEDED"),MAX_NUMBER_OF_VPA("MAX_NUMBER_OF_VPA"), UPI_REQUEST_ID_PREFIX("UPI_REQUEST_ID_PREFIX"), AGENT_NAME("AGENT_NAME"), JUSPAY_BASE_URL("JUSPAY_BASE_URL");
	
	private String value;
	 
	ProgramParamConstants(String value) {
        this.value = value;
    }
 
    public String getValue() {
        return value;
    }
	
}
