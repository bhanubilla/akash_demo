package com.wibmo.dfs.upi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserProfileResponse {

	private static final long serialVersionUID = 1L;
	private String firstName;
	private String middleName;
	private String lastName;
	private String mobile;
	private String email;
	private int accountNumber;
	private String fcmId;
	private String deviceId;
	private String dob; // YYYY-MM-DD

}
