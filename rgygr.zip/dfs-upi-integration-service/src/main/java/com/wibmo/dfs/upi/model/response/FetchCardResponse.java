package com.wibmo.dfs.upi.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.wibmo.dfs.upi.model.CardDetails;
import com.wibmo.dfs.upi.model.ServiceTypes;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FetchCardResponse extends CardDetails {
    private long balance;
    private String walletStatus;
    private String productType;
    private List<ServiceTypes> txnProfile;
}
