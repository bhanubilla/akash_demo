package com.wibmo.dfs.upi.model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApproveDeclineTransaction {
    private String payerVpa;
    private String payeeVpa;
    private String payeeName;
    private String isVerifiedPayee;
    private String isMarkedSpam;
    private String amount;
    private String payeeMcc;
    private String transactionTimestamp;
    private String gatewayTransactionId;
    private String gatewayReferenceId;
    private String remarks;
    private String expiry;
    private String refUrl;
    private String refCategory;
    private String collectType;
    private String seqNumber;
}
