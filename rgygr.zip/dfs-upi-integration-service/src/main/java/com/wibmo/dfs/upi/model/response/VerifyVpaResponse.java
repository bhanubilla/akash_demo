package com.wibmo.dfs.upi.model.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayVerifyVpaResponsePayload;
import com.wibmo.dfs.upi.model.MerchantType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VerifyVpaResponse extends JuspayVerifyVpaResponsePayload {

    @JsonIgnore
    private String customGatewayStatusCode;
    private int wibmoRespCode;
    private String wibmoResDesc;
    private String wibmoErrorMessage;

}
