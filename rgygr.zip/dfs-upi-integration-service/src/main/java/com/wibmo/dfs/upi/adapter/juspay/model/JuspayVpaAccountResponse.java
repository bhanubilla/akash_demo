package com.wibmo.dfs.upi.adapter.juspay.model;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayVpaAccountResponse implements Serializable {
	private static final long serialVersionUID = 1L;
	private JuspayVpaAccount account;
	private String vpa;
	private String isDefault;
}
