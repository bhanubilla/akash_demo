package com.wibmo.dfs.upi.adapter.juspay.service.impl;

import com.wibmo.dfs.upi.adapter.juspay.model.JuspaySendMoneyRequest;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspaySendMoneyResponse;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspaySendMoneyResponsePayload;
import com.wibmo.dfs.upi.dao.VPADetailsDAO;
import com.wibmo.dfs.upi.dao.VPALinkedAccountDAO;
import com.wibmo.dfs.upi.helper.CommonHelper;
import com.wibmo.dfs.upi.model.VPADetails;
import com.wibmo.dfs.upi.model.VPALinkedAccount;
import com.wibmo.dfs.upi.service.UpiServiceCallbacks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MockResponse {
    public static final String SINGLE_QUOTE_WITH_COMMA = "\",";
    public static final String DOUBLE_QUOTE_WITH_COMMA = "\"\",";
    @Autowired
    public UpiServiceCallbacks callbacks;
    @Autowired
    public VPADetailsDAO vpaDetailsDAO;
    @Autowired
    public VPALinkedAccountDAO vpaLinkedAccountDAO;

    public JuspaySendMoneyResponse mockSendResponse(JuspaySendMoneyRequest juspaySendMoneyRequest){
        JuspaySendMoneyResponse response = new JuspaySendMoneyResponse();
        String payeeAccNumber = null;
        StringBuilder cbsreq = new StringBuilder("{");
        if(juspaySendMoneyRequest.getPayeeVpa().contains(".ifsc.npci")){
            payeeAccNumber = juspaySendMoneyRequest.getPayeeVpa().substring(0,juspaySendMoneyRequest.getPayeeVpa().indexOf('@'));

            cbsreq.append("\"gatewayTransactionId\":")
                    .append("\""+juspaySendMoneyRequest.getUpiRequestId()+ SINGLE_QUOTE_WITH_COMMA)
                    .append("\"accountIdentifier\":")
                    .append("\""+payeeAccNumber+ SINGLE_QUOTE_WITH_COMMA)
                    .append("\"gatewayReferenceId\":").append(DOUBLE_QUOTE_WITH_COMMA)
                    .append("\"type\":").append(DOUBLE_QUOTE_WITH_COMMA)
                    .append("\"complaintUpiRequestId\":").append(DOUBLE_QUOTE_WITH_COMMA)
                    .append("\"amount\":")
                    .append("\""+juspaySendMoneyRequest.getAmount()+"\"}");
        }else{
            VPADetails payeeVpaDetails = vpaDetailsDAO.findByVpa(juspaySendMoneyRequest.getPayeeVpa());
            VPALinkedAccount payeeVpaLinkedDetails = vpaLinkedAccountDAO.findByAccountNumber(payeeVpaDetails.getAccountNumber());
            cbsreq.append("\"gatewayTransactionId\":")
                    .append("\""+juspaySendMoneyRequest.getUpiRequestId()+ SINGLE_QUOTE_WITH_COMMA)
                    .append("\"accountIdentifier\":")
                    .append("\""+payeeVpaLinkedDetails.getBankAccountNumber()+ SINGLE_QUOTE_WITH_COMMA)
                    .append("\"gatewayReferenceId\":").append(DOUBLE_QUOTE_WITH_COMMA)
                    .append("\"type\":").append(DOUBLE_QUOTE_WITH_COMMA)
                    .append("\"complaintUpiRequestId\":").append(DOUBLE_QUOTE_WITH_COMMA)
                    .append("\"amount\":")
                    .append("\""+juspaySendMoneyRequest.getAmount()+"\"}");
        }


        callbacks.creditMoneyCBSCallback("2001",cbsreq.toString());
        response.setResponseCode("00");
        response.setResponseMessage("SUCCESS");
        response.setUdfParameters("{}");
        JuspaySendMoneyResponsePayload responsePayload = new JuspaySendMoneyResponsePayload();
        responsePayload.setAmount(juspaySendMoneyRequest.getAmount());
        responsePayload.setGatewayResponseCode("01");
        responsePayload.setGatewayResponseMessage("PENDING");
        responsePayload.setGatewayResponseStatus("PENDING");
        responsePayload.setBankCode("");
        responsePayload.setBankAccountUniqueId("");
        responsePayload.setCustomerMobileNumber("");
        responsePayload.setGatewayTransactionId(juspaySendMoneyRequest.getUpiRequestId());
        responsePayload.setTransactionTimestamp(CommonHelper.juspayExpectedDate());
        responsePayload.setPayeeName(juspaySendMoneyRequest.getPayeeName());
        responsePayload.setPayeeVpa(juspaySendMoneyRequest.getPayeeVpa());
        responsePayload.setPayerVpa(juspaySendMoneyRequest.getPayerVpa());
        responsePayload.setGatewayTransactionId(juspaySendMoneyRequest.getUpiRequestId());
        responsePayload.setTransactionType(juspaySendMoneyRequest.getTransactionType());

        response.setPayload(responsePayload);
        return response;
    }
}
