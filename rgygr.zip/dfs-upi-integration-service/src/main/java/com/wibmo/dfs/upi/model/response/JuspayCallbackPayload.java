package com.wibmo.dfs.upi.model.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class JuspayCallbackPayload {
    private String cbsStatus;
    private String cbsResponseCode;
    private String amount;
    private String gatewayTransactionId;
    private String gatewayReferenceId;
    private String accountIdentifier;
    private String cbsReferenceId;
    private String updatedAt;
    private String remarks;
}
