package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayDeleteVpaResponse {
    private String status;
    private String responseCode;
    private String responseMessage;
    private JuspayDeleteVpaPayload payload;
    private String udfParameters;
}
