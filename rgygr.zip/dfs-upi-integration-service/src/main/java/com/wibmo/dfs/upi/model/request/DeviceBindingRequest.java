package com.wibmo.dfs.upi.model.request;

import java.math.BigInteger;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DeviceBindingRequest {

	private BigInteger refNumber;
	private String mobileNumber;
	private String packageName;
	private String udfParameters;
	private DeviceParams deviceParams;
	
}
