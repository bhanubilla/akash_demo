package com.wibmo.dfs.upi.model.request;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class RaiseUdirComplaintRequest {

    private String disputeType;
    private String reasonCode;
    private String txnId;
    private String remarks;
    private String billerId;
    private String complaintType;
    private String isMerchantTxn;

}
