package com.wibmo.dfs.upi.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class VpaDetails {

	private int accountNmber;
	private int walletId;

}
