package com.wibmo.dfs.upi.dao.impl;

import com.wibmo.dfs.upi.constants.Constants;
import com.wibmo.dfs.upi.dao.VPADetailsDAO;
import com.wibmo.dfs.upi.model.VPADetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.*;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Repository
@Slf4j
public class VPADetailsDAOImpl implements VPADetailsDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private static final String SAVE_VPA_DETAILS_INFO = "INSERT INTO VPA_DETAILS (ACCOUNT_NUMBER, MOBILE_NUMBER, UPI_CUSTOMER_ID, DEVICE_ID, SSID, DEVICE_FINGERPRINT, VPA, IS_PRIMARY_VPA, LINKED_ACCOUNT_ID, STATUS, ACTIVE, WALLET_ID)"
            + " VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";

    private static final String SELECT_VPA_DETAILS_INFO = "SELECT * FROM vpa_details where account_number = ?";

    private static final String UPDATE_ACTIVE_COLUMN = "UPDATE vpa_details set active = ? where id = ?";
    
    private static final String UPDATE_VPA_DETAILS = "UPDATE VPA_DETAILS SET SSID = ?, DEVICE_FINGERPRINT =?, DEVICE_ID =? WHERE id = ?";

    private static final String FETCH_VPA_REG_LOG_DETAILS = "SELECT * FROM VPA_DETAILS VD, VPA_REGISTRATION_LOG VRL WHERE VRL.ID=? AND VD.ACCOUNT_NUMBER=VRL.ACCOUNT_NUMBER AND VD.UPI_CUSTOMER_ID=VRL.MERCHANT_CUSTOMER_ID AND VD.MOBILE_NUMBER=VRL.MOBILE_NUMBER";

    private static final String SELECT_VPA_DETAILS_ACTIVE_INFO = "SELECT * FROM vpa_details where account_number = ? and active=1";

    private static final String SELECT_VPA_DETAILS_BY_VPA = "SELECT * FROM vpa_details where vpa = ?";
    
    private static final String SELECT_VPA_DETAILS_WHERE_ACCOUNT_NUMBER = "SELECT * FROM vpa_details where account_number = ?";
    
    private static final String UPI_CUSTOMER_ID = "UPI_CUSTOMER_ID";
    private static final String MOBILE_NUMBER="MOBILE_NUMBER";
    private static final String DEVICE_ID = "DEVICE_ID";
    private static final String SSID= "SSID";
    private static final String DEVICE_FINGERPRINT = "DEVICE_FINGERPRINT";
    private static final String LINKED_ACCOUNT_ID = "LINKED_ACCOUNT_ID";
    private static final String VPA = "vpa";
    public static final String EXCEPTION_MSG_FETCHING_VPA_DETAILS = "Exception while getting findByAccountNumber :: {}";
    public static final String EXCEPTION_MSG_UPDATE_VPA_DETAILS_BY_ID = "Error occurred in VPADetailsDAOImpl : updateVpaDetails {}";
    public static final String EXCEPTION_MSG_UPDATING_VPA_DETAILS = "Error occurred in VPADetailsDAOImpl : updateVpaDetails {}";
    public static final String EXCEPTION_MSG_DELETING_VPA_DETAILS = "Error occurred in VPADetailsDAOImpl : deleteVpaDetails {}";
    
    @Override
    public VPADetails findByAccountNumber(Long accountNumber) {

        VPADetails row = new VPADetails();
        try {
            return jdbcTemplate.query(SELECT_VPA_DETAILS_WHERE_ACCOUNT_NUMBER, new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setLong(1, accountNumber);
                }
            }, new ResultSetExtractor<VPADetails>() {
                @Override
                public VPADetails extractData(ResultSet rs) throws SQLException {
                    if (rs.next()) {
                        row.setId(rs.getLong(Constants.ID));
                        row.setAccountNumber(rs.getLong(Constants.ACCOUNT_NUMBER));
                        row.setVpa(rs.getString("vpa"));
                        row.setUpiCustomerId(rs.getLong(UPI_CUSTOMER_ID));
                        row.setMobileNumber(rs.getString(MOBILE_NUMBER));
                        row.setDeviceId(rs.getString(DEVICE_ID));
                        row.setSsid(rs.getString(SSID));
                        row.setDeviceFingerprint(rs.getString(DEVICE_FINGERPRINT));
                        row.setLinkedAccountId(rs.getLong(LINKED_ACCOUNT_ID));
                        return row;
                    } else {
                        return row;
                    }
                }
            });
        } catch (Exception exception) {
            log.error(EXCEPTION_MSG_FETCHING_VPA_DETAILS, exception);
        }
        return row;
    }

    @Override
    public void saveVpaDetails(VPADetails vpaDetails) {
        String sql = SAVE_VPA_DETAILS_INFO;
        try {
            jdbcTemplate.update(sql, vpaDetails.getAccountNumber(), vpaDetails.getMobileNumber(),
                    vpaDetails.getUpiCustomerId(), vpaDetails.getDeviceId(), vpaDetails.getSsid(),
                    vpaDetails.getDeviceFingerprint(), vpaDetails.getVpa(), vpaDetails.getIsPrimaryVpa(),
                    vpaDetails.getLinkedAccountId(), vpaDetails.getStatus(), vpaDetails.getActive(), vpaDetails.getWalletId());
        } catch (DataAccessException e) {
            log.error("Error occurred in VPADetailsDAOImpl : saveVpaDetails {}", e.getMessage());
        }
    }

    @Override
    public VPADetails findByUpiCustomerId(Long upiCustomerId) {
        VPADetails row = new VPADetails();
        try {
            return jdbcTemplate.query("SELECT * FROM vpa_details where upi_customer_id = ?", new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setLong(1, upiCustomerId);
                }
            }, new ResultSetExtractor<VPADetails>() {
                @Override
                public VPADetails extractData(ResultSet rs) throws SQLException {
                    if (rs.next()) {
                        row.setId(rs.getLong(Constants.ID));
                        row.setAccountNumber(rs.getLong(Constants.ACCOUNT_NUMBER));
                        row.setVpa(rs.getString(VPA));
                        row.setUpiCustomerId(rs.getLong(UPI_CUSTOMER_ID));
                        row.setMobileNumber(rs.getString(MOBILE_NUMBER));
                        row.setDeviceId(rs.getString(DEVICE_ID));
                        row.setSsid(rs.getString(SSID));
                        row.setDeviceFingerprint(rs.getString(DEVICE_FINGERPRINT));
                        row.setLinkedAccountId(rs.getLong(LINKED_ACCOUNT_ID));
                        return row;
                    } else {
                        return null;
                    }
                }
            });
        } catch (Exception exception) {
            log.error("Exception while getting vpa details :: {}", exception);
        }
        return null;
    }

    @Override
    public List<VPADetails> findVpaByAccountNumber(Long accountNumber) {
        List<VPADetails> vpaNames = new ArrayList<>();
        try {
            BeanPropertyRowMapper<VPADetails> rowMapper = BeanPropertyRowMapper.newInstance(VPADetails.class);
            vpaNames =  jdbcTemplate.query(SELECT_VPA_DETAILS_INFO, new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setLong(1, accountNumber);
                }
            }, rowMapper);
        } catch (Exception e) {
            log.error("Exception while getting findVpas details :: {}", e);
        }
        return vpaNames;
    }

    @Override
    public void updateVpaDetails(VPADetails vpaDetails){
        String sql = UPDATE_ACTIVE_COLUMN;
        try {
            jdbcTemplate.update(sql, vpaDetails.getActive(), vpaDetails.getId());
        } catch (DataAccessException e) {
            log.error(EXCEPTION_MSG_UPDATING_VPA_DETAILS, e.getMessage());
        }
    }

    @Override
    public void deleteVpaDetails(List<Long> ids) {
        String params = ids.toString().substring(1,ids.toString().length()-1);
        StringBuilder sql = new StringBuilder("DELETE from vpa_details where id in ("+params+")");
        try {
            jdbcTemplate.update(sql.toString());
        } catch (DataAccessException e) {
            log.error(EXCEPTION_MSG_DELETING_VPA_DETAILS, e.getMessage());
        }
    }

	@Override
	public void updateVpaDetails(String ssid, String deviceFingerPrint, String deviceId, Long refId) {

		try {
		    jdbcTemplate.update(UPDATE_VPA_DETAILS, ssid, deviceFingerPrint, deviceId, refId);
		} catch (DataAccessException e) {
		    log.error(EXCEPTION_MSG_UPDATE_VPA_DETAILS_BY_ID, e.getMessage());
		}
	}

    @Override
    public VPADetails fetchVpaDetailsInfoByAccnoAndMobileAndMerchantcustid(BigInteger refId) {
        VPADetails row = new VPADetails();
        try {
            jdbcTemplate.query(FETCH_VPA_REG_LOG_DETAILS, new PreparedStatementSetter() {

                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setString(1, refId.toString());
                }
            }, new ResultSetExtractor<VPADetails>() {

                @Override
                public VPADetails extractData(ResultSet rs) throws SQLException {
                    if (rs.next()) {
                        row.setId(rs.getLong(Constants.ID));
                        row.setAccountNumber(rs.getLong(Constants.ACCOUNT_NUMBER));
                        row.setVpa(rs.getString(VPA));
                        row.setUpiCustomerId(rs.getLong(UPI_CUSTOMER_ID));
                        row.setMobileNumber(rs.getString(MOBILE_NUMBER));
                        row.setDeviceId(rs.getString(DEVICE_ID));
                        row.setSsid(rs.getString(SSID));
                        row.setDeviceFingerprint(rs.getString(DEVICE_FINGERPRINT));
                        row.setLinkedAccountId(rs.getLong(LINKED_ACCOUNT_ID));
                    } else {
                        return null;
                    }
                    return row;
                }
            });

        } catch(DataAccessException e) {
            log.error("error in fetchVpaRegInfoByAccnoAndMobileAndMerchantcustid ", e);
        }
        return row;
    }

    @Override
    public List<VPADetails> findVpaByAccountNumberAndActive(Long accountNumber) {
        List<VPADetails> vpaNames = new ArrayList<>();
        try {
            BeanPropertyRowMapper<VPADetails> rowMapper = BeanPropertyRowMapper.newInstance(VPADetails.class);
            vpaNames =  jdbcTemplate.query(SELECT_VPA_DETAILS_ACTIVE_INFO, new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setLong(1, accountNumber);
                }
            }, rowMapper);
        } catch (Exception e) {
            log.error("Exception while getting findVpaByAccountNumberAndActive details :: {}", e);
        }
        return vpaNames;
    }

    @Override
    public VPADetails findByVpa(String vpa) {

        VPADetails row = new VPADetails();
        try {
            return jdbcTemplate.query(SELECT_VPA_DETAILS_BY_VPA, new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setString(1, vpa);
                }
            }, new ResultSetExtractor<VPADetails>() {
                @Override
                public VPADetails extractData(ResultSet rs) throws SQLException {
                    if (rs.next()) {
                        row.setId(rs.getLong(Constants.ID));
                        row.setAccountNumber(rs.getLong(Constants.ACCOUNT_NUMBER));
                        row.setVpa(rs.getString(Constants.VPA));
                        row.setUpiCustomerId(rs.getLong(UPI_CUSTOMER_ID));
                        row.setMobileNumber(rs.getString(MOBILE_NUMBER));
                        row.setDeviceId(rs.getString(DEVICE_ID));
                        row.setSsid(rs.getString(SSID));
                        row.setDeviceFingerprint(rs.getString(DEVICE_FINGERPRINT));
                        row.setLinkedAccountId(rs.getLong(LINKED_ACCOUNT_ID));
                        return row;
                    } else {
                        return null;
                    }
                }
            });
        } catch (Exception exception) {
            log.error("Exception while getting vpa details :: {}", exception);
        }
        return null;
    }

}
