package com.wibmo.dfs.upi.service;

import com.wibmo.dfs.upi.model.request.BlockedVpaRequest;
import com.wibmo.dfs.upi.model.request.BlockedVpasRequest;
import com.wibmo.dfs.upi.model.response.WibmoResponse;

public interface BlockedVpaService {
    WibmoResponse blockedVpa(String programId,  String accountNumber, BlockedVpaRequest request);
    WibmoResponse unblockedVpa(String accountNumber, BlockedVpaRequest request);
    WibmoResponse blockedVpaList(String accountNumber, BlockedVpasRequest request);
    WibmoResponse fetchAllBlockedVpaList(String programId, String accountNumber);
}
