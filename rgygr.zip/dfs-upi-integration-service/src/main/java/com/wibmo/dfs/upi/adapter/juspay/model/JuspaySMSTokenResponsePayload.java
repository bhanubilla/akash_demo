package com.wibmo.dfs.upi.adapter.juspay.model;

import com.wibmo.dfs.upi.model.ServiceProvider;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class JuspaySMSTokenResponsePayload implements Serializable {
	private String merchantId;
	private String merchantChannelId;
	private String merchantCustomerId;
	private ServiceProvider[] serviceProviders;
	private String smsContent;
	private String expiryTimestamp;
}
