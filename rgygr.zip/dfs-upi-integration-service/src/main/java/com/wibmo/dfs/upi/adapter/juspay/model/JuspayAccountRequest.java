package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayAccountRequest {
	private String accountNumber;
	private String name;
	private String type;
	private String kycStatus;
	
}
