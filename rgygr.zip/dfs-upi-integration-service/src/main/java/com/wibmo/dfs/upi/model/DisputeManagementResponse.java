package com.wibmo.dfs.upi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DisputeManagementResponse {

    private String complaintRefNo;
    private String complaintStatus;
    private String amount;
    private String status;
    private String name;
    private String createdTime;
    private String txnId;
    private String transDesc;
}
