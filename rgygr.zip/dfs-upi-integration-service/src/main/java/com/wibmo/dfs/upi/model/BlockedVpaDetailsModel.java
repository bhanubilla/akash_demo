package com.wibmo.dfs.upi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BlockedVpaDetailsModel {
    private long id;
    private String accountNumber;
    private String vpa;
    private String blockedVpa;
    private String blockedVpaName;
    private Long updatedTs;
    private Long createdTs;
}
