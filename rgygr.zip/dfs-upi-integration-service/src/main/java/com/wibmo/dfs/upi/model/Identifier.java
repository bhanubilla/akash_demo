package com.wibmo.dfs.upi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class Identifier implements Serializable {
    private String subCode;
    private String mid;
    private String sid;
    private String tid;
    private String merchantType;
}

