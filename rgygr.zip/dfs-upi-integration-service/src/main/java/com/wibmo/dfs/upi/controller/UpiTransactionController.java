package com.wibmo.dfs.upi.controller;

import com.wibmo.dfs.upi.constants.UpiStatusConstants;
import com.wibmo.dfs.upi.model.request.RequestMoneyRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wibmo.dfs.upi.model.request.UPITransactionRequest;
import com.wibmo.dfs.upi.model.request.VerifyVpaRequest;
import com.wibmo.dfs.upi.model.response.WibmoResponse;
import com.wibmo.dfs.upi.service.UpiService;
import com.wibmo.dfs.upi.validator.RequestValidator;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/upi/transaction")
@Slf4j
public class UpiTransactionController {
	
	private static final String ERROR_DESC = "Error Desc : {}";
	public static final String ERR_DESC = "Error Occurred {}";

    @Autowired
    private UpiService upiService;
    
    @Autowired
	private RequestValidator validator;
    
    @PostMapping("/v1/verifyVpa")
    public WibmoResponse verifyVpa(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestBody VerifyVpaRequest request) {
        log.info("UpiTransactionController : verify vpa method");
        log.debug("UpiTransactionController : programId : {} - verifyVpaRequest : {}", programId, request);
        
        WibmoResponse response = new WibmoResponse();
  		    validator.validateVerifyVpa(request, response);
  			if (response.getResCode() > 0) {
  				log.info(ERROR_DESC, response.getResDesc());
  				response = new WibmoResponse(response.getResCode(), response.getResDesc());
  			} else {
  				response = upiService.verifyVpa(programId, request);
  			}
        return response;
    }

    @PostMapping("/v1/sendMoney")
    public WibmoResponse sendMoney(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber, @RequestBody UPITransactionRequest request) {
    	log.info("UpiTransactionController : sendMoney API");
    	log.debug("UpiTransactionController - programId : {} - accountNumber : {} - sendMoneyRequest : {}", programId, accountNumber, request);
    	return upiService.sendMoney(programId, accountNumber, request);
    }

    @PostMapping("/v1/requestMoney")
    public WibmoResponse requestMoney(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber, @RequestBody RequestMoneyRequest request) {
        log.info("requestMoney called fro account number :: {}, programId :: {}",accountNumber,programId);
        return upiService.requestMoney(programId, accountNumber, request);
    }

    @PostMapping("/v1/listPendingCollectRequests")
    public WibmoResponse listPendingCollectRequests(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber) {
        log.info("pending collect requests for account number :: {}, program id :: {}",accountNumber, programId);
        return upiService.listPendingCollectRequests(programId, accountNumber);
    }

}
