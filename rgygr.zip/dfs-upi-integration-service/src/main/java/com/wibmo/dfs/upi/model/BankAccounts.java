package com.wibmo.dfs.upi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BankAccounts  implements Serializable {
    private static final long serialVersionUID = 1L;

    private String bankAcId;
    private String customerId;
    private String accountNo;
    private String accountName;
    private String ifscCode;
    private String bankName;
    private String accountType;
    private String vpa;
    private String nickName;
    private int pinGenerated;
    private String branch;
    private int primaryAccount;
    private String customerName;
}
