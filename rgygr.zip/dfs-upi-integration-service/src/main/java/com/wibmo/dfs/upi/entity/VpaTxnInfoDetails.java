package com.wibmo.dfs.upi.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class VpaTxnInfoDetails {

	private String status;
	private String merchantCustomerId;
	private String amount;
	private String txnType;
	private String payerVpa;
	private String payeeVpa;
	private String message;

}
