package com.wibmo.dfs.upi.model.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class VpaValidRequest {
	@ApiModelProperty(dataType="String", required=true)
	private String vpa;
	private String udfParameters;
}
