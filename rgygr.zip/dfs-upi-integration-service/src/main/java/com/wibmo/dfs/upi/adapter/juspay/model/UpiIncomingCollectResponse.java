package com.wibmo.dfs.upi.adapter.juspay.model;

import com.wibmo.dfs.upi.entity.TrackingTxnStatus;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
    public class UpiIncomingCollectResponse {
    private String txnId;
    private String payerVpa;
    private String payeeVpa;
    private String payeeName;
    private String txnMode;
    private String txnAmount;
    private String approvalStatus;
    private String txnDesc;
    private int wibmoRespCode;
    private String wibmoResDesc;
    private String wibmoErrorMessage;
    private String currency;
    private String walletId;
    private long txnDate;
    private String remarks;
    private List<TrackingTxnStatus> trackingTxnStatus;
}
