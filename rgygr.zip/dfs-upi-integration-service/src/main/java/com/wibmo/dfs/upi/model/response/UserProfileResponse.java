package com.wibmo.dfs.upi.model.response;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserProfileResponse {
    private int accountNumber;
    private String firstName;
    private String middleName;
    private String lastName;
    private String gender;
    private int allowEdit;
    private String mobile;
    private String emailId;
    private String preferredLanguage;
    private int kycLevel;
    private String kycName;
    private String kycDisplayName;
    private String age;
    private String dob;
    private String walletStatus;
    private String walletCreated;
    private String vpa;
}
