package com.wibmo.dfs.upi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class Name implements Serializable {
    private String brand;
    private String legal;
    private String franchise;
}

