package com.wibmo.dfs.upi.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayCallbackStatusCodes {
    private String code;
    private String status;
    private String description;
    private String terminalState;
}
