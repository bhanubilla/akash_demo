package com.wibmo.dfs.upi.adapter.juspay.model;

import com.wibmo.dfs.upi.dao.VPADetailsDAO;
import com.wibmo.dfs.upi.dao.VPALinkedAccountDAO;
import com.wibmo.dfs.upi.model.VPADetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



@Component
public class JuspayDeclineDeviceBindingRequestMapper {

    @Autowired
    private VPADetailsDAO vpaDetailsDAO;

    @Autowired
    private VPALinkedAccountDAO vpaLinkedAccountDAO;

    public JuspayApproveDeclineRequest map(String accountNumber) {
        JuspayApproveDeclineRequest req = new JuspayApproveDeclineRequest();
        VPADetails vpaDetails = vpaDetailsDAO.findByAccountNumber(Long.parseLong(accountNumber));
        req.setMerchantCustomerId(String.valueOf(vpaDetails.getUpiCustomerId()));
        req.setDeviceFingerPrint(vpaDetails.getDeviceFingerprint());
        return req;
    }
}
