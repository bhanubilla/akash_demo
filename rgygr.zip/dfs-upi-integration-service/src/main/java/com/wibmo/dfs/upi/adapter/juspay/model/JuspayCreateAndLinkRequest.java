package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class JuspayCreateAndLinkRequest {
	private String merchantCustomerId;
	private String customerVpa;
	private JuspayAccountRequest account;
	private String setAsDefaultBank;
	private String udfParameters;

}
