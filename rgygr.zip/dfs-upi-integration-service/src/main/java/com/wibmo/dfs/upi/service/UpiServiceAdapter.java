package com.wibmo.dfs.upi.service;


import com.wibmo.dfs.upi.adapter.juspay.model.UpiIncomingCollectResponse;
import com.wibmo.dfs.upi.exception.UnAuthorizedException;
import com.wibmo.dfs.upi.exception.UpiGenericException;
import com.wibmo.dfs.upi.model.CheckUdirComplaintStatus;
import com.wibmo.dfs.upi.model.CheckUdirComplaints;
import com.wibmo.dfs.upi.model.MerchantDetails;
import com.wibmo.dfs.upi.model.VPADetails;
import com.wibmo.dfs.upi.model.request.*;
import com.wibmo.dfs.upi.model.response.*;
import com.wibmo.dfs.upi.model.response.AddVpaResponse;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;

@Component
public interface UpiServiceAdapter {
	String getVendorId(String programId);

	VpaValidResponse isVpaAvailable(String programId, String accountNum, VpaValidRequest request, MerchantDetails merDetails, String privateKey)
			throws UnAuthorizedException, UpiGenericException, IOException;

	SmsTokenResponse getSmsToken(String programId, String accountNum, SmsTokenRequest request,
			MerchantDetails merDetails, String privateKey) throws UnAuthorizedException, IOException;

	DeviceBindingResponse deviceBinding(String programId, String accountNumber, DeviceBindingRequest request, MerchantDetails merDetails, String privateKey)
			throws UpiGenericException, IOException;

	DeclineDeviceBindingResponse declineDeviceBinding(String programId, String accountNumber,
                                                      ApproveDeclineRequest request) throws UpiGenericException, IOException;

	CreateWalletAndLinkResponse createAndLink(String programId, String accountNumber,
			CreateWalletAndLinkRequest request) throws UpiGenericException, IOException;

	DeviceBindingCallbackResponse handleDeviceBindingCallback(String programId, String request);

	VerifyVpaResponse verifyVpa(String programId, VerifyVpaRequest request)
			throws UpiGenericException, IOException;

	UpiIncomingCollectResponse incomingRequest(String programId, String accountNumber, UpiIncomingCollectRequest request );

	SendMoneyResponse sendMoney(String programId, String accountNumber, UPITransactionRequest req,
			MerchantDetails merDetails, String privateKey) throws UnAuthorizedException, IOException;

	RequestMoneyResponse requestMoney(String programId, String accountNumber, RequestMoneyRequest request) throws IOException;

	TransactionStatusCallbackResponse handleTransactionStatusCallback(String programId, String request);

	AddVpaResponse addVpaAccount(String programId, String accountNumber, AddVpaRequest request, VPADetails vpaDetails) throws IOException;

	DeleteVpaResponse deleteVpaAccount(String programId, String accountNumber, DeleteVpaRequest request, List<VPADetails> vpaDetails, String customerPrimaryVpa);

    DeregisterCustomerResponse deRegisterCustomer(String programId, String accountNumber, DeregisterCustomerRequest request);

	RaiseUdirComplaintResponse raiseComplaint(String programId, String accountNum, RaiseUdirComplaintRequest raiseUdirComplaintRequest);

	UdirComplaintStatusResponse checkComplaint(String programId, String accountNum, CheckUdirComplaintStatus checkUdirComplaintStatus);
	UdirComplaintsListResponse listComplaint(String programId, String accountNum, CheckUdirComplaints checkUdirComplaints);

}
