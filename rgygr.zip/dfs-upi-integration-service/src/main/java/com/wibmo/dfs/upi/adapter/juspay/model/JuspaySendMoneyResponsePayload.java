package com.wibmo.dfs.upi.adapter.juspay.model;

import com.wibmo.dfs.upi.model.response.JuspaySendMoneyResponseCommon;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class JuspaySendMoneyResponsePayload extends JuspaySendMoneyResponseCommon {

	private String gatewayPayerResponseCode;
	private String gatewayPayeeResponseCode;
	private String gatewayPayerReversalResponseCode;
	private String gatewayPayeeReversalResponseCode;
}
