package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayAddVpaAccounts {
    private JuspayAccount account;
    private String vpa;
    private String isDefault;
}
