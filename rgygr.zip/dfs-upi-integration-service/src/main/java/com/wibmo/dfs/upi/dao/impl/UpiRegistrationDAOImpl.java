package com.wibmo.dfs.upi.dao.impl;

import java.math.BigInteger;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.wibmo.dfs.upi.constants.RegistrationConstants;
import com.wibmo.dfs.upi.dao.UpiRegistrationDAO;
import com.wibmo.dfs.upi.entity.VpaBasicDetails;
import com.wibmo.dfs.upi.entity.VpaDetails;
import com.wibmo.dfs.upi.entity.VpaTxnInfoDetails;
import com.wibmo.dfs.upi.exception.InternalServerException;
import com.wibmo.dfs.upi.model.VpaRegistrationAudit;
import com.wibmo.dfs.upi.model.request.DeviceBindingRequest;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class UpiRegistrationDAOImpl implements UpiRegistrationDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public static final String QUERY_FETCH_VPA_BASIC_DETAILS = "SELECT ssid, device_id, vpa, is_primary_vpa from vpa_details where account_number=? and active=true;";
	
	private static final String SAVE_VPA_REGISTRATION_INFO = "INSERT INTO VPA_REGISTRATION_LOG (ACCOUNT_NUMBER, MOBILE_NUMBER, WALLET_URN, MERCHANT_CUSTOMER_ID, SMS_TOKEN, DEVICE_FINGERPRINT, DEVICE_ID, SSID, STATUS)"
			+ " VALUES (?, ?, ?, ? ,?, ?, ?, ?, ?)";
	
	private static final String FETCH_VPA_REG_INFO_BY_REF_ID = "SELECT * FROM VPA_REGISTRATION_LOG WHERE ID = ? ";
	private static final String FETCH_VPA_REG_INFO_BY_ACCOUNT_NUMBER = "SELECT * FROM VPA_REGISTRATION_LOG WHERE ACCOUNT_NUMBER = ? ";

	private static final String FETCH_SMS_TOKEN_BY_REF_ID = "SELECT SMS_TOKEN FROM VPA_REGISTRATION_LOG WHERE ID = ? ";

	private  static final String UPDATE_VPA_REGISTRATION_INFO = "UPDATE VPA_REGISTRATION_LOG Set STATUS = ? where ID = ?";

	private static final String FETCH_RECORD_BY_SMS_AND_MOBILE = "SELECT * FROM VPA_REGISTRATION_LOG WHERE SMS_TOKEN = ? AND MOBILE_NUMBER = ?";

	private static final String UPDATE_VPA_REGISTRATION_INFO_REF_ID = "UPDATE VPA_REGISTRATION_LOG set VPA = ? where ID= ?";

	private  static final String UPDATE_VPA_REGISTRATION_DETAILS = "UPDATE VPA_REGISTRATION_LOG Set MOBILE_NUMBER= ? , DEVICE_ID = ? , SSID = ? , STATUS = ? where ID = ?";
	
	private  static final String UPDATE_VPA_REGISTRATION_DETAILS_WITH_FINGERPRINT = "UPDATE VPA_REGISTRATION_LOG Set MOBILE_NUMBER= ? , DEVICE_FINGERPRINT = ?, DEVICE_ID = ? , SSID = ? , STATUS = ? where ID = ?";

	private  static final String UPDATE_VPA_TXN_INFO = "UPDATE VPA_TXN_INFO Set GATEWAY_RESPONSE_STATUS = ?, STATUS = ? where GATEWAY_TXN_ID = ? AND payee_merchant_customer_id = ?";

	private  static final String FETCH_VPA_TXN_INFO = "SELECT * FROM VPA_TXN_INFO where GATEWAY_TXN_ID = ? AND payee_merchant_customer_id = ?";

	private  static final String FETCH_VPA_TXN_INFO_BY_TXN_ID_AND_REF_NO = "SELECT * FROM VPA_TXN_INFO where GATEWAY_TXN_ID = ? AND AMOUNT = ?";

	private  static final String FETCH_VPA_DETAILS = "SELECT * FROM VPA_DETAILS where UPI_CUSTOMER_ID = ? AND VPA = ?";
	private  static final String FETCH_VPA_DETAILS_BY_VPA = "SELECT * FROM VPA_DETAILS where VPA = ?";

	private static final String DEVICE_FINGERPRINT = "DEVICE_FINGERPRINT";
	private static final String DEVICE_ID = "DEVICE_ID";
	private static final String SSID = "SSID";
	private static final String VPA = "VPA";
	private static final String MOBILE_NUMBER = "MOBILE_NUMBER";
	private static final String SMS_TOKEN = "SMS_TOKEN";
	private static final String WALLET_URN = "WALLET_URN";
	private static final String WALLET_ID = "WALLET_ID";
	private static final String MERCHANT_CUSTOMER_ID = "MERCHANT_CUSTOMER_ID";
	private static final String STATUS = "STATUS";
	private static final String ACCOUNT_NUMBER = "ACCOUNT_NUMBER";
	private static final String ID = "ID";
	private static final String AMOUNT = "AMOUNT";
	private static final String TRANSACTION_TYPE = "TRANSACTION_TYPE";
	private static final String PAYER_VPA = "PAYER_VPA";
	private static final String PAYEE_VPA = "PAYEE_VPA";
	public static final String EXCEPTION_MESSAGE_FETCH_REG_SMS_MOBILE = "Error occurred in UpiRegistrationDAOImpl : fetchVpaRegInfoBySmsAndMobile {}";
	public static final String EXCEPTION_MESSAGE_FETCH_GATEWAY_TXN = "Error occurred in UpiRegistrationDAOImpl : fetchStatusBasesOnGatewayTxnId {}";
	public static final String EXCEPTION_MESSAGE_FETCH_MERCHANT_CUST_ID = "Error occurred in UpiRegistrationDAOImpl : fetchVpaDetailsBasesOnMerchantCustId {}";
	
	@Override
	public List<VpaBasicDetails> fetchVpaDetailsBasedOnAccountNo(String programId, int accountNumber) {
		List<VpaBasicDetails> vpaBasicDetailsList = new ArrayList<>();
		try {
			BeanPropertyRowMapper<VpaBasicDetails> rowMapper = BeanPropertyRowMapper.newInstance(VpaBasicDetails.class);
			vpaBasicDetailsList = jdbcTemplate.query(QUERY_FETCH_VPA_BASIC_DETAILS,
					new PreparedStatementSetter() {

						public void setValues(PreparedStatement preparedStatement) throws SQLException {
							preparedStatement.setInt(1, accountNumber);
						}
					}, rowMapper);

		} catch (CannotGetJdbcConnectionException e) {
			log.error("program :{}, not configured ,error: {}", programId, e.toString());
		} catch (Exception e) {
			log.error("Exception :{}", e);
		}
		return vpaBasicDetailsList;
	}

	@Override
	public BigInteger saveVpaRegistrationLogDetails(VpaRegistrationAudit vpaAudit) {
		
		KeyHolder keyHolder;
		try {
			keyHolder = new GeneratedKeyHolder();
			jdbcTemplate.update(connection -> {
				PreparedStatement ps = connection.prepareStatement(SAVE_VPA_REGISTRATION_INFO, Statement.RETURN_GENERATED_KEYS);
				int i = 1;
				ps.setLong(i++, vpaAudit.getAccountNumber());
				ps.setString(i++, vpaAudit.getMobileNumber());
				ps.setString(i++, vpaAudit.getWalletUrn());
				ps.setLong(i++, vpaAudit.getMerchantCustomerId());
				ps.setString(i++, vpaAudit.getSmsToken());
				ps.setString(i++, vpaAudit.getDeviceFingerPrint());
				ps.setString(i++, vpaAudit.getDeviceId());
				ps.setString(i++, vpaAudit.getSsid());
				ps.setString(i++, vpaAudit.getStatus());
				return ps;
			}, keyHolder);
		} catch (DataAccessException e) {
			log.error("Error occurred in UpiRegistrationDAOImpl : saveVpaRegistrationLogDetails {}", e.getMessage());
			throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);
		}
		
		return (BigInteger) keyHolder.getKey();
	}

	@Override
	public VpaRegistrationAudit fetchVpaRegistrationLogInfoByRefId(BigInteger refId) {
		VpaRegistrationAudit vpaRegistrationAudit = new VpaRegistrationAudit();
		try {
			jdbcTemplate.query(FETCH_VPA_REG_INFO_BY_REF_ID, new PreparedStatementSetter() {

				@Override
				public void setValues(PreparedStatement ps) throws SQLException {
					ps.setString(1, refId.toString());
				}
			}, getRse(vpaRegistrationAudit));
		} catch (DataAccessException e) {
			log.error("Error occured in getKycLevel {}", e.getMessage());
			throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);
		}
		return vpaRegistrationAudit;

	}

	private ResultSetExtractor<VpaRegistrationAudit> getRse(VpaRegistrationAudit vpaRegistrationAudit) {
		return new ResultSetExtractor<VpaRegistrationAudit>() {

			@Override
			public VpaRegistrationAudit extractData(ResultSet rs) throws SQLException {
				if (rs.next()) {
					setResultSetToVpaRegistrationAudit(vpaRegistrationAudit, rs);
				}
				return vpaRegistrationAudit;
			}
		};
	}

	private void setResultSetToVpaRegistrationAudit(VpaRegistrationAudit vpaRegistrationAudit,ResultSet rs) throws SQLException {
		vpaRegistrationAudit.setId(rs.getLong(ID));
		vpaRegistrationAudit.setMobileNumber(rs.getString(MOBILE_NUMBER));
		vpaRegistrationAudit.setSmsToken(rs.getString(SMS_TOKEN));
		vpaRegistrationAudit.setAccountNumber(rs.getLong(ACCOUNT_NUMBER));
		vpaRegistrationAudit.setMerchantCustomerId(rs.getLong(MERCHANT_CUSTOMER_ID));
		vpaRegistrationAudit.setStatus(rs.getString(STATUS));
		vpaRegistrationAudit.setDeviceFingerPrint(rs.getString(DEVICE_FINGERPRINT));
		vpaRegistrationAudit.setWalletUrn(rs.getString(WALLET_URN));
		vpaRegistrationAudit.setDeviceId(rs.getString(DEVICE_ID));
		vpaRegistrationAudit.setSsid(rs.getString(SSID));
		vpaRegistrationAudit.setVpa(rs.getString(VPA));
	}

	@Override
	public String fetchSmsToken(String refId) {
		VpaRegistrationAudit vpaRegistrationAudit = new VpaRegistrationAudit();
		
		try {
			return jdbcTemplate.query(FETCH_SMS_TOKEN_BY_REF_ID, ps -> ps.setString(1,refId), rs -> {
				if(rs.next()) {
					vpaRegistrationAudit.setSmsToken(rs.getString(SMS_TOKEN));
					return vpaRegistrationAudit.getSmsToken();
				} else {
					return null;
				}
			});
		} catch (DataAccessException e) {
			log.error("Error occurred in UpiRegistrationDAOImpl : fetchSmsToken {}", e.getMessage());
			throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);
		}
	}

	@Override
	public BigInteger updateVpaRegistrationLogDetails(String status, DeviceBindingRequest request, String deviceFingerPrint) {
		int rv = 0;
		try {
			rv = jdbcTemplate.update(connection -> {
				PreparedStatement ps = connection.prepareStatement(UPDATE_VPA_REGISTRATION_DETAILS_WITH_FINGERPRINT,
						Statement.RETURN_GENERATED_KEYS);
				int i = 1;
				ps.setString(i++, request.getMobileNumber());
				if(deviceFingerPrint!=null) {
				ps.setString(i++, deviceFingerPrint);
				} else ps.setString(i++, RegistrationConstants.EMPTY_STRING);
				ps.setString(i++, request.getDeviceParams().getDeviceId());
				ps.setString(i++, request.getDeviceParams().getSsid());
				ps.setString(i++, status);
				ps.setString(i++, String.valueOf(request.getRefNumber()));
				return ps;
			});
		} catch (DataAccessException e) {
			log.info("Error occurred in UpiRegistrationDAOImpl : updateVpaRegistrationLogDetails {}", e.getMessage());
			throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);
		}
		return BigInteger.valueOf(rv);
	}
	
	@Override
	public BigInteger updateVpaRegistrationLogDetails(String status, DeviceBindingRequest request) {
		int rv = 0;
		try {
			rv = jdbcTemplate.update(connection -> {
				PreparedStatement ps = connection.prepareStatement(UPDATE_VPA_REGISTRATION_DETAILS,
						Statement.RETURN_GENERATED_KEYS);
				int i = 1;
				ps.setString(i++, request.getMobileNumber());
				ps.setString(i++, request.getDeviceParams().getDeviceId());
				ps.setString(i++, request.getDeviceParams().getSsid());
				ps.setString(i++, status);
				ps.setString(i++, String.valueOf(request.getRefNumber()));
				return ps;
			});
		} catch (DataAccessException e) {
			log.info("Error occurred in UpiRegistrationDAOImpl : updateVpaRegistrationLogDetails {}", e.getMessage());
			throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);
		}
		return BigInteger.valueOf(rv);
	}

	@Override
	public VpaRegistrationAudit fetchVpaRegInfoBySmsAndMobile(String smsContent, String mobileNumber) {
		VpaRegistrationAudit vpaRegistrationAudit = new VpaRegistrationAudit();
		String db = FETCH_RECORD_BY_SMS_AND_MOBILE;
		try {
			return jdbcTemplate.query(db, new PreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement ps) throws SQLException {
					ps.setString(1, smsContent);
					ps.setString(2, mobileNumber);
				}
			}, new ResultSetExtractor<VpaRegistrationAudit>() {
				@Override
				public VpaRegistrationAudit extractData(ResultSet rs) throws SQLException {
					if (rs.next()) {
						setResultSetToVpaRegistrationAudit(vpaRegistrationAudit,rs);
						return vpaRegistrationAudit;
					} else {
						return null;
					}
				}
			});
		} catch (EmptyResultDataAccessException e) {
			log.error(EXCEPTION_MESSAGE_FETCH_REG_SMS_MOBILE, e.getMessage());
			throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);
		}
	}

	@Override
	public void updateVpaRegistrationLogByRefID(String vpa, BigInteger refNumber) {
		try {
			jdbcTemplate.update(UPDATE_VPA_REGISTRATION_INFO_REF_ID, vpa, refNumber);
		} catch (DataAccessException e) {
			log.info("Error occurred in UpiRegistrationDAOImpl : updateVupdateVpaRegistrationLogByRefID  {}", e.getMessage());
			throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);
		}
	}

	@Override
	public void updateVpaRegLogByRefID(String status, BigInteger refNumber) {
		try {
			jdbcTemplate.update(UPDATE_VPA_REGISTRATION_INFO, status, refNumber);
		} catch (DataAccessException e) {
			log.info("Error occurred in UpiRegistrationDAOImpl : updateVpaRegLogByRefID  {}", e.getMessage());
			throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);
		}
	}

	@Override
	public void updateVpaTxnInfoByTxnId(String gatewayStatus, String status, String gatewayTransactionId, String payeeMerchantCustomerId) {
		try {
			jdbcTemplate.update(UPDATE_VPA_TXN_INFO, gatewayStatus, status, gatewayTransactionId, payeeMerchantCustomerId);
		} catch (DataAccessException e) {
			log.info("Error occurred in UpiRegistrationDAOImpl : updateVpaRegLogByRefID  {}", e.getMessage());
			throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);
		}
	}


	@Override
	public VpaTxnInfoDetails fetchStatusBasesOnGatewayTxnId(String gatewayTransactionId, String payeeMerchantCustomerId) {
		VpaTxnInfoDetails vpaTxnInfoDetails=new VpaTxnInfoDetails();
		String db = FETCH_VPA_TXN_INFO;
		try {
			return jdbcTemplate.query(db, new PreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement ps) throws SQLException {
					ps.setString(1, gatewayTransactionId);
					ps.setString(2, payeeMerchantCustomerId);
				}
			}, new ResultSetExtractor<VpaTxnInfoDetails>() {
				@Override
				public VpaTxnInfoDetails extractData(ResultSet rs) throws SQLException {
					if (rs.next()) {
						vpaTxnInfoDetails.setStatus(rs.getString("GATEWAY_RESPONSE_STATUS"));
						vpaTxnInfoDetails.setMerchantCustomerId(rs.getString(MERCHANT_CUSTOMER_ID));
						vpaTxnInfoDetails.setAmount(rs.getString(AMOUNT));
						vpaTxnInfoDetails.setTxnType(rs.getString(TRANSACTION_TYPE));
						vpaTxnInfoDetails.setPayerVpa(rs.getString(PAYER_VPA));

						return vpaTxnInfoDetails;
					} else {
						return null;
					}
				}
			});
		} catch (EmptyResultDataAccessException e) {
			log.error(EXCEPTION_MESSAGE_FETCH_GATEWAY_TXN, e.getMessage());
			throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);
		}
	}

	@Override
	public VpaTxnInfoDetails fetchVpaTxnInfoBasesOnGatewayTxnIdGatewayRefId(String gatewayTransactionId, String gatewayReferenceId, String amount) {
		log.info("gatewayTransactionId :: {}, amount :: {}",gatewayTransactionId,amount);
		VpaTxnInfoDetails vpaTxnInfoDetails=new VpaTxnInfoDetails();
		String db = FETCH_VPA_TXN_INFO_BY_TXN_ID_AND_REF_NO;
		try {
			return jdbcTemplate.query(db, new PreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement ps) throws SQLException {
					ps.setString(1, gatewayTransactionId);
					ps.setString(2, amount);
				}
			}, new ResultSetExtractor<VpaTxnInfoDetails>() {
				@Override
				public VpaTxnInfoDetails extractData(ResultSet rs) throws SQLException {
					if (rs.next()) {
						vpaTxnInfoDetails.setPayeeVpa(rs.getString(PAYEE_VPA));
						vpaTxnInfoDetails.setPayerVpa(rs.getString(PAYER_VPA));
						vpaTxnInfoDetails.setTxnType(rs.getString(TRANSACTION_TYPE));
						vpaTxnInfoDetails.setMerchantCustomerId(rs.getNString(MERCHANT_CUSTOMER_ID));
						vpaTxnInfoDetails.setMessage(rs.getNString("message"));

						return vpaTxnInfoDetails;
					} else {
						return null;
					}
				}
			});
		} catch (EmptyResultDataAccessException e) {
			log.error(EXCEPTION_MESSAGE_FETCH_GATEWAY_TXN, e.getMessage());
			throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);
		}
	}

	@Override
	public VpaDetails fetchVpaDetailsBasesOnMerchantCustId(String merchantCustomerId, String payerVpa) {

		String db = FETCH_VPA_DETAILS;
		try {
			return jdbcTemplate.query(db, new PreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement ps) throws SQLException {
					ps.setString(1, merchantCustomerId);
					ps.setString(2, payerVpa);
				}
			}, new ResultSetExtractor<VpaDetails>() {
				@Override
				public VpaDetails extractData(ResultSet rs) throws SQLException {
					return setVpaDetails(rs);
				}
			});
		} catch (EmptyResultDataAccessException e) {
			log.error(EXCEPTION_MESSAGE_FETCH_MERCHANT_CUST_ID, e.getMessage());
			throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);
		}
	}

	private VpaDetails setVpaDetails(ResultSet rs) throws SQLException {
		VpaDetails vpaDetails=new VpaDetails();
		if (rs.next()) {
			vpaDetails.setAccountNmber(rs.getInt(ACCOUNT_NUMBER));
			vpaDetails.setWalletId(rs.getInt(WALLET_ID));

			return vpaDetails;
		} else {
			return null;
		}
	}

	@Override
	public VpaDetails fetchVpaDetailsBasesOnVpa(String payeeVpa) {
		String db = FETCH_VPA_DETAILS_BY_VPA;
		try {
			return jdbcTemplate.query(db, new PreparedStatementSetter() {
				@Override
				public void setValues(PreparedStatement ps) throws SQLException {
					ps.setString(1, payeeVpa);
				}
			}, new ResultSetExtractor<VpaDetails>() {
				@Override
				public VpaDetails extractData(ResultSet rs) throws SQLException {
					return setVpaDetails(rs);
				}
			});
		} catch (EmptyResultDataAccessException e) {
			log.error(EXCEPTION_MESSAGE_FETCH_MERCHANT_CUST_ID, e.getMessage());
			throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);
		}
	}

	@Override
	public VpaRegistrationAudit fetchVpaRegistrationLogInfoByAccountNumber(String accountNumber) {
		VpaRegistrationAudit vpaRegistrationAudit = new VpaRegistrationAudit();
		try {
			jdbcTemplate.query(FETCH_VPA_REG_INFO_BY_ACCOUNT_NUMBER, new PreparedStatementSetter() {

				@Override
				public void setValues(PreparedStatement ps) throws SQLException {
					ps.setString(1, accountNumber);
				}
			}, getRse(vpaRegistrationAudit));
		} catch (DataAccessException e) {
			log.error("Error occured in getKycLevel {}", e.getMessage());
			throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);
		}
		return vpaRegistrationAudit;

	}

}


