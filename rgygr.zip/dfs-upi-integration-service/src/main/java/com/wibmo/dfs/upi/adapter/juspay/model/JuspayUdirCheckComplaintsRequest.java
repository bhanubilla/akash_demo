package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayUdirCheckComplaintsRequest {

    private String originalUpiRequestId;
    private String originalTransactionUpiRequestId;
    private String type;
    private String udfParameters;
    private String merchantCustomerId;

}
