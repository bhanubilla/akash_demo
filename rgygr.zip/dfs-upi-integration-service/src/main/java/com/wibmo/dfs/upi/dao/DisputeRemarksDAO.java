package com.wibmo.dfs.upi.dao;

import com.wibmo.dfs.upi.entity.DisputeRemarksDetails;

public interface DisputeRemarksDAO {
    DisputeRemarksDetails fetchDisputeAdjCode(String adjCode);
}
