package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayIncomingOutgoingCommon {
    private String merchantCustomerId;
    private String deviceFingerPrint;
    private String merchantRequestId;
    private String payeeVpa;
    private String payerVpa;
    private String payerName;
    private String collectRequestExpiryMinutes;
    private String amount;
    private String upiRequestId;
    private String bankAccountUniqueId;
    private String remarks;
    private String currency;
    private String udfParameters;
}
