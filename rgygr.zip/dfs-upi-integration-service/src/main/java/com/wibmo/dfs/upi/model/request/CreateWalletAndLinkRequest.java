package com.wibmo.dfs.upi.model.request;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CreateWalletAndLinkRequest {
	
	private String customerVpa;
	private String accountNumber;
	private String name;
	private String type;
	private String kycStatus;
	private String udfParameters;

}
