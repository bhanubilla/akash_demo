package com.wibmo.dfs.upi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FetchCardBalanceRequest {
	private String customerId;
	private String productType;
	private int walletId;
	private String rrn;
}