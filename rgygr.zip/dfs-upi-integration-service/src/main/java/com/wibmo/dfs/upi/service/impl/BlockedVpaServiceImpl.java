package com.wibmo.dfs.upi.service.impl;

import com.wibmo.dfs.upi.constants.UpiGatewayStatusConstants;
import com.wibmo.dfs.upi.constants.UpiStatusConstants;
import com.wibmo.dfs.upi.dao.BlockedVpaDao;
import com.wibmo.dfs.upi.dao.VpaUnblockLogDao;
import com.wibmo.dfs.upi.entity.BlockedVpaDetails;
import com.wibmo.dfs.upi.model.BlockedVpaDetailsModel;
import com.wibmo.dfs.upi.model.request.BlockedVpaRequest;
import com.wibmo.dfs.upi.model.request.BlockedVpasRequest;
import com.wibmo.dfs.upi.model.request.VerifyVpaRequest;
import com.wibmo.dfs.upi.model.response.VerifyVpaResponse;
import com.wibmo.dfs.upi.model.response.WibmoResponse;
import com.wibmo.dfs.upi.service.BlockedVpaService;
import com.wibmo.dfs.upi.service.UpiService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

@Service
@Slf4j
public class BlockedVpaServiceImpl implements BlockedVpaService {

    public static final String EXCEPTION_WHILE_BLOCKING = "Exception while blocking :: {}";
    @Autowired
    private BlockedVpaDao blockedVpaDao;

    @Autowired
    private VpaUnblockLogDao vpaUnblockLogDao;

    @Autowired
    private UpiService upiService;

    @Override
    public WibmoResponse blockedVpa(String programId, String accountNumber, BlockedVpaRequest request) {
        log.debug("BlockedVpaServiceimpl : blockedVpa :    accountNum - {}", accountNumber);
        try {
            VerifyVpaRequest vpaRequest = new VerifyVpaRequest();
            vpaRequest.setVpa(request.getVpa());
            WibmoResponse verifyVpaResponse = upiService.verifyVpa(programId, vpaRequest);
            VerifyVpaResponse vpaResponse = (VerifyVpaResponse) verifyVpaResponse.getData();
            if (UpiGatewayStatusConstants.VERIFY_VPA_ZH.getStatusMsg().equalsIgnoreCase(verifyVpaResponse.getResDesc()) && UpiStatusConstants.FAILURE.name().equalsIgnoreCase(vpaResponse.getGatewayResponseStatus())) {
                return new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), UpiGatewayStatusConstants.VERIFY_VPA_ZH.getStatusMsg());
            }

            int id = blockedVpaDao.insertBlockedVpaAccountNumber(accountNumber, request, vpaResponse.getName());
            if (id == 0) {
                return new WibmoResponse(UpiStatusConstants.VPA_BLOCKED_FAILED);
            } else {

                return new WibmoResponse(UpiStatusConstants.VPA_BLOCKED_SUCCESS);
            }
        } catch (Exception exception) {
            log.info(EXCEPTION_WHILE_BLOCKING, exception);
            return new WibmoResponse(UpiStatusConstants.VPA_BLOCKED_FAILED);
        }
    }

    @Override
    public WibmoResponse unblockedVpa(String accountNumber, BlockedVpaRequest request) {
        log.info("BlockedVpaServiceimpl : blockedVpa :    accountNum - {}", accountNumber);


        try {


            BlockedVpaDetails blockedVpaDetails = blockedVpaDao.fetchBlockedVPA(accountNumber, request);
            if (blockedVpaDetails != null) {
                vpaUnblockLogDao.insertVpaUnblock(accountNumber, request.getVpa(), blockedVpaDetails.getCreatedTs());
                blockedVpaDao.deleteUnblockedVpaByAccountNumber(accountNumber, request);

            }

            return new WibmoResponse((UpiStatusConstants.VPA_UMBLOCKED_SUCCESS));

        } catch (Exception exception) {
            log.info(EXCEPTION_WHILE_BLOCKING, exception);
            return new WibmoResponse(UpiStatusConstants.VPA_UNBLOCKED_FAILED);

        }

    }
//-----------------------------------------------------------------------------------------------


    @Override
    public WibmoResponse blockedVpaList(String accountNumber, BlockedVpasRequest request) {
        log.info("BlockedVpaServiceImpl : blockedVpaList :  accountNumber -{} ", accountNumber);
        WibmoResponse wibmoResponse = new WibmoResponse();
        try {
            List<BlockedVpaDetails> uniqueBlockedVpaList = new ArrayList<>();
            List<BlockedVpaDetailsModel> uniqueBlockedVpaFinalList = null;
            List<BlockedVpaDetails> blockedVpaDetails = blockedVpaDao.fetchBlockedVpaListByAccountNumber(accountNumber, request);
            //fetching uniqueBlockedVpa records from DB
            if (blockedVpaDetails != null && !blockedVpaDetails.isEmpty()) {
                uniqueBlockedVpaList = blockedVpaDetails.stream().collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(
                        Comparator.comparing(BlockedVpaDetails::getAccountNumber).thenComparing(BlockedVpaDetails::getBlockedVpa)
                )), ArrayList::new));
            }
            uniqueBlockedVpaFinalList = mapEntityToModel(uniqueBlockedVpaList);
            wibmoResponse.setResCode(200);
            wibmoResponse.setResDesc("SUCCESS");
            wibmoResponse.setData(uniqueBlockedVpaFinalList);
            return wibmoResponse;

        } catch (Exception exception) {
            log.info(EXCEPTION_WHILE_BLOCKING, exception);
            return new WibmoResponse(100,"Failure to fetch list");
        }

    }

    private List<BlockedVpaDetailsModel> mapEntityToModel(List<BlockedVpaDetails> uniqueBlockedVpaList) {
        List<BlockedVpaDetailsModel> blockedVpaDetailsModels = new ArrayList<>();
        for (BlockedVpaDetails row : uniqueBlockedVpaList) {
            BlockedVpaDetailsModel blockedVpaDetailsModel = new BlockedVpaDetailsModel();
            blockedVpaDetailsModel.setAccountNumber(row.getAccountNumber());
            blockedVpaDetailsModel.setBlockedVpa(row.getBlockedVpa());
            blockedVpaDetailsModel.setBlockedVpaName(row.getBlockedVpaName());
            blockedVpaDetailsModel.setVpa(row.getVpa());
            blockedVpaDetailsModel.setId(row.getId());
            blockedVpaDetailsModel.setCreatedTs(row.getCreatedTs() == null ? null : row.getCreatedTs().getTime());
            blockedVpaDetailsModel.setUpdatedTs(row.getUpdatedTs() == null ? null : row.getUpdatedTs().getTime());
            blockedVpaDetailsModels.add(blockedVpaDetailsModel);
        }
        return blockedVpaDetailsModels;
    }

    @Override
    public WibmoResponse fetchAllBlockedVpaList(String programId, String accountNumber) {
        log.info("BlockedVpaServiceImpl : blockedVpaList :  programId : {}, accountNumber : {} ", programId, accountNumber);
        WibmoResponse wibmoResponse = new WibmoResponse();
        try {
            List<BlockedVpaDetails> uniqueBlockedVpaList = new ArrayList<>();
            List<BlockedVpaDetailsModel> uniqueBlockedVpaFinalList = null;
            List<BlockedVpaDetails> blockedVpaDetails = blockedVpaDao.fetchAllBlockedVpaListByAccNo(accountNumber);
            //fetching uniqueBlockedVpa records from list
            if (blockedVpaDetails != null && !blockedVpaDetails.isEmpty()) {
                uniqueBlockedVpaList = blockedVpaDetails.stream().collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(
                        Comparator.comparing(BlockedVpaDetails::getAccountNumber).thenComparing(BlockedVpaDetails::getBlockedVpa)
                )), ArrayList::new));
            }
            uniqueBlockedVpaFinalList = mapEntityToModel(uniqueBlockedVpaList);
            wibmoResponse.setResCode(200);
            wibmoResponse.setResDesc("SUCCESS");
            wibmoResponse.setData(uniqueBlockedVpaFinalList);
            log.debug("Response fetchAllBlockedVpaList() {} ", uniqueBlockedVpaList);
            return wibmoResponse;

        } catch (Exception exception) {
            log.info(EXCEPTION_WHILE_BLOCKING, exception);
            return new WibmoResponse(100, "Failure to fetch list");
        }

    }

}
