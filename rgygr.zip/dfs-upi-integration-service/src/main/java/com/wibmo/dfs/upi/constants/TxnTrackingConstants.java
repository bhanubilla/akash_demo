package com.wibmo.dfs.upi.constants;

import io.swagger.annotations.ApiModelProperty;

public enum TxnTrackingConstants {

    PAYMENT_INITIATION_SUCCESS("PAY_INIT_SUCCESS", "payment initiated"),
    MONEY_DEBIT_SUCCESS("MONEY_DEBIT_SUCCESS", Constants.MONEY_DEBITED_FROM_BANK),
    MONEY_DEBIT_FAILURE("MONEY_DEBIT_FAILURE", Constants.MONEY_DEBITED_FROM_BANK),
    CREDIT_MONEY_PENDING("CREDIT_MONEY_PENDING", Constants.MONEY_SENT_TO_RECEIVER_S_BANK),
    CREDIT_MONEY_SUCCESS("CREDIT_MONEY_SUCCESS", Constants.MONEY_SENT_TO_RECEIVER_S_BANK),
    CREDIT_MONEY_FAILURE("CREDIT_MONEY_FAILURE", Constants.MONEY_SENT_TO_RECEIVER_S_BANK),
    TXN_SUCCESS("TXN_SUCCESS","payment completed"),
    DEBIT_REVERSAL_SUCCESS("DEBIT_REVERSAL_SUCCESS",Constants.MONEY_CREDIT_TO_BANK),
    DEBIT_REVERSAL_FAILURE("DEBIT_REVERSAL_ CREDIT_FAILURE",Constants.MONEY_CREDIT_TO_BANK),
    TXN_DECLINE("TXN_DECLINE","Payment declined"),
    PAY_BACK("PAY_BACK","Payment reversed");



    @ApiModelProperty(notes = "Status Name", name = "statusName")
    private final String statusName;
    @ApiModelProperty(notes = "Status description", name = "statusDescription")

    private final String statusDescription;

    TxnTrackingConstants(String statusName, String statusDescription) {
        this.statusName = statusName;
        this.statusDescription = statusDescription;
    }

    /**
     * Return the status name.
     */
    public String getStatusName() {
        return this.statusName;
    }

    /**
     * Return the status msg.
     */
    public String getStatusDescription() {
        return this.statusDescription;
    }

    private static class Constants {
        public static final String MONEY_SENT_TO_RECEIVER_S_BANK = "Money Sent to receiver's bank";
        public static final String MONEY_DEBITED_FROM_BANK = "Money debited from bank";
        public static final String MONEY_CREDIT_TO_BANK = "Money credit to bank";
    }
}
