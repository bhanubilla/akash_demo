package com.wibmo.dfs.upi.dao.impl;

import com.wibmo.dfs.upi.constants.RegistrationConstants;
import com.wibmo.dfs.upi.dao.BlockedVpaDao;
import com.wibmo.dfs.upi.entity.BlockedVpaDetails;
import com.wibmo.dfs.upi.exception.InternalServerException;
import com.wibmo.dfs.upi.helper.CommonHelper;
import com.wibmo.dfs.upi.model.request.BlockedVpaRequest;
import com.wibmo.dfs.upi.model.request.BlockedVpasRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.*;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Repository
@Slf4j
public class BlockedVpaDaoImpl implements BlockedVpaDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private static final String INSERT_SQL = "INSERT INTO BLOCKED_VPA_DETAILS (account_number,blockedvpa, blocked_vpa_name) VALUES(?,?,?)";
    private static final String DELETE_QUERY = "DELETE FROM BLOCKED_VPA_DETAILS WHERE ACCOUNT_NUMBER=? AND BLOCKEDVPA=?";
    private static final String SELECT_QUERY = "SELECT * FROM BLOCKED_VPA_DETAILS where ACCOUNT_NUMBER=? AND BLOCKEDVPA=?";
    private static final String SELECT_QUERY_ALL_BLOCKED_LIST = "SELECT * FROM BLOCKED_VPA_DETAILS where ACCOUNT_NUMBER=?";
    private static final String SELECT_QUERY_BLOCKED_LIST = "SELECT *  FROM BLOCKED_VPA_DETAILS WHERE ACCOUNT_NUMBER= ? LIMIT ? OFFSET ?";
    @Override
    public int insertBlockedVpaAccountNumber(String accountNumber, BlockedVpaRequest request, String name) {
        log.info("accountNumber :: {}, vpa :: {}, name :: {}",accountNumber, request.getVpa(),name);
        KeyHolder holder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
                try {
                    PreparedStatement ps = connection.prepareStatement(INSERT_SQL, Statement.RETURN_GENERATED_KEYS);
                    ps.setString(1, accountNumber);
                    ps.setString(2, request.getVpa());
                    ps.setString(3, name);

                    return ps;
                }catch (DataAccessException e) {
                    log.error("Error occurred in BlockedVpaDaoImpl : insertBlockedVpaAccountNumber {}", e.getMessage());
                    throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);
                }

        }, holder);
        return CommonHelper.getKeyHolderValue(holder);
    }

    @Override
    public void deleteUnblockedVpaByAccountNumber(String accountNumber, BlockedVpaRequest request) {
        KeyHolder holder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
                try{
                    PreparedStatement ps = connection.prepareStatement(DELETE_QUERY, Statement.RETURN_GENERATED_KEYS);
                    ps.setString(1, accountNumber);
                    ps.setString(2, request.getVpa());

                    return ps;
                }
                catch (DataAccessException e) {
                    log.error("Error occurred in BlockedVpaDaoImpl : deleteUnblockedVpaByAccountNumber {}", e.getMessage());
                    throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);
                }
        }, holder);

    }


    @Override
    public BlockedVpaDetails fetchBlockedVPA(String accountNumber, BlockedVpaRequest request) {
        BlockedVpaDetails blockedVpaDetails = new BlockedVpaDetails();
        String db = SELECT_QUERY;
        try {
            return jdbcTemplate.query(db, new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setString(1, accountNumber);
                    ps.setString(2, request.getVpa());
                }
            }, new ResultSetExtractor<BlockedVpaDetails>() {

                @Override
                public BlockedVpaDetails extractData(ResultSet resultSet) throws SQLException {
                    if (resultSet.next()) {
                        blockedVpaDetails.setId(resultSet.getLong("ID"));
                        blockedVpaDetails.setBlockedVpaName(resultSet.getString("BLOCKED_VPA_NAME"));
                        blockedVpaDetails.setAccountNumber(resultSet.getString("ACCOUNT_NUMBER"));
                        blockedVpaDetails.setBlockedVpa(resultSet.getString("BLOCKEDVPA"));
                        blockedVpaDetails.setUpdatedTs(resultSet.getTimestamp("UPDATED_TS"));
                        blockedVpaDetails.setCreatedTs(resultSet.getTimestamp("CREATED_TS"));
                        return blockedVpaDetails;
                    } else {
                        return null;
                    }


                }

            });


        } catch (EmptyResultDataAccessException e) {
            log.error("Error accur in BloackedVpaDaoImpl : fetchBlockedVPA {}", e.getMessage());
            throw new InternalServerException(RegistrationConstants.DB_REQUEST_COULD_NOT_BE_PROCESSED);

        }
    }

    @Override
    public List<BlockedVpaDetails> fetchBlockedVpaListByAccountNumber(String accountNumber, BlockedVpasRequest request) {
        List<BlockedVpaDetails> blockedVpaDetails  = new ArrayList<>();
        log.debug("BlockedVpaDaoImpl - List<BlockedVpaDetails> fetchBlockedVpaListByAccountNumber ");
        try{
            BeanPropertyRowMapper<BlockedVpaDetails> rowMapper = BeanPropertyRowMapper.newInstance(BlockedVpaDetails.class);
            blockedVpaDetails  = jdbcTemplate.query(SELECT_QUERY_BLOCKED_LIST, new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement preparedStatement) throws SQLException {
                    preparedStatement.setString(1,accountNumber);
                    preparedStatement.setInt(2,request.getPageno());
                    preparedStatement.setInt(3,request.getPageSize());

                }
            }, rowMapper);
        }catch (CannotGetJdbcConnectionException exception){
            log.error("program :{}, not configured ,error: {}", exception.toString());
        }catch (Exception e) {
            log.error("Exception :{}", e);
        }
        return blockedVpaDetails ;
    }

    @Override
    public List<BlockedVpaDetails> fetchAllBlockedVpaListByAccNo(String accountNumber) {
        List<BlockedVpaDetails> blockedVpaDetails = new ArrayList<>();
        log.debug("BlockedVpaDaoImpl - List<BlockedVpaDetails> fetchAllBlockedVpaListByAccNo ");
        try {
            BeanPropertyRowMapper<BlockedVpaDetails> rowMapper = BeanPropertyRowMapper.newInstance(BlockedVpaDetails.class);
            blockedVpaDetails = jdbcTemplate.query(SELECT_QUERY_ALL_BLOCKED_LIST, new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement preparedStatement) throws SQLException {
                    preparedStatement.setString(1, accountNumber);

                }
            }, rowMapper);
        } catch (CannotGetJdbcConnectionException exception) {
            log.error("Exception while getting jdbc connection error: {}", exception);
        } catch (Exception e) {
            log.error("Exception while fetchAllBlockedVpaListByAccNo error: {} :{}", e);
        }
        return blockedVpaDetails;
    }


}


















