package com.wibmo.dfs.upi.helper;

import com.wibmo.dfs.upi.adapter.juspay.util.CommonUtil;
import com.wibmo.dfs.upi.constants.Constants;
import com.wibmo.dfs.upi.model.AlertRequest;
import com.wibmo.dfs.upi.model.PushNotificationData;
import com.wibmo.dfs.upi.model.UserProfileResponse;
import com.wibmo.dfs.upi.model.response.WibmoResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Component
public class PushNotificationHelper {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${resource.url.onboarding}")
    private String onboardingUrl;

    @Value("${resource.url.notification}")
    private String notificationUrl;

    public void sendPushNotification(String programId, String accountNumber, String amount, String name, String action, String eventId, PushNotificationData pushNotificationData) {
        UserProfileResponse userProfileResponse = null;
        log.debug(" UpiServiceImpl : sendPushNotification : programId :{} , accountNumber : {}, name : {} amount :{} action :{} eventId : {}", programId, accountNumber, name, amount, action, eventId);
        try {
            MultiValueMap<String, String> userProfileDetailsHeader = new LinkedMultiValueMap<>();
            userProfileDetailsHeader.add("Content-Type", String.valueOf(MediaType.APPLICATION_JSON));
            userProfileDetailsHeader.add("X-PROGRAM-ID", programId);
            userProfileDetailsHeader.add("X-ACCOUNT-NUMBER", accountNumber);
            HttpEntity<String> entity = new HttpEntity<>(userProfileDetailsHeader);
            log.info("Rest Temp value 1: {}", this.restTemplate);
            log.info("Rest Temp value 2: {}", restTemplate);
            log.info("Onboarding url value: {}", onboardingUrl);
            ResponseEntity<UserProfileResponse> result = this.restTemplate.exchange(onboardingUrl + "/onboarding/userProfile/fetchUserProfileDetails/v1", HttpMethod.GET, entity, UserProfileResponse.class, new Object[0]);

            userProfileResponse = result.getBody();
            if (userProfileResponse != null) {
                Map<String, String> placeHolder = new HashMap<>();
                placeHolder.put("PAYER", name);
                placeHolder.put("AMOUNT", Constants.CURRENCY_IND+ CommonUtil.decimalFormat(Long.parseLong(amount)));
                placeHolder.put("action", action);
                placeHolder.put("txnRefNumber", pushNotificationData.getTxnRefNumber());
                placeHolder.put("payeeName", pushNotificationData.getPayeeName());
                placeHolder.put("txnMode", pushNotificationData.getTxnMode());
				placeHolder.put("requestedDate", String.valueOf(pushNotificationData.getRequestedDate()));
                placeHolder.put("expiryDate", String.valueOf(pushNotificationData.getExpiryDate()));
                placeHolder.put("txnAmount", Constants.CURRENCY_IND+ CommonUtil.decimalFormat(Long.parseLong(pushNotificationData.getTxnAmount())));
                placeHolder.put("desc", "Push Notification");
                placeHolder.put("payeeMobileNumber", userProfileResponse.getMobile());
                placeHolder.put("payeeVPA", pushNotificationData.getPayeeVPA());
                placeHolder.put("actionCode", "2");
                AlertRequest alertRequest = new AlertRequest();
                alertRequest.setEventId(Integer.parseInt(eventId));
                alertRequest.setFcmToken(userProfileResponse.getFcmId());
                alertRequest.setAccountNumber(Long.parseLong(accountNumber));
                alertRequest.setDeviceId(userProfileResponse.getDeviceId());
                alertRequest.setWhatsappEnabled(false);
                alertRequest.setPlaceHolders(placeHolder);
                //fix to sent notification alert
                alertRequest.setMobileNumber(userProfileResponse.getMobile());
                callToNotificationSendAlert(programId, alertRequest);
            }
        } catch (Exception ex) {
            log.error("Issue while fetching sendPushNotification : {} ", ex);
        }

    }

    public void callToNotificationSendAlert(String programId, AlertRequest alertRequest) {
        try {
            MultiValueMap<String, String> customNotificationHeader = new LinkedMultiValueMap<>();
            customNotificationHeader.add("Content-Type", String.valueOf(MediaType.APPLICATION_JSON));
            customNotificationHeader.add("X-PROGRAM-ID", programId);
            HttpEntity<Object> notificationEntity = new HttpEntity<>(alertRequest, customNotificationHeader);
            ResponseEntity<WibmoResponse> resp = this.restTemplate.exchange(notificationUrl + "/notification-service/notification/sendAlert", HttpMethod.POST, notificationEntity, WibmoResponse.class);
            WibmoResponse tempResp=resp.getBody();
            if (tempResp!=null && resp.getStatusCodeValue() != 200) {
                log.debug("Notification sending failed: {}", tempResp.getErrorMessage());
            }
        } catch (Exception var6) {
            log.error("Issue while sending callToNotificationSendAlert : {}", var6);
        }
    }
}
