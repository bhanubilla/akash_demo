package com.wibmo.dfs.upi.validator;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;

public class Test {
    public static void main(String[] args) {
        String s = "[{\"code\":\"JPFL\",\"description\":\"First transaction limit exceeds 5,000\"},{\"code\":\"JPFP\",\"description\":\"Total transaction in last 24hrs exceeds 5,000\"},{\"code\":\"JPPL\",\"description\":\"Total P2P transaction exceeds 10\"},{\"code\":\"JPCL\",\"description\":\"Total Collect transaction exceeds 5\"},{\"code\":\"JPZ8\",\"description\":\"Per transaction amount for normal case exceeds 1,00,000. / Per transaction amount for P2P Collect exceeds 100000\"},{\"code\":\"JPZU\",\"description\":\"Total Daily Amount per User exceeds / Total P2M Daily Amount per User exceeds\"},{\"code\":\"JPML\",\"description\":\"JPZU - Total Daily Amount per User exceeds / Total P2M Daily Amount per User exceeds\"}]";
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            List<LimitExceed> l = objectMapper.readValue(s, new TypeReference<List<LimitExceed>>() {
            });
            System.out.println(l);
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }
}

