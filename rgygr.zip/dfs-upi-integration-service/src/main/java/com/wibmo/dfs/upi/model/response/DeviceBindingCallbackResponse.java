package com.wibmo.dfs.upi.model.response;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

@Data
@NoArgsConstructor
public class DeviceBindingCallbackResponse {
    private String vpa;
    private String status;
    private String accountNumber;
    private BigInteger refId;
    private String mobileNumber;
    private String deviceId;
    private String ssid;
    private String deviceFingerPrint;

}
