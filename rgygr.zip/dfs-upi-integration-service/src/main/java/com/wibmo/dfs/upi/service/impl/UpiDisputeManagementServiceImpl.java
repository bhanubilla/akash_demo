package com.wibmo.dfs.upi.service.impl;

import com.wibmo.dfs.upi.adapter.juspay.model.JuspayRaiseComplaintUdirPayload;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayUdirComplaintStatusResponse;
import com.wibmo.dfs.upi.adapter.juspay.model.JuspayUdirListAllComplaintsResponse;
import com.wibmo.dfs.upi.constants.Constants;
import com.wibmo.dfs.upi.constants.ProgramParamConstants;
import com.wibmo.dfs.upi.constants.UpiStatusConstants;
import com.wibmo.dfs.upi.dao.ProgramParamsDAO;
import com.wibmo.dfs.upi.dao.UpiDisputeManagementDAO;
import com.wibmo.dfs.upi.dao.VpaTxnDAO;
import com.wibmo.dfs.upi.model.*;
import com.wibmo.dfs.upi.model.request.RaiseUdirComplaintRequest;
import com.wibmo.dfs.upi.model.request.VerifyVpaRequest;
import com.wibmo.dfs.upi.model.response.*;
import com.wibmo.dfs.upi.service.UpiDisputeManagementService;
import com.wibmo.dfs.upi.service.UpiService;
import com.wibmo.dfs.upi.service.UpiServiceAdapter;
import com.wibmo.dfs.upi.service.UpiServiceFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
@Slf4j
public class UpiDisputeManagementServiceImpl implements UpiDisputeManagementService {

    @Autowired
    UpiServiceFactory upiServiceFactory;

    @Autowired
    private UpiService upiService;
    @Autowired
    private UpiDisputeManagementDAO upiDisputeManagementDAO;

    @Autowired
    VpaTxnDAO vpaTxnDAO;
    @Autowired
    ProgramParamsDAO programParamsDAO;

    @Override
    public WibmoResponse raiseComplaint(String programId, String accountNum, RaiseUdirComplaintRequest raiseUdirComplaintRequest) {
        log.debug("UpiServiceImpl : raiseComplaint : programId - {} : accountNum - {}", programId, accountNum);
        WibmoResponse wibmoResponse = new WibmoResponse();
        try {
            UpiServiceAdapter upiServiceAdapter = upiServiceFactory.getUpiService(programId);
            if(upiServiceAdapter == null){
                return new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), UpiStatusConstants.FAILURE.name(),
                        Constants.UPI_VENDOR_NOT_FOUND_ERROR);
            }
            String upiRequestIdPrefix = programParamsDAO.fetchParamValueByParamName(programId,
                    ProgramParamConstants.UPI_REQUEST_ID_PREFIX.getValue());
            VpaTxnInfo vpaTxnInfo=vpaTxnDAO.fetchByGatewayTxnId(upiRequestIdPrefix+raiseUdirComplaintRequest.getTxnId());
            String timeForComplaintCreation=programParamsDAO.fetchParamValueByParamName(programId,Constants.DEFAULT_TIMESTAMP_FOR_COMPALINT_CREATION);

            if(timeForComplaintCreation==null){
                log.info("PARAM_VALUE Not found for this param:{}",Constants.DEFAULT_TIMESTAMP_FOR_COMPALINT_CREATION);
            }
            if(vpaTxnInfo!=null){
                long created_ts=vpaTxnInfo.getCreatedTs().getTime();
                long current_ts=new Timestamp(new Date().getTime()).getTime();
                log.info("created_ts:{},current_ts:{}",created_ts,current_ts);
                if(current_ts-created_ts<Long.valueOf(timeForComplaintCreation)){
                   return new WibmoResponse(101,"Complaint cant be raised within this time "+Long.valueOf(timeForComplaintCreation)/60000+"min");
                }
            }
            else{
                log.info("Transaction is not done for this gateway Txn Id:{}",raiseUdirComplaintRequest.getTxnId());
            }
            RaiseUdirComplaintResponse raiseUdirComplaintResponse=upiServiceAdapter.raiseComplaint(programId, accountNum, raiseUdirComplaintRequest);
            if(raiseUdirComplaintResponse!=null && raiseUdirComplaintResponse.getStatus()!=null
            && raiseUdirComplaintResponse.getStatus().equals(UpiStatusConstants.SUCCESS.getStatusMsg())
                    && raiseUdirComplaintResponse.getPayload()!=null){
                JuspayRaiseComplaintUdirPayload juspayRaiseComplaintUdirPayload=raiseUdirComplaintResponse.getPayload();
                DisputeManagementResponse disputeManagementResponse=new DisputeManagementResponse();
                disputeManagementResponse.setComplaintRefNo(juspayRaiseComplaintUdirPayload.getGatewayComplaintId());
                disputeManagementResponse.setComplaintStatus(juspayRaiseComplaintUdirPayload.getGatewayResponseStatus());
                disputeManagementResponse.setAmount(juspayRaiseComplaintUdirPayload.getReqAdjAmount());
                disputeManagementResponse.setTxnId(raiseUdirComplaintRequest.getTxnId());
                disputeManagementResponse.setName(juspayRaiseComplaintUdirPayload.getPayeeVpa());
                Timestamp timestamp=upiDisputeManagementDAO.fetchInsertedTimestamp(juspayRaiseComplaintUdirPayload.getCrn());
                disputeManagementResponse.setCreatedTime(String.valueOf(timestamp));
                wibmoResponse.setData(disputeManagementResponse);
                wibmoResponse.setResCode(UpiStatusConstants.SUCCESS.getStatusCode());
                wibmoResponse.setResDesc(Constants.RAISE_COMPLAINT_SUCCESS);
            }
            else {
                wibmoResponse = new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), Constants.RAISE_COMPLAINT_FAILED);
            }
        }
        catch (Exception e) {
        log.error("Exception in raiseComplaint method :::: {} ", e);
        }
		return wibmoResponse;
    }

    @Override
    public WibmoResponse checkComplaint(String programId, String accountNum, CheckUdirComplaintStatus checkUdirComplaintStatus) {
        log.debug("UpiServiceImpl : checkComplaint : programId - {} : accountNum - {}", programId, accountNum);
        WibmoResponse wibmoResponse = null;
        try {
            UpiServiceAdapter upiServiceAdapter = upiServiceFactory.getUpiService(programId);
            if (upiServiceAdapter == null) {
                return new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), UpiStatusConstants.FAILURE.name(),
                        Constants.UPI_VENDOR_NOT_FOUND_ERROR);
            }
            UdirComplaintStatusResponse udirComplaintStatusResponse = upiServiceAdapter.checkComplaint(programId, accountNum, checkUdirComplaintStatus);
           if (udirComplaintStatusResponse != null && udirComplaintStatusResponse.getStatus() != null
                    && udirComplaintStatusResponse.getStatus().equals(UpiStatusConstants.SUCCESS.getStatusMsg())
                    && udirComplaintStatusResponse.getPayload() != null) {
                JuspayUdirComplaintStatusResponse juspayUdirComplaintStatusResponse = udirComplaintStatusResponse.getPayload();
                DisputeManagementResponse disputeManagementResponse=new DisputeManagementResponse();
                disputeManagementResponse.setComplaintRefNo(juspayUdirComplaintStatusResponse.getCrn());
                disputeManagementResponse.setComplaintStatus(juspayUdirComplaintStatusResponse.getGatewayResponseStatus());
                disputeManagementResponse.setAmount(juspayUdirComplaintStatusResponse.getReqAdjAmount());
                disputeManagementResponse.setTxnId(checkUdirComplaintStatus.getTxnId());
                disputeManagementResponse.setName(juspayUdirComplaintStatusResponse.getPayeeVpa());
                wibmoResponse = new WibmoResponse(UpiStatusConstants.SUCCESS.getStatusCode(), Constants.FETCH_COMPLAINT_STATUS_SUCCESS, disputeManagementResponse);
            } else {
                wibmoResponse = new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), Constants.FETCH_COMPLAINT_STATUS_FAILURE);
            }
        } catch (Exception e) {
            log.error("Exception in checkComplaint method :::: {} ", e);
        }
        return wibmoResponse;
    }

    @Override
    public WibmoResponse listComplaints(String programId, String accountNum, CheckUdirComplaints checkUdirComplaints) {
        log.debug("UpiServiceImpl : listComplaints : programId - {} : accountNum - {}", programId, accountNum);
        WibmoResponse wibmoResponse=null;
        try {
            UpiServiceAdapter upiServiceAdapter = upiServiceFactory.getUpiService(programId);
            if (upiServiceAdapter == null) {
                return new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), UpiStatusConstants.FAILURE.name(),
                        Constants.UPI_VENDOR_NOT_FOUND_ERROR);
            }
          UdirComplaintsListResponse udirComplaintsListResponse = upiServiceAdapter.listComplaint(programId, accountNum, checkUdirComplaints);
            if (udirComplaintsListResponse != null && udirComplaintsListResponse.getStatus() != null
                    && udirComplaintsListResponse.getStatus().equals(UpiStatusConstants.SUCCESS.getStatusMsg())
                    && udirComplaintsListResponse.getPayload() != null) {
                JuspayUdirListAllComplaintsResponse juspayUdirListAllComplaintsResponse = udirComplaintsListResponse.getPayload();
                List<DisputeManagementResponse> list=new ArrayList<>();
                if(juspayUdirListAllComplaintsResponse.getComplaintsList()!=null && !juspayUdirListAllComplaintsResponse.getComplaintsList().isEmpty()){
                    for(PendingComplaints pendingComplaints:juspayUdirListAllComplaintsResponse.getComplaintsList()){
                        DisputeManagementResponse disputeManagementResponse=new DisputeManagementResponse();
                        disputeManagementResponse.setComplaintRefNo(pendingComplaints.getUpiRequestId());
                        disputeManagementResponse.setComplaintStatus(pendingComplaints.getStatus());
                        disputeManagementResponse.setAmount(pendingComplaints.getReqAdjAmount());
                        disputeManagementResponse.setCreatedTime(pendingComplaints.getOrgTxnDate());
                        disputeManagementResponse.setTxnId(pendingComplaints.getOriginalUpiRequestId());
                        disputeManagementResponse.setName(getVPAName(programId,pendingComplaints.getPayerVpa()));
                        Timestamp timestamp=upiDisputeManagementDAO.fetchInsertedTimestamp(pendingComplaints.getCrn());
                        disputeManagementResponse.setCreatedTime(String.valueOf(timestamp));

                        list.add(disputeManagementResponse);
                    }
                }
                DisputeManagementListResponse disputeManagementListResponse=new DisputeManagementListResponse();
                disputeManagementListResponse.setDisputeManagementList(list);
                wibmoResponse = new WibmoResponse(UpiStatusConstants.SUCCESS.getStatusCode(), Constants.RAISED_COMPLAINT_LIST, disputeManagementListResponse);
            } else {
                wibmoResponse = new WibmoResponse(UpiStatusConstants.FAILURE.getStatusCode(), Constants.RAISED_COMPLAINT_LIST_FAILED);
            }
        } catch (Exception e) {
            log.error("Exception in listComplaints method :::: {} ", e);
        }
        return wibmoResponse;
    }

    private String getVPAName(String programId,String vpa){
        VerifyVpaRequest verifyVpaRequest = new VerifyVpaRequest();
        verifyVpaRequest.setVpa(vpa);
        WibmoResponse wibmoResponse = upiService.verifyVpa(programId, verifyVpaRequest);
        VerifyVpaResponse vpaResponse = wibmoResponse !=null ? (VerifyVpaResponse) wibmoResponse.getData() : null;
        String payerName = null;
        if(vpaResponse!=null){
            payerName = vpaResponse.getName();
        }
        return payerName;
    }
}
