package com.wibmo.dfs.upi.model;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Component;

import com.wibmo.dfs.upi.adapter.juspay.model.JuspaySendMoneyResponse;
import com.wibmo.dfs.upi.model.response.SendMoneyResponse;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class VpaTxnInfoMapper {
	public VpaTxnInfo map(JuspaySendMoneyResponse juspaySendMoneyResponse) {
		log.info("Mapping JuspaySendMoney Response to VpaTxnInfo..");
		VpaTxnInfo response = new VpaTxnInfo();
		response.setMerchantCustomerId(juspaySendMoneyResponse.getPayload().getMerchantCustomerId());
		response.setMerchantRequestId(juspaySendMoneyResponse.getPayload().getMerchantRequestId());
		String mobileNumber = juspaySendMoneyResponse.getPayload().getCustomerMobileNumber();
		response.setCustomerMobileNumber(mobileNumber.length()==12 ? mobileNumber.substring(2) : mobileNumber);
		response.setPayerVpa(juspaySendMoneyResponse.getPayload().getPayerVpa());
		response.setPayeeMcc(juspaySendMoneyResponse.getPayload().getPayeeMcc());
		response.setPayeeMerchantCustomerId(juspaySendMoneyResponse.getPayload().getPayeeMerchantCustomerId());
		response.setPayeeName(juspaySendMoneyResponse.getPayload().getPayeeName());
		response.setPayeeVpa(juspaySendMoneyResponse.getPayload().getPayeeVpa());
		response.setRefUrl(juspaySendMoneyResponse.getPayload().getRefUrl());
		response.setBankAccountUniqueId(juspaySendMoneyResponse.getPayload().getBankAccountUniqueId());
		response.setBankCode(juspaySendMoneyResponse.getPayload().getBankCode());
		response.setMaskedAccountNumber(juspaySendMoneyResponse.getPayload().getMaskedAccountNumber());
		response.setAmount(Double.valueOf(juspaySendMoneyResponse.getPayload().getAmount()));
		response.setTransactionType(juspaySendMoneyResponse.getPayload().getTransactionType());
		
		DateTimeFormatter formatDateTime = DateTimeFormatter.ISO_ZONED_DATE_TIME;
	    LocalDateTime localDateTime = LocalDateTime.from(formatDateTime.parse(juspaySendMoneyResponse.getPayload().getTransactionTimestamp()));
	    Timestamp ts = Timestamp.valueOf(localDateTime);
	    response.setTransactionTimestamp(ts);
		
		response.setGatewayTxnId(juspaySendMoneyResponse.getPayload().getGatewayTransactionId());
		response.setGatewayResponseStatus(juspaySendMoneyResponse.getPayload().getGatewayResponseStatus());
		response.setGatewayReferenceId(juspaySendMoneyResponse.getPayload().getGatewayReferenceId());
		response.setGatewayResponseCode(juspaySendMoneyResponse.getPayload().getGatewayResponseCode());
		response.setGatewayResponseMessage(juspaySendMoneyResponse.getPayload().getGatewayResponseMessage());
		response.setGatewayPayerResponseCode(juspaySendMoneyResponse.getPayload().getGatewayPayerResponseCode());
		response.setGatewayPayeeResponseCode(juspaySendMoneyResponse.getPayload().getGatewayPayeeResponseCode());
		response.setGatewayPayerReversalResponseCode(juspaySendMoneyResponse.getPayload().getGatewayPayerReversalResponseCode());
		response.setGatewayPayeeReversalResponseCode(juspaySendMoneyResponse.getPayload().getGatewayPayeeReversalResponseCode());
		response.setStatus(juspaySendMoneyResponse.getStatus());
		response.setMessage(juspaySendMoneyResponse.getResponseMessage());
		return response;
	}
	
	public VpaTxnInfo map(SendMoneyResponse sendMoneyResponse) {
		log.info("Mapping JuspaySendMoney Response to VpaTxnInfo..");
		VpaTxnInfo response = new VpaTxnInfo();
		response.setMerchantCustomerId(sendMoneyResponse.getMerchantCustomerId());
		response.setMerchantRequestId(sendMoneyResponse.getMerchantRequestId());
		String mobileNumber = sendMoneyResponse.getCustomerMobileNumber();
		response.setCustomerMobileNumber(mobileNumber.length()==12 ? mobileNumber.substring(2) : mobileNumber);
		response.setPayerVpa(sendMoneyResponse.getPayerVpa());
		response.setPayeeMcc(sendMoneyResponse.getPayeeMcc());
		response.setPayeeMerchantCustomerId(sendMoneyResponse.getPayeeMerchantCustomerId());
		response.setPayeeName(sendMoneyResponse.getPayeeName());
		response.setPayeeVpa(sendMoneyResponse.getPayeeVpa());
		response.setRefUrl(sendMoneyResponse.getRefUrl());
		response.setBankAccountUniqueId(sendMoneyResponse.getBankAccountUniqueId());
		response.setBankCode(sendMoneyResponse.getBankCode());
		response.setMaskedAccountNumber(sendMoneyResponse.getMaskedAccountNumber());
		response.setAmount(Double.valueOf(sendMoneyResponse.getAmount()));
		response.setTransactionType(sendMoneyResponse.getTransactionType());
		
		DateTimeFormatter formatDateTime = DateTimeFormatter.ISO_ZONED_DATE_TIME;
	    LocalDateTime localDateTime = LocalDateTime.from(formatDateTime.parse(sendMoneyResponse.getTransactionTimestamp()));
	    Timestamp ts = Timestamp.valueOf(localDateTime);
	    response.setTransactionTimestamp(ts);
		
		response.setGatewayTxnId(sendMoneyResponse.getGatewayTransactionId());
		response.setGatewayResponseStatus(sendMoneyResponse.getGatewayResponseStatus());
		response.setGatewayReferenceId(sendMoneyResponse.getGatewayReferenceId());
		response.setGatewayResponseCode(sendMoneyResponse.getGatewayResponseCode());
		response.setGatewayResponseMessage(sendMoneyResponse.getGatewayResponseMessage());
		response.setStatus(sendMoneyResponse.getStatus());
		response.setMessage(sendMoneyResponse.getResponseMessage());
		return response;
	}
}
