package com.wibmo.dfs.upi.model.request;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UpiIncomingCollectRequest {
    private String txnId;
    private String payerVpa;
    private String payeeVpa;
    private String payeeName;
    private String payerName;
    private String txnAmount;
    private String currency;
    private String approvalStatus;
    private String remarks;
    private String walletId;
    private long txnDate;

}
