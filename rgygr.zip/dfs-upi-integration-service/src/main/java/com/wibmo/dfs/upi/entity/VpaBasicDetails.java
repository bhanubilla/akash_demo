package com.wibmo.dfs.upi.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class VpaBasicDetails {

	private String ssid;
	private String deviceId;
	private String vpa;
	private int isPrimaryVpa;

}
