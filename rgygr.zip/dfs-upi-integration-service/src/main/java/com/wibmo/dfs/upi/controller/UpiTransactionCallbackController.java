package com.wibmo.dfs.upi.controller;

import com.wibmo.dfs.upi.model.response.JuspayCallbackResponse;
import com.wibmo.dfs.upi.model.response.WibmoResponse;
import com.wibmo.dfs.upi.service.UpiService;
import com.wibmo.dfs.upi.service.UpiServiceCallbacks;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/upi/callback")
@Slf4j
public class UpiTransactionCallbackController {

    @Autowired
    private UpiService upiService;

    @Autowired
    private UpiServiceCallbacks upiServiceCallbacks;

    private static final String SUCCESS = "SUCCESS";
    @PostMapping("/v1/transaction/status")
    public WibmoResponse transactionStatusCallback(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestBody String request) {
        log.info("transactionStatusCallback method : programId-{}, request-{}", programId, request);
        return upiService.transactionStatusCallback(programId, request);
    }

    @PostMapping("/v1/creditMoneyCBS")
    public JuspayCallbackResponse creditMoneyCBSCallback(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestBody String request) {
        log.info("creditMoneyCBSCallback method : programId-{}, request-{}", programId, request);
        return upiServiceCallbacks.creditMoneyCBSCallback(programId, request);
    }

    @PostMapping("/v1/incomingCollectRequestToCustomer")
    public WibmoResponse incomingCollectRequestCallback(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestBody String request) {
        log.info("incomingCollectRequestToCustomer method : programId-{}, request-{}", programId, request);
        return upiServiceCallbacks.incomingCollectRequestToCustomer(programId, request);
    }
    @PostMapping("/v1/incomingMoneyToCustomerPay")
    public WibmoResponse incomingMoneyToCustomerPayCallback(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestBody String request) {
        log.info("incomingMoneyToCustomerPayCallback method : programId-{}, request-{}", programId, request);
        return new WibmoResponse(200,SUCCESS);
    }
    @PostMapping("/v1/outgoingMoneyFromACustomer")
    public WibmoResponse outgoingMoneyFromACustomerCallback(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestBody String request) {
        log.info("outgoingMoneyFromACustomerCallback method : programId-{}, request-{}", programId, request);
        return new WibmoResponse(200,SUCCESS);
    }
    @PostMapping("/v1/outgoingCollectRequestFromCustomer")
    public WibmoResponse outgoingCollectRequestFromCustomerCallback(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestBody String request) {
        log.info("outgoingCollectRequestFromCustomer method : programId-{}, request-{}", programId, request);
        return upiServiceCallbacks.outgoingCollectRequestFromCustomerCallback(programId, request);
    }
    @PostMapping("/v1/incomingMoneyToCustomerCsCallback")
    public WibmoResponse incomingMoneyToCustomerCsCallback(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestBody String request) {
        log.info("incomingMoneyToCustomerCsCallback method : programId-{}, request-{}", programId, request);
        return upiServiceCallbacks.incomingMoneyToCustomerCsCallback(programId, request);
    }
}
