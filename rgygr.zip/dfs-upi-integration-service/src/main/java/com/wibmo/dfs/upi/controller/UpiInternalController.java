package com.wibmo.dfs.upi.controller;

import com.wibmo.dfs.upi.dao.UpiDisputeManagementDAO;
import com.wibmo.dfs.upi.dao.VpaTxnDAO;
import com.wibmo.dfs.upi.model.response.WibmoResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/upi/internal")
@Slf4j
public class UpiInternalController {
    @Autowired
    VpaTxnDAO vpaTxnDAO;

    @Autowired
    UpiDisputeManagementDAO upiDisputeManagementDAO;

    @GetMapping("/vpaTxnDetails")
    public WibmoResponse fetchVpaTxnDetails(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader("VPA-TXN-ID") String vpaTxnId ){
        log.info("programId :: {}, vpaTxnId :: {}",programId,vpaTxnId);
        return new WibmoResponse(200,"SUCCESS",vpaTxnDAO.fetchByGatewayTxnId(vpaTxnId));
    }

    @GetMapping("/complaintDetails")
    public WibmoResponse fetchComplaintDetails(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader("TXN-ID") String txnId ){
        log.info("programId :: {}, txnId :: {}",programId,txnId);
        return new WibmoResponse(200,"SUCCESS",upiDisputeManagementDAO.fetchComplaintByTxnId(txnId));
    }

}
