package com.wibmo.dfs.upi.service;

import com.wibmo.dfs.upi.exception.UpiGenericException;
import com.wibmo.dfs.upi.model.request.*;
import com.wibmo.dfs.upi.model.response.WibmoResponse;

public interface UpiService {
	
	WibmoResponse isVpaAvailable(String programId, String accountNum, VpaValidRequest request);
	WibmoResponse checkDeviceBindingStatus(String programId, int accountNumber, CheckDeviceStatusRequest checkDeviceStatusRequest);
	WibmoResponse getSmsToken(String programId, String accountNum, SmsTokenRequest request);
	WibmoResponse deviceBinding(String programId, int accountNumber, DeviceBindingRequest deviceBindingRequest) throws UpiGenericException ;
	WibmoResponse declineDeviceBinding(String programId, String accountNumber, DeclineDeviceBindingRequest deviceBindingRequest);
	WibmoResponse createAndLink(String programId, String accountNumber, LinkVPARequest linkVPARequest) throws UpiGenericException;
	WibmoResponse pollingForVPAStatus(String programId, int accountNumber, PollingRequest pollingRequest) throws UpiGenericException ;
	WibmoResponse deviceStatusCallback(String programId, String request);
	WibmoResponse verifyVpa(String programId, VerifyVpaRequest request);
	WibmoResponse sendMoney(String programId, String accountNumber, UPITransactionRequest req);
	WibmoResponse requestMoney(String programId, String accountNumber, RequestMoneyRequest request);
	WibmoResponse listPendingCollectRequests(String programId, String accountNumber);
	WibmoResponse transactionStatusCallback(String programId, String request);
	WibmoResponse retrieveVpaDetails(String programId, String accountNumber, String mobileNumber);
	WibmoResponse accountAddVpa(String programId, String accountNumber, AddVpaRequest request);
	WibmoResponse accountDeleteVpa(String programId, String accountNumber, DeleteVpaRequest request);
	WibmoResponse deRegisterCustomer(String programId, String accountNumber, DeregisterCustomerRequest request);
	void sendPushNotification(String programId, String accountNumber, RequestMoneyRequest request, String payeeMobNumber, String payeeVpa, String payeeName, String txnId);
}
