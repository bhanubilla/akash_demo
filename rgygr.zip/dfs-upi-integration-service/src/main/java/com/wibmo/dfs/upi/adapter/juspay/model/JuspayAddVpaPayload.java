package com.wibmo.dfs.upi.adapter.juspay.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;

@Data
@NoArgsConstructor
public class JuspayAddVpaPayload {
    private String merchantId;
    private String merchantChannelId;
    private String merchantCustomerId;
    private String customerMobileNumber;
    private ArrayList<JuspayAddVpaAccounts> vpaAccounts;
}
