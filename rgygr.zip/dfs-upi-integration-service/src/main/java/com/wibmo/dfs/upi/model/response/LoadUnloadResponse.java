package com.wibmo.dfs.upi.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class LoadUnloadResponse {
    private long availableBalance;
    private long transactionAmount;
    private long availableCashLimit;
    private long urn;
    private String customerId;
    private String description;
    private String responseCode;
    private int messageCode;
    private String clientTxnId;
    private String clientId;
    private String responseDateTime;
    private long accosaTransactionId;
    private String responseMessage;
    private int bankId;
    private String accosaRefNo;

}
