package com.wibmo.dfs.upi.model.response;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;

@Data
@NoArgsConstructor
public class AddVpaPayload {
    private String merchantId;
    private String merchantChannelId;
    private String merchantCustomerId;
    private String customerMobileNumber;
    private ArrayList<AddVpaAccounts> vpaAccounts;
}
