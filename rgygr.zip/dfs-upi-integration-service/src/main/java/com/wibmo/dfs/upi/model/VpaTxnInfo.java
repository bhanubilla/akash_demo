package com.wibmo.dfs.upi.model;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class VpaTxnInfo implements Serializable {

	private static final long serialVersionUID = 1L;
	private long id;
	private String merchantRequestId;
	private String merchantCustomerId;
	private String customerMobileNumber;
	private String payerVpa;
	private String payeeMcc;
	private String payeeMerchantCustomerId;
	private String payeeName;
	private String payeeVpa;
	private String refUrl;
	private String bankAccountUniqueId;
	private String bankCode;
	private String maskedAccountNumber;
	private double amount;
	private String transactionType;
	private Timestamp transactionTimestamp;
	private String originalTxnId;
	private String gatewayTxnId;
	private String gatewayResponseStatus;
	private String gatewayReferenceId;
	private String gatewayResponseCode;
	private String gatewayResponseMessage;
	private String upiRequestId;
	private String status;
	private String message;
	private Timestamp updatedTs;
	private Timestamp createdTs;
	private String gatewayPayerResponseCode;
	private String gatewayPayeeResponseCode;
	private String gatewayPayerReversalResponseCode;
	private String gatewayPayeeReversalResponseCode;
	
}
