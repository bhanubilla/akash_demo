#!/bin/bash
tagver=$1
id=$2
export  AWS_PROFILE=awsBankezy
aws ecr get-login-password --region ap-south-1 | docker login --username AWS --password-stdin ${id}.dkr.ecr.ap-south-1.amazonaws.com
docker build -t dfs-wallet-service:${tagver} .
docker tag dfs-wallet-service:${tagver} ${id}.dkr.ecr.ap-south-1.amazonaws.com/dfs-wallet-service:${tagver}
docker push ${id}.dkr.ecr.ap-south-1.amazonaws.com/dfs-wallet-service:${tagver}