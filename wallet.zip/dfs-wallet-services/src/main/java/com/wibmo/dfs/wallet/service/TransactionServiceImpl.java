package com.wibmo.dfs.wallet.service;

import java.util.*;

import com.wibmo.dfs.wallet.adapter.UpiIntegrationServiceAdapter;
import com.wibmo.dfs.wallet.aero.constants.TxnTrackingConstants;
import com.wibmo.dfs.wallet.model.*;
import com.wibmo.dfs.wallet.util.ApiManagerUtil;
import com.wibmo.dfs.wallet.validation.BLValidator;
import org.apache.commons.lang.StringUtils;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.wallet.common.MsgConstants;
import com.wibmo.dfs.wallet.common.ProgramParamConstants;
import com.wibmo.dfs.wallet.constants.AckTxnTypes;
import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.constants.ServiceHttpStatus;
import com.wibmo.dfs.wallet.entity.WalletCard;
import com.wibmo.dfs.wallet.kafka.KafkaProducer;
import com.wibmo.dfs.wallet.kafka.model.TxnDetails;
import com.wibmo.dfs.wallet.kafka.model.W2UPITxnDetailsRequest;
import com.wibmo.dfs.wallet.repository.ProgramParametersRepository;
import com.wibmo.dfs.wallet.repository.WalletCardRepository;
import com.wibmo.dfs.wallet.util.CommonUtil;
import com.wibmo.dfs.wallet.validation.RequestValidator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class TransactionServiceImpl implements TransactionService {

	private static final String ERROR_DESC = "Error Desc : {}";

	@Autowired
	private DozerBeanMapper mapper;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	KafkaProducer kafkaProducer;

	@Autowired
	private WalletServiceFactory findService;

	@Autowired
	WalletCardRepository walletCardRepo;

	@Autowired
	WalletToAccountService walletToAccountService;

	@Autowired
	UserConsumptionService userConsumptionService;

	@Autowired
	BLValidator blValidator;

	@Autowired
	private ProgramParametersRepository progParamRespository;

	@Autowired
	private RequestValidator validator;

	@Value("${resource.url.upiIntegrationService}")
	private String upiIntegrationServiceUrl;

	@Value("${resource.url.upiServiceSendMoney}")
	private String upiIntegrationSendMoneyUrl;

	@Value("${resource.url.orchestration}")
	private String orchestrateServiceUrl;

	@Value("${resource.url.orchestrateV1Validation}")
	private String orchestrateV1Validation;

	@Value("${resource.url.orchestrateV1Verification}")
	private String orchestrateVerification;

	@Value("${resource.url.orchestrateV1Transfer}")
	private String orchestrateV1Transfer;

	@Autowired
	private UpiIntegrationServiceAdapter upiIntegrationServiceAdapter;

	@Autowired
	private ApiManagerUtil apiManagerUtil;

	@Override
	public SendMoneyRequest prepareSendMoneyRequest(SendMoneyTransactionRequest request, String bankId, String userId) {
		String productType = request.getProductType();
		if(productType==null) {
			productType="RW";
		}
		WalletCard wc = walletCardRepo.fetchByCustIdAndProduct(userId, productType, bankId);
		SendMoneyRequest sendMoneyRequest = mapper.map(request, SendMoneyRequest.class);
		sendMoneyRequest.setProductType(productType);
		sendMoneyRequest.setRecipientMobileNo(request.getRecipientMobileNo());
		sendMoneyRequest.setSenderCustomerId(userId);
		sendMoneyRequest.setAmount(request.getAmount());
		sendMoneyRequest.setRemarks(request.getDescription());
		sendMoneyRequest.setSenderWalletId(wc.getId());
		sendMoneyRequest.setMcc(request.getMcc());
		sendMoneyRequest.setRecipientLastName(request.getBeneficiaryName());
		return sendMoneyRequest;
	}

	@Override
	public W2ADebitRequest createW2ADebitRequest(SendMoneyTransactionRequest request, String bankId, String userId) {
		W2ADebitRequest w2ADebitRequest = new W2ADebitRequest();
		w2ADebitRequest.setCustId(userId);
		w2ADebitRequest.setWalletId(request.getSenderWalletId());
		w2ADebitRequest.setFinalAmount(request.getAmount());
		w2ADebitRequest.setTxnAmount(request.getAmount());
		return w2ADebitRequest;
	}

	@Override
	public UpiTransactionRequest createUpiTransactionRequest(SendMoneyTransactionRequest request, String bankId, String userId, Object data)  {
		UpiTransactionRequest upiTransactionRequest = new UpiTransactionRequest();
		upiTransactionRequest.setPayerVpa(request.getSendervpa());
		if(StringUtils.isNotBlank(request.getIfsc()) && StringUtils.isNotBlank(request.getBeneficiaryAccountNumber())) {
			request.setRecipientvpa(request.getBeneficiaryAccountNumber()+"@"+request.getIfsc()+".ifsc.npci");
			upiTransactionRequest.setTransacType(Constants.P2P_PAY);
		}
		FundResponse debitResponse = new ObjectMapper().convertValue(data, FundResponse.class);

		upiTransactionRequest.setPayeeVpa(request.getRecipientvpa());
		upiTransactionRequest.setPayeeName(request.getBeneficiaryName());
		upiTransactionRequest.setAmount(String.valueOf(request.getAmount()));
		upiTransactionRequest.setRemarks(request.getDescription());
		upiTransactionRequest.setRefUrl(request.getRefUrl());
		upiTransactionRequest.setRefCategory(request.getRefCategory());
		Optional<String> checkRefNo = Optional.ofNullable(debitResponse.getRefNumber());
		if (checkRefNo.isPresent()) {
			upiTransactionRequest.setOriginalTxnId(debitResponse.getRefNumber());
		}
		Optional<String> checkPPTxnId = Optional.ofNullable(debitResponse.getRefNumber());
		Map<String,String> prepaidTxnDetails = new HashMap<>();
		if(checkPPTxnId.isPresent()) {

			prepaidTxnDetails.put("ppTxnId", debitResponse.getPpTxnId());
		}
		if(request.getTransactionType().equals(Constants.SCAN_PAY) || request.getTransactionType().equals(Constants.INTENT_PAY)) {
			upiTransactionRequest.setCurrency(request.getCurrency());
			upiTransactionRequest.setTransacType(request.getTransactionType());
			upiTransactionRequest.setMcc(request.getMcc());
			upiTransactionRequest.setTransacationReference(request.getTransactionReference());
			if(request.getUdfParams()!= null && upiTransactionRequest.getUdfParameters()!=null) {
				prepaidTxnDetails.putAll(request.getUdfParams());
			}
		}
		String udfParams = null;
		try {
			udfParams = new ObjectMapper().writeValueAsString(prepaidTxnDetails);
		} catch (JsonProcessingException e) {
			log.error("error in parsing Udfparams - createUpiTransactionRequest");
			e.printStackTrace();

		}
		upiTransactionRequest.setUdfParameters(udfParams);
		return upiTransactionRequest;
	}

	@Override
	public WibmoResponse makeTransaction(SendMoneyTransactionRequest sendMoneyTransactionRequest, String bankId,
										 String userId) {
		log.info("TransactionServiceImpl :: makeTransaction()");
		WibmoResponse response = new WibmoResponse();

		WibmoResponse validationResponse = blValidation(sendMoneyTransactionRequest, bankId, userId);
		if(validationResponse != null)
			return validationResponse;

		WalletService ws = findService.getService(bankId);
		String sendMoneyTransactionType = sendMoneyTransactionRequest.getTransactionType();

		switch (sendMoneyTransactionType) {
			case Constants.W2W:
				return handleW2W(sendMoneyTransactionRequest, response, bankId, userId); 
			
			case Constants.W2A:
				return handleW2A(sendMoneyTransactionRequest, response, bankId, userId);

			case (Constants.W2UPI), (Constants.INTENT_PAY), (Constants.SCAN_PAY):
				String wibmoTxnId = CommonUtil.generateWibmoTxnId();
				validator.validateW2UPIDebitRequest(sendMoneyTransactionRequest, response, bankId);
				if (response.getResCode() > 0) {
					log.info(ERROR_DESC, response.getResDesc());
					return response;
				}
				W2UPIDebitRequest w2UPIDebitRequest = prepareW2UPIDebitRequest(sendMoneyTransactionRequest, userId, wibmoTxnId);
				validator.validateUPITransactionRequest(sendMoneyTransactionRequest, response, bankId);
				try {
					//PAY_INIT
					Runnable txnInitSuccess = () -> kafkaProducer.publishUpiTxnTracking(wibmoTxnId, TxnTrackingConstants.PAYMENT_INITIATION_SUCCESS);
					new Thread(txnInitSuccess).start();
					WibmoResponse rs = w2upiTransacation(w2UPIDebitRequest, ws, bankId, userId);
					if (rs.getResCode() > 1) {
						// DEBIT FAIL
						log.info(ERROR_DESC, response.getResDesc());
						Runnable txnDebitSuccess = () -> kafkaProducer.publishUpiTxnTracking(wibmoTxnId, TxnTrackingConstants.MONEY_DEBIT_FAILURE);
						new Thread(txnDebitSuccess).start();
						return rs;
					}
					// DEBIT SUCCESS
					Runnable txnDebitSuccess = () -> kafkaProducer.publishUpiTxnTracking(wibmoTxnId, TxnTrackingConstants.MONEY_DEBIT_SUCCESS);
					new Thread(txnDebitSuccess).start();
					response = populateUpiSendMoney(sendMoneyTransactionRequest, bankId, userId, wibmoTxnId,rs.getData());

					//updating SMUserConsumption table
					WalletCard wc = walletCardRepo.fetchById(sendMoneyTransactionRequest.getSenderWalletId(), bankId);
					String cardNumber = wc.getCardNumber();
					userConsumptionService.updateSMUserConsumption(userId, cardNumber, sendMoneyTransactionRequest.getAmount(), "P2P", Integer.valueOf(bankId));
				} catch (Exception e) {
					log.error(Constants.ERR_DESC, e.getMessage());
					return response;
				}
				break;
			default:
				break;
		}

		return response;
	}
	
	private WibmoResponse handleW2W(SendMoneyTransactionRequest sendMoneyTransactionRequest, WibmoResponse response, String bankId, String userId) {
		WalletService ws = findService.getService(bankId);
		validator.validateSendMoneyTransactionRequest(sendMoneyTransactionRequest, response, bankId);
		if (response.getResCode() > 0) {
			log.info(ERROR_DESC, response.getResDesc());
			return response;
		}
		SendMoneyRequest sendMoneyRequest = prepareSendMoneyRequest(sendMoneyTransactionRequest, bankId, userId);
		return ws.sendMoney(sendMoneyRequest);
	}
	
	
	private WibmoResponse handleW2A(SendMoneyTransactionRequest sendMoneyTransactionRequest, WibmoResponse response, String bankId, String userId) {
		WalletService ws = findService.getService(bankId);
		String wibmoTxnId = CommonUtil.generateWibmoTxnId();
		String transactionMode = progParamRespository.fetchParamValueByParamName(bankId,
				ProgramParamConstants.ALLOWED_TRANSACTION_MODES);
		List<String> transactionModes = Arrays.asList(transactionMode.split("\\s*,\\s*"));
		if (transactionModes.contains(Constants.W2A)) {

			// route to orchestration v1/transfer
			W2ATransactionRequest w2atransactionRequest = new W2ATransactionRequest();
			w2atransactionRequest.setBeneficiaryId(Integer.valueOf(sendMoneyTransactionRequest.getBeneficiaryId()));
			w2atransactionRequest.setTxnType(sendMoneyTransactionRequest.getTransactionType());
			w2atransactionRequest.setTxnAmt(sendMoneyTransactionRequest.getAmount());
			w2atransactionRequest.setSourceRefId(sendMoneyTransactionRequest.getSenderWalletId());
			w2atransactionRequest.setVpaName(sendMoneyTransactionRequest.getRecipientvpa());

			final String orchestrateTransferUrl = orchestrateServiceUrl + orchestrateV1Transfer;
			MultiValueMap<String, String> orchCustomHeader = new LinkedMultiValueMap<>();
			orchCustomHeader.add("Content-Type", Constants.APPLICATION_JSON);
			orchCustomHeader.add("Accept", "application/*+json");
			orchCustomHeader.add("X-PROGRAM-ID", bankId);
			orchCustomHeader.add("X-ACCOUNT-NUMBER", userId);

			HttpEntity<Object> transferEntity = new HttpEntity<>(w2atransactionRequest, orchCustomHeader);
			ObjectMapper obj = new ObjectMapper();
			String reqJson;
			try {
				reqJson = obj.writeValueAsString(w2atransactionRequest);
				log.debug("sending request to Orchestration service : {}", reqJson);
				ResponseEntity<WibmoResponse> transferResponseEntity = restTemplate.exchange(orchestrateTransferUrl,
						HttpMethod.POST, transferEntity, WibmoResponse.class);
				WibmoResponse apiResponse = transferResponseEntity.getBody();

				if (null != apiResponse && apiResponse.getResCode() == 200) {
					response.setResCode(200);
					response.setResDesc("transaction initiation successful");
					response.setData(apiResponse);
				} else {
					response.setResCode(3);
					response.setResDesc("Internal server error");
					log.info(ERROR_DESC, response.getResDesc());
				}
			} catch (JsonProcessingException e) {
				log.error("error in sending request to Orchestration service");
				e.printStackTrace();
			}
		}

		else {
			validator.validateW2UPIDebitRequest(sendMoneyTransactionRequest, response, bankId);
			if (response.getResCode() > 0) {
				log.info(ERROR_DESC, response.getResDesc());
				return response;
			}
			

			W2UPIDebitRequest w2UPIDebitRequest = prepareW2UPIDebitRequest(sendMoneyTransactionRequest, userId, wibmoTxnId);
			validator.validateUPITransactionRequest(sendMoneyTransactionRequest, response, bankId);
			handleReturnErrorResp(response);
			try {
				//PAY_INIT_SUCCESS
				Runnable txnInitSuccess = () -> kafkaProducer.publishUpiTxnTracking(wibmoTxnId, TxnTrackingConstants.PAYMENT_INITIATION_SUCCESS);
				new Thread(txnInitSuccess).start();
				WibmoResponse wrs = w2upiTransacation(w2UPIDebitRequest, ws, bankId, userId);
				if (wrs.getResCode() > 1) {
					//Debit fail
					log.info(ERROR_DESC, response.getResDesc());
					Runnable moneyDebitFailStatus = () -> kafkaProducer.publishUpiTxnTracking(wibmoTxnId, TxnTrackingConstants.MONEY_DEBIT_FAILURE);
					new Thread(moneyDebitFailStatus).start();
					return wrs;
				}
				// Debit success
				Runnable debitSuccessStatus = () -> kafkaProducer.publishUpiTxnTracking(wibmoTxnId, TxnTrackingConstants.MONEY_DEBIT_SUCCESS);
				new Thread(debitSuccessStatus).start();
				response = populateUpiSendMoney(sendMoneyTransactionRequest, bankId, userId, wibmoTxnId,wrs.getData());

				//updating SMUserConsumption table
				log.info("updating SMUserConsumption table");
				WalletCard wc = walletCardRepo.fetchById(sendMoneyTransactionRequest.getSenderWalletId(), bankId);
				String cardNumber = wc.getCardNumber();
				userConsumptionService.updateSMUserConsumption(userId, cardNumber,
						sendMoneyTransactionRequest.getAmount(), "P2P", Integer.valueOf(bankId));
			} catch (Exception e) {
				log.error(Constants.ERR_DESC, e.getMessage());
				return response;
			}
		}	
		return response;
	}
	
	private WibmoResponse handleReturnErrorResp(WibmoResponse response) {
		if(response.getResCode()>0){
			log.info(ERROR_DESC, response.getResDesc());
		}
		return response;
	}
		
	private WibmoResponse blValidation(SendMoneyTransactionRequest sendMoneyTransactionRequest, String bankId,
											   String userId){
		// Check sender wallet is blocked or not
		WibmoResponse senderCardBlocked = blValidator.validateCardStatus(bankId,userId,2,"SENDER - CARD TEMPORARY BLOCK");
		if(senderCardBlocked != null)
			return senderCardBlocked;

		//if it is w2w check receiver's wallet status
		if(sendMoneyTransactionRequest.getTransactionType().equals(Constants.W2W)) {
			log.info("W2W txn so checking receiver card status");
			CustomerMiniProfile payeeDetails = apiManagerUtil.fetchUserProfile(bankId, null, sendMoneyTransactionRequest.getRecipientMobileNo());
			senderCardBlocked = blValidator.validateCardStatus(bankId,payeeDetails.getCustomerId(),2,"RECEIVER - CARD TEMPORARY BLOCK");
			if(senderCardBlocked != null)
				return senderCardBlocked;
		}
		//fix for MP-10788, 10640
		//validate user kycLevel to allow sendMoney to fullKycUser only
		CustomerMiniProfile custMiniProfile = apiManagerUtil.fetchUserProfile(bankId, userId, null);

		if(custMiniProfile!=null) {
			int kycLevel = custMiniProfile.getKycLevel();
			if(kycLevel<100) {
				log.error("user cannot initiate transaction. Please upgrade to full kyc");
				WibmoResponse response = new WibmoResponse();
				response.setResCode(102);
				response.setResDesc("User cannot initiate transaction. Please upgrade to full KYC");
				return response;
			}
		}
		return null;
	}

	private W2UPIDebitRequest prepareW2UPIDebitRequest(SendMoneyTransactionRequest sendMoneyTransactionRequest,
													   String userId, String wibmoTxnId) {
		W2UPIDebitRequest w2UPIDebitRequest = new W2UPIDebitRequest();
		w2UPIDebitRequest.setCustId(userId);
		w2UPIDebitRequest.setWalletId(sendMoneyTransactionRequest.getSenderWalletId());
		w2UPIDebitRequest.setFinalAmount(sendMoneyTransactionRequest.getAmount());
		w2UPIDebitRequest.setTxnAmount(sendMoneyTransactionRequest.getAmount());
		w2UPIDebitRequest.setRrn(wibmoTxnId);
		w2UPIDebitRequest.setRemarks(sendMoneyTransactionRequest.getDescription());
		if(sendMoneyTransactionRequest.getTransactionType().equals(Constants.W2A)) {
			w2UPIDebitRequest.setTxnType(Constants.W2A);
			w2UPIDebitRequest.setBeneficiaryVpa(sendMoneyTransactionRequest.getBeneficiaryAccountNumber()+"@"+sendMoneyTransactionRequest.getIfsc()+".ifsc.npci");

		} else {
			w2UPIDebitRequest.setTxnType(Constants.W2UPI);
			w2UPIDebitRequest.setBeneficiaryVpa(sendMoneyTransactionRequest.getRecipientvpa());
		}

		w2UPIDebitRequest.setBeneficiaryAccountName(sendMoneyTransactionRequest.getBeneficiaryName());
		w2UPIDebitRequest.setBeneficiaryAccountNumber(sendMoneyTransactionRequest.getBeneficiaryAccountNumber());
		w2UPIDebitRequest.setMcc(sendMoneyTransactionRequest.getMcc());
		return w2UPIDebitRequest;
	}

	private WibmoResponse populateUpiSendMoney(SendMoneyTransactionRequest sendMoneyTransactionRequest,
											   String bankId, String userId, String originalTxnId, Object data) {
		UpiTransactionRequest upiTransactionrequest = createUpiTransactionRequest(sendMoneyTransactionRequest,
				bankId, userId, data);
		upiTransactionrequest.setOriginalTxnId(originalTxnId);
		final String url = upiIntegrationServiceUrl + upiIntegrationSendMoneyUrl;
		MultiValueMap<String, String> customHeader = new LinkedMultiValueMap<>();
		customHeader.add("Content-Type", "application/json");
		customHeader.add("Accept", "application/json");
		customHeader.add("X-PROGRAM-ID", bankId);
		customHeader.add("X-ACCOUNT-NUMBER", userId);
		HttpEntity<Object> sendMoneyEntity = new HttpEntity<>(upiTransactionrequest, customHeader);
		ObjectMapper obj = new ObjectMapper();
		try {
			String reqJson = obj.writeValueAsString(upiTransactionrequest);
			log.debug("sending sendMoney request to UpiIntegration service : UpiTransactionRequest :{}",  reqJson);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
		ResponseEntity<WibmoResponse> sendMoneyResponseEntity = restTemplate.exchange(url, HttpMethod.POST,
				sendMoneyEntity, WibmoResponse.class);
		WibmoResponse apiResponse = sendMoneyResponseEntity.getBody();
		if(apiResponse!=null && (apiResponse.getResCode()!=517&&apiResponse.getResCode()!=518&&apiResponse.getResCode()!=519)) {
			log.debug("Crediting funds back to sender wallet");
			FundRequest fundLoadRequest = new FundRequest();
			fundLoadRequest.setCustId(userId);
			fundLoadRequest.setWalletId(sendMoneyTransactionRequest.getSenderWalletId());
			fundLoadRequest.setAmount(sendMoneyTransactionRequest.getAmount());
			fundLoadRequest.setRrn(CommonUtil.generateWibmoTxnId());
			fundLoadRequest.setTxnType(Constants.P2P_CREDIT);
			fundLoadRequest.setOriginalRRN(upiTransactionrequest.getOriginalTxnId());
			fundLoadRequest.setBeneficiaryName(sendMoneyTransactionRequest.getBeneficiaryName());
			WalletService ws = findService.getService(bankId);
			log.info("Crediting funds back to sender wallet successful");
			try {
				ws.fundsLoad(fundLoadRequest);
				log.info("Funds credited back to sender wallet successful");
			} catch (Exception e) {
				log.error("Error in crediting funds back to sender wallet");
			}
			return apiResponse;
		}
		log.info("apiResponse :: {}",apiResponse);
		return apiResponse;
	}

	@Override
	public WibmoResponse w2upiTransacation(W2UPIDebitRequest request, WalletService service, String bankId, String userId) {
		log.info("TransactionServiceImpl :: w2upiTransacation()");
		FundRequest fundRequest;
		WibmoResponse wibmoResponse;
		FetchCardRequest inquiry = new FetchCardRequest();
		try
		{
			inquiry.setWalletId(request.getWalletId());
			wibmoResponse = service.inquiry(inquiry);
			if(wibmoResponse.getResCode() != 1) {
				return wibmoResponse;
			}

			FetchCardResponse cardResp = (FetchCardResponse) wibmoResponse.getData();
			fundRequest = prepareWalletDebitReq(request);
			wibmoResponse = service.fundsUnload(fundRequest);
			FundResponse debitResponse = new ObjectMapper().convertValue(wibmoResponse.getData(), FundResponse.class);

			//Add Txn History kafka call
			prepareTxnHistoryData(request, debitResponse, cardResp, bankId);

		}
		catch(Exception e){
			log.error(Constants.ERR_DESC, e.getMessage());
			log.error("Exception in w2upiTransacation ::::{} ",e);
			wibmoResponse = new WibmoResponse(ServiceHttpStatus.INTERNAL_ERROR.getStatusCode(),ServiceHttpStatus.INTERNAL_ERROR.getStatusMsg());
		}
		return wibmoResponse;
	}

	public FundRequest prepareWalletDebitReq(W2UPIDebitRequest request){
		log.info("TransactionServiceImpl :: prepareWalletDebitReq()");
		FundRequest fundRequest = new FundRequest();
		fundRequest.setCustId(request.getCustId());
		fundRequest.setWalletId(request.getWalletId());
		fundRequest.setAmount(request.getFinalAmount());
		fundRequest.setRrn(request.getRrn());
		fundRequest.setTxnType(Constants.P2P_DEBIT);
		fundRequest.setSendMoneyTransactionType(request.getTxnType());
		fundRequest.setOriginalRRN(request.getRrn());
		return fundRequest;
	}

	public void prepareTxnHistoryData(W2UPIDebitRequest request, FundResponse debitResponse, FetchCardResponse cardResp, String bankId) {
		log.info("TransactionServiceImpl :: prepareTxnHistoryData");
		log.info("request :: {}",request);
		log.info("cardResp :: {}",cardResp);
		StringBuilder txnDesc = new StringBuilder();
		String maskPattern = "";
		try {
			maskPattern = progParamRespository
					.fetchParamValueByParamName(bankId, ProgramParamConstants.CARD_MASK_PATTERN);
			W2UPITxnDetailsRequest w2UPITxnDetailsRequest = new W2UPITxnDetailsRequest();
			w2UPITxnDetailsRequest.setCustomerId(request.getCustId());
			w2UPITxnDetailsRequest.setMobile(cardResp.getMobile());
			w2UPITxnDetailsRequest.setPaymentMode(cardResp.getProductType());
			w2UPITxnDetailsRequest.setTxnType(Constants.W2UPI);
			w2UPITxnDetailsRequest.setMerCategory(Constants.OTHERS);
			w2UPITxnDetailsRequest.setTxnCategory(request.getTxnType());
			w2UPITxnDetailsRequest.setTxnAmount(request.getFinalAmount());
			w2UPITxnDetailsRequest.setPaymentTxnId(request.getRrn());
			w2UPITxnDetailsRequest.setTxnStatus(Constants.TXN_STATUS_PENDING);
			w2UPITxnDetailsRequest.setTxnDate(new Date().getTime());
			w2UPITxnDetailsRequest.setRemarks(request.getRemarks());
			w2UPITxnDetailsRequest.setSourceAccount(String.valueOf(cardResp.getWalletId()));
			txnDesc.append(Constants.SENT).append(Constants.RS_SYMBOL).append(CommonUtil.decimalFormat(request.getTxnAmount())).append(Constants.TO);
			if(request.getTxnType().equals(Constants.W2A)) {
				txnDesc.append(request.getBeneficiaryAccountName());
				w2UPITxnDetailsRequest.setTxnShortDesc(request.getBeneficiaryAccountName());
				log.info("beneficiary Acc no {} & maskPattern  {}", request.getBeneficiaryAccountNumber(), maskPattern);
				w2UPITxnDetailsRequest.setDestAccount(request.getBeneficiaryVpa());
			}else if(request.getTxnType().equals(Constants.W2UPI)) {
				VerifyVpaResponse verifyVpaResponse = upiIntegrationServiceAdapter.verifyVPA(bankId,request.getBeneficiaryVpa());
				if(verifyVpaResponse != null)
					txnDesc.append(verifyVpaResponse.getName());
				else
					txnDesc.append(request.getBeneficiaryAccountName()==null ? request.getBeneficiaryVpa():request.getBeneficiaryAccountName());
				w2UPITxnDetailsRequest.setTxnShortDesc(getShortName(request,verifyVpaResponse));
				log.info("W2UPI {},{}", request.getBeneficiaryVpa(),request.getBeneficiaryVpaName());
				w2UPITxnDetailsRequest.setDestAccount(request.getBeneficiaryVpa());
			}else {
				if(StringUtils.isNotBlank(request.getBeneficiaryVpa())) {
					txnDesc.append(request.getBeneficiaryVpa());
					w2UPITxnDetailsRequest.setTxnShortDesc(request.getBeneficiaryVpa());

					String[] account = request.getBeneficiaryVpa().split("@");
					w2UPITxnDetailsRequest.setDestAccount("*".repeat(account[0].length())+"@"+account[1]);
				}
			}
			w2UPITxnDetailsRequest.setTxnDesc(txnDesc.toString());
			log.info("Txn desc {} {}",w2UPITxnDetailsRequest.getTxnDesc(), request.getTxnAmount());
			w2UPITxnDetailsRequest.setClosingBalance((long) CommonUtil.decimalFormatWithoutComma(cardResp.getBalance()));
			w2UPITxnDetailsRequest.setPpTxnId((debitResponse ==null ? null : debitResponse.getPpTxnId()));
			w2UPITxnDetailsRequest.setTxnCategory(AckTxnTypes.W2UPI_DEB.getType());
			w2UPITxnDetailsRequest.setMerCategory("Others");
			w2UPITxnDetailsRequest.setTxnFlow(Constants.OUT_TXN_FLOW);
			w2UPITxnDetailsRequest.setOriginalTxnId(request.getRrn());
			w2UPITxnDetailsRequest.setAdditionalFields("Debit Success");
			w2UPITxnDetailsRequest.setMcc(request.getMcc());
			TxnDetails txn = new TxnDetails();
			txn.setProgramId(bankId);
			txn.setTxnType(AckTxnTypes.W2UPI.getType());
			ObjectMapper obj = new ObjectMapper();
			String w2UPITxnDetailsRequestReqJson = obj.writeValueAsString(w2UPITxnDetailsRequest);
			log.debug("w2upiTxnDetailsRequest: {}", w2UPITxnDetailsRequestReqJson);
			txn.setData(w2UPITxnDetailsRequest);
			log.info("making kafka call");
			Runnable runnable = () -> kafkaProducer.publishWalletTxn(txn);
			new Thread(runnable).start();
		}
		catch(Exception e)
		{
			log.debug("failed to push record to Transaction history {} -- SourceAccount {}",request, CommonUtil.maskCardNumberWOPlaceHolder(cardResp.getCardNumber(),maskPattern));
			log.error(" Exception in prepareTxnHistoryData() :::{} ", e);
		}
	}

	public String getShortName(W2UPIDebitRequest request,VerifyVpaResponse verifyVpaResponse){
		if(verifyVpaResponse == null && StringUtils.isEmpty(request.getBeneficiaryVpaName())){
			log.info("Beneficiary Name is not null");
			return request.getBeneficiaryVpaName();
		}else{
			String name="";
			if(null!=verifyVpaResponse) {
				name = verifyVpaResponse.getName() != null ? verifyVpaResponse.getName() : verifyVpaResponse.getVpa();
			}
			log.info("Beneficiary Name is :: {}",name);
			return  name;
		}
	}


}
