package com.wibmo.dfs.wallet.model;

import java.io.Serializable;


import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UpiTransactionRequest implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private String deviceFingerprint;
	private String payerVpa;
	private String payeeVpa;
	private String payeeName;
	private String amount;
	private String upiRequestId;
	private String bankAccountUniqueId;
	private String remarks;
	private String currency;
	private String transacType;
	private boolean amountBlocked=true;
	private String refUrl;
	private String refCategory;
	private String mcc;
	private String transacationReference;
	private String udfParameters;
	private String originalTxnId;

}
