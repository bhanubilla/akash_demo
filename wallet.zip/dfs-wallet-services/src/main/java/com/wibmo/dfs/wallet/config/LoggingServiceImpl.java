package com.wibmo.dfs.wallet.config;

import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class LoggingServiceImpl implements LoggingService {

	public final Gson gson;

	public LoggingServiceImpl() {
		gson = new Gson();
	}

	@Override
	public void logRequest(HttpServletRequest httpServletRequest, Object body) {
		Map<String, String> parameters = buildParametersMap(httpServletRequest);
		log.info("---BEGIN request---");
		log.info("method=[{}]", httpServletRequest.getMethod());
		log.info("path=[{}]", httpServletRequest.getRequestURI());

		if (!parameters.isEmpty()) {
			log.debug("parameters=[{}]", parameters);
		}

		if (!ObjectUtils.isEmpty(body)) {
			log.debug("body=[{}]", gson.toJson(body));
		}
		log.info("---END request---");
		log.info("---processing...");
	}

	@Override
	public void logResponse(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse,
			Object body) {
		log.info("---BEGIN response---");
		log.info("method=[{}]", httpServletRequest.getMethod());
		log.info("path=[{}]", httpServletRequest.getRequestURI());
		log.info("responseCode=[{}]", httpServletResponse.getStatus());
		if (!ObjectUtils.isEmpty(body)) {
			log.debug("responseBody=[{}]", gson.toJson(body));
		}
		log.info("---END response---");
	}

	private Map<String, String> buildParametersMap(HttpServletRequest httpServletRequest) {
		var resultMap = new HashMap<String, String>();
		var parameterNames = httpServletRequest.getParameterNames();

		while (parameterNames.hasMoreElements()) {
			var key = parameterNames.nextElement();
			var value = httpServletRequest.getParameter(key);
			resultMap.put(key, value);
		}

		return resultMap;
	}

}