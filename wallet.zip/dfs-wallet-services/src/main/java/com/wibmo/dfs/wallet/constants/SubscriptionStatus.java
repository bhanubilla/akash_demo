package com.wibmo.dfs.wallet.constants;

public enum SubscriptionStatus {

	ACTIVE(1,"A"),PAUSE(2,"P"),INACTIVE(0,"I");
	
	private int code;
	private String status;
     SubscriptionStatus(int code, String status) {
		this.code = code;
		this.status = status;
	}
     
    public int getCode() {
    	 return this.code;
    }
    
    public String getStatus() {
    	return this.status;
    }
    
    public static String codeToStatus(int code) {
    	for(SubscriptionStatus s : SubscriptionStatus.values()) {
    		if(s.getCode() == code) return s.getStatus();
    	}
    	return null;
    }
    
    public static Integer statusToCode(String status) {
    	for(SubscriptionStatus s : SubscriptionStatus.values()) {
    		if(s.getStatus().equals(status)) return s.getCode();
    	}
    	return null;
    }
}
