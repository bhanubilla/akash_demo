package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TransactionParams {

    private String fromDate;
    private String toDate;
    private String emailId;
    private int programId;
    private int walletStatementId;
    private String userId;
    private String walletStatus;
}
