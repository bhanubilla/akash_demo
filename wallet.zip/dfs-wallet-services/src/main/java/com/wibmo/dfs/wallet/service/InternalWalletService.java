package com.wibmo.dfs.wallet.service;

import com.wibmo.dfs.wallet.model.WalletDetailsRequest;
import com.wibmo.dfs.wallet.model.WibmoResponse;

public interface InternalWalletService {
    public WibmoResponse persistWalletDetails(WalletDetailsRequest request, String programId);
}
