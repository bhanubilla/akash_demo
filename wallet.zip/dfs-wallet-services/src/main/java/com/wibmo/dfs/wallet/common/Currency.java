package com.wibmo.dfs.wallet.common;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author ajay.mahto
 */
@Data
@NoArgsConstructor
public class Currency {
    
	private String currencyCode;
	private String currencyAlfCode;
	private String currencyUnicode;
	private String currencyHtmlcode;
	private String currencyFormatString;   
   
    
}
