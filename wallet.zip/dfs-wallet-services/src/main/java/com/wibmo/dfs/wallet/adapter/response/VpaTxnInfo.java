package com.wibmo.dfs.wallet.adapter.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Timestamp;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class VpaTxnInfo implements Serializable {

	private static final long serialVersionUID = 1L;
	private long id;
	private String merchantRequestId;
	private String merchantCustomerId;
	private String customerMobileNumber;
	private String payerVpa;
	private String payeeMcc;
	private String payeeMerchantCustomerId;
	private String payeeName;
	private String payeeVpa;
	private String refUrl;
	private String bankAccountUniqueId;
	private String bankCode;
	private String maskedAccountNumber;
	private double amount;
	private String transactionType;
	private Timestamp transactionTimestamp;
	private String originalTxnId;
	private String gatewayTxnId;
	private String gatewayResponseStatus;
	private String gatewayReferenceId;
	private String gatewayResponseCode;
	private String gatewayResponseMessage;
	private String upiRequestId;
	private String status;
	private String message;
	private Timestamp updatedTs;
	private Timestamp createdTs;

	
}
