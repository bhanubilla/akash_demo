package com.wibmo.dfs.wallet.aero.repository;

import com.wibmo.dfs.cache_client.manager.DfsCacheManager;
import com.wibmo.dfs.wallet.aero.entity.AeroCMSConf;
import com.wibmo.dfs.wallet.constants.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

@Repository
@Slf4j
public class AeroCmsConfRepositoryImpl implements AeroCmsConfRepository{

	@Autowired
    private JdbcTemplate jdbcTemplate;

	@Autowired
	private DfsCacheManager cacheManager;

	private static final String CACHE_KEY = "CMS_CONF";
	
	@Override
	public AeroCMSConf fetchByPPBankId(int ppBankId, String programId) {
		AeroCMSConf value = (AeroCMSConf) cacheManager.get(CACHE_KEY + Constants.UNDER_SCORE + programId + Constants.UNDER_SCORE + ppBankId);
		if (null != value) {
			return value;
		}
		log.info("NFC - going to DB programId:{} id:{}",programId, ppBankId);
		return loadFromDB(ppBankId, programId);
	}

	@Override
	public boolean reloadAeroCMSConf(String programId, int ppBankId) {
		Object obj = cacheManager.remove(CACHE_KEY + Constants.UNDER_SCORE + programId + Constants.UNDER_SCORE + ppBankId);
		if(obj instanceof Boolean) {
			log.info("Successfully Removed from cache - programId:{} ppBankId:{}",programId,ppBankId);
			return (Boolean)obj;
		}
		else return false;
	}

	private AeroCMSConf loadFromDB(int ppBankId, String programId) {
		BeanPropertyRowMapper<AeroCMSConf> rowMapper = BeanPropertyRowMapper.newInstance(AeroCMSConf.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<AeroCMSConf> li = jdbcTemplate.query("select * from aero_cms_configurations where pp_bank_id = ?", new PreparedStatementSetter() {

			 public void setValues(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setInt(1, ppBankId);
			 }
		  }, rowMapper);
		AeroCMSConf cmsConf = !li.isEmpty()? li.get(0) : null;
		if(null != cmsConf) cacheManager.put(CACHE_KEY + Constants.UNDER_SCORE + programId + Constants.UNDER_SCORE + ppBankId, cmsConf);
		return cmsConf;
	}

}
