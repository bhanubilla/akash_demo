package com.wibmo.dfs.wallet.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RefundResponse {

	private int resCode;
	private String resDesc;
}
