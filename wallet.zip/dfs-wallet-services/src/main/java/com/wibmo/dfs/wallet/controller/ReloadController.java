package com.wibmo.dfs.wallet.controller;

import com.wibmo.dfs.wallet.constants.ServiceHttpStatus;
import com.wibmo.dfs.wallet.model.WibmoResponse;
import com.wibmo.dfs.wallet.service.ReloadService;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/wallet/internal/reload")
@RestController
@Slf4j
@ApiOperation(value = "/wallet/internal/reload", tags = "Reload Params Controller")
public class ReloadController {

    @Autowired
    ReloadService reloadService;

    @GetMapping("/prog-parameters/{paramName}")
    public WibmoResponse reloadProgParameter(@RequestHeader(name = "X-PROGRAM-ID") String programId, @PathVariable("paramName") String paramName) {
        log.info("reload prog params for programId:{} paramName:{} ", programId, paramName);
        boolean reloaded = reloadService.reloadProgParameter(programId, paramName);
        if (reloaded) {
            return new WibmoResponse(ServiceHttpStatus.SUCCESS);
        } else {
            return new WibmoResponse(ServiceHttpStatus.FAILURE);
        }
    }

    @GetMapping("/msg-detail/{msgName}")
    public WibmoResponse reloadMsgDetails(@RequestHeader(name = "X-PROGRAM-ID") String programId, @PathVariable("msgName") String msgName) {
        log.info("reload msg detail for programId:{} msgName:{} ", programId, msgName);
        boolean reloaded = reloadService.reloadMsgDetail(programId, msgName);
        if (reloaded) {
            return new WibmoResponse(ServiceHttpStatus.SUCCESS);
        } else {
            return new WibmoResponse(ServiceHttpStatus.FAILURE);
        }
    }

    @GetMapping("/cms-conf/{ppBnkId}")
    public WibmoResponse reloadAeroCmsConf(@RequestHeader(name = "X-PROGRAM-ID") String programId, @PathVariable("ppBnkId") int ppBnkId) {
        log.info("reload msg params for programId:{} ppBnkId:{} ", programId, ppBnkId);
        boolean reloaded = reloadService.reloadAeroCMSConf(programId, ppBnkId);
        if (reloaded) {
            return new WibmoResponse(ServiceHttpStatus.SUCCESS);
        } else {
            return new WibmoResponse(ServiceHttpStatus.FAILURE);
        }
    }

    @GetMapping("/pp-mstr/{ppId}")
    public WibmoResponse reloadPPMaster(@RequestHeader(name = "X-PROGRAM-ID") String programId, @PathVariable("ppId") int ppId) {
        log.info("reload msg params for programId:{} ppId:{} ", programId, ppId);
        boolean reloaded = reloadService.reloadPPMaster(programId, ppId);
        if (reloaded) {
            return new WibmoResponse(ServiceHttpStatus.SUCCESS);
        } else {
            return new WibmoResponse(ServiceHttpStatus.FAILURE);
        }
    }

    @GetMapping("/pp-bnk-mapping/{ppBnkId}")
    public WibmoResponse reloadPPBnkMapping(@RequestHeader(name = "X-PROGRAM-ID") String programId, @PathVariable("ppBnkId") int ppBnkId) {
        log.info("reload msg params for programId:{} ppBnkId:{} ", programId, ppBnkId);
        boolean reloaded = reloadService.reloadPPBnkMapping(programId, ppBnkId);
        if (reloaded) {
            return new WibmoResponse(ServiceHttpStatus.SUCCESS);
        } else {
            return new WibmoResponse(ServiceHttpStatus.FAILURE);
        }
    }

    @GetMapping("/pp-bnk")
    public WibmoResponse reloadPPBnkMapping(@RequestHeader(name = "X-PROGRAM-ID") String programId) {
        log.info("reload msg params for programId:{} ", programId);
        boolean reloaded = reloadService.reloadBankId(programId);
        if (reloaded) {
            return new WibmoResponse(ServiceHttpStatus.SUCCESS);
        } else {
            return new WibmoResponse(ServiceHttpStatus.FAILURE);
        }
    }

    @GetMapping("/wc/{walletId}")
    public WibmoResponse reloadWalletWithId(@RequestHeader(name = "X-PROGRAM-ID") String programId, @PathVariable("walletId") int walletId) {
        log.info("reload msg params for programId:{}, walletId:{} ", programId, walletId);
        boolean reloaded = reloadService.reloadWalletWithId(programId, walletId);
        if (reloaded) {
            return new WibmoResponse(ServiceHttpStatus.SUCCESS);
        } else {
            return new WibmoResponse(ServiceHttpStatus.FAILURE);
        }
    }

    @GetMapping("/wc/{custId}/{productType}")
    public WibmoResponse reloadWalletWithCustIdAndProductType(@RequestHeader(name = "X-PROGRAM-ID") String programId, @PathVariable("custId") String custId
            , @PathVariable("productType") String productType) {
        log.info("reload msg params for programId:{}, custId:{}, productType:{} ", programId, custId, productType);
        boolean reloaded = reloadService.reloadWalletWithCustIdAndProdType(programId, custId, productType);
        if (reloaded) {
            return new WibmoResponse(ServiceHttpStatus.SUCCESS);
        } else {
            return new WibmoResponse(ServiceHttpStatus.FAILURE);
        }
    }

}
