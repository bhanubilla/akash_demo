package com.wibmo.dfs.wallet.model;

import lombok.Data;

@Data
public class WalletMobileNoBasedInquiryRequest {
    private String mobileNumber;
    private int accountNumber;
    private String programId;
}
