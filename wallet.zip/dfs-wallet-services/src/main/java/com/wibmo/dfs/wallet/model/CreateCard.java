package com.wibmo.dfs.wallet.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CreateCard {
	@ApiModelProperty(required = true, dataType="String", example="RW")
	private String productType;
	
	@ApiModelProperty(required = false, dataType="long")
	private long loadAmt;
	
	@ApiModelProperty(required = true)
	private UserInfo user;
	
	
}
