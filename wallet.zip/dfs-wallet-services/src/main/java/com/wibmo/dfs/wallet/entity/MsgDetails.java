/**
 * 
 */
package com.wibmo.dfs.wallet.entity;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
public class MsgDetails implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String msgName;
	private String msgDesc;

}
