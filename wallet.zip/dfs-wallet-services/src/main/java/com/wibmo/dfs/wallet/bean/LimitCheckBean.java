/**
 * 
 */
package com.wibmo.dfs.wallet.bean;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
public class LimitCheckBean {
	
	private String limitDefinition;
	private String errorMsg;
	private boolean limitExceeded;

}
