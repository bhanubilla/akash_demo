/**
 * 
 */
package com.wibmo.dfs.wallet.service;

import java.util.List;

import com.wibmo.dfs.platform.fw.multitenantconfig.ThreadLocalStorage;
import com.wibmo.dfs.wallet.model.*;
import com.wibmo.dfs.wallet.repository.MsgsRepository;
import com.wibmo.dfs.wallet.repository.ProgramParametersRepository;
import com.wibmo.dfs.wallet.util.ApiManagerUtil;
import org.apache.http.HttpHeaders;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.wallet.bean.ChargeOrEnquiryRequest;
import com.wibmo.dfs.wallet.bean.RefundRequest;
import com.wibmo.dfs.wallet.bean.SubscriptionDetails;
import com.wibmo.dfs.wallet.bean.SubscriptionInfo;
import com.wibmo.dfs.wallet.bean.TxnEnquiry;
import com.wibmo.dfs.wallet.bean.UserSubscriptions;
import com.wibmo.dfs.wallet.common.MsgConstants;
import com.wibmo.dfs.wallet.common.ProgramParamConstants;
import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.constants.SubscriptionStatus;
import com.wibmo.dfs.wallet.entity.AutoTopupSubscriptions;
import com.wibmo.dfs.wallet.repository.AutoTopupSubscriptionRepository;
import com.wibmo.dfs.wallet.util.CommonUtil;

import lombok.extern.slf4j.Slf4j;

import javax.ws.rs.core.MediaType;

/**
 * @author rajasekhar.kaniti
 *
 */
@Slf4j
@Service
public class AutoTopupServiceImpl implements AutoTopupService {

	@Autowired
	private AutoTopupSubscriptionRepository autoTopupSubRepo;

	@Autowired
	private MsgsRepository msgsRepository;

	@Autowired
	private ProgramParametersRepository progParamRespository;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	public DozerBeanMapper dozerBeanMapper;

	@Value("${resource.url.payment}")
	private String paymentServiceUrl;

	@Autowired
	private ApiManagerUtil apiManagerUtil;

	@Override
	public WibmoResponse authStatusUpdate(AutoTopupAuthStatusUpdateRequest authStatusUpdateReq, int bankId) {
		WibmoResponse response = new WibmoResponse();
		AutoTopupSubscriptions autoTopupSubscription = autoTopupSubRepo
				.fetchByMerRefIdAndCustId(authStatusUpdateReq.getCustomerId(), authStatusUpdateReq.getMerchnatTxnId());
		if (null != autoTopupSubscription) {
			log.info("authentication  status : {}", authStatusUpdateReq.isAuthentication());
			if (authStatusUpdateReq.isAuthentication()) {
				autoTopupSubscription.setRemarks(Constants.AUTHN_SUCCESS);
				autoTopupSubscription.setSubDesc(autoTopupSubscription.getSubDesc() + " | " + Constants.AUTHN_SUCCESS);
				autoTopupSubscription.setPaymentRefId(authStatusUpdateReq.getRecurringPaymentRefId());
				autoTopupSubRepo.updateStatus(autoTopupSubscription);

				log.info("call to charge API to do dummy autherization for customer id : {} ",
						authStatusUpdateReq.getCustomerId());
				chargeOrEnquiry(authStatusUpdateReq, response, autoTopupSubscription, String.valueOf(bankId));
			} else {
				log.info("authentication false for customer id : {} ", authStatusUpdateReq.getCustomerId());
				autoTopupSubscription.setStatus(null);
				autoTopupSubscription.setRemarks(Constants.AUTHN_FAILED);
				autoTopupSubscription.setSubDesc(autoTopupSubscription.getSubDesc() + " | " + Constants.AUTHN_FAILED);
				response.setResCode(150);
				response.setResDesc(Constants.AUTHN_FAILED);
				autoTopupSubRepo.updateStatus(autoTopupSubscription);

			}
		} else {
			log.info("Customer details not found in DB for customer id : {} and merchant reference id : {}",
					authStatusUpdateReq.getCustomerId(), authStatusUpdateReq.getMerchnatTxnId());
			response.setResCode(100);
			response.setResDesc("Txn Details not found.. Please try with valid details");
			return response;
		}

		return response;
	}

	@Override
	public WibmoResponse fetchSubscriptionStatus(AutoTopupStatusRequest autoTopupStatusRequest, String bankId) {
		log.info("request to fetch autotopup status for customer id : {}", autoTopupStatusRequest.getCustomerId());
		WibmoResponse response = new WibmoResponse();
		AutoTopupSubscriptions subStatus = autoTopupSubRepo.fetchStatusByCustId(autoTopupStatusRequest.getCustomerId());
		if (null != subStatus) {
			AutoTopupStatusResponse statusResp = new AutoTopupStatusResponse();
			statusResp.setStatus(subStatus.getStatus());
			statusResp.setThresholdAmt(subStatus.getThresholdAmt());
			statusResp.setTopupAmt(subStatus.getTopupAmt());
			statusResp.setRemarks(subStatus.getRemarks());
			if (Constants.AUTOTOPUP_STATUS_ACTIVE.equalsIgnoreCase(subStatus.getStatus())) {
				setSubscriptionInfo(autoTopupStatusRequest, subStatus, statusResp, bankId);

				response.setResCode(200);
				response.setResDesc("autotopup status fetched successfully");

				log.info("auto topup status is : {} for customer id: {} ", subStatus,
						autoTopupStatusRequest.getCustomerId());
			} else if (Constants.AUTOTOPUP_STATUS_INACTIVE.equalsIgnoreCase(subStatus.getStatus())) {
				setSubscriptionInfo(autoTopupStatusRequest, subStatus, statusResp, bankId);
				response.setResCode(150);
				response.setResDesc("status is inactive");
			} else {
				response.setResCode(100);
				response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.AUTO_TOPUP_NOT_SUBSCRIBED));
			}
			response.setData(statusResp);

		} else {
			response.setResCode(100);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.AUTO_TOPUP_NOT_SUBSCRIBED));
			log.info("no data found for this customer id : {} ", autoTopupStatusRequest.getCustomerId());
		}

		return response;
	}

	private void setSubscriptionInfo(AutoTopupStatusRequest autoTopupStatusRequest, AutoTopupSubscriptions subStatus, AutoTopupStatusResponse statusResp, String bankId) {
		SubscriptionInfo subscriptionInfo = userSubscriptionsAPi(autoTopupStatusRequest, bankId);
		if (null != subscriptionInfo) {
			if (null == subscriptionInfo.getCardMaskedNumber()) {
				subscriptionInfo.setCardMaskedNumber(subStatus.getCardNumber());
			}
			statusResp.setSubscriptionInfo(subscriptionInfo);
		}
	}

	@Override
	public WibmoResponse autoTopupInit(AutoTopupInitRequest autoTopupInitRequest, String bankId) {
		log.info("requestfor autotopup init for customer id : {}", autoTopupInitRequest.getCustomerId());
		WibmoResponse response = new WibmoResponse();
		AutoTopupInitResponse initRes = new AutoTopupInitResponse();
		String txnId = CommonUtil.generateWibmoTxnId();
		AutoTopupSubscriptions autoTopupSubscription = null;
		autoTopupSubscription = autoTopupSubRepo.fetchByCustId(autoTopupInitRequest.getCustomerId());
		if (null != autoTopupSubscription
				&& Constants.AUTOTOPUP_STATUS_ACTIVE.equals(autoTopupSubscription.getStatus())) {
			log.info("auto topup subscription already enabled for customer id: {} ",
					autoTopupInitRequest.getCustomerId());
			response.setResCode(250);
			response.setResDesc("auto topup subscription already enabled");
			return response;
		} else {
			autoTopupSubscription = new AutoTopupSubscriptions();
			autoTopupSubscription.setCustomerId(autoTopupInitRequest.getCustomerId());
			autoTopupSubscription.setMerchantRefId(txnId);
			autoTopupSubscription.setSubDesc("Autotopup Subscription Init");
			initRes.setMerchantId(progParamRespository.fetchParamValueByParamName(bankId,ProgramParamConstants.LM_MER_ID_KEY));
			initRes.setMerchantName(
					progParamRespository.fetchParamValueByParamName(bankId,ProgramParamConstants.LM_MER_NAME_KEY));
			initRes.setMerchantTxnId(txnId);
			int id = autoTopupSubRepo.save(autoTopupSubscription);

			if (id > 0) {
				log.info("auto topup init data saved successfully for customer id: {} ",
						autoTopupInitRequest.getCustomerId());
				response.setResCode(200);
				response.setResDesc("AutoTopup subscription Initiated Successfully");
				response.setData(initRes);
			} else {
				log.info("auto topup initiation failed for customer id: {} ", autoTopupInitRequest.getCustomerId());
				response.setResCode(100);
				response.setResDesc("AutoTopup subscription Initiation failed.. Please try after some time.");
			}
		}

		return response;
	}

	private void chargeOrEnquiry(AutoTopupAuthStatusUpdateRequest authStatusUpdateReq, WibmoResponse response,
			AutoTopupSubscriptions autoTopupSubscription, String bankId) {
		ChargeOrEnquiryRequest chrgReq = prepareChargeReq(authStatusUpdateReq, bankId);
		WibmoResponse chrgResp = null;

		try {
			chrgResp = CommonUtil.invokeApi(restTemplate, HttpMethod.POST, paymentServiceUrl, Constants.CHRG_ENQUIRY_EP, bankId,
					chrgReq);
		} catch (Exception e) {
			log.error("payment charge api exception :" + e.getMessage());
		}

		if (null != chrgResp) {
			log.info("charge API response code : {} , response desc :{} ", chrgResp.getResCode(),
					chrgResp.getResDesc());
			TxnEnquiry txn = null!= chrgResp.getData() ? dozerBeanMapper.map(chrgResp.getData(),TxnEnquiry.class) : null ;
			if (chrgResp.getResCode() == 200 && (null!= txn && txn.getPgStatusCode().equalsIgnoreCase(Constants.PG_SUCCESS_CODE))) {
				log.info("charge is success for customer id: {} ", autoTopupSubscription.getCustomerId());
				
				prepareAutoTopupSubInfo(authStatusUpdateReq, autoTopupSubscription);
				autoTopupSubscription
						.setSubDesc(autoTopupSubscription.getSubDesc() + " | " + Constants.AUTHERIZATION_SUCCESS);
				autoTopupSubscription.setRemarks(chrgResp.getResDesc());
				autoTopupSubscription.setCardNumber(txn.getCardMasked());
				int subscriptionUpdated = autoTopupSubRepo.update(autoTopupSubscription);
				if (subscriptionUpdated > 0)
					log.info("auto subscription details updated in DB successfully for customer id: {} ",
							autoTopupSubscription.getCustomerId());

				response.setResCode(chrgResp.getResCode());
				response.setResDesc(chrgResp.getResDesc());

				Runnable refundReq = () -> initiateRefundReq(authStatusUpdateReq, autoTopupSubscription, bankId);

				new Thread(refundReq).start();

			} else {
				log.info("charge req is failed: " + chrgResp.getErrorMessage());
				response.setResCode(chrgResp.getResCode());
				response.setResDesc(chrgResp.getResDesc());
				autoTopupSubscription.setStatus(Constants.AUTOTOPUP_STATUS_INACTIVE);
				autoTopupSubscription.setRemarks(chrgResp.getErrorMessage());
				autoTopupSubscription
						.setSubDesc(autoTopupSubscription.getSubDesc() + " | " + Constants.AUTHERIZATION_FAILED);
				autoTopupSubRepo.updateStatus(autoTopupSubscription);

			}
		} else {
			log.info("Payment service resp is null");
			response.setResCode(100);
			response.setResDesc("Payment service not responding.. please try after some time");
		}
	}

	private void prepareAutoTopupSubInfo(AutoTopupAuthStatusUpdateRequest authStatusUpdateReq,
			AutoTopupSubscriptions subscriptionData) {
		subscriptionData.setStatus(Constants.AUTOTOPUP_STATUS_ACTIVE);
		subscriptionData.setThresholdAmt(authStatusUpdateReq.getThresholdAmt());
		subscriptionData.setTopupAmt(authStatusUpdateReq.getTopupAmt());
		subscriptionData.setWalletId(authStatusUpdateReq.getWalletId());
		subscriptionData.setWibmoTxnId(authStatusUpdateReq.getWibmoTxnId());
	}

	private ChargeOrEnquiryRequest prepareChargeReq(AutoTopupAuthStatusUpdateRequest authStatusUpdateReq, String bankId) {
		ChargeOrEnquiryRequest chrgReq = new ChargeOrEnquiryRequest();
		chrgReq.setChargeCard(!Boolean.parseBoolean(authStatusUpdateReq.getChargeAttempted()));
		chrgReq.setMerchantId(progParamRespository.fetchParamValueByParamName(bankId,ProgramParamConstants.LM_MER_ID_KEY));
		chrgReq.setMerchantName(progParamRespository.fetchParamValueByParamName(bankId,ProgramParamConstants.LM_MER_NAME_KEY));
		chrgReq.setMerchantRefNumber(authStatusUpdateReq.getMerchnatTxnId());
		chrgReq.setTxnAmt(100);
		chrgReq.setTxnDate(authStatusUpdateReq.getTxnDate());
		return chrgReq;
	}

	private void initiateRefundReq(AutoTopupAuthStatusUpdateRequest authStatusUpdateReq,
			AutoTopupSubscriptions autoTopupSubscription, String bankId) {
		try {
			//to support new thread..
			ThreadLocalStorage.setTenantId(Integer.parseInt(bankId));
			RefundRequest refundReq = new RefundRequest();
			WibmoResponse refundResp = null;
			refundReq.setInitiateRefund(true);
			refundReq.setMerchantId(progParamRespository.fetchParamValueByParamName(bankId,ProgramParamConstants.LM_MER_ID_KEY));
			refundReq.setMerchantRefNumber(autoTopupSubscription.getMerchantRefId());
			refundReq.setTxnAmt(100);
			refundReq.setRefundType("Enrollment Refund");
			refundReq.setTxnDate(authStatusUpdateReq.getTxnDate());

			refundResp = getRefundResp(bankId, refundReq, refundResp);

			if (null != refundResp) {
				log.info("Refund Response code : {} response desc: {}", refundResp.getResCode(), refundResp.getResDesc());
				if (refundResp.getResCode() == 200) {
					log.info("Refund has successfully done for customer id: {} ", autoTopupSubscription.getCustomerId());
					autoTopupSubscription.setRefundStatus(Constants.REFUND_SUCCESS);
					autoTopupSubscription
							.setSubDesc(autoTopupSubscription.getSubDesc() + " | " + Constants.REFUND_SUCCESSFULLY);
				} else {
					log.info("Refund has failed for customer id: {} ", autoTopupSubscription.getCustomerId());
					autoTopupSubscription.setRefundStatus(Constants.REFUND_FAILED);
					autoTopupSubscription.setSubDesc(autoTopupSubscription.getSubDesc() + " | " + Constants.REFUND_FAILURE);
				}

			} else {
				log.error("payment service is not responding..");
				autoTopupSubscription.setRefundStatus(Constants.REFUND_FAILED);
				autoTopupSubscription.setSubDesc(autoTopupSubscription.getSubDesc() + " | " + Constants.REFUND_FAILURE);
			}
			boolean refundStatus = autoTopupSubRepo.updateRefundStatus(autoTopupSubscription);
			if (refundStatus) {
				log.info("refund status updated successfully for customer id: {}", authStatusUpdateReq.getCustomerId());
			} else {
				log.info("failed to update refund status for customer id: {}", authStatusUpdateReq.getCustomerId());
			}
		} catch(Exception e) {
			log.error("error in"+e);
		}finally {
			ThreadLocalStorage.clear();
		}
	}

	private WibmoResponse getRefundResp(String bankId, RefundRequest refundReq, WibmoResponse refundResp) {
		try {
			refundResp = CommonUtil.invokeApi(restTemplate, HttpMethod.POST, paymentServiceUrl, Constants.REFUND_EP, bankId, refundReq);
		} catch (Exception e) {
			log.error("exception in Refund Api: {}", e.getMessage());
		}
		return refundResp;
	}

	private SubscriptionInfo userSubscriptionsAPi(AutoTopupStatusRequest autoTopupStatusRequest, String bankId) {
		CustomerMiniProfile miniProfile = apiManagerUtil.fetchUserProfile(bankId, autoTopupStatusRequest.getCustomerId(), null);
		UserSubscriptions userSub = new UserSubscriptions(autoTopupStatusRequest.getCountryCode(),
				null != miniProfile ? miniProfile.getMobileNo(): null);
		SubscriptionInfo subscriptionInfo = null;
		WibmoResponse resp = null;
		try {
			MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
			custHeader.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
			custHeader.add(Constants.X_PROGRAM_ID, bankId);
			custHeader.add(Constants.X_ACCOUNT_NUMBER, autoTopupStatusRequest.getCustomerId());
			HttpEntity<Object> entity = new HttpEntity<>(userSub, custHeader);
			ResponseEntity<WibmoResponse> responseEntity = restTemplate.postForEntity( paymentServiceUrl+Constants.FETCH_SUBS_EP,entity,WibmoResponse.class);
			resp = responseEntity.getBody();
		} catch (Exception e) {
			log.error("payment user subscriptions api exception : {}", e);
		}

		if (null != resp) {
			log.info("Payment user subscription API response code : {} , response desc :{} ", resp.getResCode(),
					resp.getResDesc());
			if (resp.getResCode() == 200) {
				List<SubscriptionDetails> listOfSubDetails = new ObjectMapper().convertValue(resp.getData(),
						new TypeReference<List<SubscriptionDetails>>() {
						});
				for (SubscriptionDetails subscriptionDetails : listOfSubDetails) {
					if (null!= subscriptionDetails && subscriptionDetails.getMerchantId().equals(
							progParamRespository.fetchParamValueByParamName(bankId,ProgramParamConstants.LM_MER_ID_KEY))) {
						subscriptionInfo = dozerBeanMapper.map(subscriptionDetails.getSubscriptionInfo(),
								SubscriptionInfo.class);
						log.info("SubscriptionInfo data received from payment service");
						subscriptionInfo.setRecurringPaymentRefId(subscriptionDetails.getRecurringPaymentRefId());
						subscriptionInfo.setMerchantId(subscriptionDetails.getMerchantId());
						subscriptionInfo.setSubscriberId(subscriptionDetails.getSubscriberId());
					}
				}
			}
		}
		return subscriptionInfo;
	}

	@Override
	public WibmoResponse modifyAutoTopup(ModifyAutotopupRequest modifyAutotopupRequest, String bankId) {
		UpdateAutoTopupSubscriptionRequest req = new UpdateAutoTopupSubscriptionRequest();
		req.setMerchantId(modifyAutotopupRequest.getMerchantId());
		req.setRecurringPaymentRefId(modifyAutotopupRequest.getRecurringPaymentRefId());
		req.setStatus(SubscriptionStatus.statusToCode(modifyAutotopupRequest.getStatus()));
		req.setTopUpAmount(modifyAutotopupRequest.getTopupAmt());
		req.setUserId(Long.valueOf(modifyAutotopupRequest.getCustomerId()));
		WibmoResponse subsResp = new WibmoResponse();
		WibmoResponse resp = null;
		try {
			resp = CommonUtil.invokeApi(restTemplate, HttpMethod.PUT, paymentServiceUrl, Constants.UPDATE_SUBS_EP, bankId, req);
		} catch (Exception e) {
			log.error("Modify Autotopup subscription api exception :" + e.getMessage());
		}
		req.setThresholdAmt(modifyAutotopupRequest.getThresholdAmt());
		if (null != resp) {
			log.info("update Autotopup subscription API response code : {} , response desc :{} ", resp.getResCode(),
					resp.getResDesc());
			if (resp.getResCode() == 200) {
				updateSubscription(req, subsResp);
			} else {
				subsResp.setResCode(180);
				subsResp.setResDesc("Payment Api Failed");
			}
		} else {
			subsResp.setResCode(150);
			subsResp.setResDesc("Some thing went wrong..");
		}
		return subsResp;
	}

	/**
	 * @param req
	 * @return
	 */
	private WibmoResponse updateSubscription(UpdateAutoTopupSubscriptionRequest req, WibmoResponse subsResp) {
		AutoTopupSubscriptions subscription = autoTopupSubRepo.fetchByCustId(String.valueOf(req.getUserId()));
		subscription.setStatus(SubscriptionStatus.codeToStatus(req.getStatus()));
		subscription.setThresholdAmt(req.getThresholdAmt() > 0 ? req.getThresholdAmt() : subscription.getThresholdAmt());
		subscription.setTopupAmt(req.getTopUpAmount());
		subscription.setPaymentRefId(req.getRecurringPaymentRefId());
		boolean flag = autoTopupSubRepo.updateSubscription(subscription);
		if (flag) {
			subsResp.setResCode(200);
			subsResp.setResDesc("Subscription updated Successfully..");
		} else {
			subsResp.setResCode(100);
			subsResp.setResDesc("update Subscription Failed..");
		}
		return subsResp;
	}

	@Override
	public WibmoResponse updateAutoTopup(UpdateAutoTopupSubscriptionRequest updateAutotopupRequest) {
		WibmoResponse resp = new WibmoResponse();
		return updateSubscription(updateAutotopupRequest, resp);
	}

}
