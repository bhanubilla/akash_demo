/**
 * 
 */
package com.wibmo.dfs.wallet.controller;

import com.wibmo.dfs.platform.fw.multitenantconfig.ThreadLocalStorage;
import com.wibmo.dfs.wallet.model.UserACSCheckRequest;
import com.wibmo.dfs.wallet.model.WibmoResponse;
import com.wibmo.dfs.wallet.service.UserACSService;
import com.wibmo.dfs.wallet.util.CommonUtil;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.ws.rs.FormParam;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * @author rajasekhar.kaniti
 *
 */
@Slf4j
@RestController
@RequestMapping("/wibmoServices/wallet")
public class UserACSController {
	
	@Autowired
	private UserACSService userACSService;
	
	@ApiOperation(value="ITP Check API")
	@ApiResponses(value={
			@ApiResponse(code = 0, message = "Success",response =WibmoResponse.class),
			@ApiResponse(code = 101, message = "Card not found",response =WibmoResponse.class),
			@ApiResponse(code = 103, message = "cardNumber not passed (or) phoneNumber not passed (or) Internal error",response =WibmoResponse.class),
			@ApiResponse(code = 107, message = "Mobile number not found or not verified",response =WibmoResponse.class),
			
	})

	@PostMapping("/userCheck/api/v1")
	public String userCheck(@FormParam("bankId") String bankId, 
            @FormParam("cardNumber") String cardNumber, @FormParam("phoneNumber") String phoneNumber,
              @FormParam("dobYYYYMMDD") String dob){
		Thread.currentThread().setName("ITP Check");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), phoneNumber);
		StringBuilder resultString = new StringBuilder(50);
		Calendar cal = new GregorianCalendar();
		SimpleDateFormat ddMMyyyyHHmmssFormat = new SimpleDateFormat("ddMMyyyyHHmmss");
		resultString.append("response_timestamp=").append(ddMMyyyyHHmmssFormat.format(cal.getTime())).append("&");
		log.info("Bank Id : {} phoneNumber : {}",bankId,phoneNumber);

		if (cardNumber == null || cardNumber.isEmpty()) {
			resultString.append("error_code=").append("103");
			resultString.append("&");
			resultString.append("error_desc=").append("cardNumber not passed");
			return resultString.toString();
		}

		if (phoneNumber == null || phoneNumber.isEmpty()) {
			resultString.append("error_code=").append("103");
			resultString.append("&");
			resultString.append("error_desc=").append("phoneNumber not passed");
			return resultString.toString();
		}
		
		UserACSCheckRequest userCheckACSReq = new UserACSCheckRequest();
		// temp fix: ignoring sonar lint issue
		// sonar lint fix
		if (null != bankId) {
			userCheckACSReq.setBankId(bankId.equals("1111") ? bankId : "1111");
		} else {
			userCheckACSReq.setBankId("1111");
		}
		userCheckACSReq.setDob(dob);
		userCheckACSReq.setMobileNo(phoneNumber);
		userCheckACSReq.setWalletCardNumber(cardNumber);
		try {
			ThreadLocalStorage.setTenantId(Integer.parseInt(userCheckACSReq.getBankId()));
			userACSService.userCheck(userCheckACSReq, resultString);
		} finally {
			ThreadLocalStorage.clear();
		}
		return resultString.toString();
	}

}
