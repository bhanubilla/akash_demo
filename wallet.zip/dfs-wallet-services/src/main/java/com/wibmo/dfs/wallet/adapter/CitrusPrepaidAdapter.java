package com.wibmo.dfs.wallet.adapter;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.wallet.adapter.request.MobilenumberBasedCardInquiryRequest;
import com.wibmo.dfs.wallet.adapter.response.EncMobileNoBasedCardInquiryResponse;
import com.wibmo.dfs.wallet.adapter.response.MobilenumberBasedCardInquiryResponse;
import com.wibmo.dfs.wallet.adapter.util.AESGCMPayLoadEncryption;
import com.wibmo.dfs.wallet.aero.entity.AeroCMSConf;
import com.wibmo.dfs.wallet.aero.repository.AeroCmsConfRepository;
import com.wibmo.dfs.wallet.common.ProgramParamConstants;
import com.wibmo.dfs.wallet.constants.ServiceHttpStatus;
import com.wibmo.dfs.wallet.entity.PrepaidBankMapping;
import com.wibmo.dfs.wallet.model.WalletMobileNoBasedInquiryRequest;
import com.wibmo.dfs.wallet.model.WibmoResponse;
import com.wibmo.dfs.wallet.repository.ProgramParametersRepository;
import com.wibmo.dfs.wallet.service.WalletServiceFactory;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CitrusPrepaidAdapter {
	
    //public static final String X_API_KEY_VALUE = "lll1234395";
    public static final String WIBMOINQUIRY = "WIBMOINQUIRY_";
    public static final String APPLICATION_JSON = "application/json";
    public static final String MOBILE_NUMBER_BASED_CARD_INQUIRY = "/api/v1/mobileNumberBasedCardInquiry";

    @Autowired
    private RestTemplate restTemplate;
    
    @Autowired
    private AESGCMPayLoadEncryption aesgcmPayLoadEncryption;

    @Autowired
    private AeroCmsConfRepository aeroConfRepository;

    @Autowired
    private WalletServiceFactory findService;

    @Autowired
    private ProgramParametersRepository progParamRespository;
    private String xApiKey = "x-api-key";
    private String contentType = "Content-Type";
    private static final String COUNTRY_CODE = "91";
    //private String  privateKey = "KbPdSgVkYp3s6v9y";

    public WibmoResponse getCustomerProfile(WalletMobileNoBasedInquiryRequest walletMobileNoBasedInquiryRequest){
        WibmoResponse response = null;
        Date requestingTime = new Date();
        log.info("requesting time {}",requestingTime);
        try{
            log.info("CitrusPrepaidAdapter :: getCustomerProfile for mobile number {}",walletMobileNoBasedInquiryRequest.getMobileNumber());
        findService.getService(walletMobileNoBasedInquiryRequest.getProgramId());
        PrepaidBankMapping mapping = findService.fetchBankMapping();
        log.info("mapping :: {}",mapping);
        AeroCMSConf cmsConfig = aeroConfRepository.fetchByPPBankId(mapping.getId(),mapping.getBankId());
        log.info("cmsConfig :: {}",cmsConfig);
        MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
            String apiKeyValue = progParamRespository.fetchParamValueByParamName(walletMobileNoBasedInquiryRequest.getProgramId(), ProgramParamConstants.CITRUS_X_API_KEY_VALUE);
            String privateKey = progParamRespository.fetchParamValueByParamName(walletMobileNoBasedInquiryRequest.getProgramId(), ProgramParamConstants.CITRUS_ENC_DEC_PVT_KEY);
            custHeader.add(xApiKey, apiKeyValue);
        custHeader.add(contentType, APPLICATION_JSON);
        MobilenumberBasedCardInquiryRequest request = new MobilenumberBasedCardInquiryRequest();
        request.setMessageCode(1930);
        request.setBankId(Integer.parseInt(cmsConfig.getSourceAccount()));
        request.setClientId(cmsConfig.getClientId());
        request.setRequestDateTime(getCurrentTime());
        request.setClientTxnId(getUniqueRandomString(WIBMOINQUIRY,walletMobileNoBasedInquiryRequest));
        request.setCardHolderMobileNumber(COUNTRY_CODE+walletMobileNoBasedInquiryRequest.getMobileNumber());
        request.setSecureCode(cmsConfig.getSecureCode());
        ObjectMapper obj = new ObjectMapper();
        obj.writer().withDefaultPrettyPrinter();
            String reqJson = obj.writeValueAsString(request);
            String encryptedReq = aesgcmPayLoadEncryption.encrypt(reqJson,privateKey);
            String reqBody = "{\"token\":\"" +encryptedReq+ "\"}";
            HttpEntity<Object> entity = new HttpEntity<>(reqBody, custHeader);
            String url = cmsConfig.getUrl().concat(MOBILE_NUMBER_BASED_CARD_INQUIRY);
            log.info("url :: {}, request ::{}",url,reqBody);
            ResponseEntity<EncMobileNoBasedCardInquiryResponse> responseEntity = restTemplate.exchange(url, HttpMethod.POST, entity,EncMobileNoBasedCardInquiryResponse.class);
            if(responseEntity.getStatusCode() == HttpStatus.OK){
                log.info("SUCCESS response from prepaid");
                EncMobileNoBasedCardInquiryResponse encrptedResp =  responseEntity.getBody();
                log.info("encryptedResp :: {}",encrptedResp);
                String resp=null;
                if(encrptedResp!=null)
                    resp = aesgcmPayLoadEncryption.decrypt(encrptedResp.getToken(),privateKey);
                MobilenumberBasedCardInquiryResponse inquiryResponse = obj.readValue(resp,MobilenumberBasedCardInquiryResponse.class);
                response = new WibmoResponse(ServiceHttpStatus.SUCCESS,inquiryResponse);
                Date responseTime = new Date();
                log.info("success response time :: {}",responseTime.getTime() - requestingTime.getTime());
               return response;
            }else{
                log.error("Exception in prepaid :: {} ,  response code ::{}", responseEntity.getBody(),responseEntity.getStatusCode());
                Date responseTime = new Date();
                log.info("Exception response time :: {}",responseTime.getTime() - requestingTime.getTime());
                return new WibmoResponse(ServiceHttpStatus.FAILURE);
            }
        }catch (Exception ex){
            log.error("error while communicating prepaid :: {}",ex);
            Date responseTime = new Date();
            log.info("Exception response time :: {}",responseTime.getTime() - requestingTime.getTime());
            return new WibmoResponse(ServiceHttpStatus.FAILURE);
        }
    }
    
    protected String getUniqueRandomString(String type,WalletMobileNoBasedInquiryRequest request) {
        StringBuilder sb = new StringBuilder(type);
        sb.append(new Date().getTime());
        sb.append(request.getMobileNumber().substring(6));
        sb.append(request.getAccountNumber());
        return sb.toString();
    }

    private String getCurrentTime(){
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMddHHmmss");
        return f.format(new Date());
    }
}
