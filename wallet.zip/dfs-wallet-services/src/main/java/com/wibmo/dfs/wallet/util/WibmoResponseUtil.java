package com.wibmo.dfs.wallet.util;

import com.wibmo.dfs.wallet.model.WibmoResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class WibmoResponseUtil {
	private WibmoResponseUtil() {}

	public static ResponseEntity<WibmoResponse> frameResponse(WibmoResponse resp) {
		HttpStatus status = HttpStatus.OK;

		return new ResponseEntity<>(resp, status);
	}
}
