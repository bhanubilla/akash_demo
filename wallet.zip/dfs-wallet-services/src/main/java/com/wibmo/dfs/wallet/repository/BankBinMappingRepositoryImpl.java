/**
 * 
 */
package com.wibmo.dfs.wallet.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.wibmo.dfs.wallet.entity.BankBinMapping;

/**
 * @author rajasekhar.kaniti
 *
 */
@Repository
public class BankBinMappingRepositoryImpl implements BankBinMappingRepository {

	private static final String INSERT_QUERY = "INSERT INTO BANK_BIN_MAPPING (bin, country_code, card_type, card_union, bank_name, card_association, on_us, status)"
			+ " VALUES (?,?,?,?,?,?,?,?)";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int save(BankBinMapping bankBinMapping) {
		KeyHolder keyHolder = new GeneratedKeyHolder();

		jdbcTemplate.update(connection -> {
			PreparedStatement preparedStmt = connection.prepareStatement(INSERT_QUERY, Statement.RETURN_GENERATED_KEYS);
			int i = 1;
			preparedStmt.setString(i++, bankBinMapping.getBin());
			preparedStmt.setString(i++, bankBinMapping.getCountryCode());
			preparedStmt.setString(i++, bankBinMapping.getCardType());
			preparedStmt.setString(i++, bankBinMapping.getCardUnion());
			preparedStmt.setString(i++, bankBinMapping.getBankName());
			preparedStmt.setString(i++, bankBinMapping.getCardAssociation());
			preparedStmt.setInt(i++, bankBinMapping.getOnUs());
			preparedStmt.setInt(i++, bankBinMapping.getStatus());

			return preparedStmt;
		}, keyHolder);

		Number key = keyHolder.getKey();
		return null != key ? key.intValue() : 0;
	}

	@Override
	public int update(BankBinMapping bankBinMapping, int id) {
		return 0;
	}

	@Override
	public BankBinMapping getByBin(String bin) {
		BeanPropertyRowMapper<BankBinMapping> rowMapper = BeanPropertyRowMapper.newInstance(BankBinMapping.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<BankBinMapping> list = jdbcTemplate.query("select * from bank_bin_mapping  where bin = ?",
				new PreparedStatementSetter() {

					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setString(1, bin);
					}
				}, rowMapper);
		return !list.isEmpty() ? list.get(0) : null;
	}

	@Override
	public int checkAndSave(BankBinMapping bankBinMapping) {
		BankBinMapping bankBin = getByBin(bankBinMapping.getBin());
		if (bankBin != null) {
			return bankBin.getId();
		} else {
			return save(bankBinMapping);
		}
	}

	@Override
	public BankBinMapping getById(int id) {
		BeanPropertyRowMapper<BankBinMapping> rowMapper = BeanPropertyRowMapper.newInstance(BankBinMapping.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<BankBinMapping> list = jdbcTemplate.query("select * from bank_bin_mapping  where id = ?",
				new PreparedStatementSetter() {

					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setInt(1, id);
					}
				}, rowMapper);
		return !list.isEmpty() ? list.get(0) : null;
	}

}
