package com.wibmo.dfs.wallet.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class W2UPIDebitRequest {
    @ApiModelProperty(required = false, dataType="String", hidden = true)
    private String custId;

    @ApiModelProperty(required = true, dataType="int")
    private int walletId;

    @ApiModelProperty(required = true, dataType="long")
    private long finalAmount;

    @ApiModelProperty(required = true, dataType="long")
    private long txnAmount;

    @ApiModelProperty(required = true, dataType="String")
    private String rrn;

    @ApiModelProperty(required = true, dataType="String", example="Load Money", notes="possible values are Load Money, P2M, W2A, P2P Credit and P2P Debit, etc")
    private String txnType;

    @ApiModelProperty(hidden = true, required = false, dataType="String")
    private String sourceAccount;

    @ApiModelProperty(hidden = true, required = true, dataType="String", notes = "This is used for Txn history transaction description")
    private String beneficiaryAccountName;

    @ApiModelProperty(hidden = true, required = false, dataType="String", notes = "This is used for Txn history transaction description")
    private String beneficiaryVpaName;

    @ApiModelProperty(hidden = true, required = true, dataType="String", notes = "This is used for Txn history transaction description")
    private String beneficiaryAccountNumber;
    
    @ApiModelProperty(hidden = true, required = false, dataType="String", notes = "This is used for Txn history transaction description")
    private String beneficiaryVpa;

    @ApiModelProperty(hidden = true, required = false, dataType="String", notes = "This is used for Txn history transaction description")
    private String mcc;

    private String upiRequestId;

    private String remarks;


}