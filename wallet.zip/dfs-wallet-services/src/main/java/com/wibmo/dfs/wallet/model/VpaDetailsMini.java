package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class VpaDetailsMini {
	
	private String vpa;
	private String isPrimaryVpa;

}
