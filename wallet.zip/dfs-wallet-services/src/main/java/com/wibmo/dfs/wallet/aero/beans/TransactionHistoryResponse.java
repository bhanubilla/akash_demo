package com.wibmo.dfs.wallet.aero.beans;

import java.io.Serializable;
import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author ajay.mahto
 */
@Data
@NoArgsConstructor
public class TransactionHistoryResponse extends AeroResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    private long availableBalance;
    private long openingBalance;
    private long closingBalance;

    private int pageNumber;
    private int count;

    private List<StatementDetails> statementDetails;

   
}