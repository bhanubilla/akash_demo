package com.wibmo.dfs.wallet.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserAddress {
	@ApiModelProperty(required = true, dataType="String")
	private String addressLine;
	
	@ApiModelProperty(required = true, dataType="String")
	private String cityCode;
	
	@ApiModelProperty(required = true, dataType="String")
	private String zipCode;
	
	@ApiModelProperty(required = true, dataType="String")
	private String country;
}
