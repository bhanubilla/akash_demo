package com.wibmo.dfs.wallet.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FetchCardRequest {
	@ApiModelProperty(required = false, dataType="String", notes="if walletId is missing", hidden = true)
	private String customerId;
	
	@ApiModelProperty(required = true, dataType="String", notes="if walletId is missing", example="RW")
	private String productType;
	
	@ApiModelProperty(required = true, dataType="int", notes="if both customerId and productType are missing", example="1")
	private int walletId;
}
