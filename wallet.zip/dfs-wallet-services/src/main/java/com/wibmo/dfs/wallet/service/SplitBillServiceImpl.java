package com.wibmo.dfs.wallet.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wibmo.dfs.wallet.aero.beans.InitiateUpiCollectResponse;
import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.entity.RequestMoneyTxnInfo;
import com.wibmo.dfs.wallet.model.RMRequest;
import com.wibmo.dfs.wallet.model.SBRequest;
import com.wibmo.dfs.wallet.model.SBResponse;
import com.wibmo.dfs.wallet.model.SBTxnDetails;
import com.wibmo.dfs.wallet.model.UpiToUpiRequestMoneyReq;
import com.wibmo.dfs.wallet.model.WalletUserReq;
import com.wibmo.dfs.wallet.model.WibmoResponse;

@Service
public class SplitBillServiceImpl implements SplitBillService {

	@Autowired
	private RequestMoneyService rmService;
	
	@Autowired
	private DozerBeanMapper mapper;
	
	@Override
	public WibmoResponse raiseSpiltBill(SBRequest request, String bankId) {
		WibmoResponse response = new WibmoResponse(200, "SUCCESS");
		List<SBTxnDetails> txnDetails = new ArrayList<>();
		RMRequest rmRequest = mapper.map(request, RMRequest.class);
		SBResponse sbResp =  new SBResponse();
		switch (request.getTxnMode()) {
		case Constants.W2W:
			processW2WSB(request, txnDetails, rmRequest, bankId);
			break;
		case Constants.V2V:
			processV2VSB(request, txnDetails, rmRequest, bankId);
			break;
		case Constants.W2V:
			// make a method call
			break;
		case Constants.V2W:
			// make a method call
			break;
		default:
			response.setResCode(100);
			response.setResDesc("Split bill Txn Type/Txn Mode is not valid");
			break;
		}
		sbResp.setReqDate(new Date().getTime());
		sbResp.setTxnDetails(txnDetails);
		response.setData(sbResp);
		return response;
	}

	private void processV2VSB(SBRequest request, List<SBTxnDetails> li, RMRequest rmRequest, String bankId) {
		for(UpiToUpiRequestMoneyReq req : request.getRequesteeAccounts()) {
			rmRequest.setAmount(Long.valueOf(req.getTxnAmount()));
			rmRequest.setRequesteeMobile(req.getMobileNo());
			rmRequest.setRequesteeName(req.getPayerName());
			WibmoResponse rmResponse = new WibmoResponse();
			rmRequest.setUpiReq(req);
			rmService.processRequestMoney(rmRequest, rmResponse, bankId);
			
			InitiateUpiCollectResponse rm = rmResponse.getData() != null ? mapper.map(rmResponse.getData(), InitiateUpiCollectResponse.class) : new InitiateUpiCollectResponse();
			SBTxnDetails sb = mapper.map(rm, SBTxnDetails.class);
			sb.setResCode(rmResponse.getResCode());
			sb.setResDesc(rmResponse.getResDesc());
			sb.setRequesteeName(rmRequest.getRequesteeName());
			sb.setRequesteeMobile(rmRequest.getRequesteeMobile());
			sb.setAmount(rmRequest.getAmount());
			sb.setTxnId(rm.getUpiTxnRefNo());
			li.add(sb);
			
		}
	}

	private void processW2WSB(SBRequest request, List<SBTxnDetails> li, RMRequest rmRequest, String bankId) {
		
		for(WalletUserReq req : request.getRequesteeWallets()) {
			rmRequest.setAmount(req.getAmount());
			rmRequest.setRequesteeCustomerId(req.getRequesteeCustomerId());
			rmRequest.setRequesteeMobile(req.getRequesteeMobile());
			rmRequest.setRequesteeName(req.getRequesteeName());
			rmRequest.setInitiateFrom("SB");
			WibmoResponse rmResponse = new WibmoResponse();
			rmService.processRequestMoney(rmRequest, rmResponse, bankId);
			
			RequestMoneyTxnInfo rm = rmResponse.getData() != null ? mapper.map(rmResponse.getData(), RequestMoneyTxnInfo.class) : new RequestMoneyTxnInfo();
			SBTxnDetails sb = mapper.map(rm, SBTxnDetails.class);
			sb.setResCode(rmResponse.getResCode());
			sb.setResDesc(rmResponse.getResDesc());
			sb.setRequesteeName(rmRequest.getRequesteeName());
			sb.setRequesteeMobile(rmRequest.getRequesteeMobile());
			sb.setAmount(rmRequest.getAmount());
			li.add(sb);
			
		}
	}

}
