package com.wibmo.dfs.wallet.controller;


import com.wibmo.dfs.wallet.model.BlockedMobileDetailsReq;
import com.wibmo.dfs.wallet.model.WibmoResponse;
import com.wibmo.dfs.wallet.service.BlockedMobileNumberDetailsService;
import com.wibmo.dfs.wallet.util.WibmoResponseUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/wallet/accountManagement")
public class AccountManagementController {
    @Autowired
    private BlockedMobileNumberDetailsService blockedMobileNumberDetailsService;

    @PostMapping("/v1/block/mobileNumber")
    public ResponseEntity<WibmoResponse> blockedMobilNumber(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber, @RequestBody BlockedMobileDetailsReq request) {
        log.info("Blocked mobile called for programId :: {}, accountId :: {}", programId, accountNumber);
        request.setAccountNumber(accountNumber);
        return WibmoResponseUtil.frameResponse(blockedMobileNumberDetailsService.block(programId,request));
    }

    @PostMapping("/v1/unblockNumber")
    public ResponseEntity<WibmoResponse> unblockedMobileNumber(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber, @RequestBody BlockedMobileDetailsReq request) {
        log.info("Unblocked mobile called for programId :: {}, accountId :: {}", programId, accountNumber);
        return WibmoResponseUtil.frameResponse(blockedMobileNumberDetailsService.unBlockMobileNumber(accountNumber,request.getBlockedMobileNumber()));
    }

    @GetMapping ("/v1/blockedlist")
    public ResponseEntity<WibmoResponse> blockedMobileNumberList(@RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber){
        log.info("Get blockedMobilNumberlist for programId :: {}, accountId ::{}", programId, accountNumber);
        return  WibmoResponseUtil.frameResponse(blockedMobileNumberDetailsService.fetchBlockedMobileNumbers(programId, accountNumber));
    }
}
