/**
 * 
 */
package com.wibmo.dfs.wallet.aero.beans;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
public class LoadUnloadResponse extends AeroResponse implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private long availableBalance;
    private long transactionAmount;
    private long availableCashLimit;

}
