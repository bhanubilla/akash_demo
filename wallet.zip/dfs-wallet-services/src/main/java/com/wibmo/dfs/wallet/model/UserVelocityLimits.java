/**
 * 
 */
package com.wibmo.dfs.wallet.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown=true)
public class UserVelocityLimits implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private int id;
	private int kycLevel;
	private String txnType;
	private long dailyLimitAmt;
	private int dailyLimitCnt;
	private long monthlyLimitAmt;
	private int monthlyLimitCnt;
	private long maxAmtPerTxn;
	private String cardNumber;
	private String userId;

}
