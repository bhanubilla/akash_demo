package com.wibmo.dfs.wallet.adapter.util;

import org.bouncycastle.crypto.digests.SHA256Digest;
import org.bouncycastle.crypto.generators.PKCS5S2ParametersGenerator;
import org.bouncycastle.crypto.params.KeyParameter;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Random;


public class EncryptDecryptHelper {

    private static final String AES = "AES";
    private static final int ITERATION_COUNT = 10; //65536
    private static final int KEY_LENGTH = 256;

    //    @Value("${secretkey.range.max}")
    private String range = "1024";

    /**
     * @param noOfBytes
     * @return random initial vector (IV)
     * @apiNote
     */
    public static byte[] getRandomNonce(int noOfBytes) {
        if (noOfBytes <= 0) {
            noOfBytes = 16;
        }
        byte[] nonce = new byte[noOfBytes];
        new SecureRandom().nextBytes(nonce);
        return nonce;
    }

    // Password derived AES 256 bits secret key
    public static SecretKey getAESKeyFromSecretKey(byte[] password, byte[] salt){
        PKCS5S2ParametersGenerator gen = new PKCS5S2ParametersGenerator(new SHA256Digest());
        gen.init(password, salt, ITERATION_COUNT);
        byte[] dk = ((KeyParameter) gen.generateDerivedParameters(KEY_LENGTH)).getKey();
        return new SecretKeySpec(dk,AES);

    }

    public int generateSecrectKey() throws NoSuchAlgorithmException {
        Random random = SecureRandom.getInstanceStrong();
        return random.nextInt(Integer.parseInt(range));
    }
}
