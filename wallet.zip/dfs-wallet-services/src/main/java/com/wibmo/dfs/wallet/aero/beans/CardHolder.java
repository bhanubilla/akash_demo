package com.wibmo.dfs.wallet.aero.beans;
import java.io.Serializable;

/**
 * 
 * @author meriyala.raghavendra
 *
 */
public class CardHolder implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private String cardProfileId;
    private String cardholderFirstName;
    private String cardholderLastName;
    private String cardholderMobile;
    private String cardholderDateOfBirth;
    private String cardholderEmail;
    private String cardholderAddress;
    private String cardholderCity;
    private String cardholderState;
    private String cardholderZipCode;
    private String cardholderCountry;
    private String cardholderGender;

    public String getCardProfileId() {
        return cardProfileId;
    }

    public void setCardProfileId(String cardProfileId) {
        this.cardProfileId = cardProfileId;
    }

    public String getCardholderFirstName() {
        return cardholderFirstName;
    }

    public void setCardholderFirstName(String cardholderFirstName) {
        this.cardholderFirstName = cardholderFirstName;
    }

    public String getCardholderLastName() {
        return cardholderLastName;
    }

    public void setCardholderLastName(String cardholderLastName) {
        this.cardholderLastName = cardholderLastName;
    }

    public String getCardholderMobile() {
        return cardholderMobile;
    }

    public void setCardholderMobile(String cardholderMobile) {
        this.cardholderMobile = cardholderMobile;
    }

    public String getCardholderDateOfBirth() {
        return cardholderDateOfBirth;
    }

    public void setCardholderDateOfBirth(String cardholderDateOfBirth) {
        this.cardholderDateOfBirth = cardholderDateOfBirth;
    }

    public String getCardholderEmail() {
        return cardholderEmail;
    }

    public void setCardholderEmail(String cardholderEmail) {
        this.cardholderEmail = cardholderEmail;
    }

    public String getCardholderAddress() {
        return cardholderAddress;
    }

    public void setCardholderAddress(String cardholderAddress) {
        this.cardholderAddress = cardholderAddress;
    }

    public String getCardholderCity() {
        return cardholderCity;
    }

    public void setCardholderCity(String cardholderCity) {
        this.cardholderCity = cardholderCity;
    }

    public String getCardholderState() {
        return cardholderState;
    }

    public void setCardholderState(String cardholderState) {
        this.cardholderState = cardholderState;
    }

    public String getCardholderZipCode() {
        return cardholderZipCode;
    }

    public void setCardholderZipCode(String cardholderZipCode) {
        this.cardholderZipCode = cardholderZipCode;
    }

    public String getCardholderCountry() {
        return cardholderCountry;
    }

    public void setCardholderCountry(String cardholderCountry) {
        this.cardholderCountry = cardholderCountry;
    }

	public String getCardholderGender() {
		return cardholderGender;
	}

	public void setCardholderGender(String cardholderGender) {
		this.cardholderGender = cardholderGender;
	}    
    
    
}
