package com.wibmo.dfs.wallet.repository;

import com.wibmo.dfs.wallet.entity.PrepaidBankMapping;

public interface PrepaidBankMappingRepository {

	PrepaidBankMapping fetchByBankId(String programId);
	
	int save(PrepaidBankMapping pmaster);
	
	PrepaidBankMapping fetchById(int id, String programId);
	boolean reloadPPBnkMapping(String programId, int ppBnkId);
	boolean reloadBankId(String programId);
}
