package com.wibmo.dfs.wallet.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.wibmo.dfs.wallet.entity.BankAccounts;

@Repository
public class BankAccountsRepositoryImpl implements BankAccountsRepository {

	private static final String INSERT_QUERY = "INSERT INTO bank_accounts (customer_id,account_name,account_number,"
			+ "ifsc_code,bank_name,account_type,vpa,nick_name,pinset,primary_act,branch)"
			+ " VALUES (?,?,?,?,?,?,?,?,?,?,?)";

	private static final String DELETE_QUERY = "delete from  bank_accounts where id=? and customer_id=? ";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int save(BankAccounts account) {
		KeyHolder keyHolder = new GeneratedKeyHolder();

		jdbcTemplate.update(connection -> {
			PreparedStatement ps = connection.prepareStatement(INSERT_QUERY, Statement.RETURN_GENERATED_KEYS);
			int i = 1;
			ps.setString(i++, account.getCustomerId());
			ps.setString(i++, account.getAccountName());
			ps.setString(i++, account.getAccountNumber());
			ps.setString(i++, account.getIfscCode());
			ps.setString(i++, account.getBankName());
			ps.setString(i++, account.getAccountType());
			ps.setString(i++, account.getVpa());
			ps.setString(i++, account.getNickName());
			ps.setInt(i++, account.getPinset());
			ps.setInt(i++, account.getPrimaryAct());
			ps.setString(i++, account.getBranch());
			return ps;
		}, keyHolder);

		Number key = keyHolder.getKey();
		return null != key ? key.intValue() : 0;
	}

	@Override
	public boolean delete(int id, String customerId) {
		int cnt = jdbcTemplate.update(DELETE_QUERY, id, customerId);
		return cnt == 1;
	}

	@Override
	public BankAccounts fetchById(int id) {
		BeanPropertyRowMapper<BankAccounts> rowMapper = BeanPropertyRowMapper.newInstance(BankAccounts.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<BankAccounts> li = jdbcTemplate.query("select * from bank_accounts where id = ?",
				new PreparedStatementSetter() {

					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setInt(1, id);
					}
				}, rowMapper);
		return !li.isEmpty() ? li.get(0) : null;
	}

	@Override
	public List<BankAccounts> fetchByCustId(String customerId) {
		BeanPropertyRowMapper<BankAccounts> rowMapper = BeanPropertyRowMapper.newInstance(BankAccounts.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		return jdbcTemplate.query("select * from bank_accounts where customer_id = ?", new PreparedStatementSetter() {

			public void setValues(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setString(1, customerId);
			}
		}, rowMapper);
	}

	@Override
	public List<BankAccounts> fetchByCustIdOrId(String customerId, int id) {
		List<BankAccounts> listOfBankAccounts = new ArrayList<>();
		if (id > 0) {
			BankAccounts bankAccount = fetchByCustIdAndId(customerId, id);
			if (bankAccount != null)
				listOfBankAccounts.add(bankAccount);
		} else {
			listOfBankAccounts = fetchByCustId(customerId);
		}

		return listOfBankAccounts;
	}

	@Override
	public BankAccounts fetchByCustIdAndId(String customerId, int id) {
		BeanPropertyRowMapper<BankAccounts> rowMapper = BeanPropertyRowMapper.newInstance(BankAccounts.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<BankAccounts> li = jdbcTemplate.query("select * from bank_accounts where id = ? and customer_id = ? ",
				new PreparedStatementSetter() {

					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setInt(1, id);
						preparedStatement.setString(2, customerId);
					}
				}, rowMapper);
		return !li.isEmpty() ? li.get(0) : null;
	}

}
