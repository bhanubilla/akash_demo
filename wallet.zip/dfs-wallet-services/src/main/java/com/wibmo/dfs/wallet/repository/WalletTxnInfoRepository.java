/**
 * 
 */
package com.wibmo.dfs.wallet.repository;

import com.wibmo.dfs.wallet.entity.FetchTxnDetails;
import com.wibmo.dfs.wallet.entity.WalletTxnInfo;

/**
 * @author rajasekhar.kaniti
 *
 */
public interface WalletTxnInfoRepository {
	
	int save(WalletTxnInfo walletTxnInfo);
	int update(WalletTxnInfo walletTxnInfo);
	
	FetchTxnDetails fetchTxnInfoByTxnId(String txnId);

}
