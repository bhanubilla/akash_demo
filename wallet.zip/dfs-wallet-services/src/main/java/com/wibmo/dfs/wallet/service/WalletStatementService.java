package com.wibmo.dfs.wallet.service;

import com.wibmo.dfs.wallet.model.WibmoResponse;

import java.sql.Timestamp;

public interface WalletStatementService {
    WibmoResponse fetchWalletStatement(String fromDate, String toDate, int programId, String userId, String emailId);
    void updateAudit(int programId, String userId, String status, Timestamp updatedDate, int walletStatementId);
    }
