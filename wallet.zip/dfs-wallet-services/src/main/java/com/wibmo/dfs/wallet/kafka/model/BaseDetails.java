package com.wibmo.dfs.wallet.kafka.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BaseDetails {

	private String customerId;
	private String mobile;
	private String paymentMode;
	private String txnDesc;
	private String merCategory;
	private String txnCategory;
	private String txnType;
	private long txnAmount;
	private String txnDateStr;
	private String txnStatus;
	private String remarks;
	private String txnFlow;
	private String txnShortDesc;
	// meta data
	private int tryCount;
	private String failureReason;
	private long closingBalance;
	private String mcc;
}
