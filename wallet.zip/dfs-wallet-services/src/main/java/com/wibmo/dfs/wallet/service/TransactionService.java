package com.wibmo.dfs.wallet.service;

import com.wibmo.dfs.wallet.model.SendMoneyRequest;
import com.wibmo.dfs.wallet.model.SendMoneyTransactionRequest;
import com.wibmo.dfs.wallet.model.UpiTransactionRequest;
import com.wibmo.dfs.wallet.model.W2ADebitRequest;
import com.wibmo.dfs.wallet.model.W2UPIDebitRequest;
import com.wibmo.dfs.wallet.model.WibmoResponse;

public interface TransactionService {
	
	W2ADebitRequest createW2ADebitRequest(SendMoneyTransactionRequest sendMoneyTransacReq, String bankId, String userId);
	
	WibmoResponse makeTransaction(SendMoneyTransactionRequest sendMoneyTransactionRequest, String bankId, String userId);

	UpiTransactionRequest createUpiTransactionRequest(SendMoneyTransactionRequest request, String bankId, String userid, Object data);

	SendMoneyRequest prepareSendMoneyRequest(SendMoneyTransactionRequest request, String bankId, String userId);
	
	WibmoResponse w2upiTransacation(W2UPIDebitRequest request, WalletService service, String bankId, String userId);
	
}
