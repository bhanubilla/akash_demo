package com.wibmo.dfs.wallet.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ModifyAutotopupRequest {

	@ApiModelProperty(required = false, dataType="String", hidden = true)
	private String customerId;
	
	@ApiModelProperty(required = true, dataType="long")
	private int thresholdAmt;
	
	@ApiModelProperty(required = true, dataType="long")
	private long topupAmt;
	
	@ApiModelProperty(required = true, dataType="String")
	private String merchantId;
	
	@ApiModelProperty(required = true, dataType="String")
	private String status;
	
	@ApiModelProperty(required = true, dataType="long")
	private long recurringPaymentRefId;
}
