package com.wibmo.dfs.wallet.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.wibmo.dfs.wallet.constants.ServiceHttpStatus;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = Visibility.ANY)
public class WibmoResponse implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int resCode;
	private String resDesc;
	private String errorMessage;
	private transient Object data;

	public WibmoResponse(int resCode, String resDesc, Object data) {
		super();
		this.resCode = resCode;
		this.resDesc = resDesc;
		this.data = data;
	}

	public WibmoResponse(int resCode, String resDesc) {
		super();
		this.resCode = resCode;
		this.resDesc = resDesc;
	}

	public WibmoResponse(ServiceHttpStatus status, String errorMessage) {
		super();
		this.resCode = status.getStatusCode();
		this.resDesc = status.getStatusMsg();
		this.errorMessage = errorMessage;
	}

	public WibmoResponse(ServiceHttpStatus status, Object data) {
		super();
		this.resCode = status.getStatusCode();
		this.resDesc = status.getStatusMsg();
		this.data = data;
	}

	public WibmoResponse(ServiceHttpStatus status) {
		super();
		this.resCode = status.getStatusCode();
		this.resDesc = status.getStatusMsg();
	}

}
