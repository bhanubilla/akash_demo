package com.wibmo.dfs.wallet.service;


import com.wibmo.dfs.wallet.adapter.UpiIntegrationServiceAdapter;
import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.entity.BlockedDetails;
import com.wibmo.dfs.wallet.kafka.KafkaProducer;
import com.wibmo.dfs.wallet.kafka.model.AuditLog;
import com.wibmo.dfs.wallet.model.BlockedMobileDetailsReq;
import com.wibmo.dfs.wallet.model.BlockedVpaDetails;
import com.wibmo.dfs.wallet.model.CustomerMiniProfile;
import com.wibmo.dfs.wallet.model.WibmoResponse;
import com.wibmo.dfs.wallet.repository.BlockedMobileNumberDetailsRepo;
import com.wibmo.dfs.wallet.util.ApiManagerUtil;
import lombok.extern.slf4j.Slf4j;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class BlockedMobileNumberDetailsServiceImpl implements BlockedMobileNumberDetailsService{
    @Autowired
    private   BlockedMobileNumberDetailsRepo blockedMobileNumberDetailsRepo;

    @Autowired
    private UpiIntegrationServiceAdapter upiIntegrationServiceAdapter;

    @Autowired
    private DozerBeanMapper dozerBeanMapper;

    @Autowired
    private ApiManagerUtil apiManagerUtil;

    @Autowired
    private KafkaProducer kafkaProducer;

    private String exceptionTag = "Exception :: {}";

    @Override
    public WibmoResponse block(String programId, BlockedMobileDetailsReq blockedMobileDetailsReq) {
        WibmoResponse response = new WibmoResponse();
        try{
            BlockedDetails data = blockedMobileNumberDetailsRepo.fetchBlockedMobileNumber(blockedMobileDetailsReq.getAccountNumber(), blockedMobileDetailsReq.getBlockedMobileNumber());
            AuditLog auditLog =new AuditLog();
            auditLog.setProgramId("2001");
            auditLog.setAuditType("api");
            auditLog.setData(data);
            kafkaProducer.publishAuditLogs(auditLog);
            if(null != data){
                log.info("User already blocked.... for this account");
                response.setResCode(200);
                response.setResDesc(Constants.RESPONSE_DESC_SUCCESS);
                response.setData(blockedMobileDetailsReq);
            }
            else {
                CustomerMiniProfile blockedUserdetails = apiManagerUtil.fetchUserProfile(programId, null, blockedMobileDetailsReq.getBlockedMobileNumber());
                blockedMobileDetailsReq.setBlockedUserName(blockedUserdetails.getFirstName());
                int i = blockedMobileNumberDetailsRepo.save(blockedMobileDetailsReq);
                if (i != 0) {
                    log.info("blocked successfully ...");
                    response.setResCode(200);
                    response.setResDesc("SUCCESS");
                    response.setData(blockedMobileDetailsReq);
                }
            }
        }catch (Exception exception){
            log.info(exceptionTag ,exception);
            response.setResCode(100);
            response.setResDesc(Constants.FAILURE);
            response.setErrorMessage("Unable to blocking mobile number "+blockedMobileDetailsReq.getBlockedMobileNumber()+". Please try again");

        }
        return response;
    }

    @Override
    public WibmoResponse  fetchBlockedMobileNumbers(String programId, String accountNumber) {
        log.debug("inside fetchBlockedMobileNumbers() ::: {}", accountNumber);
        WibmoResponse response = new WibmoResponse();
        List<BlockedDetails> blockedVpaDetailsList = null;
        List<BlockedDetails> blockedWalletlist = null;
        List<BlockedDetails> totalList = new ArrayList<>();
        try {
            blockedVpaDetailsList = upiIntegrationServiceAdapter.fetchBlockVpaList(programId, accountNumber);
            if (blockedVpaDetailsList != null && !blockedVpaDetailsList.isEmpty()) {
                log.debug("vpa blocked list is not empty :: {} ",blockedVpaDetailsList.size());
                totalList.addAll(blockedVpaDetailsList);
            }
            blockedWalletlist = blockedMobileNumberDetailsRepo.fetchBlockedMobileNumbers(accountNumber);
            if(blockedWalletlist != null && !blockedWalletlist.isEmpty()){
                log.debug("block wallet list is not empty :: {} ",blockedWalletlist.size());
                totalList.addAll(blockedWalletlist);
            }
            response.setResCode(200);
            response.setResDesc(Constants.RESPONSE_DESC_SUCCESS);
            response.setData(totalList);
            log.debug("response fetchBlockedMobileNumbers ::: {}", totalList);
        } catch (Exception exception) {
            log.info(exceptionTag, exception);
            response.setResCode(100);
            response.setResDesc(Constants.FAILURE);
        }
        return response;
    }

    @Override
    public WibmoResponse  fetchBlockedMobileNumber(String accountNumber, String blockedMobileNumber) {
        WibmoResponse response = new WibmoResponse();
        try{
            log.info("fetch Blocked MobileNumber for accountNumber :: {} blockedMobileNumber:: {}",accountNumber,blockedMobileNumber);
            BlockedDetails data = blockedMobileNumberDetailsRepo.fetchBlockedMobileNumber(accountNumber, blockedMobileNumber);
            response.setResCode(200);
            response.setResDesc(Constants.RESPONSE_DESC_SUCCESS);
            response.setData(data);
        }catch (Exception exception){
            log.info(exceptionTag,exception);
            response.setResCode(100);
            response.setResDesc(Constants.FAILURE);
        }
        return response;
    }

    @Override
    public WibmoResponse unBlockMobileNumber(String accountNumber, String unBlockMobileNumber) {
        WibmoResponse response = new WibmoResponse();
        try{
            log.info("unBlock number service method is called for accountNumber :: {} unBlockMobileNumber:: {}",accountNumber,unBlockMobileNumber);
            int i = blockedMobileNumberDetailsRepo.delete(accountNumber, unBlockMobileNumber);
            if(i!=0){
                log.info("unblocked successfully ...");
                response.setResCode(200);
                response.setResDesc(Constants.RESPONSE_DESC_SUCCESS);
                response.setData(unBlockMobileNumber + " unblocked successfully");
            }
        }catch (Exception exception){
            log.info(exceptionTag,exception);
            response.setResCode(100);
            response.setResDesc(Constants.FAILURE);
            response.setErrorMessage("Unable to unblock mobile number "+unBlockMobileNumber+". Please try again");

        }
        return response;
    }
}
