/**
 * 
 */
package com.wibmo.dfs.wallet.repository;

import java.util.Map;

/**
 * @author rajasekhar.kaniti
 *
 */
public interface MsgsRepository {
	Map<String, String> getAllMsgDetails();
	String fetchMsgValueByMsgName(String programId, String msgName);
	boolean reloadMsgDetail(String programId, String msgName);
}
