package com.wibmo.dfs.wallet.service;
import com.wibmo.dfs.wallet.entity.AuditStatement;
import com.wibmo.dfs.wallet.kafka.KafkaProducer;
import com.wibmo.dfs.wallet.model.TransactionParams;
import com.wibmo.dfs.wallet.model.WibmoResponse;
import com.wibmo.dfs.wallet.repository.AuditStatementRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.sql.Timestamp;


@Slf4j
@Service
public class WalletStatementServiceImpl implements WalletStatementService {

    @Autowired
    private AuditStatementRepository auditStatementRepository;

    @Autowired
    public KafkaProducer kafkaProducer;

    @Override
    public WibmoResponse fetchWalletStatement(String fromDate, String toDate, int programId, String userId, String emailId) {
        if(fromDate!=null && toDate!=null && emailId!=null) {
            try {
                AuditStatement auditStatement = new AuditStatement();
                auditStatement.setCustomerId(userId);
                auditStatement.setStatus("I");
                int walletId = auditStatementRepository.save(auditStatement);

                TransactionParams transactionParams = new TransactionParams();
                transactionParams.setProgramId(programId);
                transactionParams.setUserId(userId);
                transactionParams.setWalletStatementId(walletId);
                transactionParams.setFromDate(fromDate);
                transactionParams.setToDate(toDate);
                transactionParams.setEmailId(emailId);
                Runnable runnable = () -> kafkaProducer.publishWalletStatement(transactionParams);
                new Thread(runnable).start();
            } catch (Exception e) {
                log.error("Error occurred: {}",e);
            }
            WibmoResponse response = new WibmoResponse();
            response.setResCode(200);
            response.setResDesc("Pdf generated initiated, you will receive it on mail");
            response.setData(null);
            return response;
        }
        WibmoResponse response = new WibmoResponse();
        response.setResCode(400);
        response.setResDesc("Request is not proper");
        response.setData(null);
        return response;
    }

    @Override
    public void updateAudit(int programId, String userId, String status, Timestamp updatedDate, int walletStatementId) {
        try {
            AuditStatement auditStatement = new AuditStatement();
            auditStatement.setCustomerId(userId);
            auditStatement.setWalletStatementId(walletStatementId);
            auditStatement.setStatus(status);
            auditStatement.setUpdatedDate(updatedDate);
            auditStatementRepository.updateAudit(auditStatement);
        }
        catch (Exception e)
        {
            log.error("Error occurred: {}",e);
        }
    }

}
