package com.wibmo.dfs.wallet.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FetchRMRequest implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String msgHash;
	private String virtualAddress;
	private String customerId;
	private String mobileNo;
	private String deviceName;
	private String token;

}
