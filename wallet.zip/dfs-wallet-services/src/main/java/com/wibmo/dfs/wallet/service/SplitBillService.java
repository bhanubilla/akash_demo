package com.wibmo.dfs.wallet.service;

import com.wibmo.dfs.wallet.model.SBRequest;
import com.wibmo.dfs.wallet.model.WibmoResponse;

public interface SplitBillService {

	WibmoResponse raiseSpiltBill(SBRequest request, String bankId);
}
