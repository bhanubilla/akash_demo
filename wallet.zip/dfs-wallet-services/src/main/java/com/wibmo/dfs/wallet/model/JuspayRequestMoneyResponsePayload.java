package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class JuspayRequestMoneyResponsePayload {
    private String merchantId;
    private String merchantChannelId;
    private String merchantCustomerId;
    private String merchantRequestId;
    private String customerMobileNumber;
    private String expiryTimestamp;
    private String payeeVpa;
    private String payeeMcc;
    private String payerVpa;
    private String payerName;
    private String refUrl;
    private String remarks;
    private String bankAccountUniqueId;
    private String bankCode;
    private String maskedAccountNumber;
    private String txnAmount;
    private String transactionTimestamp;
    private String gatewayTransactionId;
    private String gatewayReferenceId;
    private String gatewayResponseStatus;
    private String gatewayResponseCode;
    private String gatewayResponseMessage;
}

