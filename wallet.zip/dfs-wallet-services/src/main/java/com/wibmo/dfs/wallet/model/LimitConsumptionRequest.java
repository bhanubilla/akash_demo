package com.wibmo.dfs.wallet.model;

import lombok.Data;

@Data
public class LimitConsumptionRequest {
    private String txnType;
    private long txnAmt;
    private String limitKey;
    private boolean benefIsInCoolingPeriod;
    private int beneficiaryId;
    private String beneficiaryName;
    private int walletId;
    private String txnId;
    private String merchantId;
}
