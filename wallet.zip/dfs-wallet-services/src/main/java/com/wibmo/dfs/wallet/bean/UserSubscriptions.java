/**
 * 
 */
package com.wibmo.dfs.wallet.bean;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
public class UserSubscriptions {
	
	private int countryCode;
	private String mobile;
	
	
	public UserSubscriptions(int countryCode, String mobile) {
		super();
		this.countryCode = countryCode;
		this.mobile = mobile;
	}
	
	

}
