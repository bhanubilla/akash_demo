/**
 * 
 */
package com.wibmo.dfs.wallet.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wibmo.dfs.cache_client.manager.DfsCacheManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.wibmo.dfs.wallet.entity.ProgramParameters;
import org.springframework.util.StringUtils;

/**
 * @author rajasekhar.kaniti
 *
 */
@Repository
@Slf4j
public class ProgramParametersRepositoryImpl implements ProgramParametersRepository {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private DfsCacheManager cacheManager;

	private static final String CACHE_KEY = "PRGM_PARAM";
	private static final String UNDER_SCORE = "_";

	@Override
	public Map<String, String> getAllProgramParams() {
		Map<String, String> params = new HashMap<>();
		BeanPropertyRowMapper<ProgramParameters> rowMapper = BeanPropertyRowMapper.newInstance(ProgramParameters.class);
        rowMapper.setPrimitivesDefaultedForNullValue(true);
        List<ProgramParameters> listOfParams = jdbcTemplate.query("select * from program_parameters",rowMapper);
        for(ProgramParameters param: listOfParams) {
        	params.put(param.getParamName(), param.getParamValue());
        }
		
		return params;
	}

	@Override
	public String fetchParamValueByParamName(String programId, String paramName) {
		String value = (String) cacheManager.get(CACHE_KEY + UNDER_SCORE + programId + UNDER_SCORE + paramName);
		if (StringUtils.hasLength(value)) {
			return value;
		}
		log.info("NFC - going to DB programId:{} paramName:{}",programId,paramName);
		return loadFromDB(programId, paramName);
	}

	@Override
	public boolean reloadProgParamValues(String programId, String paramName) {
		Object obj = cacheManager.remove(CACHE_KEY + UNDER_SCORE + programId + UNDER_SCORE + paramName);
		if(obj instanceof Boolean) {
			log.info("Successfully Removed from cache - programId:{} paramName:{}",programId,paramName);
			return (Boolean)obj;
		}
		else return false;

	}

	private String loadFromDB(String programId, String paramName) {
		var paramValue = jdbcTemplate.queryForObject("select param_value from program_parameters where param_name=?",String.class, paramName);
		cacheManager.put(CACHE_KEY + UNDER_SCORE + programId + UNDER_SCORE + paramName, paramValue);
		return paramValue;
	}

}
