package com.wibmo.dfs.wallet.aero.beans;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @author ajay.mahto
 */
@Data
@NoArgsConstructor
public class StatementDetails implements Serializable{

    private String transactionNarration;
    private String transactionDate;
    private String rowId;
    private String approvalCode;
    private String eventId;
    private String clientTxnId;
    private String status;
    private String merchantCity;
    private String transRefNumber;
    private String rrn;
    private int isMerchantTxn;
    private long openningBalance;
    private long closingBalance;
    private String merchantName;
    private String authDate;
    private String transactionType;
    private long transactionAmount;
    private String stan;
    private String authEpfTxnId;
    private String reserved2;
    private String reserved1;
    private boolean reversal; 

    
}
