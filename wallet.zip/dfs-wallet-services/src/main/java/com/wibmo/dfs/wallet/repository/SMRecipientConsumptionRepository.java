/**
 * 
 */
package com.wibmo.dfs.wallet.repository;

import java.util.List;
import java.util.Map;

import com.wibmo.dfs.wallet.entity.SMUserConsumption;

/**
 * @author rajasekhar.kaniti
 *
 */
public interface SMRecipientConsumptionRepository {
	int saveOrUpdate(List<SMUserConsumption> smUserCon,int bankId);
	int save(SMUserConsumption smUserCon,int bankId);
	int update(SMUserConsumption smUserCon,int bankId);
	SMUserConsumption fetchByCustIdCardHashAndKey(String customerId,String cardHash,int bankId, String key);
	Map<String,Long> fetchByCustId(String customerId, String cardHash, int bankId, String... keys);
}
