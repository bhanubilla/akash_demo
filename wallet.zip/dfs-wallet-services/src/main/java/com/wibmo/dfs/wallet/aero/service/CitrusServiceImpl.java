package com.wibmo.dfs.wallet.aero.service;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.platform.fw.multitenantconfig.ThreadLocalStorage;
import com.wibmo.dfs.platform.service.notification.NotificationServiceCall;
import com.wibmo.dfs.platform.service.notification.model.NotificationRequest;
import com.wibmo.dfs.wallet.adapter.CitrusPrepaidAdapter;
import com.wibmo.dfs.wallet.adapter.response.MobilenumberBasedCardInquiryResponse;
import com.wibmo.dfs.wallet.adapter.util.AESGCMPayLoadEncryption;
import com.wibmo.dfs.wallet.aero.beans.AeroRequest;
import com.wibmo.dfs.wallet.aero.beans.AmlInquiryResponse;
import com.wibmo.dfs.wallet.aero.beans.CMSResponse;
import com.wibmo.dfs.wallet.aero.beans.CardHolder;
import com.wibmo.dfs.wallet.aero.beans.CardHolderProfileUpdateRequest;
import com.wibmo.dfs.wallet.aero.beans.CardIdentityProfile;
import com.wibmo.dfs.wallet.aero.beans.CardInquiryRequest;
import com.wibmo.dfs.wallet.aero.beans.CardInquiryResponse;
import com.wibmo.dfs.wallet.aero.beans.CardTransactionProfile;
import com.wibmo.dfs.wallet.aero.beans.CitrusFundTransferResponse;
import com.wibmo.dfs.wallet.aero.beans.CreateCardRequest;
import com.wibmo.dfs.wallet.aero.beans.CreateCardResponse;
import com.wibmo.dfs.wallet.aero.beans.CustomerIdentityProfile;
import com.wibmo.dfs.wallet.aero.beans.EncLoadUnloadResponse;
import com.wibmo.dfs.wallet.aero.beans.FundTransferRequest;
import com.wibmo.dfs.wallet.aero.beans.FundTransferResponse;
import com.wibmo.dfs.wallet.aero.beans.FundTransferVO;
import com.wibmo.dfs.wallet.aero.beans.LoadUnloadRequest;
import com.wibmo.dfs.wallet.aero.beans.LoadUnloadResponse;
import com.wibmo.dfs.wallet.aero.beans.PrepaidEncResponse;
import com.wibmo.dfs.wallet.aero.beans.Receiver;
import com.wibmo.dfs.wallet.aero.beans.Sender;
import com.wibmo.dfs.wallet.aero.beans.WAServiceEnableDisableRequest;
import com.wibmo.dfs.wallet.aero.beans.WAServiceEnableDisableResponse;
import com.wibmo.dfs.wallet.aero.constants.AeroConstants;
import com.wibmo.dfs.wallet.aero.constants.AeroMsgDefinitions;
import com.wibmo.dfs.wallet.aero.constants.WCStatusServiceType;
import com.wibmo.dfs.wallet.aero.entity.AeroCMSConf;
import com.wibmo.dfs.wallet.aero.entity.ProductMaster;
import com.wibmo.dfs.wallet.aero.helper.AeroCMSHelper;
import com.wibmo.dfs.wallet.aero.repository.AeroCmsConfRepository;
import com.wibmo.dfs.wallet.aero.repository.AeroCmsProductMasterRepository;
import com.wibmo.dfs.wallet.common.MsgConstants;
import com.wibmo.dfs.wallet.common.ProgramParamConstants;
import com.wibmo.dfs.wallet.constants.AckTxnTypes;
import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.constants.InflowImplConstant;
import com.wibmo.dfs.wallet.constants.OutflowImplConstant;
import com.wibmo.dfs.wallet.constants.ServiceHttpStatus;
import com.wibmo.dfs.wallet.entity.AuditApiReq;
import com.wibmo.dfs.wallet.entity.InflowImpl;
import com.wibmo.dfs.wallet.entity.OutflowImpl;
import com.wibmo.dfs.wallet.entity.PrepaidBankMapping;
import com.wibmo.dfs.wallet.entity.UserAccountInfo;
import com.wibmo.dfs.wallet.entity.WalletCard;
import com.wibmo.dfs.wallet.entity.WalletTxnInfo;
import com.wibmo.dfs.wallet.helper.CommonHelper;
import com.wibmo.dfs.wallet.kafka.KafkaProducer;
import com.wibmo.dfs.wallet.kafka.model.LoadMoneyEvent;
import com.wibmo.dfs.wallet.kafka.model.P2PCreditEvent;
import com.wibmo.dfs.wallet.kafka.model.P2PDebitEvent;
import com.wibmo.dfs.wallet.kafka.model.TxnDetails;
import com.wibmo.dfs.wallet.model.BlockCardRequest;
import com.wibmo.dfs.wallet.model.CardDetails;
import com.wibmo.dfs.wallet.model.CardHolderProfileUpdateResponse;
import com.wibmo.dfs.wallet.model.CheckUserAmlLimitsRequest;
import com.wibmo.dfs.wallet.model.CheckUserLimitsRequest;
import com.wibmo.dfs.wallet.model.CitrusPrepaidBlockCardRequest;
import com.wibmo.dfs.wallet.model.CitrusPrepaidBlockCardResponse;
import com.wibmo.dfs.wallet.model.CitrusPrepaidUnBlockCardRequest;
import com.wibmo.dfs.wallet.model.CitrusPrepaidUnBlockCardResponse;
import com.wibmo.dfs.wallet.model.CreateCard;
import com.wibmo.dfs.wallet.model.CustomerMiniProfile;
import com.wibmo.dfs.wallet.model.FetchCardBalanceRequest;
import com.wibmo.dfs.wallet.model.FetchCardBalanceResponse;
import com.wibmo.dfs.wallet.model.FetchCardCVVRequest;
import com.wibmo.dfs.wallet.model.FetchCardCVVResponse;
import com.wibmo.dfs.wallet.model.FetchCardRequest;
import com.wibmo.dfs.wallet.model.FetchCardResponse;
import com.wibmo.dfs.wallet.model.FetchCardStatusRequest;
import com.wibmo.dfs.wallet.model.FetchCardStatusResponse;
import com.wibmo.dfs.wallet.model.FundRequest;
import com.wibmo.dfs.wallet.model.FundResponse;
import com.wibmo.dfs.wallet.model.P2PRequest;
import com.wibmo.dfs.wallet.model.ParametersLoadUnloadResp;
import com.wibmo.dfs.wallet.model.SendMoneyRequest;
import com.wibmo.dfs.wallet.model.SendMoneyResponse;
import com.wibmo.dfs.wallet.model.ServiceTypeRequest;
import com.wibmo.dfs.wallet.model.ServiceTypes;
import com.wibmo.dfs.wallet.model.UnBlockCardRequest;
import com.wibmo.dfs.wallet.model.UpdateCardHolderProfileData;
import com.wibmo.dfs.wallet.model.UserVelocityCheck;
import com.wibmo.dfs.wallet.model.WalletMobileNoBasedInquiryRequest;
import com.wibmo.dfs.wallet.model.WibmoResponse;
import com.wibmo.dfs.wallet.repository.AuditApiReqRepository;
import com.wibmo.dfs.wallet.repository.InflowImplRepository;
import com.wibmo.dfs.wallet.repository.MsgsRepository;
import com.wibmo.dfs.wallet.repository.OutflowImplRepository;
import com.wibmo.dfs.wallet.repository.ProgramParametersRepository;
import com.wibmo.dfs.wallet.repository.WalletCardRepository;
import com.wibmo.dfs.wallet.repository.WalletTxnInfoRepository;
import com.wibmo.dfs.wallet.service.UserConsumptionService;
import com.wibmo.dfs.wallet.service.WalletService;
import com.wibmo.dfs.wallet.service.WalletServiceFactory;
import com.wibmo.dfs.wallet.util.ApiManagerUtil;
import com.wibmo.dfs.wallet.util.CommonUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CitrusServiceImpl implements WalletService {

	public static final String IMPL_DESC_IS_NOT_AVAILABLE_IN_DB = "Impl Desc is not available in db.";
	public static final String PREPAID_RESPONSE_MSG = "prepaid ResponseMsg:{}";
	public static final String EXCEPTION_OCCURRED = "Exception occurred";
	public static final String ADD_MONEY = "Add Money ";
	public static final String D_M_YYYY_H_M_S = "d-M-yyyy H:m:s";
	public static final String EXCEPTION = "exception :{}";
	public static final String FAILURE = "Failure";
	private static final String SUCCESS = "SUCCESS";
	
	@Autowired
	private WalletCardRepository wcrepository;

	@Autowired
	private WalletServiceFactory walletServiceFactory;

	@Autowired
	private AeroCmsConfRepository aeroConfRepository;

	@Autowired
	private AeroCmsProductMasterRepository aeroPMRepository;

	@Autowired
	private AuditApiReqRepository auditRepository;

	@Autowired
	private WalletTxnInfo walletTxnInfo;

	@Autowired
	private WalletTxnInfoRepository walletInfoRepository;

	@Autowired
	private FundResponse fundResponse;

	@Autowired
	private OutflowImplRepository ofImplRepository;

	@Autowired
	private InflowImplRepository inImplRepository;

	@Autowired
	private MsgsRepository msgsRepository;

	@Autowired
	private ProgramParametersRepository progParamRespository;

	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	@Autowired
	private UserConsumptionService userConsumptionService;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private KafkaProducer kafkaProducer;

	@Autowired
	private AESGCMPayLoadEncryption aesgcmPayLoadEncryption;

	@Autowired
	ProgramParametersRepository programParametersRepository;

	@Value("${resource.url.onboarding}")
	private String onBoardingUrl;

	@Value("${resource.url.notification}")
	private String notificationUrl;

	@Value("${resource.url.citrusFundsDebitUrl}")
	private String citrusFundsDebitUrl;

	@Value("${resource.url.citrusFundsCreditUrl}")
	private String citrusFundsCreditUrl;

	@Value("${resource.url.citrusBlockCardUrl}")
	private String citrusBlockCardUrl;

	@Value("${resource.url.citrusUnblockCardUrl}")
	private String citrusUnblockCardUrl;

	@Value("${resource.url.citrusFundsTransferUrl}")
	private String citrusFundsTransferUrl;

	@Value("${resource.url.citrusCreateCardUrl}")
	private String citrusCreateCardUrl;

	@Value("${resource.url.citrusCardHolderProfileUrl}")
	private String citrusCardHolderProfileUrl;

	@Autowired
	private CitrusPrepaidAdapter citrusPrepaidAdapter;

	@Autowired
	private ApiManagerUtil apiManagerUtil;

	private String dateFormat = "yyyyMMddhhmmss";

	private String bankId = "bankId";
	private String custIdLast4Digit = "custIdLast4Digit";
	private String clientTxnId = "clientTxnId";
	private String xApiKey = "x-api-key";
	private String contentType = "Content-Type";
	//private String  privateKey = "KbPdSgVkYp3s6v9y";

	//public static final String X_API_KEY_VALUE = "lll1234395";
	public static final String APPLICATION_JSON = "application/json";
	public static final String WALLET_CARD_TYPE = "WALLET_CARD_TYPE";
	public static final String TOKEN = "{\"token\":\"";
	public static final String SUCCESS_RES_FROM_PREPAID = "SUCCESS response from prepaid";
	public static final String EXCEPTION_IN_PREPAID = "Exception in prepaid :: {} ,  response code ::{}";


	@Override
	public WibmoResponse create(CreateCard createCard) {
		var response = new WibmoResponse();
		CreateCardResponse createCardResponse = null;
		PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
		var cardDetail = new CardDetails();
		AeroCMSConf cmsConfig = aeroConfRepository.fetchByPPBankId(mapping.getId(), mapping.getBankId());
		ProductMaster productConfig = aeroPMRepository.fetchByBankAndProdutType(mapping.getBankId(),
				createCard.getProductType());
		if (null == productConfig) {
			log.info("Unknown Product Type : {}", createCard.getProductType());
			response.setResCode(6);
			response.setResDesc(String.format("Unknown Product Type : %s", createCard.getProductType()));
			return response;
		}
		var card = new WalletCard();
		String auditStatus = null;
		String auditRemarks = null;
		try {

			var auditReq = new AuditApiReq();
			AeroCMSHelper.setAuditReq(createCard, auditReq);
			int auditId = auditRepository.save(auditReq);

			WalletCard existingWC = wcrepository.fetchByCustIdAndProduct(
					createCard.getUser().getAccount().getCustomerId(), createCard.getProductType(), mapping.getBankId());
			if (null != existingWC) {
				log.info("customer have wallet already.. walletId: {}, customerId: {}", existingWC.getId(),
						existingWC.getCustomerId());
				String walletCardType=progParamRespository.fetchParamValueByParamName(mapping.getBankId(), WALLET_CARD_TYPE);
				existingWC.setWalletCardType(walletCardType);
				AeroCMSHelper.prepareResponse(createCard, cardDetail, existingWC);
				auditStatus = FAILURE;
				auditRemarks = "Card Present already";
				auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId, auditStatus, auditRemarks));
				response.setResCode(5);
				response.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.CARD_IS_PRESENT_ALREADY));
				response.setData(cardDetail);

				return response;
			}

			var createCardRequest = new CreateCardRequest();
			CustomerMiniProfile miniProfile = apiManagerUtil.fetchUserProfile(mapping.getBankId(),createCard.getUser().getAccount().getCustomerId(), null);
			if(null != miniProfile) {
				createCard.getUser().getProfile().setMobile(miniProfile.getMobileNo());
				createCard.getUser().getAccount().setKycLevel(String.valueOf(miniProfile.getKycLevel()).equals("100") ? "150" : String.valueOf(miniProfile.getKycLevel()));

			} else {
				// rejecting the req
				auditStatus = FAILURE;
				auditRemarks = "User not registered with Program: "+ mapping.getBankId();
				auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId, auditStatus, auditRemarks));
				response.setResCode(100);
				response.setResDesc("User profile not found");
				return response;
			}
			createCardRequest = AeroCMSHelper.prepareCreateCardRequest(createCard, cmsConfig, productConfig,
					createCardRequest);
			//createCardIssue -fix
			CardIdentityProfile cip = new CardIdentityProfile();
			setCreateCardAndCIP(createCard, cip);

			createCardRequest.setCustomerIdentityProfile(cip);
			createCardResponse = invokeCreateCardApi(createCardResponse, createCardRequest, cmsConfig);
			if (null != createCardResponse && (createCardResponse.getResponseCode()
					.equals(AeroConstants.RESPONSE_CODE_SUCCESS)
					|| createCardResponse.getResponseCode().equals(AeroConstants.RESPONSE_CODE_CARD_ALREADY_CREATED))) {
				AeroCMSHelper.setCardDetails(createCardResponse, cmsConfig, productConfig, card);
				int walletId = wcrepository.save(card, mapping.getBankId());
				card.setId(walletId);

				WibmoResponse response1 = loadAmount(createCard, response, productConfig, card, auditId, createCardResponse);
				if (response1 != null) return response1;
				String walletCardType=progParamRespository.fetchParamValueByParamName(mapping.getBankId(), WALLET_CARD_TYPE);
				card.setWalletCardType(walletCardType);
				AeroCMSHelper.prepareResponse(createCard, cardDetail, card);

				auditStatus = "Success";
				auditRemarks = "Card Created Successfully";
				auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId, auditStatus, auditRemarks));
				response.setResCode(1);
				response.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.CARD_CREATED_SUCCESSFULLY));
				response.setData(cardDetail);

				Map<String, String> placeHolder = new HashMap<>();
				placeHolder.put("CUSTOMER_NAME", miniProfile.getFirstName());
				buildNotificationRequest(miniProfile, mapping, placeHolder);
			} else {
				processAuditStatusFailure(createCardResponse, response, mapping, auditId);
			}

		} catch (Exception e) {
			log.info("msg :{}", e);
		}

		return response;
	}

	private void setCreateCardAndCIP(CreateCard createCard, CardIdentityProfile cip) {
		if(null != createCard.getUser().getCustomerIdentityProfile()){
		   String aadhaarNbr = createCard.getUser().getCustomerIdentityProfile().getCustomerAadharCardNumber();
		   String pancard = createCard.getUser().getCustomerIdentityProfile().getCustomerPANCardNumber();
		   String drivingLicense = createCard.getUser().getCustomerIdentityProfile().getCustomerDrivingLicenseNumber();
		   String passportNbr = createCard.getUser().getCustomerIdentityProfile().getCustomerPassportNumber();
		   String voterId = createCard.getUser().getCustomerIdentityProfile().getCustomerVoterIdNumber();
		   if (aadhaarNbr != null) {
		      String val = "4";
		      String updatedAadhaar = aadhaarNbr.replaceAll("(.{" + val + "})", "$0 ").trim();
		      cip.setCustomerAadharCardNumber(updatedAadhaar);
		   }
		   if(pancard!=null) {
		      cip.setCustomerPANCardNumber(pancard);
		   }
		   if(drivingLicense!=null && drivingLicense.length()>5) {
		      String updatedDrivingLicence = drivingLicense.substring(0,4) + " "+ drivingLicense.substring(4);
		      cip.setCustomerDrivingLicenseNumber(updatedDrivingLicence);
		   }
		   if(passportNbr!=null) {
		      cip.setCustomerPassportNumber(passportNbr);
		   }
		   if(voterId!=null) {
		      cip.setCustomerVoterIdNumber(voterId);
		   }
		}
	}

	private void buildNotificationRequest(CustomerMiniProfile miniProfile, PrepaidBankMapping mapping, Map<String, String> placeHolder) {
		try {
			NotificationRequest request = NotificationRequest.builder()
					.mobileNumber(miniProfile.getMobileNo())
					.programId(Integer.parseInt(mapping.getBankId()))
					.eventId(AeroConstants.WALLET_CREATE)
					.emailId(miniProfile.getEmailId())
					.whatsappEnabled(false)
					.placeHolders(placeHolder).build();
			log.info("buildNotificationRequest : {}", request);
		} catch (Exception e) {
			log.info("exception in Notification :", e);
		}
	}

	/**
	 *
	 * @param createCard
	 * @param response
	 * @param productConfig
	 * @param card
	 * @param auditId
	 * @param createCardResp
	 * @return
	 */
	private WibmoResponse loadAmount(CreateCard createCard, WibmoResponse response, ProductMaster productConfig, WalletCard card, int auditId, CreateCardResponse createCardResp) {
		String auditRemarks;
		if (createCard.getLoadAmt() > 0) {
			InflowImpl ifImpl = inImplRepository.fetchByImplId(InflowImplConstant.LOAD_MONEY.getImplId());
			if (ifImpl == null) {
				response.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
				response.setResDesc(msgsRepository.fetchMsgValueByMsgName(productConfig.getBankId(),AeroMsgDefinitions.IMPL_ID_NOT_FOUND));
				log.info(msgsRepository.fetchMsgValueByMsgName(productConfig.getBankId(),AeroMsgDefinitions.IMPL_ID_NOT_FOUND));

				auditRemarks = msgsRepository.fetchMsgValueByMsgName(productConfig.getBankId(),AeroMsgDefinitions.IMPL_ID_NOT_FOUND);
				auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
						AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));

				return response;
			}
			log.debug("InflowImplId :{}", ifImpl.getIfImplId());
			CommonHelper.prepareWalletInfo(createCard.getLoadAmt(), card, walletTxnInfo);
			walletTxnInfo.setInflowImplId(ifImpl.getIfImplId());
			walletTxnInfo.setTxnType(ifImpl.getImplDesc());
			walletTxnInfo.setStatus(AeroConstants.CLIENT_RESPONSE_CODE_SUCCESS);
			walletTxnInfo.setStatusDesc(AeroConstants.AUDIT_STATUS_DESC_SUCCESS);
			walletTxnInfo.setComments("load via Creation");
			int id = walletInfoRepository.save(walletTxnInfo);
			walletTxnInfo.setId(id);
			Runnable runnable = () -> updateLMConsumption(createCard, productConfig);
			new Thread(runnable).start();

			//Acknowledge to txn history
			LoadMoneyEvent lm = new LoadMoneyEvent();
			lm.setPpTxnId(String.valueOf(createCardResp.getAccosaTransactionId()));
			lm.setTxnDateStr(CommonUtil.dateToStringWithFormat(new Date(), D_M_YYYY_H_M_S));
			lm.setTxnAmount(createCard.getLoadAmt());
			lm.setMobile(createCard.getUser().getProfile().getMobile());
			lm.setPaymentTxnId(walletTxnInfo.getTxnId());
			lm.setRemarks("load via creation");
			lm.setClosingBalance(createCardResp.getAvailableBalance());
			lm.setTxnType(AckTxnTypes.LM.getType());
			acknowledgeLMTxn(card, lm, productConfig.getBankId());
			log.debug("acknowledgement done for customer Id: {}, LoadCreation txn :{}", createCard.getUser().getAccount().getCustomerId(), walletTxnInfo.getTxnId());


		}
		return null;
	}

	private CreateCardResponse invokeCreateCardApi(CreateCardResponse createCardResponse, CreateCardRequest createCardRequest, AeroCMSConf cmsConfig) {
		try {
			MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
			PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
			String xApiKeyValue = programParametersRepository.fetchParamValueByParamName(mapping.getBankId(),
					ProgramParamConstants.CITRUS_X_API_KEY_VALUE);

			String privateKey = programParametersRepository.fetchParamValueByParamName(mapping.getBankId(),
					ProgramParamConstants.CITRUS_ENC_DEC_PVT_KEY);
			custHeader.add(xApiKey, xApiKeyValue);
			custHeader.add(contentType, APPLICATION_JSON);
			ObjectMapper obj = new ObjectMapper();
			obj.writer().withDefaultPrettyPrinter();
			String reqJson = obj.writeValueAsString(createCardRequest);
			String encryptedReq = aesgcmPayLoadEncryption.encrypt(reqJson,privateKey);
			String reqBody = TOKEN +encryptedReq+ "\"}";
			log.info("reqBody :: {}",reqBody);
			HttpEntity<Object> entity = new HttpEntity<>(reqBody, custHeader);
			
			String url = cmsConfig.getUrl().concat(citrusCreateCardUrl);
			log.info("Concatenated url : " + url);
			ResponseEntity<EncLoadUnloadResponse> responseEntity = restTemplate.exchange(
					url,
					HttpMethod.POST,entity , EncLoadUnloadResponse.class);

			if(responseEntity.getStatusCode() == HttpStatus.OK){
				log.info(SUCCESS_RES_FROM_PREPAID);
				EncLoadUnloadResponse encrptedResp =  responseEntity.getBody();
				log.info("encryptedResp :: {}",encrptedResp);
				String resp=null;
				if(encrptedResp!=null)
					resp = aesgcmPayLoadEncryption.decrypt(encrptedResp.getToken(),privateKey);
				createCardResponse = obj.readValue(resp,CreateCardResponse.class);
				return createCardResponse;
			}else{
				log.error(EXCEPTION_IN_PREPAID, responseEntity.getBody(),responseEntity.getStatusCode());
			}
		} catch (Exception e) {
			log.info("msg :{}", e);
		}
		return createCardResponse;
	}

	/**
	 * @param createCard
	 * @param productConfig
	 */
	private void updateLMConsumption(CreateCard createCard, ProductMaster productConfig) {
		// update consumption
		var request = new UserVelocityCheck();
		request.setBankId(productConfig.getBankId());
		request.setCustomerId(createCard.getUser().getAccount().getCustomerId());
		request.setKycLevel(Integer.valueOf(createCard.getUser().getAccount().getKycLevel()));
		request.setProductType(createCard.getProductType());
		request.setTxnType("LM");
		request.setVal(createCard.getLoadAmt());
		userConsumptionService.updateUserConsumption(request);
	}

	@Override
	public WibmoResponse inquiry(FetchCardRequest inquiry) {
		var wibmoResponse = new WibmoResponse();
		var cardResp = new FetchCardResponse();
		CardInquiryResponse cardInquiryResponse = null;
		PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
		var response = new CMSResponse();

		String wibmoTxnId = null;
		String cardNumber = null;
		WalletCard wc = null;
		try {
			AeroCMSConf cmsConfig = aeroConfRepository.fetchByPPBankId(mapping.getId(),mapping.getBankId());
			// check if walletId avbl in req
			if (inquiry.getWalletId() > 0) {
				wc = wcrepository.fetchById(inquiry.getWalletId(), mapping.getBankId());
			} else {
				wc = wcrepository.fetchByCustIdAndProduct(inquiry.getCustomerId(), inquiry.getProductType(), mapping.getBankId());
			}
			if (null == wc) {
				wibmoResponse.setResCode(10);
				wibmoResponse.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.CUSTID_WALLETID_PRODUCTTYPE_NOT_MATCHING));
				return wibmoResponse;
			}
			cardNumber = wc.getCardNumber();
			var cardInquiryRequest = new CardInquiryRequest();
			cardInquiryRequest = AeroCMSHelper.prepareCardInquiryReq(wibmoTxnId, cardNumber, wc, cmsConfig,
					cardInquiryRequest);
			cardInquiryResponse = invokeCardInquiryApi(cardInquiryResponse, cardInquiryRequest, mapping.getBankId());

			if (cardInquiryResponse == null) {
				log.error(AeroMsgDefinitions.AERO_BANK_RESPONSE);
				wibmoResponse.setResCode(11);
				wibmoResponse
						.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.AERO_CARD_NOT_FOUND));
				return wibmoResponse;
			}

			if (AeroConstants.RESPONSE_CODE_SUCCESS.equals(cardInquiryResponse.getResponseCode())) {
				String walletCardType=progParamRespository.fetchParamValueByParamName(mapping.getBankId(), WALLET_CARD_TYPE);
				wc.setWalletCardType(walletCardType);
				AeroCMSHelper.prepareCMSResponse(response, cardInquiryResponse);
				AeroCMSHelper.prepareFetchCardResp(cardResp, response, cardInquiryResponse, wc);
				wibmoResponse.setResCode(1);
				wibmoResponse.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.FETCH_CARD_DETAILS_SUCCESSFULLY));
				wibmoResponse.setData(cardResp);
			}

		} catch (Exception e) {
			log.debug("error :{}",e);
			wibmoResponse.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_INTERNAL_ERROR);
			wibmoResponse.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_INTERNAL_ERROR));
			return wibmoResponse;
		}
		return wibmoResponse;
	}

	private CardInquiryResponse invokeCardInquiryApi(CardInquiryResponse cardInquiryResponse, CardInquiryRequest cardInquiryRequest, String programId) {
		try {
			log.info("fetch user min profile :: calling for bankId :: {}, customer Id :: {}",programId,cardInquiryRequest.getCustomerId());
			CustomerMiniProfile miniProfile = apiManagerUtil.fetchUserProfile(programId,cardInquiryRequest.getCustomerId(), null);
			if(null != miniProfile) {
				WalletMobileNoBasedInquiryRequest mobileBasedInquiry = new WalletMobileNoBasedInquiryRequest();
				mobileBasedInquiry.setMobileNumber(miniProfile.getMobileNo());
				mobileBasedInquiry.setAccountNumber(Integer.parseInt(cardInquiryRequest.getCustomerId()));
				mobileBasedInquiry.setProgramId(programId);
				WibmoResponse mobileBasedInquiryWibmoResponse  = citrusPrepaidAdapter.getCustomerProfile(mobileBasedInquiry);
				log.info("MobileBasedInquiryWibmoResponse : {}" , mobileBasedInquiryWibmoResponse);
				if(mobileBasedInquiryWibmoResponse.getResCode()==200){
					cardInquiryResponse = new CardInquiryResponse();
					MobilenumberBasedCardInquiryResponse response = MobilenumberBasedCardInquiryResponse.class.cast(mobileBasedInquiryWibmoResponse.getData());
					cardInquiryResponse.setResponseCode(response.getResponseCode());
					cardInquiryResponse.setResponseMessage(response.getResponseMessage());
					cardInquiryResponse.setCardNumber(new StringBuilder("999999999999"+response.getLast4Digits()));//need to check
					cardInquiryResponse.setBankId(response.getBankId());
					cardInquiryResponse.setCustomerId(response.getCustomerId());
					cardInquiryResponse.setClientTxnId(response.getClientTxnId());
					cardInquiryResponse.setUrn(response.getUrn());
					cardInquiryResponse.setMessageCode(response.getMessageCode());
					cardInquiryResponse.setCardStatus(response.getCardStatus());
					cardInquiryResponse.setAvailableBalance(response.getAvailableBalance());
					cardInquiryResponse.setAccosaTransactionId(response.getAccosaTransactionId());
					
					if(response.getCardHolder()!=null) {
						CardHolder cardHolder = new CardHolder();
						cardHolder.setCardholderDateOfBirth(response.getCardHolder().getCardholderDateOfBirth());
						cardHolder.setCardholderCity(response.getCardHolder().getCardholderCity());
						cardHolder.setCardholderAddress(response.getCardHolder().getCardholderAddress());
						cardHolder.setCardholderCountry(response.getCardHolder().getCardholderCountry());
						cardHolder.setCardholderEmail(response.getCardHolder().getCardholderEmail());
						cardHolder.setCardholderMobile(response.getCardHolder().getCardholderMobile());
						cardHolder.setCardholderFirstName(response.getCardHolder().getCardholderFirstName());
						cardHolder.setCardholderLastName(response.getCardHolder().getCardholderLastName());
						cardHolder.setCardProfileId(String.valueOf(response.getCardHolder().getCardProfileId()));
						cardInquiryResponse.setCardHolder(cardHolder);
					}
					log.info("Mapped Mobile number Based Card Inquiry Response to card Inquiry Response : " + cardInquiryResponse);
				}
			}
		} catch (Exception e) {
			log.debug("error while invoking card Inquiry :{}",e);
		}
		return cardInquiryResponse;
	}

	/*
	 * it will fetch the AeroCMSConf details based on ppBankId for prepaid request
	 * generate walletTxnInfo and save the details into wallet_txn_info table
	 * generate prepaid request data and call prepaid api to credit money into
	 * wallet update the prepaid response into wallet_txn_info table
	 *
	 * @param fundLoadReq
	 *
	 * @param bankId
	 *
	 * @param isInflowTxn
	 *
	 * @return Object
	 */


	@Override
	public WibmoResponse fundsLoad(FundRequest fundLoadReq) {
		log.info("CirtrusServiceImpl :: fundsLoad : {}", fundLoadReq);
		PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
		AeroCMSConf cmsConfig = aeroConfRepository.fetchByPPBankId(mapping.getId(),mapping.getBankId());
		var response = new WibmoResponse();
		LoadUnloadResponse loadUnloadResponse = null;
		var auditReq = new AuditApiReq();
		var auditId = 0;

		if (fundLoadReq != null) {
			String auditRemarks = null;
			try {
				AeroCMSHelper.setWalletTxnAuditReq(fundLoadReq, auditReq);
				auditId = auditRepository.save(auditReq);

				WalletCard cardDetails = wcrepository.fetchById(fundLoadReq.getWalletId(), mapping.getBankId());
				if (cardDetails == null) {
					response.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
					response.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_INVALID_WALLET_CARD));
					log.info(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_INVALID_WALLET_CARD));

					auditRemarks = "Invalid Wallet Id passed";
					auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
							AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));

					return response;
				}
				if (!cardDetails.isCreditAllowed()) {
					response.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
					response.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_ISCREDIT_ALLOWED));
					log.info(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_ISCREDIT_ALLOWED));

					auditRemarks = "Wallet Credits disabled";
					auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
							AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));
					return response;
				}

				InflowImpl ifImpl = inImplRepository.fetchByImplDesc(AckTxnTypes.W2UPI.getType().equalsIgnoreCase(fundLoadReq.getTxnType()) ? Constants.P2P_CREDIT :  fundLoadReq.getTxnType());
				if (ifImpl == null) {
					response.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
					response.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.IMPL_ID_NOT_FOUND));
					log.info("ImplId not found in db");

					auditRemarks = "ImplId not found in db";
					auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
							AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));

					return response;
				}

				log.debug("InflowImplId :{}", ifImpl.getIfImplId());
				CommonHelper.prepareWalletInfo(fundLoadReq.getAmount(), cardDetails, walletTxnInfo);
				walletTxnInfo.setOriginalTxnId(fundLoadReq.getRrn());
				walletTxnInfo.setInflowImplId(ifImpl.getIfImplId());
				walletTxnInfo.setTxnType(ifImpl.getImplDesc());
				cmsConfig.setAuditId(auditId);
				WibmoResponse response1 = getWibmoResponse(fundLoadReq, mapping, cmsConfig, response, loadUnloadResponse, cardDetails, ifImpl);
				if (response1 != null) return response1;
			} catch (Exception e) {
				log.error(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_INTERNAL_ERROR)
						+ " : " + e);
				auditRemarks = msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_INTERNAL_ERROR);
				auditRepository.updateApiReq(
						AeroCMSHelper.updateAuditReq(auditId, AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));
				response.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_INTERNAL_ERROR);
				response.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_INTERNAL_ERROR));
			}

		}
		return response;
	}

	private void setHostCustomerIdInCardDetails(WalletCard cardDetails, FundRequest fundLoadReq) {
		if(cardDetails.getHostCustomerId() != null){
			log.info("HostCustomerId is not null {} ",cardDetails.getHostCustomerId());
			fundLoadReq.setCustId(cardDetails.getHostCustomerId());
		}
	}

	private void acknowledgeLMTxn(WalletCard cardDetails,LoadMoneyEvent lm, String bankId) {
		ProductMaster productConfig = aeroPMRepository.fetchByBankAndProdutType(bankId,
				cardDetails.getProductType());
		String productName = null != productConfig.getProductName() ? productConfig.getProductName() : "card";
		String maskPattern = progParamRespository
				.fetchParamValueByParamName(bankId,ProgramParamConstants.CARD_MASK_PATTERN);
		lm.setDestAccount(CommonUtil.maskCardNumberWOPlaceHolder(cardDetails.getCardNumber(),maskPattern));
		lm.setCustomerId(cardDetails.getCustomerId());
		lm.setPaymentMode(cardDetails.getProductType());
		String txnDesc = AckTxnTypes.W2A.getType().equals(lm.getTxnType()) ? "Refunded " : "Added ";
		lm.setTxnDesc(txnDesc+Constants.RS_SYMBOL+CommonUtil.toDecimal(String.valueOf(lm.getTxnAmount()))+" to "+productName);
		if(lm.getTxnType().equals(Constants.W2A)){
			lm.setTxnCategory(Constants.REFUND);
		} else if (lm.getTxnType().equals(Constants.W2UPI)) {
			lm.setTxnCategory(AckTxnTypes.W2UPI_CRED.getType());
		}else{
			lm.setTxnCategory(AckTxnTypes.LM.getType());
			lm.setTxnShortDesc(productName+" XX "+cardDetails.getCardNumber().substring(cardDetails.getCardNumber().length() -4));
		}
		lm.setTxnFlow(Constants.TXN_IN_FLOW);
		lm.setTxnStatus(Constants.TXN_STATUS_SUCCESS);
		TxnDetails txn = new TxnDetails();
		txn.setProgramId(bankId);
		txn.setTxnType(lm.getTxnType());
		txn.setData(lm);
		Runnable runnable = () -> kafkaProducer.publishWalletTxn(txn);
		new Thread(runnable).start();
	}

	private void populateLoadunloadResponse(FundRequest fundLoadReq, WibmoResponse response, LoadUnloadResponse loadUnloadResponse, ParametersLoadUnloadResp parametersLoadUnloadResp, WalletCard cardDetails, LoadUnloadRequest loadUnloadRequest) {
		String auditRemarks;
		if (loadUnloadResponse != null) {
			populateAeroResponse(fundLoadReq, response, loadUnloadResponse, parametersLoadUnloadResp.getAuditId(), cardDetails, fundLoadReq.getBankId());

			String prepaidResponseBody = AeroCMSHelper.convertToJson(loadUnloadResponse);
			fundResponse.setWalletId(walletTxnInfo.getWalletId());
			fundResponse.setAmount(loadUnloadResponse.getTransactionAmount());
			fundResponse.setAvailableBal(loadUnloadResponse.getAvailableBalance());
			fundResponse.setCustId(fundLoadReq.getCustId());
			fundResponse.setRefNumber(String.valueOf(loadUnloadResponse.getAccosaTransactionId()));
			fundResponse.setRemarks(loadUnloadResponse.getDescription());
			fundResponse.setPpTxnId(loadUnloadResponse.getAccosaRefNo());
			fundResponse.setPpResponseCode(loadUnloadResponse.getResponseCode());
			fundResponse.setPpResponseMessage(loadUnloadResponse.getResponseMessage());

			walletTxnInfo.setCmsRef(prepaidResponseBody);
			walletTxnInfo.setStatusDesc(loadUnloadResponse.getResponseMessage());

			response.setData(fundResponse);
			log.info("populateLoadunloadResponse : {}", fundLoadReq.getTxnType());
			if("Load Money".equalsIgnoreCase(fundLoadReq.getTxnType()) || Constants.W2A_REFUND.equalsIgnoreCase(fundLoadReq.getTxnType()) || Constants.P2P_CREDIT.equalsIgnoreCase(parametersLoadUnloadResp.getTxnType())) {
				// acknowledge txn
				LoadMoneyEvent lm = new LoadMoneyEvent();
				lm.setMerTxnId(fundLoadReq.getRrn());
				lm.setPpTxnId(String.valueOf(loadUnloadResponse.getAccosaTransactionId()));
				lm.setClosingBalance(loadUnloadResponse.getAvailableBalance());
				lm.setTxnDateStr(CommonUtil.dateToStringWithFormat(new Date(), D_M_YYYY_H_M_S));
				lm.setTxnAmount(fundLoadReq.getAmount());
				CustomerMiniProfile miniProfile = apiManagerUtil.fetchUserProfile(fundLoadReq.getBankId(), fundLoadReq.getCustId(), null);
				if(null != miniProfile) lm.setMobile(miniProfile.getMobileNo());
				lm.setSourceAccount(fundLoadReq.getSourceAccount());
				lm.setClosingBalance(loadUnloadResponse.getAvailableBalance());
				if(Constants.W2A_REFUND.equalsIgnoreCase(fundLoadReq.getTxnType()))
				{
					lm.setOriginalTxnId(fundLoadReq.getOriginalRRN());
					lm.setTxnType(AckTxnTypes.W2A.getType());
					lm.setTxnShortDesc(fundLoadReq.getBeneficiaryName());
					lm.setPpTxnId(loadUnloadResponse.getAccosaRefNo());
				} else if (Constants.W2UPI.equalsIgnoreCase(fundLoadReq.getTxnType())) {
					lm.setOriginalTxnId(fundLoadReq.getOriginalRRN());
					lm.setTxnType(AckTxnTypes.W2UPI.getType());
					lm.setTxnCategory(AckTxnTypes.W2UPI_CRED.getType());
					lm.setTxnShortDesc(fundLoadReq.getBeneficiaryName());
					lm.setPpTxnId("PUO" + loadUnloadResponse.getAccosaRefNo());
					lm.setDestAccount(String.valueOf(fundLoadReq.getWalletId()));
					lm.setMerchantId(fundLoadReq.getMerchantId());
					lm.setAdditionalFields("W2UPI Credit Success");
				}
				else {
					lm.setOriginalTxnId(fundLoadReq.getRrn());
					lm.setTxnType(AckTxnTypes.LM.getType());
				}
				processAcknowledgeLMTxnByType(fundLoadReq, cardDetails, lm, fundLoadReq.getBankId());
				log.debug("acknowledgement done for customer Id: {}, LM txn :{}", fundLoadReq.getCustId(), fundLoadReq.getRrn());
			}
		} else {
			log.info("received null response from prepaid " + loadUnloadRequest.getOriginalClientTxnId());

			response.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(fundLoadReq.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_NULL));
			walletTxnInfo.setStatus(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
			walletTxnInfo.setStatusDesc(msgsRepository.fetchMsgValueByMsgName(fundLoadReq.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_NULL));
			auditRemarks = msgsRepository.fetchMsgValueByMsgName(fundLoadReq.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_NULL);
			auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(parametersLoadUnloadResp.getAuditId(),
					AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));
		}
	}

	private void populateAeroResponse(FundRequest fundLoadReq, WibmoResponse response, LoadUnloadResponse loadUnloadResponse, int auditId, WalletCard cardDetails, String bankId) {
		String auditRemarks;
		if (AeroConstants.RESPONSE_CODE_SUCCESS.equals(loadUnloadResponse.getResponseCode())) {
			log.info("prepaid response " + loadUnloadResponse.getResponseCode());

			walletTxnInfo.setStatus(AeroConstants.CLIENT_RESPONSE_CODE_SUCCESS);
			response.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_SUCCESS);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.FUND_CREDITED_SUCCESSFULLY));
			auditRemarks = msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.FUND_CREDITED_SUCCESSFULLY);
			auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
					AeroConstants.AUDIT_STATUS_DESC_SUCCESS, auditRemarks));
			String maskPattren = progParamRespository
					.fetchParamValueByParamName(bankId,ProgramParamConstants.CARD_MASK_PATTERN);
			walletTxnInfo.setComments("Load Money".equalsIgnoreCase(fundLoadReq.getTxnType())
					? ADD_MONEY + CommonUtil.mask(maskPattren, cardDetails.getCardNumber(), "X")
					: loadUnloadResponse.getDescription());

		} else {
			walletTxnInfo.setStatus(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
			response.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
			response.setResDesc(loadUnloadResponse.getResponseMessage());
			auditRemarks = loadUnloadResponse.getResponseMessage();
			auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
					AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));
			walletTxnInfo.setComments(loadUnloadResponse.getDescription());
		}
	}

	private void populateReserve5(InflowImpl ifImpl, LoadUnloadRequest loadUnloadRequest) {
		if (ifImpl.getImplDesc() != null) {
			loadUnloadRequest.setReserved5(ifImpl.getImplDesc());
		} else {
			log.debug("ImplDesc is null");
			loadUnloadRequest.setReserved5("PG Load");
		}
	}

	private WibmoResponse validateCard(WibmoResponse response, int auditId, WalletCard cardDetails, LoadUnloadRequest loadUnloadRequest, String bankId) {
		String auditRemarks;
		if (cardDetails.getCardNumber() != null && cardDetails.getCardNumber().length() >= 4) {
			log.info("cardNumber is not null && cardNumber length is greater than zero ");
			loadUnloadRequest.setLast4Digits(
					cardDetails.getCardNumber().substring(cardDetails.getCardNumber().length() - 4));
		}else if(cardDetails.getCardNumber().length() == 4){
			log.info("cardNumber is has 4 digits ");
			loadUnloadRequest.setLast4Digits(cardDetails.getCardNumber());
		} else {
			response.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.AERO_CARD_NOT_FOUND));
			log.info(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.AERO_CARD_NOT_FOUND));
			auditRemarks = msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.AERO_CARD_NOT_FOUND);
			auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
					AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));

			return response;
		}
		return null;
	}

	private LoadUnloadResponse invokeCreditFundApi(LoadUnloadResponse loadUnloadResponse, LoadUnloadRequest loadUnloadRequest, String bankId, AeroCMSConf cmsConfig) {
		try {
			log.info("CitrusServiceImpl :: invokeCreditFundApi");
			MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
			PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
			String xApiKeyValue = programParametersRepository.fetchParamValueByParamName(mapping.getBankId(),
					ProgramParamConstants.CITRUS_X_API_KEY_VALUE);

			String privateKey = programParametersRepository.fetchParamValueByParamName(mapping.getBankId(),
					ProgramParamConstants.CITRUS_ENC_DEC_PVT_KEY);
			custHeader.add(xApiKey, xApiKeyValue);
			custHeader.add(contentType, APPLICATION_JSON);
			ObjectMapper obj = new ObjectMapper();
			obj.writer().withDefaultPrettyPrinter();
			String reqJson = obj.writeValueAsString(loadUnloadRequest);
			log.debug("LoadUnloadRequest : {}", reqJson);
			String encryptedReq = aesgcmPayLoadEncryption.encrypt(reqJson,privateKey);
			String reqBody = TOKEN +encryptedReq+ "\"}";
			HttpEntity<Object> entity = new HttpEntity<>(reqBody, custHeader);
			
			String url = cmsConfig.getUrl().concat(citrusFundsCreditUrl);
			ResponseEntity<EncLoadUnloadResponse> responseEntity = restTemplate.exchange(
					url,
					HttpMethod.POST,entity , EncLoadUnloadResponse.class);
			if(responseEntity.getStatusCode() == HttpStatus.OK){
				log.info(SUCCESS_RES_FROM_PREPAID);
				EncLoadUnloadResponse encrptedResp =  responseEntity.getBody();
				String resp=null;
				if(encrptedResp!=null)
					resp =  aesgcmPayLoadEncryption.decrypt(encrptedResp.getToken(),privateKey);
				log.debug("response from prepaid : LoadUnloadResponse obj : {}", resp);
				loadUnloadResponse = obj.readValue(resp,LoadUnloadResponse.class);
				return loadUnloadResponse;
			}else{
				log.error(EXCEPTION_IN_PREPAID, responseEntity.getBody(),responseEntity.getStatusCode());
			}
		} catch (Exception e) {
			log.error(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.RESPONSE_DESC_INTERNAL_ERROR)
					+ " : " + e);
		}
		return loadUnloadResponse;
	}

	@Override
	public WibmoResponse fundsUnload(FundRequest fundUnloadReq) {
		log.info("request for wallet debit");
		log.info("CitrusServiceImpl :: fundsUnload ");
		PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
		AeroCMSConf cmsConfig = aeroConfRepository.fetchByPPBankId(mapping.getId(), mapping.getBankId());
		var debitRes = new WibmoResponse();
		var auditReq = new AuditApiReq();
		LoadUnloadResponse loadUnloadRes = null;
		var auditId = 0;
		String auditRemarks = null;
		if (fundUnloadReq != null) {

			try {
				AeroCMSHelper.setWalletTxnAuditReq(fundUnloadReq, auditReq);
				auditId = auditRepository.save(auditReq);

				var yyyyMMddhhmmss = new SimpleDateFormat(dateFormat);
				WalletCard card = wcrepository.fetchById(fundUnloadReq.getWalletId(), mapping.getBankId());
				if (card == null) {
					debitRes.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
					debitRes.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_INVALID_WALLET_CARD));
					log.info("Wallet details not found, please provide correct wallet details");
					auditRemarks = "Wallet details not found";
					auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
							AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));

					return debitRes;
				}
				if (!card.isDebitAllowed()) {
					debitRes.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
					debitRes.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_ISDEBIT_ALLOWED));
					log.info(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_ISDEBIT_ALLOWED));
					auditRemarks = msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_ISDEBIT_ALLOWED);
					auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
							AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));

					return debitRes;
				}

				OutflowImpl ofImpl = ofImplRepository.fetchByImplDesc(fundUnloadReq.getTxnType());

				if (ofImpl == null) {
					debitRes.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
					debitRes.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.IMPL_ID_NOT_FOUND));
					log.info("OutflowImplId details not available in db");

					auditRemarks = "OutflowImplId details not available in db";
					auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
							AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));

					return debitRes;
				}
				walletTxnInfo = AeroCMSHelper.prepareWalletInfo(fundUnloadReq.getAmount(), card);
				walletTxnInfo.setOutflowImplId(ofImpl.getOfImplId());
				walletTxnInfo.setTxnType(ofImpl.getImplDesc());
				walletTxnInfo.setMerchantId(fundUnloadReq.getMerchantId());
				walletTxnInfo.setOriginalTxnId(fundUnloadReq.getRrn());

				var loadUnloadReq = new LoadUnloadRequest();
				loadUnloadReq = AeroCMSHelper.populateCommon(loadUnloadReq, yyyyMMddhhmmss, cmsConfig);
				loadUnloadReq.setMessageCode(AeroConstants.REQUEST_DEBIT_ACCOUNT);
				loadUnloadReq.setSourceAccount(cmsConfig.getSourceAccount());
				loadUnloadReq.setSourceAccountType(cmsConfig.getSourceAccountType());
				WibmoResponse debitRes1 = checkCardNumber(debitRes, auditId, card, loadUnloadReq, mapping.getBankId());
				if (debitRes1 != null) return debitRes1;
				if(card.getHostCustomerId() != null){
					log.info("Funds unload HostCustomerId is not null {} ",card.getHostCustomerId());
					fundUnloadReq.setCustId(card.getHostCustomerId());
				}
				loadUnloadReq.setCustomerId(fundUnloadReq.getCustId());
				loadUnloadReq.setTransactionAmount(fundUnloadReq.getAmount());
				loadUnloadReq.setClientTxnId(walletTxnInfo.getTxnId());
				loadUnloadReq.setAgentComments("Debit money from Wallet");
				loadUnloadReq.setReserved1(loadUnloadReq.getMessageCode());
				loadUnloadReq.setReserved2(loadUnloadReq.getAgentComments());
				var clientEventId = new StringBuilder();
				clientEventId.append(AeroConstants.FUND_FLOW_TYPE_OUTFLOW).append("|");
				clientEventId.append(ofImpl.getOfImplId());
				loadUnloadReq.setReserved4(clientEventId.toString());
				populateReserved5(ofImpl, loadUnloadReq);
				log.info("Debit request send to prepaid, custId:{}, TxnId:{}",
						new Object[] { loadUnloadReq.getCustomerId(), loadUnloadReq.getClientTxnId() });
				loadUnloadReq.setDestinationAccountType(0);

				loadUnloadRes = invokeDebitFundApi(loadUnloadRes, loadUnloadReq, cmsConfig);

				populateAeroResp(fundUnloadReq, debitRes, loadUnloadRes, auditId, loadUnloadReq, mapping.getBankId());
				log.info("saving wallet txn info info into DB, ClientTxnId:{}", walletTxnInfo.getTxnId());
				int id = walletInfoRepository.save(walletTxnInfo);
				log.debug("DB Id :{}", id);

			} catch (Exception e) {
				log.error("Error : " + e);
				auditRemarks = EXCEPTION_OCCURRED;
				auditRepository.updateApiReq(
						AeroCMSHelper.updateAuditReq(auditId, AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));
				debitRes.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_INTERNAL_ERROR);
				debitRes.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_INTERNAL_ERROR));
			}
		}

		return debitRes;
	}

	private void populateAeroResp(FundRequest fundUnloadReq, WibmoResponse debitRes, LoadUnloadResponse loadUnloadRes, int auditId, LoadUnloadRequest loadUnloadReq, String bankId) {
		String auditRemarks;
		if (null != loadUnloadRes) {
			if (AeroConstants.RESPONSE_CODE_SUCCESS.equals(loadUnloadRes.getResponseCode())) {
				walletTxnInfo.setStatus(AeroConstants.CLIENT_RESPONSE_CODE_SUCCESS);
				walletTxnInfo.setStatusDesc(loadUnloadRes.getResponseMessage());
				walletTxnInfo.setComments(loadUnloadRes.getDescription());
				debitRes.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_SUCCESS);
				debitRes.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.FUND_DEBITED_SUCCESSFULLY));

				auditRemarks = msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.FUND_DEBITED_SUCCESSFULLY);
				auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
						AeroConstants.AUDIT_STATUS_DESC_SUCCESS, auditRemarks));
			} else {
				log.info(PREPAID_RESPONSE_MSG, loadUnloadRes.getResponseMessage());
				walletTxnInfo.setStatus(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
				walletTxnInfo.setStatusDesc(loadUnloadRes.getResponseMessage());
				debitRes.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
				debitRes.setResDesc(loadUnloadRes.getResponseMessage());

				auditRemarks = loadUnloadRes.getResponseMessage();
				auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
						AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));

			}
			String cmsResponseBody = AeroCMSHelper.convertToJson(loadUnloadRes);
			walletTxnInfo.setCmsRef(cmsResponseBody);
			walletTxnInfo.setPpTxnId(loadUnloadRes.getAccosaRefNo());
			// Setting Response object
			fundResponse.setWalletId(fundUnloadReq.getWalletId());
			fundResponse.setCustId(fundUnloadReq.getCustId());
			fundResponse.setAmount(loadUnloadReq.getTransactionAmount());
			fundResponse.setAvailableBal(loadUnloadRes.getAvailableBalance());
			fundResponse.setRefNumber(loadUnloadReq.getClientTxnId());
			fundResponse.setRemarks(loadUnloadRes.getDescription());
			fundResponse.setPpTxnId(loadUnloadRes.getAccosaRefNo());
			debitRes.setData(fundResponse);
		} else {
			log.info("null response from prepaid, OriginalTxnId:{} ", loadUnloadReq.getOriginalClientTxnId());
			debitRes.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
			debitRes.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.RESPONSE_DESC_NULL));
			auditRemarks = "null response from prepaid";
			auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
					AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));
		}
	}

	private void populateReserved5(OutflowImpl ofImpl, LoadUnloadRequest loadUnloadReq) {
		if (ofImpl.getImplDesc() != null) {
			loadUnloadReq.setReserved5(ofImpl.getImplDesc());
		} else {
			log.debug(IMPL_DESC_IS_NOT_AVAILABLE_IN_DB);
			loadUnloadReq.setReserved5("Debit Fund");
		}
	}

	private WibmoResponse checkCardNumber(WibmoResponse debitRes, int auditId, WalletCard card, LoadUnloadRequest loadUnloadReq, String bankId) {
		String auditRemarks;
		log.info("card.getCardNumber() :: {} ",card.getCardNumber());
		if (card.getCardNumber() != null && card.getCardNumber().length() > 4) {
			loadUnloadReq.setLast4Digits(card.getCardNumber().substring(card.getCardNumber().length() - 4));
			loadUnloadReq.setUrn(card.getBankUrn());
		}else if(card.getCardNumber() != null && card.getCardNumber().length() == 4){
			loadUnloadReq.setLast4Digits(card.getCardNumber());
			loadUnloadReq.setUrn(card.getBankUrn());
		} else {
			debitRes.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
			debitRes.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.CARD_NOT_FOUND));
			log.info(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.CARD_NOT_FOUND));
			auditRemarks = msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.CARD_NOT_FOUND);
			auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
					AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));

			return debitRes;
		}
		return null;
	}

	private LoadUnloadResponse invokeDebitFundApi(LoadUnloadResponse loadUnloadRes, LoadUnloadRequest loadUnloadReq, AeroCMSConf cmsConfig) {
		try {
			log.info("CitrusServiceImpl :: invokeDebitFundApi()");
			MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
			PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
			String xApiKeyValue = programParametersRepository.fetchParamValueByParamName(mapping.getBankId(),
					ProgramParamConstants.CITRUS_X_API_KEY_VALUE);

			String privateKey = programParametersRepository.fetchParamValueByParamName(mapping.getBankId(),
					ProgramParamConstants.CITRUS_ENC_DEC_PVT_KEY);
			custHeader.add(xApiKey, xApiKeyValue);
			custHeader.add(contentType, APPLICATION_JSON);
			ObjectMapper obj = new ObjectMapper();
			obj.writer().withDefaultPrettyPrinter();
			String reqJson = obj.writeValueAsString(loadUnloadReq);
			String encryptedReq = aesgcmPayLoadEncryption.encrypt(reqJson,privateKey);
			log.debug("LoadUnloadRequest obj : {}", reqJson);
			String reqBody = TOKEN +encryptedReq+ "\"}";
			HttpEntity<Object> entity = new HttpEntity<>(reqBody, custHeader);

			String url = cmsConfig.getUrl().concat(citrusFundsDebitUrl);
			ResponseEntity<EncLoadUnloadResponse>  responseEntity= restTemplate.exchange(url,HttpMethod.POST,entity, EncLoadUnloadResponse.class);

			if(responseEntity.getStatusCode() == HttpStatus.OK){
				log.info(SUCCESS_RES_FROM_PREPAID);
				EncLoadUnloadResponse encrptedResp =  responseEntity.getBody();
				String resp=null;
				if(encrptedResp!=null)
					resp = aesgcmPayLoadEncryption.decrypt(encrptedResp.getToken(),privateKey);
				log.debug("response object from prepaid : LoadUnloadResponse : {}", resp);
				loadUnloadRes = obj.readValue(resp,LoadUnloadResponse.class);
				return loadUnloadRes;
			}else{
				log.error(EXCEPTION_IN_PREPAID, responseEntity.getBody(),responseEntity.getStatusCode());
			}
		} catch (Exception e) {
			log.error("exception occured during the prepaid call " + e);
		}
		return loadUnloadRes;
	}

	@Override
	public WibmoResponse fetchCardStatus(FetchCardStatusRequest inquiry) {
		var wibmoResponse = new WibmoResponse();
		var cardResp = new FetchCardStatusResponse();
		PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
		String programId = mapping.getBankId();
		var response = new CMSResponse();
		CardInquiryResponse cardInquiryResponse = null;
		String wibmoTxnId = null;
		String cardNumber = null;
		WalletCard wc = null;
		try {
			AeroCMSConf cmsConfig = aeroConfRepository.fetchByPPBankId(mapping.getId(), mapping.getBankId());
			// check if walletId avbl in req
			if (inquiry.getWalletId() > 0) {
				wc = wcrepository.fetchById(inquiry.getWalletId(), mapping.getBankId());
			} else {
				wc = wcrepository.fetchByCustIdAndProduct(inquiry.getCustomerId(), inquiry.getProductType(), mapping.getBankId());
			}

			if (null == wc) {
				wibmoResponse.setResCode(10);
				wibmoResponse.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.CUSTID_WALLETID_PRODUCTTYPE_NOT_MATCHING));
				return wibmoResponse;
			}
			cardNumber = wc.getCardNumber();
			var cardInquiryRequest = new CardInquiryRequest();
			cardInquiryRequest = AeroCMSHelper.prepareCardInquiryReq(wibmoTxnId, cardNumber, wc, cmsConfig,
					cardInquiryRequest);
			cardInquiryResponse = invokeCardInquiryApi(cardInquiryResponse, cardInquiryRequest, programId);

			if (cardInquiryResponse == null) {
				log.error(AeroMsgDefinitions.AERO_BANK_RESPONSE);
				wibmoResponse.setResCode(11);
				wibmoResponse.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.CARD_NOT_FOUND));
				return wibmoResponse;
			}

			if (AeroConstants.RESPONSE_CODE_SUCCESS.equals(cardInquiryResponse.getResponseCode())) {
				AeroCMSHelper.prepareCMSResponse(response, cardInquiryResponse);
				AeroCMSHelper.prepareFetchCardStatus(cardResp, response, wc);
				wibmoResponse.setResCode(1);
				wibmoResponse.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.FETCH_CARD_DETAILS_SUCCESSFULLY));
				wibmoResponse.setData(cardResp);
			}

		} catch (Exception e) {
			log.error(EXCEPTION,e);
			wibmoResponse.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_INTERNAL_ERROR);
			wibmoResponse.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_INTERNAL_ERROR));
			return wibmoResponse;
		}
		return wibmoResponse;
	}

	@Override
	public WibmoResponse fetchCardBalance(FetchCardBalanceRequest inquiry) {
		var wibmoResponse = new WibmoResponse();
		var cardResp = new FetchCardBalanceResponse();
		PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
		var response = new CMSResponse();
		CardInquiryResponse cardInquiryResponse = null;
		String wibmoTxnId = null;
		String cardNumber = null;
		WalletCard wc = null;
		try {
			AeroCMSConf cmsConfig = aeroConfRepository.fetchByPPBankId(mapping.getId(), mapping.getBankId());
			// check if walletId avbl in req
			if (inquiry.getWalletId() > 0) {
				wc = wcrepository.fetchById(inquiry.getWalletId(), mapping.getBankId());
			} else {
				wc = wcrepository.fetchByCustIdAndProduct(inquiry.getCustomerId(), inquiry.getProductType(), mapping.getBankId());
			}

			if (null == wc) {
				wibmoResponse.setResCode(10);
				wibmoResponse.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.CARD_NOT_FOUND));
				return wibmoResponse;
			}
			cardNumber = wc.getCardNumber();
			var cardInquiryRequest = new CardInquiryRequest();
			cardInquiryRequest = AeroCMSHelper.prepareCardInquiryReq(wibmoTxnId, cardNumber, wc, cmsConfig,
					cardInquiryRequest);
			cardInquiryResponse = invokeCardInquiryApi(cardInquiryResponse, cardInquiryRequest, mapping.getBankId());

			if (cardInquiryResponse == null) {
				log.error("Operation failed. Blank response from Aero");
				wibmoResponse.setResCode(11);
				wibmoResponse.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.PREPAID_CARD_DETAILS_NOT_FOUND));
				return wibmoResponse;
			}

			if (AeroConstants.RESPONSE_CODE_SUCCESS.equals(cardInquiryResponse.getResponseCode())) {
				AeroCMSHelper.prepareCMSResponse(response, cardInquiryResponse);
				AeroCMSHelper.prepareFetchCardBalance(cardResp, cardInquiryResponse, wc);
				wibmoResponse.setResCode(1);
				wibmoResponse.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.FETCH_CARD_DETAILS_SUCCESSFULLY));
				wibmoResponse.setData(cardResp);
			}

		} catch (Exception e) {
			log.error(EXCEPTION,e);
			wibmoResponse.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_INTERNAL_ERROR);
			wibmoResponse.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_INTERNAL_ERROR));
			return wibmoResponse;
		}
		return wibmoResponse;
	}

	@Override
	public WibmoResponse fetchCardCVV(FetchCardCVVRequest inquiry) {
		var wibmoResponse = new WibmoResponse();
		var cardResp = new FetchCardCVVResponse();
		PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
		var response = new CMSResponse();
		CardInquiryResponse cardInquiryResponse = null;
		String wibmoTxnId = null;
		String cardNumber = null;
		WalletCard wc = null;
		try {
			AeroCMSConf cmsConfig = aeroConfRepository.fetchByPPBankId(mapping.getId(), mapping.getBankId());
			// check if walletId avbl in req
			if (inquiry.getWalletId() > 0) {
				wc = wcrepository.fetchById(inquiry.getWalletId(), mapping.getBankId());
			} else {
				wc = wcrepository.fetchByCustIdAndProduct(inquiry.getCustomerId(), inquiry.getProductType(), mapping.getBankId());
			}

			if (null == wc) {
				wibmoResponse.setResCode(10);
				wibmoResponse.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.CUSTID_WALLETID_PRODUCTTYPE_NOT_MATCHING));
				return wibmoResponse;
			}
			cardNumber = wc.getCardNumber();
			var cardInquiryRequest = new CardInquiryRequest();
			cardInquiryRequest = AeroCMSHelper.prepareCardInquiryReq(wibmoTxnId, cardNumber, wc, cmsConfig,
					cardInquiryRequest);
			cardInquiryResponse = invokeCardInquiryApi(cardInquiryResponse, cardInquiryRequest,mapping.getBankId());

			if (cardInquiryResponse == null) {
				log.error("Operation failed. Blank response from Aero");
				wibmoResponse.setResCode(11);
				wibmoResponse.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.PREPAID_CARD_DETAILS_NOT_FOUND));
				return wibmoResponse;
			}

			if (AeroConstants.RESPONSE_CODE_SUCCESS.equals(cardInquiryResponse.getResponseCode())) {
				AeroCMSHelper.prepareCMSResponse(response, cardInquiryResponse);
				AeroCMSHelper.prepareFetchCardCVV(cardResp, cardInquiryResponse, wc);
				wibmoResponse.setResCode(1);
				wibmoResponse.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.FETCH_CARD_DETAILS_SUCCESSFULLY));
				wibmoResponse.setData(cardResp);
			}

		} catch (Exception e) {
			log.error(EXCEPTION,e);
			wibmoResponse.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_INTERNAL_ERROR);
			wibmoResponse.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_INTERNAL_ERROR));
			return wibmoResponse;
		}
		return wibmoResponse;
	}

	@Override
	public List<FetchCardResponse> fetchByWc(List<WalletCard> wcs) {
		List<FetchCardResponse> cardsResp = new ArrayList<>(wcs.size());
		CardInquiryResponse cardInquiryResponse = null;
		PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
		var response = new CMSResponse();
		String wibmoTxnId = null;
		String cardNumber = null;
		try {
			AeroCMSConf cmsConfig = aeroConfRepository.fetchByPPBankId(mapping.getId(), mapping.getBankId());
			for (WalletCard wc : wcs) {
				var cardResp = new FetchCardResponse();
				cardNumber = wc.getCardNumber();
				var cardInquiryRequest = new CardInquiryRequest();
				cardInquiryRequest = AeroCMSHelper.prepareCardInquiryReq(wibmoTxnId, cardNumber, wc, cmsConfig,
						cardInquiryRequest);
				cardInquiryResponse = invokeCardInquiryApi(cardInquiryResponse, cardInquiryRequest, mapping.getBankId());

				if (cardInquiryResponse == null) {
					log.error(AeroMsgDefinitions.AERO_BANK_RESPONSE);
					continue;
				}

				if (AeroConstants.RESPONSE_CODE_SUCCESS.equals(cardInquiryResponse.getResponseCode())) {
					String walletCardType=progParamRespository.fetchParamValueByParamName(mapping.getBankId(), WALLET_CARD_TYPE);
					wc.setWalletCardType(walletCardType);
					AeroCMSHelper.prepareCMSResponse(response, cardInquiryResponse);
					AeroCMSHelper.prepareFetchCardResp(cardResp, response, cardInquiryResponse, wc);
					if(wc.getWalletCardType().equals("CLOSED_LOOP")) {
						cardResp.setCardNumber(null);
						cardResp.setCardExpiry(null);
					}

					cardsResp.add(cardResp);
				}
			}

		} catch (Exception e) {
			log.error(EXCEPTION,e);

		}
		return cardsResp;
	}

	public WibmoResponse sendMoney(SendMoneyRequest sendMoneyReq) {
		log.debug("citrusServiceImpl : sendMoney - sendMoneyRequest: {}", sendMoneyReq);
		PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
		AeroCMSConf cmsConfig = aeroConfRepository.fetchByPPBankId(mapping.getId(), mapping.getBankId());
		chkProductType(sendMoneyReq);
		UserAccountInfo senderUserInfo = new UserAccountInfo();
		CustomerMiniProfile miniProfile = apiManagerUtil.fetchUserProfile(mapping.getBankId(), sendMoneyReq.getSenderCustomerId(), null);
		setSenderUserInfo(miniProfile, sendMoneyReq, senderUserInfo);
		var response = new WibmoResponse();
		setResponseKycNotEkyc(miniProfile, response);
		var auditReq = new AuditApiReq();
		var auditId = 0;
		String auditRemarks = null;
		WalletTxnInfo recipientTxnInfo = null;
		try {
			AeroCMSHelper.setWalletTxnAuditReq(sendMoneyReq, auditReq);
			log.info("saving data into audit_api_req table in DB");
			auditId = auditRepository.save(auditReq);
			P2PDebitEvent p2pd = new P2PDebitEvent();
			prepareDebitTxnInfo(sendMoneyReq, p2pd);
			var yyyyMMddhhmmss = new SimpleDateFormat(dateFormat);
			WibmoResponse response1 = validateSenderUserInfo(sendMoneyReq, response, auditId, senderUserInfo, p2pd, mapping.getBankId());
			if (response1 != null) return response1;
			// Fetch Sender Card Details for Debit
			WalletCard senderCard = wcrepository.fetchByCustIdAndId(sendMoneyReq.getSenderCustomerId(),
					sendMoneyReq.getSenderWalletId(), mapping.getBankId());
			WibmoResponse response2 = validateSenderCard(response, auditId, senderCard, p2pd, mapping.getBankId());
			if (response2 != null) return response2;

			// Fetch Recipient Card Details for Credit
			WalletCard recipientCard = null;
			CustomerMiniProfile receipientMiniProfile = null;
			String recipientCustId = null;
			var recipientkyc = 0;
			if (sendMoneyReq.getRecipientMobileNo() != null) {
				receipientMiniProfile = apiManagerUtil.fetchUserProfile(mapping.getBankId(), null,sendMoneyReq.getRecipientMobileNo());
				if (receipientMiniProfile == null) {
					response.setResCode(150);
					response.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RECIPIENT_USER_ACCOUNT_NOT_AVAILABLE_FOR_MOBILE));
					log.info("Recipient User Account details not available for this mobile number");
					auditRemarks = "Recipient User Account details not found";
					auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
							AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));
					p2pFailureTxnAck(p2pd, response, mapping.getBankId());
					return response;
				}
				recipientCard = wcrepository.fetchByCustIdAndProduct(receipientMiniProfile.getCustomerId(),
						sendMoneyReq.getProductType(), mapping.getBankId());
				recipientCustId = receipientMiniProfile.getCustomerId();
				recipientkyc = receipientMiniProfile.getKycLevel();
			}
			WibmoResponse response5 = validateRecipientCard(response, auditId, recipientCard, mapping.getBankId());
			if (response5 != null) return response5;
			OutflowImpl ofImpl = ofImplRepository.fetchByImplId(OutflowImplConstant.P2P_DEBIT.getImplId());
			if (ofImpl == null) {
				response.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
				response.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.IMPL_ID_NOT_FOUND));
				log.info("OutflowImplId is not available for P2P Debit in db");

				auditRemarks = "OutflowImplId is not available for P2P Debit in db";
				auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
						AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));
				p2pFailureTxnAck(p2pd, response, mapping.getBankId());
				return response;
			}
			InflowImpl ifImpl = inImplRepository.fetchByImplId(InflowImplConstant.P2P_CREDIT.getImplId());
			if (ifImpl == null) {
				response.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
				response.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.IMPL_ID_NOT_FOUND));
				log.info("InflowImplId is not available for P2P Credit in db");

				auditRemarks = "InflowImplId is not available for P2P Credit in db";
				auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
						AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));
				p2pFailureTxnAck(p2pd, response, mapping.getBankId());
				return response;
			}
			UserVelocityCheck senderVelocityChkReq = AeroCMSHelper.prepareVelocityCheckReq(
					senderUserInfo.getCustomerId(), sendMoneyReq.getAmount(), "P2P", senderCard.getCardNumber(),
					senderUserInfo.getKycLevel(), mapping.getBankId());
			UserVelocityCheck recipientVelocityChkReq = AeroCMSHelper.prepareVelocityCheckReq(
					recipientCustId, sendMoneyReq.getAmount(), "P2PR",
					recipientCard.getCardNumber(), recipientkyc, mapping.getBankId());
			WibmoResponse velocityLimitRes = checkVelocityLimits(auditId, senderVelocityChkReq, recipientVelocityChkReq, p2pd,  mapping.getBankId());
			if (velocityLimitRes != null) return velocityLimitRes;

			walletTxnInfo = AeroCMSHelper.prepareWalletInfo(sendMoneyReq.getAmount(), senderCard);
			walletTxnInfo.setOutflowImplId(ofImpl.getOfImplId());
			walletTxnInfo.setTxnType(setOfTxnType(sendMoneyReq, ofImpl));

			recipientTxnInfo = AeroCMSHelper.prepareWalletInfo(sendMoneyReq.getAmount(), recipientCard);
			recipientTxnInfo.setInflowImplId(ifImpl.getIfImplId());

			recipientTxnInfo.setTxnType(setIfTxnType(sendMoneyReq, ifImpl));

			var fundTransferReq = new FundTransferRequest();
			fundTransferReq = (FundTransferRequest) AeroCMSHelper.populateCommon(fundTransferReq, yyyyMMddhhmmss,
					cmsConfig);
			fundTransferReq.setMessageCode(AeroConstants.REQUEST_SEND_MONEY);
			fundTransferReq.setSourceAccount(cmsConfig.getSourceAccount());
			fundTransferReq.setSourceAccountType(cmsConfig.getSourceAccountType());
			fundTransferReq.setClientTxnId(walletTxnInfo.getTxnId());
			fundTransferReq.setCustomerId(senderCard.getHostCustomerId() != null ?senderCard.getHostCustomerId():sendMoneyReq.getSenderCustomerId());
			fundTransferReq.setAgentComments(sendMoneyReq.getRemarks());
			fundTransferReq.setTransactionAmount(sendMoneyReq.getAmount());
			WibmoResponse response3 = validateCardNumber(response, auditId, senderCard, fundTransferReq, p2pd, mapping.getBankId());
			if (response3 != null) return response3;
			fundTransferReq.setOriginalClientTxnId(fundTransferReq.getClientTxnId());

			var arr = new Sender[1];
			var sender = new Sender();

			sender.setLast4Digits(fundTransferReq.getLast4Digits());
			sender.setUrn(Long.parseLong(senderCard.getBankUrn()));
			sender.setCustomerId(senderCard.getHostCustomerId() !=null ?senderCard.getHostCustomerId():senderCard.getCustomerId());
			sender.setTransactionAmount(fundTransferReq.getTransactionAmount());
			sender.setSourceAccount(cmsConfig.getSourceAccount());
			sender.setSourceAccountType(cmsConfig.getSourceAccountType());
			sender.setReserved1(fundTransferReq.getMessageCode());
			sender.setReserved2(ofImpl.getImplDesc());
			var ofClientEventId = new StringBuilder();
			ofClientEventId.append(AeroConstants.FUND_FLOW_TYPE_OUTFLOW).append("|");
			ofClientEventId.append(ofImpl.getOfImplId());
			sender.setReserved4(ofClientEventId.toString());
			setReserved5Param(ofImpl, sender);
			arr[0] = sender;
			fundTransferReq.setSenders(arr);

			var arr2 = new Receiver[1];
			var receiver = new Receiver();
			WibmoResponse response4 = validateRecipientCard(response, auditId, recipientCard, receiver, p2pd, mapping.getBankId());
			if (response4 != null) return response4;

			receiver.setCustomerId(recipientCard.getHostCustomerId()!=null?recipientCard.getHostCustomerId():recipientCard.getCustomerId());
			receiver.setTransactionAmount(fundTransferReq.getTransactionAmount() + "");
			receiver.setReserved1(fundTransferReq.getMessageCode());
			receiver.setReserved2(ifImpl.getImplDesc());
			var ifClientEventId = new StringBuilder();
			ifClientEventId.append(AeroConstants.FUND_FLOW_TYPE_INFLOW).append("|");
			ifClientEventId.append(ifImpl.getIfImplId());
			receiver.setReserved4(ifClientEventId.toString());
			setImplDesc(ifImpl, receiver);
			arr2[0] = receiver;
			fundTransferReq.setReceivers(arr2);

			// Calling Prepaid for Debit and credit the wallet
			log.info("calling prepaid for money transfer, ClientTxnId:{}", fundTransferReq.getClientTxnId());
			var fund = new FundTransferVO();
			fund.setAuditId(auditId);
			fund.setCmsConfig(cmsConfig);
			fund.setFundTransferReq(fundTransferReq);
			fund.setMapping(mapping);
			fund.setRecipientAccInfo(receipientMiniProfile);
			fund.setRecipientCard(recipientCard);
			fund.setRecipientTxnInfo(recipientTxnInfo);
			fund.setResponse(response);
			fund.setSenderCard(senderCard);
			setSenderCustomerId(senderCard, sendMoneyReq);
			fund.setSendMoneyReq(sendMoneyReq);
			invokeFundTransferApi(fund, p2pd, cmsConfig);
			log.info("saving wallet txn info into DB, ClientTxnId:{}", walletTxnInfo.getTxnId());
			walletInfoRepository.save(walletTxnInfo);
			saveWalletInfoByClientCode(walletTxnInfo, recipientTxnInfo);
			//send notification alert to receiver regarding money sent to him
			callingNotificationResCodeSuccess(response, miniProfile, receipientMiniProfile.getMobileNo(), fundTransferReq, receiver, notificationUrl, mapping);
			//send notification alert to sender regarding sendMoney event success
			notificationAlertToSender(mapping, miniProfile, response, receipientMiniProfile, fundTransferReq);
			
		} catch (Exception e) {
			log.error("Error : {}" ,e);
			auditRemarks = EXCEPTION_OCCURRED;
			auditRepository.updateApiReq(
					AeroCMSHelper.updateAuditReq(auditId, AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));
			response.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_INTERNAL_ERROR);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_INTERNAL_ERROR));
		}


		return response;
	}

	private void notificationAlertToSender(PrepaidBankMapping mapping, CustomerMiniProfile senderProfile,
			WibmoResponse response, CustomerMiniProfile receipientMiniProfile, FundTransferRequest fundTransferReq) {
		log.info("sending notification alert to payer informing sendMoney event success");
		if (response.getResCode() == ServiceHttpStatus.SUCCESS.getStatusCode()) {
			String payeeName = receipientMiniProfile.getFirstName();
			Map<String, String> placeHolder = new HashMap<>();
			placeHolder.put("PAYER", senderProfile.getFirstName());
			placeHolder.put("PAYEE", payeeName != null ? payeeName : "PAYEE");
			placeHolder.put("CURRENCY", Constants.CURRENCY_IND);
			placeHolder.put("AMOUNT", CommonUtil.decimalFormat(fundTransferReq.getTransactionAmount()));

			NotificationRequest aRequest = NotificationRequest.builder().mobileNumber(senderProfile.getMobileNo())
					.programId(Integer.valueOf(mapping.getBankId()))
					.eventId(Integer.valueOf(Constants.RM_PAYER_ALERT_EVENT_ID)).emailId(senderProfile.getEmailId())
					.whatsappEnabled(false).placeHolders(placeHolder).build();
			NotificationServiceCall notificationServiceCall = new NotificationServiceCall();
			notificationServiceCall.send(aRequest, notificationUrl);
		}
	}

	private void prepareDebitTxnInfo(SendMoneyRequest sendMoneyReq, P2PDebitEvent p2pd) {
		p2pd.setCustomerId(sendMoneyReq.getSenderCustomerId());
		p2pd.setTxnStatus(Constants.TXN_STATUS_FAILURE);
		p2pd.setTxnFlow(Constants.TXN_OUT_FLOW);
		p2pd.setTxnAmount(sendMoneyReq.getAmount());
		p2pd.setTxnDateStr(CommonUtil.dateToStringWithFormat(new Date(), D_M_YYYY_H_M_S));
		p2pd.setMobile(sendMoneyReq.getSenderMobileNo());
		p2pd.setRecipientMobileNo(sendMoneyReq.getRecipientMobileNo());
		p2pd.setOriginalTxnId(sendMoneyReq.getOriginalTxnId());
		p2pd.setPaymentMode(sendMoneyReq.getProductType());
		p2pd.setTxnCategory(sendMoneyReq.getInitiateFrom() != null ? AckTxnTypes.RMD.getType():AckTxnTypes.P2PD.getType());
	}

	private WibmoResponse validateRecipientCard(WibmoResponse response, int auditId, WalletCard recipientCard, String bankId) {
		String auditRemarks;
		if (recipientCard == null) {
			response.setResCode(150);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.RECIPIENT_WALLET_CARD_NOT_FOUND));
			log.info("Recipient wallet details not found, please provide correct wallet details");
			auditRemarks = "Recipient wallet details not found";
			auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
					AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));

			return response;
		}
		if (!recipientCard.isCreditAllowed()) {
			response.setResCode(250);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.RESPONSE_DESC_ISCREDIT_ALLOWED));
			log.info(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.RESPONSE_DESC_ISCREDIT_ALLOWED));
			auditRemarks = msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.RESPONSE_DESC_ISCREDIT_ALLOWED);
			auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
					AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));

			return response;
		}
		return null;
	}

	private void setReserved5Param(OutflowImpl ofImpl, Sender sender) {
		if (ofImpl.getImplDesc() != null) {
			sender.setReserved5(ofImpl.getImplDesc());
		} else {
			log.debug(IMPL_DESC_IS_NOT_AVAILABLE_IN_DB);
			sender.setReserved5("P2P Debit");
		}
	}

	private String setIfTxnType(SendMoneyRequest sendMoneyReq, InflowImpl ifImpl) {
		return sendMoneyReq.getInitiateFrom() != null ? "RM Credit" : ifImpl.getImplDesc();
	}

	private String setOfTxnType(SendMoneyRequest sendMoneyReq, OutflowImpl ofImpl) {
		return sendMoneyReq.getInitiateFrom() != null ? "RM Debit" : ofImpl.getImplDesc();
	}

	private void setImplDesc(InflowImpl ifImpl, Receiver receiver) {
		if (ifImpl.getImplDesc() != null) {
			receiver.setReserved5(ifImpl.getImplDesc());
		} else {
			log.debug(IMPL_DESC_IS_NOT_AVAILABLE_IN_DB);
			receiver.setReserved5("P2P Credit");
		}
	}

	private WibmoResponse validateRecipientCard(WibmoResponse response, int auditId,
												WalletCard recipientCard, Receiver receiver, P2PDebitEvent p2pd, String bankId) {
		String auditRemarks;
		log.info("recipientCard.getCardNumber() :: {}",recipientCard.getCardNumber());
		if (recipientCard.getCardNumber() != null && recipientCard.getCardNumber().length() > 4) {
			receiver.setLast4Digits(
					recipientCard.getCardNumber().substring(recipientCard.getCardNumber().length() - 4));
			receiver.setUrn(Long.parseLong(recipientCard.getBankUrn()));
		}else if (recipientCard.getCardNumber() != null && recipientCard.getCardNumber().length() == 4) {
			receiver.setLast4Digits(recipientCard.getCardNumber());
			receiver.setUrn(Long.parseLong(recipientCard.getBankUrn()));
		} else {
			response.setResCode(350);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.RECIPIENT_CARD_NUMBER_NOT_FOUND));
			log.info("Recipientcard number not found in db");
			auditRemarks = "Recipient card number not found in db";
			auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
					AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));
			p2pFailureTxnAck(p2pd, response, bankId);
			return response;
		}
		return null;
	}

	private WibmoResponse validateCardNumber(WibmoResponse response, int auditId,
											 WalletCard senderCard, FundTransferRequest fundTransferReq, P2PDebitEvent p2pd, String bankId) {
		String auditRemarks;
		log.info("senderCard.getCardNumber() :: {}",senderCard.getCardNumber());
		if (senderCard.getCardNumber() != null && senderCard.getCardNumber().length() > 4) {
			fundTransferReq.setLast4Digits(
					senderCard.getCardNumber().substring(senderCard.getCardNumber().length() - 4));
			fundTransferReq.setUrn(senderCard.getBankUrn());
		} else if(senderCard.getCardNumber() != null && senderCard.getCardNumber().length() == 4){
			fundTransferReq.setLast4Digits(senderCard.getCardNumber());
			fundTransferReq.setUrn(senderCard.getBankUrn());
		} else {
			response.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.CARD_NOT_FOUND));
			log.info(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.CARD_NOT_FOUND));
			auditRemarks = msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.CARD_NOT_FOUND);
			auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
					AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));
			p2pFailureTxnAck(p2pd, response, bankId);
			return response;
		}
		return null;
	}

	private void chkProductType(SendMoneyRequest sendMoneyReq) {
		if (StringUtils.isBlank(sendMoneyReq.getProductType()))
			sendMoneyReq.setProductType("RW");
	}

	private void invokeFundTransferApi(FundTransferVO vo, P2PDebitEvent p2pd, AeroCMSConf cmsConfig) {
		log.info("CitrusServiceImpl : invokeFundTransferApi");
		String auditRemarks;
		FundTransferResponse fundTransRes;
		var sendMoneyRes = new SendMoneyResponse();
		SendMoneyRequest sendMoneyReq = vo.getSendMoneyReq();
		PrepaidBankMapping mapping = vo.getMapping();
		WibmoResponse response = vo.getResponse();
		int auditId = vo.getAuditId();
		WalletTxnInfo recipientTxnInfo = vo.getRecipientTxnInfo();
		WalletCard senderCard = vo.getSenderCard();
		WalletCard recipientCard = vo.getRecipientCard();
		CustomerMiniProfile recipientAccInfo = vo.getRecipientAccInfo();
		FundTransferRequest fundTransferReq = vo.getFundTransferReq();

		try {

			MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
			custHeader.add(contentType, APPLICATION_JSON);

			ObjectMapper obj = new ObjectMapper();
			obj.writer().withDefaultPrettyPrinter();

			//for kong
			String xApiKeyValue = programParametersRepository.fetchParamValueByParamName(mapping.getBankId(),
					ProgramParamConstants.CITRUS_X_API_KEY_VALUE);

			String privateKey = programParametersRepository.fetchParamValueByParamName(mapping.getBankId(),
					ProgramParamConstants.CITRUS_ENC_DEC_PVT_KEY);
			custHeader.add(xApiKey, xApiKeyValue);
			custHeader.add(contentType, APPLICATION_JSON);
			String reqJson = obj.writeValueAsString(fundTransferReq);
			log.info("citrusFundsTransfer requestObj : FundTransferRequest :{}", reqJson);
			String encryptedReq = aesgcmPayLoadEncryption.encrypt(reqJson,privateKey);
			String reqBody = TOKEN +encryptedReq+ "\"}";
			HttpEntity<Object> entity = new HttpEntity<>(reqBody, custHeader);
			
			String url = cmsConfig.getUrl().concat(citrusFundsTransferUrl);
			ResponseEntity<PrepaidEncResponse>  responseEntity= restTemplate.exchange(
					url,
					HttpMethod.POST,entity, PrepaidEncResponse.class);
			PrepaidEncResponse prepaidEncResponse=responseEntity.getBody();
			String enCryptedResp=null;
			if(prepaidEncResponse!=null)
				enCryptedResp= prepaidEncResponse.getToken();
			String jsonDecrypted = aesgcmPayLoadEncryption.decrypt(enCryptedResp,privateKey);
			log.info("jsonDecrypted :: {}",jsonDecrypted);
			CitrusFundTransferResponse citrusFundTransferResponse  = obj.readValue(jsonDecrypted,CitrusFundTransferResponse.class);
			fundTransRes = new FundTransferResponse();
			fundTransRes.setUrn(citrusFundTransferResponse.getUrn());
			fundTransRes.setCustomerId(citrusFundTransferResponse.getCustomerId());
			fundTransRes.setResponseCode(citrusFundTransferResponse.getResponseCode());
			fundTransRes.setClientTxnId(citrusFundTransferResponse.getClientTxnId());
			fundTransRes.setClientId(citrusFundTransferResponse.getClientId());
			fundTransRes.setResponseDateTime(citrusFundTransferResponse.getResponseDateTime());
			fundTransRes.setAccosaTransactionId(citrusFundTransferResponse.getAccosaTransactionId());
			fundTransRes.setResponseMessage(citrusFundTransferResponse.getResponseMessage());
			fundTransRes.setBankId((int) citrusFundTransferResponse.getBankId());
			fundTransRes.setTransactionAmount(citrusFundTransferResponse.getTransactionAmount());
			Sender[] senders = new Sender[1];
			Receiver[] receivers = new Receiver[1];

			if(citrusFundTransferResponse.getReceivers()!=null){
				log.info("Receivers .. is not null size is :: {}",citrusFundTransferResponse.getReceivers().size());
				Receiver receiver = new Receiver();
				citrusFundTransferResponse.getReceivers().forEach(
						r->{
							receiver.setAvailableBalance(r.getAvailableBalance());
							receiver.setCustomerId(r.getCustomerId());
							receiver.setTransactionAmount(String.valueOf(r.getTransactionAmount()));
							receiver.setUrn(r.getUrn());
						}
				);
				receivers[0] = receiver;
			}
			if(citrusFundTransferResponse.getSenders()!=null){
				Sender sender = new Sender();
				log.info("Senders .. is not null size is :: {}",citrusFundTransferResponse.getSenders().size());
				citrusFundTransferResponse.getSenders().forEach(s->{
					sender.setAvailableBalance(s.getAvailableBalance());
					sender.setCustomerId(s.getCustomerId());
					sender.setTransactionAmount(s.getTransactionAmount());
					sender.setUrn(s.getUrn());
				});
				senders[0] = sender;
			}
			fundTransRes.setSenders(senders);

			fundTransRes.setReceivers(receivers);

			// end of kong
			
			// Fix for MP-11124
			if (fundTransRes!=null) {
				var senderRes = new Sender[1];
				if (AeroConstants.RESPONSE_CODE_SUCCESS.equals(fundTransRes.getResponseCode())) {
					walletTxnInfo.setStatus(AeroConstants.CLIENT_RESPONSE_CODE_SUCCESS);
					walletTxnInfo.setStatusDesc("Money Transfered Successfully");
					response.setResCode(200);
					response.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.MONEY_TRANSFERED_SUCCESSFULLY));

					senderRes = fundTransRes.getSenders();
					recipientTxnInfo.setOriginalTxnId(walletTxnInfo.getTxnId());
					recipientTxnInfo.setStatus(AeroConstants.CLIENT_RESPONSE_CODE_SUCCESS);
					recipientTxnInfo.setStatusDesc("P2P Credit Successfully");
					CustomerMiniProfile senderMinProfile = apiManagerUtil.fetchUserProfile(mapping.getBankId(), sendMoneyReq.getActualSenderCustomerId() !=null ? sendMoneyReq.getActualSenderCustomerId() : sendMoneyReq.getSenderCustomerId(), null);
					log.info("senderMinProfile : {} ", senderMinProfile);

					CustomerMiniProfile recipientMinProfile = apiManagerUtil.fetchUserProfile(mapping.getBankId(), null,sendMoneyReq.getRecipientMobileNo());
					log.info("recipientMinProfile : {} ", recipientMinProfile);
					walletTxnInfo.setComments("Sent "+Constants.RS_SYMBOL + CommonUtil.toDecimal(String.valueOf(sendMoneyReq.getAmount()))+" To " + recipientMinProfile.getFirstName());
					recipientTxnInfo.setComments("Received "+Constants.RS_SYMBOL + CommonUtil.toDecimal(String.valueOf(sendMoneyReq.getAmount()))+" from  " + senderMinProfile.getFirstName());
					auditRemarks = msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.MONEY_TRANSFERED_SUCCESSFULLY);
					auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
							AeroConstants.AUDIT_STATUS_DESC_SUCCESS, auditRemarks));
					updateSMConsumption(sendMoneyReq, mapping, senderCard, recipientCard, recipientAccInfo);
					// ack to txn history
					Runnable runnable = () -> acknowledgeToTxnService(fundTransRes, sendMoneyReq, mapping, recipientTxnInfo, senderCard,
							recipientCard, recipientAccInfo);
					new Thread(runnable).start();
					log.debug("acknowledgement done for customer Id: {}, P2P txn :{}", recipientAccInfo.getCustomerId(), recipientTxnInfo.getTxnId());
				} else {
					log.info(PREPAID_RESPONSE_MSG, fundTransRes.getResponseMessage());
					walletTxnInfo.setStatus(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
					walletTxnInfo.setStatusDesc(fundTransRes.getResponseMessage());
					response.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
					response.setResDesc(fundTransRes.getResponseMessage());

					auditRemarks = fundTransRes.getResponseMessage();
					auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
							AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));
					p2pd.setOriginalTxnId(walletTxnInfo.getTxnId());
					p2pd.setPaymentTxnId(walletTxnInfo.getTxnId());
					p2pd.setPpTxnId(fundTransRes.getAccosaRefNo());
					p2pFailureTxnAck(p2pd, response, mapping.getBankId());
				}
				populateSMResp(sendMoneyReq, response, fundTransRes, recipientTxnInfo, sendMoneyRes, senderRes);

			} else {
				log.info("null response from prepaid, OriginalTxnId:{} ", fundTransferReq.getClientTxnId());
				response.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
				response.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_NULL));
				auditRemarks = "null response from prepaid";
				auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
						AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));
				p2pd.setOriginalTxnId(walletTxnInfo.getTxnId());
				p2pd.setPaymentTxnId(walletTxnInfo.getTxnId());
				p2pFailureTxnAck(p2pd, response, mapping.getBankId());
			}
		} catch (Exception e) {
			log.error("Error:" + e);
			walletTxnInfo.setStatus(AeroConstants.CLIENT_RESPONSE_CODE_INTERNAL_ERROR);
			walletTxnInfo.setStatusDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_INTERNAL_ERROR));
			response.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_INTERNAL_ERROR);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_INTERNAL_ERROR));
			auditRemarks = EXCEPTION_OCCURRED;
			auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
					AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));
			p2pd.setOriginalTxnId(walletTxnInfo.getTxnId());
			p2pd.setPaymentTxnId(walletTxnInfo.getTxnId());
			p2pFailureTxnAck(p2pd, response, mapping.getBankId());
		}
	}
	private void acknowledgeToTxnService(FundTransferResponse fundTransRes, SendMoneyRequest sendMoneyReq,
										 PrepaidBankMapping mapping, WalletTxnInfo recipientTxnInfo, WalletCard senderCard, WalletCard recipientCard,
										 CustomerMiniProfile recipientAccInfo) {
		String maskPattern = "";
		try {
			ThreadLocalStorage.setTenantId(Integer.parseInt(mapping.getBankId()));
			maskPattern = progParamRespository
					.fetchParamValueByParamName(mapping.getBankId(), ProgramParamConstants.CARD_MASK_PATTERN);
		} finally {
			ThreadLocalStorage.clear();
		}
		P2PCreditEvent p2pc = new P2PCreditEvent();
		p2pc.setDestAccount(CommonUtil.maskCardNumberWOPlaceHolder(recipientCard.getCardNumber(),maskPattern));
		p2pc.setCustomerId(recipientAccInfo.getCustomerId());
		p2pc.setPaymentTxnId(recipientTxnInfo.getTxnId());
		p2pc.setPpTxnId(String.valueOf(fundTransRes.getAccosaTransactionId()));
		p2pc.setTxnCategory(sendMoneyReq.getInitiateFrom() != null ? AckTxnTypes.RM.getType() : AckTxnTypes.P2P.getType());
		p2pc.setMerCategory(recipientTxnInfo.getTxnType());
		p2pc.setPaymentMode(recipientCard.getProductType());
		log.info("P2PCreditEvent : getComments  : {}", recipientTxnInfo.getComments());
		p2pc.setTxnDesc(recipientTxnInfo.getComments());
		p2pc.setTxnDateStr(CommonUtil.dateToStringWithFormat(new Date(), D_M_YYYY_H_M_S));
		p2pc.setTxnAmount(sendMoneyReq.getAmount());
		p2pc.setTxnStatus(Constants.TXN_STATUS_SUCCESS);
		p2pc.setTxnFlow(Constants.TXN_IN_FLOW);
		p2pc.setOriginalTxnId(recipientTxnInfo.getOriginalTxnId());
		p2pc.setMobile(sendMoneyReq.getSenderMobileNo());
		//payer name
		log.info("===BankId==={},====mapping.getBankId()=={},",mapping.getBankId(),sendMoneyReq.getSenderMobileNo());
		CustomerMiniProfile payerDetails = apiManagerUtil.fetchUserProfile(mapping.getBankId(), null, sendMoneyReq.getSenderMobileNo());
		log.info(payerDetails.toString());
		p2pc.setTxnShortDesc(payerDetails.getFirstName());
		var receiverResp = fundTransRes.getReceivers();
		p2pc.setClosingBalance(receiverResp[0].getAvailableBalance());
		p2pc.setRemarks(sendMoneyReq.getRemarks());
		p2pc.setMcc(sendMoneyReq.getMcc());
		TxnDetails txn = new TxnDetails();
		txn.setProgramId(mapping.getBankId());
		txn.setTxnType(sendMoneyReq.getInitiateFrom() != null ? AckTxnTypes.RMC.getType() : AckTxnTypes.P2PC.getType());
		txn.setData(p2pc);
		// Need to write a if condition to stop this kafka call for w2w request money
		log.info("sendMoneyReq : {}", sendMoneyReq);
		if (!"RM".equals(sendMoneyReq.getInitiateFrom())) {
			kafkaProducer.publishWalletTxn(txn);
		}

		P2PDebitEvent p2pd = new P2PDebitEvent();
		p2pd.setCustomerId(walletTxnInfo.getUserId());
		p2pd.setSourceAccount(CommonUtil.maskCardNumberWOPlaceHolder(senderCard.getCardNumber(),maskPattern));
		p2pd.setMobile(sendMoneyReq.getRecipientMobileNo());
		p2pd.setPpTxnId(String.valueOf(fundTransRes.getAccosaTransactionId()));
		p2pd.setTxnCategory(sendMoneyReq.getInitiateFrom() != null ? AckTxnTypes.RM.getType() : AckTxnTypes.P2P.getType());
		p2pd.setMerCategory(walletTxnInfo.getTxnType());
		p2pd.setPaymentMode(senderCard.getProductType());
		log.info("getComments  : {}", walletTxnInfo.getComments());
		p2pd.setTxnDesc(walletTxnInfo.getComments());
		p2pd.setTxnDateStr(CommonUtil.dateToStringWithFormat(new Date(), D_M_YYYY_H_M_S));
		p2pd.setTxnAmount(sendMoneyReq.getAmount());
		p2pd.setRemarks(sendMoneyReq.getRemarks());
		p2pd.setTxnStatus(Constants.TXN_STATUS_SUCCESS);
		p2pd.setTxnFlow(Constants.TXN_OUT_FLOW);
		p2pd.setPaymentTxnId(walletTxnInfo.getTxnId());
		p2pd.setOriginalTxnId(walletTxnInfo.getTxnId());
		//payee name
		log.info("===BankId==={},====mapping.getBankId()=={},",mapping.getBankId(),sendMoneyReq.getRecipientMobileNo());
		CustomerMiniProfile payeeDetails = apiManagerUtil.fetchUserProfile(mapping.getBankId(), null, sendMoneyReq.getRecipientMobileNo());
		log.info(payeeDetails.toString());
		p2pd.setTxnShortDesc(payeeDetails.getFirstName());
		var senderResp = fundTransRes.getSenders();
		p2pd.setClosingBalance(senderResp[0].getAvailableBalance());
		p2pd.setRemarks(sendMoneyReq.getRemarks());
		p2pd.setMcc(sendMoneyReq.getMcc());
		TxnDetails txn1 = new TxnDetails();
		txn1.setProgramId(mapping.getBankId());
		txn1.setTxnType(sendMoneyReq.getInitiateFrom() != null ? AckTxnTypes.RMD.getType() : AckTxnTypes.P2PD.getType());
		txn1.setData(p2pd);
		kafkaProducer.publishWalletTxn(txn1);
	}

	private void updateSMConsumption(SendMoneyRequest sendMoneyReq, PrepaidBankMapping mapping, WalletCard senderCard, WalletCard recipientCard, CustomerMiniProfile recipientAccInfo) {
		userConsumptionService.updateSMUserConsumption(sendMoneyReq.getSenderCustomerId(),
				senderCard.getCardNumber(), sendMoneyReq.getAmount(), "P2P",
				Integer.parseInt(mapping.getBankId()));
		userConsumptionService.updateSMUserConsumption(recipientAccInfo.getCustomerId(),
				recipientCard.getCardNumber(), sendMoneyReq.getAmount(), "P2PR",
				Integer.parseInt(mapping.getBankId()));
	}

	private void populateSMResp(SendMoneyRequest sendMoneyReq, WibmoResponse response, FundTransferResponse fundTransRes, WalletTxnInfo recipientTxnInfo, SendMoneyResponse sendMoneyRes, Sender[] senderRes) {
		String cmsResponseBody;
		cmsResponseBody = AeroCMSHelper.convertSendMoneyResponseToJson(fundTransRes);
		if (AeroConstants.RESPONSE_CODE_SUCCESS.equals(fundTransRes.getResponseCode())) {
			walletTxnInfo.setCmsRef(cmsResponseBody);
			recipientTxnInfo.setCmsRef(cmsResponseBody);
			sendMoneyRes.setTxnId(fundTransRes.getClientTxnId());
			sendMoneyRes.setSenderMobileNo(sendMoneyReq.getSenderMobileNo());
			sendMoneyRes.setRecipientMobileNo(sendMoneyReq.getRecipientMobileNo());
			sendMoneyRes.setAmount(fundTransRes.getTransactionAmount());
			sendMoneyRes.setAvailableBal(senderRes[0].getAvailableBalance());
			if (null != sendMoneyReq.getRemarks() && !StringUtils.isEmpty(sendMoneyReq.getRemarks())) {
				sendMoneyRes.setRemarks(sendMoneyReq.getRemarks());
			} else {
				sendMoneyRes.setRemarks(fundTransRes.getResponseMessage());
			}
			sendMoneyRes.setTxnDate(CommonUtil.getTimeForTxnId(fundTransRes.getClientTxnId()));
			response.setData(sendMoneyRes);
		}
	}

	private WibmoResponse checkVelocityLimits(int auditId, UserVelocityCheck senderVelocityChkReq,
											  UserVelocityCheck recipientVelocityChkReq, P2PDebitEvent p2pd, String bankId) {
		WibmoResponse senderLimitRes = userConsumptionService.chkVelocityLimits(senderVelocityChkReq, bankId);
		if (null != senderLimitRes && senderLimitRes.getResCode() != 200) {
			log.info("P2P sender velocity limits exceeded for {} ", senderLimitRes.getResDesc());
			senderLimitRes.setResDesc(senderLimitRes.getResDesc());
			auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
					AeroConstants.AUDIT_STATUS_DESC_FAILURE, "P2P sender velocity limits exceeded"));
			p2pFailureTxnAck(p2pd, senderLimitRes, bankId);
			return senderLimitRes;
		}


		WibmoResponse recipientLimitRes = userConsumptionService.chkVelocityLimits(recipientVelocityChkReq, bankId);
		if (null != recipientLimitRes && recipientLimitRes.getResCode() != 200) {
			log.info("P2P Recipient velocity limits exceeded for {} ", recipientLimitRes.getResDesc());
			recipientLimitRes.setResDesc(recipientLimitRes.getResDesc());
			auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
					AeroConstants.AUDIT_STATUS_DESC_FAILURE, "P2P recipient velocity limits exceeded"));
			p2pFailureTxnAck(p2pd, recipientLimitRes, bankId);
			return recipientLimitRes;
		}
		return null;
	}

	private WibmoResponse validateSenderCard(WibmoResponse response, int auditId,
											 WalletCard senderCard, P2PDebitEvent p2pd, String bankId) {
		String auditRemarks;
		if (senderCard == null) {
			response.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_FAILED);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.SENDER_WALLET_CARD_NOT_FOUND));
			log.info("Wallet details not found for user {}, please provide correct wallet details",
					p2pd.getCustomerId());
			auditRemarks = "Wallet details not found";
			auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
					AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));
			p2pFailureTxnAck(p2pd, response, bankId);
			return response;
		}
		if (!senderCard.isDebitAllowed()) {
			response.setResCode(250);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.RESPONSE_DESC_ISDEBIT_ALLOWED));
			log.info(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.RESPONSE_DESC_ISDEBIT_ALLOWED));
			auditRemarks = msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.RESPONSE_DESC_ISDEBIT_ALLOWED);
			auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
					AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));
			p2pFailureTxnAck(p2pd, response, bankId);
			return response;
		}
		return null;
	}

	private WibmoResponse validateSenderUserInfo(SendMoneyRequest sendMoneyReq, WibmoResponse response,
												 int auditId, UserAccountInfo senderUserInfo, P2PDebitEvent p2pd, String bankId) {
		String auditRemarks;
		if (senderUserInfo == null) {
			response.setResCode(150);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.SENDER_USER_ACCOUNT_NOT_AVAILABLE_FOR_MOBILE));
			log.info(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.SENDER_USER_ACCOUNT_NOT_AVAILABLE_FOR_MOBILE));
			auditRemarks = msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.SENDER_USER_ACCOUNT_NOT_AVAILABLE_FOR_MOBILE);
			auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
					AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));
			p2pFailureTxnAck(p2pd, response, bankId);
			return response;

		}

		if (senderUserInfo.getCustomerId() != null
				&& !sendMoneyReq.getSenderCustomerId().equals(senderUserInfo.getCustomerId())) {
			response.setResCode(150);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.SENDER_USERID_MISMATCH_FOR_MOBILE));
			log.info(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.SENDER_USERID_MISMATCH_FOR_MOBILE));
			auditRemarks = msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.SENDER_USERID_MISMATCH_FOR_MOBILE);
			auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId,
					AeroConstants.AUDIT_STATUS_DESC_FAILURE, auditRemarks));
			p2pFailureTxnAck(p2pd, response, bankId);
			return response;
		}
		return null;
	}

	private void p2pFailureTxnAck(P2PDebitEvent p2pd, WibmoResponse response, String programId) {

		p2pd.setRemarks(response.getResDesc());
		p2pd.setTxnDesc("Send Money Failed");
		TxnDetails txn = new TxnDetails();
		// to be fix for multi tenancy support
		txn.setProgramId(programId);
		txn.setTxnType(p2pd.getTxnCategory());
		p2pd.setTxnCategory(null);
		txn.setData(p2pd);
		Runnable runnableP2PFail = () -> kafkaProducer.publishWalletTxn(txn);
		new Thread(runnableP2PFail).start();

	}

	@Override
	public WibmoResponse processP2P(P2PRequest p2pRequest) {
		log.info("request for P2P");
		var sendMoneyRequest = dozerBeanMapper.map(p2pRequest, SendMoneyRequest.class);
		return sendMoney(sendMoneyRequest);
	}

	@Override
	public WibmoResponse updateServiceTypeFlag(ServiceTypeRequest serviceReq) {
		ServiceTypes type = serviceReq.getService();
		log.debug("update service type request :{}, flag: {}", type.getType(), type.isStatus());
		var response = new WibmoResponse(200, SUCCESS);
		var cardTransactionProfile = new CardTransactionProfile();
		var serviceType = WCStatusServiceType.getServices(type.getType());
		PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
		AeroCMSConf cmsConfig = aeroConfRepository.fetchByPPBankId(mapping.getId(), mapping.getBankId());
		WAServiceEnableDisableResponse enableDisableResponse = null;
		var enableDisableRequest = new WAServiceEnableDisableRequest();
		WalletCard wc = wcrepository.fetchById(serviceReq.getWalletId(), mapping.getBankId());
		ProductMaster productConfig = aeroPMRepository.fetchByBankAndProdutType(mapping.getBankId(),
				wc.getProductType());
		try {
			enableDisableRequest = prepareCardTxnProfile(serviceReq, cardTransactionProfile,
					serviceType, cmsConfig, enableDisableRequest, wc);

			enableDisableResponse = invokeCardTxnProfileApi(cmsConfig, enableDisableResponse, enableDisableRequest);
			if (null == enableDisableResponse) {
				response.setResCode(100);
				response.setResDesc(AeroMsgDefinitions.AERO_BANK_RESPONSE);
			} else {
				log.debug("Prepaid response, resp code: {}, resp desc: {}", enableDisableResponse.getResponseCode(),
						enableDisableResponse.getResponseMessage());
				if (AeroConstants.RESPONSE_CODE_SUCCESS.equals(enableDisableResponse.getResponseCode())) {
					response.setResCode(200);
					String msg = type.isStatus() ? "active" : "blocked";
					String productName = null != productConfig.getProductName() ? productConfig.getProductName() : "card";
					response.setResDesc(String.format(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.SERVICE_TYPE_FLAG_UPDATED_SUCCESS),productName, "xxxx "+wc.getCardNumber().substring(wc.getCardNumber().length() -4),msg));
					response.setData(serviceReq.getService().isStatus());
				} else {
					response.setResCode(150);
					response.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.SERVICE_TYPE_FLAG_UPDATE_FAILED));
				}

			}
		} catch (Exception e) {
			log.error("exception in prepaid call: {}", e);
			response.setResCode(AeroConstants.CLIENT_RESPONSE_CODE_INTERNAL_ERROR);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.RESPONSE_DESC_INTERNAL_ERROR));
		}
		return response;
	}

	private WAServiceEnableDisableResponse invokeCardTxnProfileApi(AeroCMSConf cmsConfig, WAServiceEnableDisableResponse enableDisableResponse, WAServiceEnableDisableRequest enableDisableRequest) {
		try {
			Map<String, String> params = new HashMap<>();
			params.put(bankId, enableDisableRequest.getBankId());
			params.put(custIdLast4Digit, enableDisableRequest.getCustomerId());
			params.put(clientTxnId, enableDisableRequest.getClientTxnId());
			enableDisableResponse = restTemplate.postForObject(
					cmsConfig.getUrl() + "/v1/{bankId}/cardTransactionProfile/{custIdLast4Digit}/{clientTxnId}",
					enableDisableRequest, WAServiceEnableDisableResponse.class, params);
		} catch (Exception e) {
			log.error("exception in prepaid api call: {}", e);
		}
		return enableDisableResponse;
	}

	/**
	 *
	 * @param serviceReq
	 * @param cardTransactionProfile
	 * @param serviceType
	 * @param cmsConfig
	 * @param enableDisableRequest
	 * @param wc
	 * @return
	 */
	private WAServiceEnableDisableRequest prepareCardTxnProfile(ServiceTypeRequest serviceReq,
																CardTransactionProfile cardTransactionProfile,
																WCStatusServiceType serviceType, AeroCMSConf cmsConfig,
																WAServiceEnableDisableRequest enableDisableRequest, WalletCard wc) {
		String cardNumber;
		cardNumber = wc.getCardNumber();
		List<CardTransactionProfile> cardTxnProfile = new ArrayList<>();
		cardTransactionProfile.setTransactionProfileId(Integer.valueOf(serviceType.getServiceType()));
		cardTransactionProfile.setTransactionType(serviceType.getServiceDesc());
		cardTransactionProfile.setStatus(serviceReq.getService().isStatus());
		cardTxnProfile.add(cardTransactionProfile);

		var yyyyMMddhhmmss = new SimpleDateFormat(dateFormat);
		enableDisableRequest = (WAServiceEnableDisableRequest) AeroCMSHelper.populateCommon(enableDisableRequest,
				yyyyMMddhhmmss, cmsConfig);
		enableDisableRequest.setMessageCode(AeroConstants.REQUEST_SERVICE_ENABLE_DISABLE_CARD);
		enableDisableRequest
				.setClientTxnId(AeroCMSHelper.generateUniqueTxnId(AeroConstants.REQUEST_SERVICE_ENABLE_DISABLE_CARD));
		enableDisableRequest.setLast4Digits(cardNumber.substring(cardNumber.length() - 4));
		enableDisableRequest.setUrn(wc.getBankUrn());
		enableDisableRequest.setCustomerId(wc.getCustomerId());
		enableDisableRequest.setCardTransactionProfile(cardTxnProfile);
		return enableDisableRequest;
	}

	@Override
	public WibmoResponse checkAmlLimits(CheckUserAmlLimitsRequest request, String bankId) {
		PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
		AeroCMSConf cmsConfig = aeroConfRepository.fetchByPPBankId(mapping.getId(), bankId);
		WibmoResponse response = new WibmoResponse();
		WalletCard wc;
		// check if walletId avbl in req
		if (request.getWalletId() > 0) {
			wc = wcrepository.fetchById(request.getWalletId(), mapping.getBankId());
		} else {
			wc = wcrepository.fetchByCustIdAndProduct(request.getCustomerId(), request.getProductType(), mapping.getBankId());
		}
		if (null == wc) {
			response.setResCode(101);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.CUSTID_WALLETID_PRODUCTTYPE_NOT_MATCHING));
			return response;
		}

		return amlInquiry(wc, cmsConfig, mapping, response, request);
	}

	@Override
	public WibmoResponse checkUserLimits(CheckUserLimitsRequest request, String bankId) {
		WibmoResponse response =  new WibmoResponse(Constants.SUCCESS_RESPONSE_CODE,Constants.USER_LIMIT_CHK_SUCCESS_RESPONSE_DESC);
		// velocity limit check
		CustomerMiniProfile user = apiManagerUtil.fetchUserProfile(bankId, request.getCustomerId(), null);
		if(null == user) {
			response.setResCode(100);
			response.setResDesc("user profile not found");
			return  response;
		}
		UserVelocityCheck velReq = AeroCMSHelper.prepareVelocityCheckReq(
				request.getCustomerId(), request.getTxnAmount(), request.getTxnType(), request.getCardNumber(),
				user.getKycLevel(), bankId);
		WibmoResponse velResp = userConsumptionService.chkVelocityLimits(velReq, bankId);
		if (null != velResp) {
			if (velResp.getResCode() != Constants.SUCCESS_RESPONSE_CODE) {
				return velResp;
			}
			log.debug("Velocity check passed for customer Id: {}", request.getCustomerId());
		}
		//Aml limit check
		CheckUserAmlLimitsRequest amlReq = dozerBeanMapper.map(request, CheckUserAmlLimitsRequest.class);
		// txn type is D or C as per aml bean
		amlReq.setTxnType(request.getTxnFlow());

		WibmoResponse amlResp = checkAmlLimits(amlReq, bankId);
		if (null != amlResp) {
			if (amlResp.getResCode() != Constants.SUCCESS_RESPONSE_CODE) {
				return amlResp;
			}
			log.debug("Aml Limit check passed for customer Id: {}", request.getCustomerId());
		}
		return response;
	}

	public WibmoResponse amlInquiry(WalletCard wc, AeroCMSConf cmsConfig, PrepaidBankMapping mapping, WibmoResponse response, CheckUserAmlLimitsRequest request){

		AeroRequest amlInquiryRequest = new AeroRequest();
		SimpleDateFormat yyyyMMddhhmmss = new SimpleDateFormat(dateFormat);
		amlInquiryRequest = AeroCMSHelper.populateCommon(amlInquiryRequest, yyyyMMddhhmmss, cmsConfig);
		amlInquiryRequest.setCustomerId(wc.getHostCustomerId()!=null ? wc.getHostCustomerId() : wc.getCustomerId());
		amlInquiryRequest.setLast4Digits(wc.getCardNumber().substring(wc.getCardNumber().length() - 4));
		amlInquiryRequest.setClientTxnId(AeroCMSHelper.generateUniqueTxnId(AeroConstants.REQUEST_AML_INQUIRY));
		amlInquiryRequest.setUrn(wc.getBankUrn());
		amlInquiryRequest.setMessageCode(AeroConstants.REQUEST_AML_INQUIRY);

		AmlInquiryResponse amlInquiryResponse = null;
		try {
			amlInquiryResponse = invokeAmlInquiryApi(amlInquiryResponse, amlInquiryRequest);
		} catch (Exception e) {
			log.debug("AML inquiry Operation failed. Connectivity issue!! {}", e);
		}
		checkAmlResponse(response, request, amlInquiryResponse, mapping);
		return response;
	}

	private void checkAmlResponse(WibmoResponse response, CheckUserAmlLimitsRequest request, AmlInquiryResponse amlInquiryResponse, PrepaidBankMapping mapping) {
		if(null == amlInquiryResponse) {
			response.setResCode(100);
			response.setResDesc(AeroMsgDefinitions.AERO_BANK_RESPONSE);
		} else if(amlInquiryResponse.getResponseCode().equals(AeroConstants.RESPONSE_CODE_SUCCESS)) {
			response.setResCode(200);
			response.setResDesc(Constants.USER_LIMIT_CHK_SUCCESS_RESPONSE_DESC);

			long amt = request.getTxnAmount();
			doAmlCheck(response, request, amlInquiryResponse, amt, mapping);
		} else {
			response.setResCode(150);
			response.setResDesc(amlInquiryResponse.getResponseMessage());
		}
	}

	private void doAmlCheck(WibmoResponse response, CheckUserAmlLimitsRequest request, AmlInquiryResponse amlInquiryResponse, long amt, PrepaidBankMapping mapping) {
		if(request.getTxnType().equalsIgnoreCase("D")) {
			if(amt > Long.parseLong(amlInquiryResponse.getAvailableDailyAmlDebitLimit())) {
				response.setResCode(300);
				response.setResDesc(String.format(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),MsgConstants.DAILY_LMT_AMT_EXCEEDED),
						amt-Long.parseLong(amlInquiryResponse.getAvailableDailyAmlDebitLimit())));
			}
			if(amt > Long.parseLong(amlInquiryResponse.getAvailableMonthlyAmlDebitLimit())) {
				response.setResCode(300);
				response.setResDesc(String.format(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),MsgConstants.MONTHLY_LMT_AMT_EXCEEDED),
						amt-Long.parseLong(amlInquiryResponse.getAvailableMonthlyAmlDebitLimit())));
			}
		} else {
			if(amt > Long.parseLong(amlInquiryResponse.getAvailableDailyAmlLimit())) {
				response.setResCode(300);
				response.setResDesc(String.format(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),MsgConstants.DAILY_LMT_AMT_EXCEEDED),
						amt-Long.parseLong(amlInquiryResponse.getAvailableDailyAmlLimit())));
			}
			if(amt > Long.parseLong(amlInquiryResponse.getAvailableMonthlyAmlLimit())) {
				response.setResCode(300);
				response.setResDesc(String.format(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),MsgConstants.MONTHLY_LMT_AMT_EXCEEDED),
						amt-Long.parseLong(amlInquiryResponse.getAvailableMonthlyAmlLimit())));
			}
		}
	}

	private AmlInquiryResponse invokeAmlInquiryApi(AmlInquiryResponse amlInquiryResponse, AeroRequest amlInquiryRequest) {
		try {
			MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
			PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
			String xApiKeyValue = programParametersRepository.fetchParamValueByParamName(mapping.getBankId(),
					ProgramParamConstants.CITRUS_X_API_KEY_VALUE);

			String privateKey = programParametersRepository.fetchParamValueByParamName(mapping.getBankId(),
					ProgramParamConstants.CITRUS_ENC_DEC_PVT_KEY);
			custHeader.add(xApiKey, xApiKeyValue);
			custHeader.add(contentType, APPLICATION_JSON);
			ObjectMapper obj = new ObjectMapper();
			obj.writer().withDefaultPrettyPrinter();
			String reqJson = obj.writeValueAsString(amlInquiryRequest);
			String encryptedReq = aesgcmPayLoadEncryption.encrypt(reqJson,privateKey);
			String reqBody = TOKEN +encryptedReq+ "\"}";
			HttpEntity<Object> entity = new HttpEntity<>(reqBody, custHeader);

			ResponseEntity<EncLoadUnloadResponse> responseEntity = restTemplate.exchange(
					"https://kong-pp.pc.enstage-sas.com/api/v1/amlInquery",
					HttpMethod.POST,entity , EncLoadUnloadResponse.class);
			if(responseEntity.getStatusCode() == HttpStatus.OK){
				log.info(SUCCESS_RES_FROM_PREPAID);
				EncLoadUnloadResponse encrptedResp =  responseEntity.getBody();
				String resp=null;
				if(encrptedResp!=null)
					resp= aesgcmPayLoadEncryption.decrypt(encrptedResp.getToken(),privateKey);
				amlInquiryResponse = obj.readValue(resp,AmlInquiryResponse.class);
				return amlInquiryResponse;
			}else{
				log.error(EXCEPTION_IN_PREPAID, responseEntity.getBody(),responseEntity.getStatusCode());
			}
		} catch (Exception e) {
			log.error("exception in prepaid api call: {}", e);
		}
		return amlInquiryResponse;
	}

	@Override
	public WibmoResponse updateCardHolderProfile(UpdateCardHolderProfileData profileUpdateRequest, String programId) {
		log.info("Update card holder profile for customer : {}", profileUpdateRequest.getAccountNumber());
		WibmoResponse wibmoResponse = null;

		PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
		AeroCMSConf cmsConfig = aeroConfRepository.fetchByPPBankId(mapping.getId(), mapping.getBankId());

		List<WalletCard> walletCardList = wcrepository.fetchByCustId(profileUpdateRequest.getAccountNumber(), programId);
		if(!walletCardList.isEmpty()) {
			for (WalletCard walletCard : walletCardList) {
				if(walletCard.getHostCustomerId() != null) {
					log.info("updating with host customer id :: {}",walletCard.getHostCustomerId());
					profileUpdateRequest.setAccountNumber(walletCard.getHostCustomerId());
				}
				wibmoResponse = invokeAeroCardHolderProfileUpdateApi(profileUpdateRequest, walletCard, cmsConfig);
				if (wibmoResponse!=null && wibmoResponse.getResCode() == 150) {
					log.error("Unable to update profile for the card ending with : {} ,Exception in prepaid api call: {}", walletCard.getCardNumber().substring(walletCard.getCardNumber().length() - 4), wibmoResponse.getData());
					return wibmoResponse;
				}
			}
		}else{
			wibmoResponse = new WibmoResponse(150, "Profile Update Failed, No cards available to update the Profile.");
		}
		return wibmoResponse;
	}

	private WibmoResponse invokeAeroCardHolderProfileUpdateApi(UpdateCardHolderProfileData profileUpdateRequest, WalletCard walletCard, AeroCMSConf cmsConfig) {
		WibmoResponse wibmoResponse = null;
		try {
			var cardHolderProfileUpdateRequest = (CardHolderProfileUpdateRequest) AeroCMSHelper.populateCommon(new CardHolderProfileUpdateRequest(), new SimpleDateFormat(dateFormat),
					cmsConfig);
			cardHolderProfileUpdateRequest.setMessageCode(AeroConstants.REQUEST_UPDATE_CARD_HOLDER_PROFILE);
			cardHolderProfileUpdateRequest.setClientTxnId(AeroCMSHelper.generateUniqueTxnId(AeroConstants.REQUEST_UPDATE_CARD_HOLDER_PROFILE));
			cardHolderProfileUpdateRequest.setLast4Digits(walletCard.getCardNumber().substring(walletCard.getCardNumber().length() - 4));
			cardHolderProfileUpdateRequest.setUrn(walletCard.getBankUrn());
			cardHolderProfileUpdateRequest.setCustomerId(profileUpdateRequest.getAccountNumber());
			setCardHolderDetails(profileUpdateRequest, cardHolderProfileUpdateRequest);
			setCustomerIdentityDetails(profileUpdateRequest, cardHolderProfileUpdateRequest);


			MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
			PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
			String xApiKeyValue = programParametersRepository.fetchParamValueByParamName(mapping.getBankId(),
					ProgramParamConstants.CITRUS_X_API_KEY_VALUE);

			String privateKey = programParametersRepository.fetchParamValueByParamName(mapping.getBankId(),
					ProgramParamConstants.CITRUS_ENC_DEC_PVT_KEY);
			custHeader.add(xApiKey, xApiKeyValue);
			custHeader.add(contentType, APPLICATION_JSON);
			ObjectMapper obj = new ObjectMapper();
			obj.writer().withDefaultPrettyPrinter();
			String reqJson = obj.writeValueAsString(cardHolderProfileUpdateRequest);
			String encryptedReq = aesgcmPayLoadEncryption.encrypt(reqJson,privateKey);
			String reqBody = TOKEN +encryptedReq+ "\"}";
			HttpEntity<Object> entity = new HttpEntity<>(reqBody, custHeader);

			String url = cmsConfig.getUrl().concat(citrusCardHolderProfileUrl);
			log.info("Concatenated url : {}", url);

			ResponseEntity<EncLoadUnloadResponse> responseEntity = restTemplate.exchange(
					url,
					HttpMethod.POST,entity , EncLoadUnloadResponse.class);
			if(responseEntity.getStatusCode() == HttpStatus.OK){
				log.info(SUCCESS_RES_FROM_PREPAID);
				EncLoadUnloadResponse encrptedResp =  responseEntity.getBody();
				String resp=null;
				if(encrptedResp!=null)
					resp= aesgcmPayLoadEncryption.decrypt(encrptedResp.getToken(),privateKey);
				CardHolderProfileUpdateResponse cardHolderProfileUpdateResponse = obj.readValue(resp,CardHolderProfileUpdateResponse.class);
				if (null != cardHolderProfileUpdateResponse && "00".equals(cardHolderProfileUpdateResponse.getResponseCode())) {
					reqJson = obj.writeValueAsString(cardHolderProfileUpdateResponse);
					log.info("response Object after update profile :: {}",reqJson);
					wibmoResponse = new WibmoResponse(200, AeroConstants.AUDIT_STATUS_DESC_SUCCESS, cardHolderProfileUpdateResponse);
				} else {
					wibmoResponse = new WibmoResponse(150, AeroConstants.AUDIT_STATUS_DESC_FAILURE, cardHolderProfileUpdateResponse);
				}
			}else{
				log.error(EXCEPTION_IN_PREPAID, responseEntity.getBody(),responseEntity.getStatusCode());
			}
		} catch (Exception e) {
			log.error("Unable to update profile for account : {} ,Exception in prepaid api call: {}", profileUpdateRequest.getAccountNumber(), e);
			wibmoResponse = new WibmoResponse(150, AeroConstants.AUDIT_STATUS_DESC_FAILURE, e);
		}
		return wibmoResponse;
	}

	private void setCustomerIdentityDetails(UpdateCardHolderProfileData profileUpdateRequest, CardHolderProfileUpdateRequest cardHolderProfileUpdateRequest) {
		CustomerIdentityProfile customerIdentityProfile = new CustomerIdentityProfile();
		if(null != profileUpdateRequest.getAadhaarNumber())
			customerIdentityProfile.setCustomerAadharCardNumber(profileUpdateRequest.getAadhaarNumber());
		else if(null != profileUpdateRequest.getPanCardNumber())
			customerIdentityProfile.setCustomerPANCardNumber(profileUpdateRequest.getPanCardNumber());
		else if(null != profileUpdateRequest.getDrivingLicenseNumber())
			customerIdentityProfile.setCustomerPANCardNumber(profileUpdateRequest.getDrivingLicenseNumber());
		else
			customerIdentityProfile.setCustomerVoterIdNumber(profileUpdateRequest.getVoterIdNumber());
		cardHolderProfileUpdateRequest.setCustomerIdentityProfile(customerIdentityProfile);
	}

	private void setCardHolderDetails(UpdateCardHolderProfileData profileUpdateRequest, CardHolderProfileUpdateRequest cardHolderProfileUpdateRequest) {
		CardHolder cardHolder = new CardHolder();
		cardHolder.setCardProfileId(AeroCMSHelper.convertToKYCLevel(String.valueOf(profileUpdateRequest.getKycLevel()))); // KYC_Level
		cardHolder.setCardholderFirstName(profileUpdateRequest.getFirstName());
		if (null != profileUpdateRequest.getLastName())
			cardHolder.setCardholderLastName(profileUpdateRequest.getLastName());
		if (null != profileUpdateRequest.getMobile())
			cardHolder.setCardholderMobile(profileUpdateRequest.getMobile().length() == 10 ? "91"+profileUpdateRequest.getMobile() : profileUpdateRequest.getMobile());
		cardHolder.setCardholderDateOfBirth(profileUpdateRequest.getDob());
		if (null != profileUpdateRequest.getEmail())
			cardHolder.setCardholderEmail(profileUpdateRequest.getEmail());
		cardHolder.setCardholderAddress(profileUpdateRequest.getAddress());
		cardHolder.setCardholderCity(profileUpdateRequest.getCity());
		cardHolder.setCardholderState(profileUpdateRequest.getState());
		cardHolder.setCardholderZipCode(profileUpdateRequest.getZipCode());
		cardHolder.setCardholderCountry(profileUpdateRequest.getCountry());
		cardHolderProfileUpdateRequest.setCardholder(cardHolder);
	}

	@Override
	public WibmoResponse blockCard(BlockCardRequest request, String programId, String accountNumber) {
		PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
		AeroCMSConf cmsConfig = aeroConfRepository.fetchByPPBankId(mapping.getId(),mapping.getBankId());
		String blockType=progParamRespository.fetchParamValueByParamName(mapping.getBankId(), "BLOCK_TYPE");

		WibmoResponse response = new WibmoResponse();
		CitrusPrepaidBlockCardResponse citrusPrepaidBlockCardResponse = null;

		CitrusPrepaidBlockCardRequest citrusPrepaidBlockCardRequest = new CitrusPrepaidBlockCardRequest();
		try {

			citrusPrepaidBlockCardRequest.setMessageCode(Integer.parseInt(AeroConstants.REQUEST_BLOCK_CARD));
			if(cmsConfig!=null) {
				citrusPrepaidBlockCardRequest.setClientId(cmsConfig.getClientId());
				citrusPrepaidBlockCardRequest.setSecureCode(cmsConfig.getSecureCode());
				citrusPrepaidBlockCardRequest.setBankId(Integer.parseInt(cmsConfig.getPpBankCode()));
				citrusPrepaidBlockCardRequest.setEntityId(Integer.parseInt(cmsConfig.getEntityId()));
			}
			citrusPrepaidBlockCardRequest.setClientTxnId(AeroCMSHelper.generateUniqueTxnId(AeroConstants.REQUEST_BLOCK_CARD));
			String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
			citrusPrepaidBlockCardRequest.setRequestDateTime(Long.parseLong(timeStamp));

			WalletCard walletCard = wcrepository.fetchById(request.getWalletId(), mapping.getBankId());
			if(walletCard!=null) {
				citrusPrepaidBlockCardRequest.setCustomerId(walletCard.getHostCustomerId()!=null ? walletCard.getHostCustomerId() : accountNumber);
				citrusPrepaidBlockCardRequest.setLast4Digits(walletCard.getCardNumber().substring(walletCard.getCardNumber().length() - 4));
				citrusPrepaidBlockCardRequest.setUrn(Integer.parseInt(walletCard.getBankUrn()));
				citrusPrepaidBlockCardRequest.setBlockType(blockType);
			}
			CitrusPrepaidBlockCardResponse blockCardResponse = invokeBlockCardApi( citrusPrepaidBlockCardResponse, citrusPrepaidBlockCardRequest, mapping.getBankId(), cmsConfig);

			if(blockCardResponse!=null && blockCardResponse.getResponseCode().equals("00")) {
				response.setResCode(200);
				response.setResDesc("Card Blocked");
			}
			else {
				response.setResCode(100);
				response.setResDesc("Card Block failed, unable to block card");
			}
		}
		catch (Exception ex)
		{
			log.error("Error occurred while card block");
		}
		return response;
	}

	private CitrusPrepaidBlockCardResponse invokeBlockCardApi( CitrusPrepaidBlockCardResponse citrusPrepaidBlockCardResponse, CitrusPrepaidBlockCardRequest citrusPrepaidBlockCardRequest, String bankId, AeroCMSConf cmsConfig) {
		try {
			MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
			PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
			String xApiKeyValue = programParametersRepository.fetchParamValueByParamName(mapping.getBankId(),
					ProgramParamConstants.CITRUS_X_API_KEY_VALUE);

			String privateKey = programParametersRepository.fetchParamValueByParamName(mapping.getBankId(),
					ProgramParamConstants.CITRUS_ENC_DEC_PVT_KEY);
			custHeader.add(xApiKey, xApiKeyValue);
			custHeader.add(contentType, APPLICATION_JSON);
			ObjectMapper obj = new ObjectMapper();
			obj.writer().withDefaultPrettyPrinter();
			String reqJson = obj.writeValueAsString(citrusPrepaidBlockCardRequest);
			String encryptedReq = aesgcmPayLoadEncryption.encrypt(reqJson,privateKey);
			String reqBody = TOKEN +encryptedReq+ "\"}";
			HttpEntity<Object> entity = new HttpEntity<>(reqBody, custHeader);

			String url = cmsConfig.getUrl().concat(citrusBlockCardUrl);
			log.info("Concatenated url : {}", url);

			ResponseEntity<EncLoadUnloadResponse> responseEntity = restTemplate.exchange(
					url,
					HttpMethod.POST,entity , EncLoadUnloadResponse.class);
			
			if(responseEntity.getStatusCode() == HttpStatus.OK){
				log.info(SUCCESS_RES_FROM_PREPAID);
				EncLoadUnloadResponse encrptedResp =  responseEntity.getBody();
				String resp=null;
				if(encrptedResp!=null)
					resp=aesgcmPayLoadEncryption.decrypt(encrptedResp.getToken(),privateKey);
				citrusPrepaidBlockCardResponse = obj.readValue(resp,CitrusPrepaidBlockCardResponse.class);
				return citrusPrepaidBlockCardResponse;
			}else{
				log.error(EXCEPTION_IN_PREPAID, responseEntity.getBody(),responseEntity.getStatusCode());
			}
		} catch (Exception e) {
			log.error(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.RESPONSE_DESC_INTERNAL_ERROR)
					+ " : " + e);
		}
		return citrusPrepaidBlockCardResponse;
	}

	@Override
	public WibmoResponse unBlockCard(UnBlockCardRequest request, String programId, String accountNumber) {
		PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
		AeroCMSConf cmsConfig = aeroConfRepository.fetchByPPBankId(mapping.getId(),mapping.getBankId());

		WibmoResponse response = new WibmoResponse();
		CitrusPrepaidUnBlockCardResponse citrusPrepaidUnBlockCardResponse = null;

		CitrusPrepaidUnBlockCardRequest citrusPrepaidUnBlockCardRequest = new CitrusPrepaidUnBlockCardRequest();
		try {

			citrusPrepaidUnBlockCardRequest.setMessageCode(Integer.parseInt(AeroConstants.REQUEST_UNBLOCK_CARD));
			if(cmsConfig!=null) {
				citrusPrepaidUnBlockCardRequest.setClientId(cmsConfig.getClientId());
				citrusPrepaidUnBlockCardRequest.setSecureCode(cmsConfig.getSecureCode());
				citrusPrepaidUnBlockCardRequest.setBankId(Integer.parseInt(cmsConfig.getPpBankCode()));
				citrusPrepaidUnBlockCardRequest.setEntityId(Integer.parseInt(cmsConfig.getEntityId()));
			}
			citrusPrepaidUnBlockCardRequest.setClientTxnId(AeroCMSHelper.generateUniqueTxnId(AeroConstants.REQUEST_UNBLOCK_CARD));
			String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
			citrusPrepaidUnBlockCardRequest.setRequestDateTime(Long.parseLong(timeStamp));

			WalletCard walletCard = wcrepository.fetchById(request.getWalletId(), mapping.getBankId());
			if(walletCard!=null) {
				citrusPrepaidUnBlockCardRequest.setCustomerId(walletCard.getHostCustomerId()!=null ? walletCard.getHostCustomerId() : accountNumber);
				citrusPrepaidUnBlockCardRequest.setLast4Digits(walletCard.getCardNumber().substring(walletCard.getCardNumber().length() - 4));
				citrusPrepaidUnBlockCardRequest.setUrn(Integer.parseInt(walletCard.getBankUrn()));
			}
			CitrusPrepaidUnBlockCardResponse unBlockCardResponse = invokeUnBlockCardApi( citrusPrepaidUnBlockCardResponse, citrusPrepaidUnBlockCardRequest, mapping.getBankId(), cmsConfig);

			if(unBlockCardResponse!=null && unBlockCardResponse.getResponseCode().equals("00")) {
				response.setResCode(200);
				response.setResDesc("Card UnBlocked");
			}
			else {
				response.setResCode(100);
				response.setResDesc("Card UnBlock failed, unable to unblock card");
			}
		}
		catch (Exception ex)
		{
			log.error("Error occurred while card unblock");
		}
		return response;
	}

	private CitrusPrepaidUnBlockCardResponse invokeUnBlockCardApi( CitrusPrepaidUnBlockCardResponse citrusPrepaidUnBlockCardResponse, CitrusPrepaidUnBlockCardRequest citrusPrepaidUnBlockCardRequest, String bankId, AeroCMSConf cmsConfig) {
		try {
			MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
			PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
			String xApiKeyValue = programParametersRepository.fetchParamValueByParamName(mapping.getBankId(),
					ProgramParamConstants.CITRUS_X_API_KEY_VALUE);

			String privateKey = programParametersRepository.fetchParamValueByParamName(mapping.getBankId(),
					ProgramParamConstants.CITRUS_ENC_DEC_PVT_KEY);
			custHeader.add(xApiKey, xApiKeyValue);
			custHeader.add(contentType, APPLICATION_JSON);
			ObjectMapper obj = new ObjectMapper();
			obj.writer().withDefaultPrettyPrinter();
			String reqJson = obj.writeValueAsString(citrusPrepaidUnBlockCardRequest);
			String encryptedReq = aesgcmPayLoadEncryption.encrypt(reqJson,privateKey);
			String reqBody = TOKEN +encryptedReq+ "\"}";
			HttpEntity<Object> entity = new HttpEntity<>(reqBody, custHeader);

			String url = cmsConfig.getUrl().concat(citrusUnblockCardUrl);
			log.info("Concatenated url : {}", url);

			ResponseEntity<EncLoadUnloadResponse> responseEntity = restTemplate.exchange(
					url,
					HttpMethod.POST,entity , EncLoadUnloadResponse.class);
			if(responseEntity.getStatusCode() == HttpStatus.OK){
				log.info(SUCCESS_RES_FROM_PREPAID);
				EncLoadUnloadResponse encrptedResp =  responseEntity.getBody();
				String resp=null;
				if(encrptedResp!=null)
					resp=aesgcmPayLoadEncryption.decrypt(encrptedResp.getToken(),privateKey);
				citrusPrepaidUnBlockCardResponse = obj.readValue(resp,CitrusPrepaidUnBlockCardResponse.class);
				return citrusPrepaidUnBlockCardResponse;
			}else{
				log.error(EXCEPTION_IN_PREPAID, responseEntity.getBody(),responseEntity.getStatusCode());
			}
		} catch (Exception e) {
			log.error(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.RESPONSE_DESC_INTERNAL_ERROR)
					+ " : " + e);
		}
		return citrusPrepaidUnBlockCardResponse;
	}

	private void setResponseKycNotEkyc(CustomerMiniProfile miniProfile, WibmoResponse response) {
		if(miniProfile !=null && miniProfile.getKycLevel()!=100){
			log.info("Sender kyc level is not ekyc");
			response.setResCode(150);
			response.setResDesc("kyc level is not full kyc");
		}
	}

	private void setSenderUserInfo(CustomerMiniProfile miniProfile, SendMoneyRequest sendMoneyReq, UserAccountInfo senderUserInfo) {
		if(null != miniProfile) {
			sendMoneyReq.setSenderMobileNo(miniProfile.getMobileNo());
			senderUserInfo.setCustomerId(miniProfile.getCustomerId());
			senderUserInfo.setMobile(miniProfile.getMobileNo());
			senderUserInfo.setKycLevel(miniProfile.getKycLevel());
		}
	}

	private void callingNotificationResCodeSuccess(WibmoResponse response, CustomerMiniProfile miniProfile, String recieverMobNo, FundTransferRequest fundTransferReq, Receiver receiver, String notificationUrl, PrepaidBankMapping mapping) {
		if(response.getResCode() == ServiceHttpStatus.SUCCESS.getStatusCode())
		{
			Map<String, String> placeHolder = new HashMap<>();
			placeHolder.put("CUSTOMER_NAME", miniProfile.getFirstName());
			placeHolder.put("CURRENCY", "INR");
			placeHolder.put("AMOUNT", Constants.CURRENCY_IND+CommonUtil.decimalFormat(fundTransferReq.getTransactionAmount()));
			Timestamp currentDateTime = new Timestamp(new Date().getTime());
			placeHolder.put("DATE", currentDateTime.toString());
			placeHolder.put("LAST_4_DIGITS_OF_RECIPIENT_MOBILE NUMBER", receiver.getLast4Digits());
			NotificationRequest aRequest = NotificationRequest.builder()
					.mobileNumber(recieverMobNo)
					.programId(Integer.parseInt(mapping.getBankId()))
					.eventId(AeroConstants.SEND_MONEY_W2W)
					.emailId(miniProfile.getEmailId())
					.whatsappEnabled(false)
					.placeHolders(placeHolder).build();

			NotificationServiceCall notificationServiceCall = new NotificationServiceCall();
			log.info("calling notification service to send notification regarding transaction");
			notificationServiceCall.send(aRequest, notificationUrl);
		}
	}

	private void saveWalletInfoByClientCode(WalletTxnInfo walletTxnInfo, WalletTxnInfo recipientTxnInfo) {
		if (AeroConstants.CLIENT_RESPONSE_CODE_SUCCESS == walletTxnInfo.getStatus()) {
			walletInfoRepository.save(recipientTxnInfo);
		}
	}

	private void setSenderCustomerId(WalletCard senderCard, SendMoneyRequest sendMoneyReq) {
		if(senderCard.getHostCustomerId() != null) {
			log.info("senderCard.getHostCustomerId() :: {}",senderCard.getHostCustomerId());
			sendMoneyReq.setActualSenderCustomerId(sendMoneyReq.getSenderCustomerId());
			sendMoneyReq.setSenderCustomerId(senderCard.getHostCustomerId());
		}
	}

	private void processAcknowledgeLMTxnByType(FundRequest fundLoadReq, WalletCard cardDetails, LoadMoneyEvent lm, String bankId) {
		if(!("UPI_RM".equalsIgnoreCase(fundLoadReq.getSendMoneyTransactionType()) || "W2UPI".equalsIgnoreCase(fundLoadReq.getSendMoneyTransactionType()))){
			log.info("inside other than UPI-REQUEST-MONEY send money txn type :: {}",fundLoadReq.getSendMoneyTransactionType());
			acknowledgeLMTxn(cardDetails, lm, bankId);
		}
	}

	private void processAuditStatusFailure(CreateCardResponse createCardResponse, WibmoResponse response, PrepaidBankMapping mapping, int auditId) {
		String auditStatus = "";
		String auditRemarks = "";
		auditStatus = FAILURE;
		auditRemarks = null != createCardResponse
				? (createCardResponse.getResponseCode() + " : " + createCardResponse.getResponseMessage())
				: "CMS Response is null";
		auditRepository.updateApiReq(AeroCMSHelper.updateAuditReq(auditId, auditStatus, auditRemarks));
		response.setResCode(11);
		response.setResDesc(msgsRepository.fetchMsgValueByMsgName(mapping.getBankId(),AeroMsgDefinitions.CARD_CREATION_FAILED));
		response.setData(null != createCardResponse ? createCardResponse.getResponseMessage() : auditRemarks);
	}

	private WibmoResponse getWibmoResponse(FundRequest fundLoadReq, PrepaidBankMapping mapping, AeroCMSConf cmsConfig, WibmoResponse response, LoadUnloadResponse loadUnloadResponse, WalletCard cardDetails, InflowImpl ifImpl) {
		if (cardDetails.getCardNumber() == null) {
			// need to implement for first fund credit
		} else {

			//If require need to add all the conditions for cash back/regular
			// wallet/card txns...

			// generate request data for prepaid API call
			var yyyyMMddhhmmss = new SimpleDateFormat(dateFormat);
			var loadUnloadRequest = new LoadUnloadRequest();
			loadUnloadRequest = AeroCMSHelper.populateCommon(loadUnloadRequest, yyyyMMddhhmmss, cmsConfig);

			loadUnloadRequest.setMessageCode(AeroConstants.REQUEST_CREDIT_ACCOUNT);
			loadUnloadRequest.setAgentComments("Credit to Wallet "); // add comments
			WibmoResponse response1 = validateCard(response, cmsConfig.getAuditId(), cardDetails, loadUnloadRequest, mapping.getBankId());
			if (response1 != null) return response1;
			loadUnloadRequest.setUrn(cardDetails.getBankUrn());

			loadUnloadRequest.setClientTxnId(walletTxnInfo.getTxnId());
			loadUnloadRequest.setOriginalClientTxnId(walletTxnInfo.getTxnId());
			loadUnloadRequest.setTransactionAmount(walletTxnInfo.getAmount());
			loadUnloadRequest.setReserved1(loadUnloadRequest.getMessageCode());
			loadUnloadRequest.setReserved2(loadUnloadRequest.getAgentComments());
			populateReserve5(ifImpl, loadUnloadRequest);

			var clientEventId = new StringBuilder();
			clientEventId.append(AeroConstants.FUND_FLOW_TYPE_INFLOW).append("|");
			clientEventId.append(ifImpl.getIfImplId());
			loadUnloadRequest.setReserved4(clientEventId.toString());
			setHostCustomerIdInCardDetails(cardDetails, fundLoadReq);
			loadUnloadRequest.setCustomerId(fundLoadReq.getCustId());

			log.info("Request sending to prepaid for credit money to wallet "
					+ loadUnloadRequest.getOriginalClientTxnId());

			loadUnloadResponse = invokeCreditFundApi(loadUnloadResponse, loadUnloadRequest, mapping.getBankId(), cmsConfig);
            ParametersLoadUnloadResp parametersLoadUnloadResp = buildParamForLoadUnloadResp(cmsConfig.getAuditId(), mapping.getBankId(), walletTxnInfo.getTxnType());
			populateLoadunloadResponse(fundLoadReq, response, loadUnloadResponse, parametersLoadUnloadResp, cardDetails, loadUnloadRequest);
			log.info("saving txn details into db, TxnId :{}", walletTxnInfo.getTxnId());
			int id = walletInfoRepository.save(walletTxnInfo);
			log.info("Id :{} ", id);

		}
		return null;
	}

	private ParametersLoadUnloadResp buildParamForLoadUnloadResp(int auditId, String bankId, String txnType) {
		ParametersLoadUnloadResp resp = new ParametersLoadUnloadResp();
		resp.setAuditId(auditId);
		resp.setBankId(bankId);
		resp.setTxnType(txnType);
		return resp;
	}

}


