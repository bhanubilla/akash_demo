/**
 * 
 */
package com.wibmo.dfs.wallet.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
public class UserACSCheckRequest {
	
	@ApiModelProperty(required = true, dataType="String")
	private String bankId;
	@ApiModelProperty(required = true, dataType="String")
	private String mobileNo;
	@ApiModelProperty(required = true, dataType="String")
	private String walletCardNumber;
	private String dob;

}
