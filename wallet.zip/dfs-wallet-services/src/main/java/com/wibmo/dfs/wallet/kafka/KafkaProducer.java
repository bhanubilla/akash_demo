package com.wibmo.dfs.wallet.kafka;

import com.wibmo.dfs.wallet.aero.constants.TxnTrackingConstants;
import com.wibmo.dfs.wallet.kafka.model.AuditLog;
import com.wibmo.dfs.wallet.kafka.model.TrackingTxnStatus;
import com.wibmo.dfs.wallet.model.TransactionParams;
import com.wibmo.dfs.wallet.repository.ProgramParametersRepository;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.KafkaTemplate;

import com.wibmo.dfs.wallet.kafka.model.TxnDetails;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class KafkaProducer {

	public static final String EXCEPTION_ON_PUBLISHING_MESSAGE = "exception on publishing message: {}";
	public static final String TOPIC_PUBLISHED = "topic published";
	@Autowired
	private ProgramParametersRepository progParamRespository;

	@Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;

	@Value("${kafka.topicName.txnDetails: dfs-transaction-history}")
	private String txnHistoryTopicName;

	@Value("${kafka.topicName.walletStatement: dfs-wallet-statement}")
	private String topicNameForStmt;

	@Value("${kafka.topicName.auditLog: dfs-audit-log}")
	private String auditLogTopicName;
	
	@Value("${kafka.topicName.txnTrackingDetails:dfs-transaction-tracking}")
	private String txnTrackingTopicName;

	public String publishWalletTxn(TxnDetails txns) {
		log.debug("publishWalletTxn req details ---> {}",txns);
		try {
			kafkaTemplate.send(txnHistoryTopicName, txns);
		} catch(Exception e) {
			log.error(EXCEPTION_ON_PUBLISHING_MESSAGE,e);
		}
		return TOPIC_PUBLISHED;
	}

	public String publishWalletStatement(TransactionParams transactionParams) {
		log.debug("publishWalletStatement req details ---> {}",transactionParams);
		try {
			kafkaTemplate.send(topicNameForStmt, transactionParams);
		} catch(Exception e) {
			log.error(EXCEPTION_ON_PUBLISHING_MESSAGE,e);
		}
		return TOPIC_PUBLISHED;
	}

	public String publishAuditLogs(AuditLog auditLog) {
		log.debug("publishAuditLogs req details ---> {}",auditLog);
		try {
			kafkaTemplate.send(auditLogTopicName, auditLog);
		} catch(Exception e) {
			log.error(EXCEPTION_ON_PUBLISHING_MESSAGE,e);
		}
		return TOPIC_PUBLISHED;
	}
	
	public String publishUpiTxnTracking(String upiRequestId, TxnTrackingConstants status) {
		TrackingTxnStatus trackingtxnstatus = new TrackingTxnStatus();
		trackingtxnstatus.setTxnNumber(upiRequestId);
		trackingtxnstatus.setTxnStatusDescription(status.getStatusDescription());
		trackingtxnstatus.setTxnStatusName(status.getStatusName());
		trackingtxnstatus.setCreateAt(new Timestamp(new Date().getTime()));
		log.info("req details for txn tracking---> {}",trackingtxnstatus);
		try {
			kafkaTemplate.send(txnTrackingTopicName, trackingtxnstatus);
		} catch(Exception e) {
			log.error("exception on publishing txn tracking message: {}",e);
		}
		return TOPIC_PUBLISHED;
	}
}
