/**
 * 
 */
package com.wibmo.dfs.wallet.common;

/**
 * @author rajasekhar.kaniti
 *
 */
public class ProgramParamConstants {
	
	private ProgramParamConstants() {}
	
	public static final String IS_ADDING_CARD_MAX_LIMIT_PER_ACCOUNT_CHECK_IS_ENABLED = "IS_ADDING_CARD_MAX_LIMIT_PER_ACCOUNT_CHECK_IS_ENABLED";
	public static final String IS_ADDING_CARD_MAX_LIMIT_CHECK_IS_ENABLED =  "IS_ADDING_CARD_MAX_LIMIT_CHECK_IS_ENABLED";
	
	public static final String MAX_LIMIT_OF_ADDING_CARD_PER_ACCOUNT = "MAX_LIMIT_OF_ADDING_CARD_PER_ACCOUNT";
	public static final String MAX_LIMIT_OF_ADDING_CARD = "MAX_LIMIT_OF_ADDING_CARD";
	
	public static final String PAYMENT_SERVICE_BASE_URL = "PAYMENT_SERVICE_BASE_URL";

	public static final String CURRENCY_CODE = "CURRENCY_CODE";
	public static final String CURRENCY_ALF_CODE = "CURRENCY_ALF_CODE";	
	public static final String CURRENCY_UNI_CODE = "CURRENCY_UNI_CODE";
	public static final String CURRENCY_HTML_CODE = "CURRENCY_HTML_CODE";
	public static final String CURRENCY_FORMAT = "CURRENCY_FORMAT";
	public static final String TXN_HISTORY_RECORD_COUNT = "TXN_HISTORY_RECORD_COUNT";
	public static final String NO_OF_MONTH_FOR_TXN_HISTORY = "NO_OF_MONTH_FOR_TXN_HISTORY";
	public static final String ENABLE_MOCK_CARD_TYPE_RESP ="ENABLE_MOCK_CARD_TYPE_RESP";
	public static final String MOCK_CARD_TYPE_RESP ="MOCK_CARD_TYPE_RESP";
	
	public static final String USERLIMITS_SERVICE_BASE_URL = "USERLIMITS_SERVICE_BASE_URL";
	public static final String LM_MER_ID_KEY = "LM_MER_ID";
	public static final String LM_MER_NAME_KEY =  "LM_MER_NAME";
	public static final String CARD_MASK_PATTERN =  "CARD_MASK_PATTERN";
	public static final String UPI_COLLECT_REQUEST_EP =  "UPI_COLLECT_REQUEST_EP";
	public static final String UPI_PENDING_COLLECT_LIST_EP = "UPI_PENDING_COLLECT_LIST_EP";
	public static final String UPI_COLLECT_APPROVE_INIT_EP = "UPI_COLLECT_APPROVE_INIT_EP";
	public static final String UPI_COLLECT_APPROVE_CONFIRM_EP = "UPI_COLLECT_APPROVE_CONFIRM_EP";
	public static final String UPI_API_KEY =  "UPI_API_KEY";
	public static final String CURRENCY =  "CURRENCY";
	public static final String KAFKA_HOST_ADDRESS_KEY =  "KAFKA_HOST_ADDRESS";
	public static final String KAFKA_TXN_ACK_TOPIC_NAME_KEY =  "KAFKA_TXN_ACK_TOPIC_NAME";
	public static final String ALLOWED_TRANSACTION_MODES = "ALLOWED_TRANSACTION_MODES";
	public static final String W2A_MERCHANT_ID = "W2A_MERCHANT_ID";
	public static final String COLLECT_REQ_EXP_MINUTES = "COLLECT_REQ_EXP_MINUTES";
	public static final String CITRUS_X_API_KEY_VALUE = "CITRUS_X_API_KEY_VALUE";
	public static  final String CITRUS_ENC_DEC_PVT_KEY = "CITRUS_ENC_DEC_PVT_KEY";

}
