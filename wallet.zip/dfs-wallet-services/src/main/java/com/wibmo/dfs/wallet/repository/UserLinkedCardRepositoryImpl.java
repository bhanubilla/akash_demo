/**
 * 
 */
package com.wibmo.dfs.wallet.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.wibmo.dfs.wallet.entity.BankBinMapping;
import com.wibmo.dfs.wallet.entity.UserLinkedCardInfo;
import com.wibmo.dfs.wallet.entity.UserNickNameInfo;
import com.wibmo.dfs.hsm_client.CryptoException;
import com.wibmo.dfs.hsm_client.CryptoHandler;

import lombok.extern.slf4j.Slf4j;

/**
 * @author rajasekhar.kaniti
 *
 */
@Slf4j
@Repository
public class UserLinkedCardRepositoryImpl implements UserLinkedCardRepository {

	private static final String EXCEPTION = "exception :";
	private static final String INSERT_QUERY = "INSERT INTO USER_LINKED_CARDS (bin_id,customer_id,card_number,expiry_MM,"
			+ "expiry_YYYY,name_on_card,nick_name,card_added_source, is_primary,status)"
			+ " VALUES (?,?,?,?,?,?,?,?,?,?)";
	private static final String UPDATE_QUERY = "UPDATE USER_LINKED_CARDS SET NICK_NAME = ? WHERE ID=? AND CUSTOMER_ID=?";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private BankBinMappingRepository bankBinMappingRepository;

	@Autowired
	CryptoHandler hsm;

	@Override
	public int save(UserLinkedCardInfo userLinkedCardInfo, int bankId) {
		KeyHolder keyHolder = new GeneratedKeyHolder();

		jdbcTemplate.update(connection -> {
			PreparedStatement preparedStmt = connection.prepareStatement(INSERT_QUERY, Statement.RETURN_GENERATED_KEYS);
			int i = 1;

			preparedStmt.setInt(i++, userLinkedCardInfo.getBinId());
			preparedStmt.setString(i++, userLinkedCardInfo.getCustomerId());
			try {
				preparedStmt.setString(i++, hsm.secureData(bankId, userLinkedCardInfo.getCardNumber()));
				preparedStmt.setString(i++, hsm.secureData(bankId, userLinkedCardInfo.getExpiryMm()));
				preparedStmt.setString(i++, hsm.secureData(bankId, userLinkedCardInfo.getExpiryYyyy()));
			} catch (CryptoException e) {
				log.debug(e.getMessage());
			}
			preparedStmt.setString(i++, userLinkedCardInfo.getNameOnCard());
			preparedStmt.setString(i++, userLinkedCardInfo.getNickName());
			preparedStmt.setString(i++, userLinkedCardInfo.getCardAddedSource());
			preparedStmt.setInt(i++, userLinkedCardInfo.isPrimary() ? 1 : 0);
			preparedStmt.setInt(i++, userLinkedCardInfo.getStatus());

			return preparedStmt;
		}, keyHolder);

		Number key = keyHolder.getKey();
		return null != key ? key.intValue() : 0;
	}

	@Override
	public int update(UserLinkedCardInfo userLinkedCardInfo, int id) {
		return 0;
	}

	@Override
	public List<UserLinkedCardInfo> fetchLinkedCardByCustId(String customerId, int bankId) {
		BeanPropertyRowMapper<UserLinkedCardInfo> rowMapper = BeanPropertyRowMapper
				.newInstance(UserLinkedCardInfo.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<UserLinkedCardInfo> userLinkedCards = jdbcTemplate
				.query("select * from USER_LINKED_CARDS where customer_id = ?", new PreparedStatementSetter() {

					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setString(1, customerId);
					}
				}, rowMapper);
		List<UserLinkedCardInfo> decryptedCardDetails = new ArrayList<>();
		for (UserLinkedCardInfo linkedCard : userLinkedCards) {

			try {
				linkedCard.setCardNumber(hsm.getClearData(bankId, linkedCard.getCardNumber()));
				linkedCard.setExpiryMm(hsm.getClearData(bankId, linkedCard.getExpiryMm()));
				linkedCard.setExpiryYyyy(hsm.getClearData(bankId, linkedCard.getExpiryYyyy()));
			} catch (CryptoException e) {
				log.debug(EXCEPTION, e.getMessage());
			}

			addBinBankMappingDetails(linkedCard);

			decryptedCardDetails.add(linkedCard);

		}
		return decryptedCardDetails;
	}

	@Override
	public boolean delete(int id, String customerId) {
		int noOfRowsDeleted = jdbcTemplate.update("delete from USER_LINKED_CARDS where customer_id = ? and id = ?",
				customerId, id);
		return noOfRowsDeleted == 1;
	}

	@Override
	public int getCardAddedCountPerAccount(String customerId) {
		return jdbcTemplate.queryForObject("select count(*) from USER_LINKED_CARDS where customer_id = ?",
				Integer.class, customerId);
	}

	@Override
	public int getCardAddedCount(String cardNumber, int bankId) {
		String encryptyedCardNumber = null;
		try {
			encryptyedCardNumber = hsm.secureData(bankId, cardNumber);
		} catch (CryptoException e) {
			log.debug(EXCEPTION, e.getMessage());
		}
		return jdbcTemplate.queryForObject("select count(*) from USER_LINKED_CARDS where card_number = ?",
				Integer.class, encryptyedCardNumber);
	}

	@Override
	public UserLinkedCardInfo fetchLinkedCardById(int id, int bankId) {
		BeanPropertyRowMapper<UserLinkedCardInfo> rowMapper = BeanPropertyRowMapper
				.newInstance(UserLinkedCardInfo.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<UserLinkedCardInfo> userLinkedCards = jdbcTemplate.query("select * from USER_LINKED_CARDS where id = ?",
				new PreparedStatementSetter() {

					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setInt(1, id);
					}
				}, rowMapper);
		UserLinkedCardInfo linkedCard = !userLinkedCards.isEmpty() ? userLinkedCards.get(0) : null;
		if (linkedCard != null) {
			try {
				linkedCard.setCardNumber(hsm.getClearData(bankId, linkedCard.getCardNumber()));
				linkedCard.setExpiryMm(hsm.getClearData(bankId, linkedCard.getExpiryMm()));
				linkedCard.setExpiryYyyy(hsm.getClearData(bankId, linkedCard.getExpiryYyyy()));
			} catch (CryptoException e) {
				log.debug("Exception : {}", e.getMessage());
			}

			addBinBankMappingDetails(linkedCard);
		}

		return linkedCard;
	}

	@Override
	public List<UserLinkedCardInfo> fetchLinkedCardByCustIdOrId(String customerId, int id, int bankId) {
		List<UserLinkedCardInfo> listOfLinkedCards = new ArrayList<>();
		if (id > 0) {
			UserLinkedCardInfo userLinkedCard = fetchLinkedCardByCustIdAndId(customerId, id, bankId);
			if (userLinkedCard != null)
				listOfLinkedCards.add(userLinkedCard);
		} else {
			listOfLinkedCards = fetchLinkedCardByCustId(customerId, bankId);
		}

		return listOfLinkedCards;
	}

	public void addBinBankMappingDetails(UserLinkedCardInfo linkedCard) {
		BankBinMapping bankBinMapping = bankBinMappingRepository.getById(linkedCard.getBinId());

		if (bankBinMapping != null) {
			linkedCard.setBankName(bankBinMapping.getBankName());
			linkedCard.setCardType(bankBinMapping.getCardType());
			linkedCard.setCardUnion(bankBinMapping.getCardUnion());
			linkedCard.setOnUs(bankBinMapping.getOnUs());
			linkedCard.setCardAssociation(bankBinMapping.getCardAssociation());
		}
	}

	@Override
	public UserLinkedCardInfo fetchLinkedCardByCustIdAndId(String customerId, int id, int bankId) {
		BeanPropertyRowMapper<UserLinkedCardInfo> rowMapper = BeanPropertyRowMapper
				.newInstance(UserLinkedCardInfo.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<UserLinkedCardInfo> userLinkedCards = jdbcTemplate.query(
				"select * from USER_LINKED_CARDS where id = ? and customer_id = ?", new PreparedStatementSetter() {

					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setInt(1, id);
						preparedStatement.setString(2, customerId);
					}
				}, rowMapper);
		UserLinkedCardInfo linkedCard = !userLinkedCards.isEmpty() ? userLinkedCards.get(0) : null;
		if (linkedCard != null) {
			try {
				linkedCard.setCardNumber(hsm.getClearData(bankId, linkedCard.getCardNumber()));
				linkedCard.setExpiryMm(hsm.getClearData(bankId, linkedCard.getExpiryMm()));
				linkedCard.setExpiryYyyy(hsm.getClearData(bankId, linkedCard.getExpiryYyyy()));
			} catch (CryptoException e) {
				log.debug("Exception :", e.getMessage());
			}

			addBinBankMappingDetails(linkedCard);
		}

		return linkedCard;
	}

	@Override
	public int updateNickName(UserNickNameInfo userNickNameInfo) {

		return jdbcTemplate.update(connection -> {
			PreparedStatement ps = connection.prepareStatement(UPDATE_QUERY);
			int i = 1;
			ps.setString(i++, userNickNameInfo.getNickName());
			ps.setLong(i++, userNickNameInfo.getCardRefId());
			ps.setString(i++, userNickNameInfo.getCustomerId());

			return ps;
		});
	}

	@Override
	public UserLinkedCardInfo fetchLinkedCardByCustIdAndCardNumber(String customerId, String cardNumber, int bankId) {
		BeanPropertyRowMapper<UserLinkedCardInfo> rowMapper = BeanPropertyRowMapper
				.newInstance(UserLinkedCardInfo.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		String encryptyedCardNumber = null;
		try {
			encryptyedCardNumber = hsm.secureData(bankId, cardNumber);
		} catch (CryptoException e) {
			log.debug(EXCEPTION, e.getMessage());
		}
		String hsmCardNum = encryptyedCardNumber;
		List<UserLinkedCardInfo> userLinkedCards = jdbcTemplate.query(
				"select * from USER_LINKED_CARDS where customer_id = ? and CARD_NUMBER = ?",
				new PreparedStatementSetter() {

					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setString(1, customerId);
						preparedStatement.setString(2, hsmCardNum);
					}
				}, rowMapper);
		UserLinkedCardInfo linkedCard = !userLinkedCards.isEmpty() ? userLinkedCards.get(0) : null;
		if (linkedCard != null) {
			try {
				linkedCard.setCardNumber(hsm.getClearData(bankId, linkedCard.getCardNumber()));
				linkedCard.setExpiryMm(hsm.getClearData(bankId, linkedCard.getExpiryMm()));
				linkedCard.setExpiryYyyy(hsm.getClearData(bankId, linkedCard.getExpiryYyyy()));
			} catch (CryptoException e) {
				log.debug("Exception :", e.getMessage());
			}

		}

		return linkedCard;
	}

}
