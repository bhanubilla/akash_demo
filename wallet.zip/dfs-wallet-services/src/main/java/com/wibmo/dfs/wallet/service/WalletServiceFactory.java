package com.wibmo.dfs.wallet.service;

import com.wibmo.dfs.wallet.repository.PrepaidBankMappingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.stereotype.Service;

import com.wibmo.dfs.wallet.entity.PrepaidBankMapping;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class WalletServiceFactory {
	
	@Autowired
	private PrepaidBankMappingRepository bankRepository;
	
	@Autowired
	private AutowireCapableBeanFactory autowireCapableBeanFactory;

	private PrepaidBankMapping bankConfig;
	
	
	public WalletService getService(String type) {
		WalletService service = null;
		PrepaidBankMapping bnk = bankRepository.fetchByBankId(type);
		try {
			service = (WalletService) Class.forName(bnk.getPpMaster().getImplClass()).getDeclaredConstructor().newInstance();
			autowireCapableBeanFactory.autowireBean(service);
			this.bankConfig = bnk;
		} catch (Exception e) {
			log.error("exception : {}", e);
		} 
		if (service == null) {
			log.info("Unknown service type: " + type);
			return new WalletServiceImpl();
		}
		return service;
	}
	
	public PrepaidBankMapping fetchBankMapping() {
		return bankConfig;
	}
}
