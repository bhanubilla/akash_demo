package com.wibmo.dfs.wallet.model;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class W2AVerificationRequest {
    @NotNull
    private String sourceRefId;
    @NotNull
    private String txnType;
    private int beneficiaryId;
    @NotNull
    private long txnAmt;
    private String beneficiaryAccountNumber;
    private String beneficiaryIfscCode;
    private String beneficiaryName;
    private String vpa;
}
