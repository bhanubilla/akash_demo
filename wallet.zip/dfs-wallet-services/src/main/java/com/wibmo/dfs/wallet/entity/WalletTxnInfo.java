/**
 * 
 */
package com.wibmo.dfs.wallet.entity;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
public class WalletTxnInfo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	
	private int id;
	private String txnId;
	private String userId;
	private int walletId;
	private String originalTxnId;
	private String txnType;
	private long amount;
	private int status;
	private String statusDesc;
	private String comments;
	private String inflowImplId;
	private int outflowImplId;
	private String cmsRef;
	private Date createdDt;
	private Date updatedDt;
	private String merchantId;
	private String ppTxnId;

}
