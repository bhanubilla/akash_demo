package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SendMoneyResponse {
	
	private String txnId;
	private long amount;
	private long availableBal;
	private String senderMobileNo;
	private String recipientMobileNo;
	private String remarks;
	private long txnDate;

}

 