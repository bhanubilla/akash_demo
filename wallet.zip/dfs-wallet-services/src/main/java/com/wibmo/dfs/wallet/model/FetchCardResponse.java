package com.wibmo.dfs.wallet.model;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FetchCardResponse extends CardDetails{

	private long balance;
	private String walletStatus;
	private String productType;
	private int kycLevel;
	private List<ServiceTypes> txnProfile;
}
