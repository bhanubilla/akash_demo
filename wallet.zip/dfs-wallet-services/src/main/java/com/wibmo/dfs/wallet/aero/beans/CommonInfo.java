package com.wibmo.dfs.wallet.aero.beans;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CommonInfo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String additionalField1 = ""; // For future use
	private String additionalField2 = ""; // For future use
	private String additionalField3 = ""; // For future use
	private String additionalField4 = ""; // RefId from QR code
	private String additionalField5 = ""; // MCC Code from QR code
	private String additionalField6 = ""; // Ref Url from QR code
	private String additionalField7 = ""; // TxnId from QR code
	private String additionalField8 = ""; // For future use
	private String additionalField9 = "NA"; // For future use
	private String additionalField10 = "NA"; // For future use
}
