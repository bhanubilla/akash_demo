package com.wibmo.dfs.wallet.repository;

import com.wibmo.dfs.wallet.entity.AuditStatement;

public interface AuditStatementRepository {

	int save(AuditStatement txn);
	int updateAudit(AuditStatement txn);

}
