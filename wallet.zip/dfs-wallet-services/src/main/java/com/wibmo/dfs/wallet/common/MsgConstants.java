/**
 * 
 */
package com.wibmo.dfs.wallet.common;

/**
 * @author rajasekhar.kaniti
 *
 */
public class MsgConstants {
	private MsgConstants() {}
	
	
	public static final String USER_INFO_IS_MISSING = "USER_INFO_IS_MISSING";
	public static final String ADDRESS_INFO_IS_MISSING ="ADDRESS_INFO_IS_MISSING";
	public static final String ACCOUNT_INFO_IS_MISSING = "ACCOUNT_INFO_IS_MISSING";
	public static final String PROFILE_INFO_IS_MISSING = "PROFILE_INFO_IS_MISSING";
	public static final String LINKEDCARD_INFO_IS_EMPTY = "LINKEDCARD_INFO_IS_EMPTY";
	
	public static final String PRODUCTTYPE_IS_EMPTY = "PRODUCTTYPE_IS_EMPTY";
	public static final String ADDRESSLINEE_IS_EMPTY = "ADDRESSLINEE_IS_EMPTY";
	public static final String CITY_CODE_IS_EMPTY = "CITY_CODE_IS_EMPTY";
	public static final String ZIP_CODE_IS_EMPTY = "ZIP_CODE_IS_EMPTY";
	public static final String COUNTRY_IS_EMPTY ="COUNTRY_IS_EMPTY";
	public static final String CUSTOMER_ID_IS_EMPTY = "CUSTOMER_ID_IS_EMPTY";
	public static final String KYC_LEVEL_IS_EMPTY = "KYC_LEVEL_IS_EMPTY";
	public static final String GENDER_IS_EMPTY = "GENDER_IS_EMPTY";
	public static final String FIRST_NAME_IS_EMPTY = "FIRST_NAME_IS_EMPTY";
	public static final String MOBILE_NUMBER_IS_EMPTY = "MOBILE_NUMBER_IS_EMPTY";
	public static final String EMAIL_ID_IS_EMPTY = "EMAIL_ID_IS_EMPTY";
	public static final String INVALID_DATE_FORMAT = "INVALID_DATE_FORMAT";
	public static final String MCC_IS_EMPTY = "MCC_IS_EMPTY";
	public static final String RRN_IS_EMPTY = "RRN_IS_EMPTY";
	public static final String AMOUNT_IS_ZERO = "AMOUNT_IS_ZERO";
	public static final String AMOUNT_IS_LESS_THAN_ONE = "AMOUNT_IS_LESS_THAN_ONE";
	public static final String WALLET_ID_IS_ZERO = "WALLET_ID_IS_ZERO";
	public static final String PRODUCT_TYPE_OR_CUST_ID_IS_EMPTY = "PRODUCT_TYPE_OR_CUST_ID_IS_EMPTY";
	public static final String CATEGORY_IS_EMPTY = "CATEGORY_IS_EMPTY";
	public static final String BANK_ACCOUNT_IS_EMPTY = "BANK_ACCOUNT_IS_EMPTY";
	public static final String ACCOUNT_NUMBER_IS_EMPTY = "ACCOUNT_NUMBER_IS_EMPTY";
	public static final String ACCOUNT_NAME_IS_EMPTY = "ACCOUNT_NAME_IS_EMPTY";
	public static final String IFSC_CODE_IS_EMPTY = "IFSC_CODE_IS_EMPTY";
	public static final String BANK_NAME_IS_EMPTY = "BANK_NAME_IS_EMPTY";
	public static final String ACCOUNT_TYPE_IS_EMPTY = "ACCOUNT_TYPE_IS_EMPTY";
	public static final String CARD_NUMBER_IS_EMPTY = "CARD_NUMBER_IS_EMPTY";
	public static final String CARD_EXPITY_YYYY_IS_EMPTY = "CARD_EXPITY_YYYY_IS_EMPTY";
	public static final String CARD_EXPITY_MM_IS_EMPTY = "CARD_EXPITY_MM_IS_EMPTY";
	public static final String NAME_ON_CARD_IS_EMPTY = "NAME_ON_CARD_IS_EMPTY";
	public static final String RECIPIENT_FIRST_NAME_IS_EMPTY = "RECIPIENT_FIRST_NAME_IS_EMPTY";
	public static final String RECIPIENT_LAST_NAME_IS_EMPTY = "RECIPIENT_LAST_NAME_IS_EMPTY";
	public static final String RECIPIENT_ADDRESS_LINE_ONE_IS_EMPTY = "RECIPIENT_ADDRESS_LINE_ONE_IS_EMPTY";
	public static final String RECIPIENT_CITY_IS_EMPTY = "RECIPIENT_CITY_IS_EMPTY";
	public static final String RECIPIENT_COUNTRY_IS_EMPTY = "RECIPIENT_COUNTRY_IS_EMPTY";
	public static final String RECIPIENT_COUNTRY_SUB_DIVISION_IS_EMPTY = "RECIPIENT_COUNTRY_SUB_DIVISION_IS_EMPTY";
	public static final String RECIPIENT_NATIONALITY_IS_EMPTY = "RECIPIENT_NATIONALITY_IS_EMPTY";
	public static final String RECIPIENT_POSTAL_CODE_IS_EMPTY = "RECIPIENT_POSTAL_CODE_IS_EMPTY";
	public static final String CARD_EXPIRY_YEAR_LESS_THAN_CURRENT_YEAR = "CARD_EXPIRY_YEAR_LESS_THAN_CURRENT_YEAR";
	public static final String CARD_EXPIRY_MONTH_LESS_THAN_CURRENT_MONTH = "CARD_EXPIRY_MONTH_LESS_THAN_CURRENT_MONTH";
	public static final String CARD_ADDED_SOURCE_IS_EMPTY = "CARD_ADDED_SOURCE_IS_EMPTY";
	public static final String CARD_ID_IS_EMPTY = "CARD_ID_IS_EMPTY";
	public static final String BANK_ID_IS_EMPTY = "BANK_ID_IS_EMPTY";
	public static final String REQUEST_EMPTY = "REQUEST_EMPTY";
	
	public static final String USER_NICKNAME_IS_EMPTY = "USER_NICKNAME_IS_EMPTY";
	public static final String TXN_ID_IS_EMPTY = "TXN_ID_IS_EMPTY";
	
	public static final String CHARGE_ATTEMPT_IS_EMPTY = "CHARGE_ATTEMPT_IS_EMPTY";
	public static final String WIBMO_TXN_ID_IS_EMPTY = "WIBMO_TXN_ID_IS_EMPTY";
	public static final String MERCHANT_TXN_ID_IS_EMPTY = "MERCHANT_TXN_ID_IS_EMPTY";
	public static final String AUTHENTICATION_IS_EMPTY = "AUTHENTICATION_IS_EMPTY";
	public static final String TOPUP_AMT_IS_ZERO = "TOPUP_AMT_IS_ZERO";
	public static final String THRESHOLD_AMT_IS_ZERO= "THRESHOLD_AMT_IS_ZERO";
	public static final String TXN_DATE_IS_EMPTY= "TXN_DATE_IS_EMPTY";
	public static final String MERCHANT_ID_IS_EMPTY = "MERCHANT_ID_IS_EMPTY";
	public static final String SUB_STATUS_IS_EMPTY = "SUB_STATUS_IS_EMPTY";
	public static final String PAYMENT_REF_ID_IS_ZERO = "PAYMENT_REF_ID_IS_ZERO";
	public static final String USER_ID_IS_ZERO = "USER_ID_IS_ZERO";
	public static final String SUB_STATUS_IS_ZERO = "SUB_STATUS_IS_ZERO";
	public static final String COLLECT_STATUS_IS_EMPTY= "COLLECT_STATUS_IS_EMPTY";


	//UserACS Service Error Msgs
	public static final String MOBILE_AND_CARD_DETAILS_ARE_MISMATCH = "MOBILE_AND_CARD_DETAILS_ARE_MISMATCH";
	public static final String WALLET_CARD_NOT_FOUND = "WALLET_CARD_NOT_FOUND";
	
	//WalletService Error Msgs
	public static final String CLIENT_ID_OR_BANK_DETAILS_ARE_INCORRECT = "CLIENT_ID_OR_BANK_DETAILS_ARE_INCORRECT";
	
	//Account Service Error Msgs
	public static final String ACCOUNT_LINKED_SUCCESSFULLY = "ACCOUNT_LINKED_SUCCESSFULLY";
	public static final String MAX_LIMIT_OF_ADDING_CARD_PER_ACCOUNT_EXCEEDED = "MAX_LIMIT_OF_ADDING_CARD_PER_ACCOUNT_EXCEEDED";
	public static final String MAX_LIMIT_OF_ADDING_CARD_EXCEEDED = "MAX_LIMIT_OF_ADDING_CARD_EXCEEDED";
	public static final String CARD_LINKED_SUCCESSFULLY = "CARD_LINKED_SUCCESSFULLY";
	public static final String INVALID_CATEGORY_PASSED = "INVALID_CATEGORY_PASSED";
	public static final String ACCOUNT_UNLINK_FAILED = "ACCOUNT_UNLINK_FAILED";
	public static final String ACCOUNT_UNLINK_SUCCESSFULLY = "ACCOUNT_UNLINK_SUCCESSFULLY";
	public static final String ACCOUNTS_FETCH_SUCCESSFULLY = "ACCOUNTS_FETCH_SUCCESSFULLY";
	
	
	
	public static final String RESPONSE_DESC_INTERNAL_ERROR = "RESPONSE_DESC_INTERNAL_ERROR";
	public static final String PAYMENT_CARDTYPE_RESPONSE_FAILED = "PAYMENT_CARDTYPE_RESPONSE_FAILED";
	
	public static final String NICKNAME_UPDATED_SUCCESSFULLY = "NICKNAME_UPDATED_SUCCESSFULLY";
	public static final String NICKNAME_UPDATE_FAILED = "NICKNAME_UPDATE_FAILED";
	
	public static final String TXN_TYPE_IS_EMPTY = "TXN_TYPE_IS_EMPTY";
	public static final String ORIGINAL_RRN_IS_EMPTY = "ORIGINAL_RRN_IS_EMPTY";
	public static final String TXN_FLOW_IS_EMPTY = "TXN_FLOW_IS_EMPTY";
	//auto topup
	public static final String AUTO_TOPUP_NOT_SUBSCRIBED = "AUTO_TOPUP_NOT_SUBSCRIBED";
	public static final String THRESHOLD_AMT_AND_TOPUP_AMT_CHECK = "THRESHOLD_AMT_AND_TOPUP_AMT_CHECK";
	public static final String COUNTRYCODE_IS_ZERO= "COUNTRYCODE_IS_ZERO";


	public static final String MAX_AMT_PER_TXN_EXCEEDED = "MAX_AMT_PER_TXN_EXCEEDED";
	public static final String MONTHLY_LMT_AMT_EXCEEDED = "MONTHLY_LMT_AMT_EXCEEDED";
	public static final String MONTHLY_LMT_CNT_EXCEEDED = "MONTHLY_LMT_CNT_EXCEEDED";
	public static final String DAILY_LMT_AMT_EXCEEDED = "DAILY_LMT_AMT_EXCEEDED";
	public static final String DAILY_LMT_CNT_EXCEEDED = "DAILY_LMT_CNT_EXCEEDED";
	public static final String KYC_LMT_NOT_FOUND = "KYC_LMT_NOT_FOUND";
	public static final String CARD_IS_ALREADY_LINKED = "CARD_IS_ALREADY_LINKED";

	public static final String SERVICE_TYPE_IS_EMPTY = "SERVICE_TYPE_IS_EMPTY";
	public static final String STATUS_IS_EMPTY = "STATUS_IS_EMPTY";
	public static final String SERVICE_IS_EMPTY = "SERVICE_IS_EMPTY";
	public static final String MOBILE_OR_CUST_ID_IS_EMPTY = "MOBILE_OR_CUST_ID_IS_EMPTY";

	public static final String BENEFICIARY_ACCOUNTS_FETCH_SUCCESSFULLY = "BENEFICIARY_ACCOUNTS_FETCH_SUCCESSFULLY";
	public static final String BENEFICIARY_ACCOUNTS_NOT_AVAILABLE = "BENEFICIARY_ACCOUNTS_NOT_AVAILABLE";
	public static final String BENEFICIARY_ACCOUNTS_ADD_SUCCESSFULLY = "BENEFICIARY_ACCOUNTS_ADD_SUCCESSFULLY";
	public static final String BENEFICIARY_ACCOUNTS_ADD_FAILED = "BENEFICIARY_ACCOUNTS_ADD_FAILED";
	public static final String BENEFICIARY_ACCOUNTS_EXISTS = "BENEFICIARY_ACCOUNTS_EXISTS";
	public static final String COUNTRY_CODE_IS_ZERO = "COUNTRY_CODE_IS_ZERO";
	public static final String BENEFICIARY_ID_MANDATORY = "BENEFICIARY_ID_MANDATORY";

	public static final String VPA_IS_EMPTY = "VPA_IS_EMPTY";
	public static final String RECIPIENT_VPA_IS_EMPTY = "RECIPIENT_VPA_IS_EMPTY";
	public static final String SENDER_VPA_IS_EMPTY = "SENDER_VPA_IS_EMPTY";
	public static final String FAILED_CONSUMPTION = "FAILED_CONSUMPTION";
	public static final String FAILED_TO_CALL_SERVICE = "FAILED_TO_CALL_SERVICE";
	public static final String FEE_VALIDATION_FAILED = "FEE_VALIDATION_FAILED";
	public static final String W2A_MESSAGE_TITLE = "W2A_MESSAGE_TITLE";
	public static final String COOLING_PERIOD_AMOUNT_EXCEEDED = "COOLING_PERIOD_AMOUNT_EXCEEDED";
	public static final String COOLING_PERIOD_COUNT_EXCEEDED = "COOLING_PERIOD_COUNT_EXCEEDED";
	public static final String INSUFFICIANT_BALANCE = "INSUFFICIANT_BALANCE";
	public static final String REMARKS_IS_EMPTY = "REMARKS_IS_EMPTY";
}