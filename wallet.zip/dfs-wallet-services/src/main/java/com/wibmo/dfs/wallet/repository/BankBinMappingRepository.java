/**
 * 
 */
package com.wibmo.dfs.wallet.repository;

import com.wibmo.dfs.wallet.entity.BankBinMapping;

/**
 * @author rajasekhar.kaniti
 *
 */

public interface BankBinMappingRepository {
	
	int save(BankBinMapping bankBinMapping);
	int update(BankBinMapping bankBinMapping,int id);
	BankBinMapping getByBin(String bin);
	int checkAndSave(BankBinMapping bankBinMapping);
	BankBinMapping getById(int id);

}
