package com.wibmo.dfs.wallet.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class FetchBeneficaryBankAccountResponse {
	
	private int id;
	private String customerId;
	private String accountNumber;
	private String accountName;
	private String ifscCode;
	private String bankName;
	private String accountType;
	private String branchName;
	private String vpa;

}
