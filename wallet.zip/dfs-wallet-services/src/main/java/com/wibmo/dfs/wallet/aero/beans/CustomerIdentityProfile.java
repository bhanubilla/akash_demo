
package com.wibmo.dfs.wallet.aero.beans;

import lombok.Data;

import java.io.Serializable;

@Data
public class CustomerIdentityProfile implements Serializable {

    private String customerAadharCardNumber;
    private String customerPANCardNumber;
    private String customerPassportNumber;
    private String customerVoterIdNumber;
    private String customerDrivingLicenseNumber;
    private String customerCkycRefNo;
    private String kycRefNo;

}
