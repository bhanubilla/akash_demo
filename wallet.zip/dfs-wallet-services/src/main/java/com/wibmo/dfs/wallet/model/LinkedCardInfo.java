/**
 * 
 */
package com.wibmo.dfs.wallet.model;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
public class LinkedCardInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@ApiModelProperty(required = true, dataType="String")
	private String cardNumber;
	
	@ApiModelProperty(required = true, dataType="String")
	private String cardExpiryMM;
	
	@ApiModelProperty(required = true, dataType="String")
	private String cardExpiryYYYY;
	
	@ApiModelProperty(required = true, dataType="String")
	private String nameOnCard;
	
	@ApiModelProperty(required = false, dataType="String")
	private String nickName;
	
	@ApiModelProperty(required = false, dataType="boolean")
	private boolean isPrimary;
	
	@ApiModelProperty(required = true, dataType="String", example="SELF", notes="possible values are SELF, or ONFLY")
	private String addedSource;
	
	@ApiModelProperty(required = false, dataType="String")
	private String countryCode;
	
	@ApiModelProperty(required = false, dataType="String")
	private String cardType;
	
	@ApiModelProperty(required = false, dataType="String")
	private String cardUnion;
	
	@ApiModelProperty(required = false, dataType="String")
	private String bankName;
	
	@ApiModelProperty(required = false, dataType="String")
	private String cardAssociation;
	
	@ApiModelProperty(required = false, dataType="int")
	private int onUs;

}
