package com.wibmo.dfs.wallet.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RMRequest  implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String requesterCustomerId;
	@ApiModelProperty(required = false, dataType = "String", hidden = true)
	private String requesteeMobile;
	private String requesteeName;
	private String requesteeCustomerId;
	@ApiModelProperty(hidden = true)
	private String initiateFrom;
	private long amount;
	private String txnMode ;
	private String remarks ;
	private UpiToUpiRequestMoneyReq upiReq;
	
}

