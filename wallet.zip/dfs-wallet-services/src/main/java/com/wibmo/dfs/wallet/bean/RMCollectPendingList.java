package com.wibmo.dfs.wallet.bean;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RMCollectPendingList implements Serializable {

	  private static final long serialVersionUID = 1L;
	  
	  private String upiTrnRefNo;
	  private long reqDate;
	  private String txnId;
	  private String txnNote;
	  private String txnAmount;
	  private String payeeVa;
	  private String payeeName;
	  private String collectExpTime;
	  private String custRefNo;
	  private String pyAccNo;
	  private String pyIfscCode;
	  private String bankCode;
	  private boolean verificationFlag;
	  private String payType;
	  private String txnRefUrl;
}
