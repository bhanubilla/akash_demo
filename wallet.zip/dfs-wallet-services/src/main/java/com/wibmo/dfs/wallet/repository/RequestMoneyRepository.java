package com.wibmo.dfs.wallet.repository;

import java.util.List;

import com.wibmo.dfs.wallet.entity.RequestMoneyTxnInfo;

public interface RequestMoneyRepository {

	int saveRequestMoney(RequestMoneyTxnInfo txnInfo);
	
	List<RequestMoneyTxnInfo> fetchByRequesteeCustomerId(String requesteeCustomerId, String status);

	public List<RequestMoneyTxnInfo> fetchBlockedUserPendingList(String requesteeCustomerId,String requesterCustomerId, String status);

	RequestMoneyTxnInfo fetchById(String id);
	
	int updateRequestMoneyTxnInfo(RequestMoneyTxnInfo txnInfo);

	RequestMoneyTxnInfo fetchByTxnId(String id);
}
