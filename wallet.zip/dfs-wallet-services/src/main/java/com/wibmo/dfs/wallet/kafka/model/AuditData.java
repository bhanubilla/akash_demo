package com.wibmo.dfs.wallet.kafka.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AuditData{

    private String eventName;
    private String requestBody;
    private String requestStatus;
    private String responseBody;
    private String remarks;
    private String customerId;
    private String secondaryCustomerId;
    private String transactionId;
    private String secondaryTransactionId;
    private String serviceName;
    private String elapsedTime;
}
