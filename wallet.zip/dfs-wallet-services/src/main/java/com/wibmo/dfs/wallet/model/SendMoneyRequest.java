package com.wibmo.dfs.wallet.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SendMoneyRequest {
	// not exposing to client, but setting at service level
	@ApiModelProperty(required = false, dataType="String", hidden = true)
	private String senderMobileNo;
	
	@ApiModelProperty(required = true, dataType="String")
	private String recipientMobileNo;
	
	@ApiModelProperty(required = true, dataType="long")
	private long amount;
	
	@ApiModelProperty(required = false, dataType="String", hidden = true)
	private String senderCustomerId;
	
	@ApiModelProperty(required = false, dataType="String")
	private String recipientCustomerId;
	
	@ApiModelProperty(required = true, dataType="String")
	private String remarks;
	
	@ApiModelProperty(required = true, dataType="int")
	private int senderWalletId ;
	
	@ApiModelProperty(required = false, dataType="String")
	private int recipientWalletId;
	
	@ApiModelProperty(required = true, dataType="String")
	private String rrn;
	
	@ApiModelProperty(required = true, dataType="String")
	private String recipientFirstName;
	
	@ApiModelProperty(required = false, dataType="String")
	private String recipientMiddleName;
	
	@ApiModelProperty(required = true, dataType="String")
	private String recipientLastName;
	
	@ApiModelProperty(required = true, dataType="String")
	private String recipientNationality;
	
	@ApiModelProperty(required = true, dataType="String")
	private String recipientAddressLine1;
	
	@ApiModelProperty(required = true, dataType="String")
	private String recipientCity;
	
	@ApiModelProperty(required = true, dataType="String")
	private String recipientCountrySubdivision;
	
	@ApiModelProperty(required = true, dataType="String")
	private String recipientPostalCode;
	
	@ApiModelProperty(required = true, dataType="String")
	private String recipientCountry;
	
	@ApiModelProperty(required = false, dataType="String")
	private String recipientEmail;
	
	@ApiModelProperty(required = true, dataType="String", example="RW", notes="possible value are RW,FC,GC,OT")
	private String productType;
	
	@ApiModelProperty(hidden = true)
	private String initiateFrom;

	private String txnRefNumber;

	@ApiModelProperty(required = false, dataType="String")
	private String actualSenderCustomerId;

	@ApiModelProperty(required = false, dataType="String")
	private String originalTxnId;

	private String mcc;
}
