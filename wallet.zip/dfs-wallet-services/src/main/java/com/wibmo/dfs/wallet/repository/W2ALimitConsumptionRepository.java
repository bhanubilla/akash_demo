package com.wibmo.dfs.wallet.repository;

import com.wibmo.dfs.wallet.entity.W2AConsumption;
import com.wibmo.dfs.wallet.model.LimitConsumptionRequest;

public interface W2ALimitConsumptionRepository {
    int save(W2AConsumption w2ALimitConsumption);
    int update(W2AConsumption w2AConsumption, String startDate, String endDate);
    W2AConsumption fetch(int programId, String customerId, String txnType, String limitKey, String startDate, String endDate);
    W2AConsumption isConsumptionAvailable(LimitConsumptionRequest request, String customerId, String date, String startDate, String endDate);
}