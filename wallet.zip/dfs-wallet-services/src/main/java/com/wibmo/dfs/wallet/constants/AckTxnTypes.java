package com.wibmo.dfs.wallet.constants;

public enum AckTxnTypes {
    LM("LM"),P2P("P2P"),P2PC("P2PC"),P2PD("P2PD"),RM("RM"),RMC("RMC"),RMD("RMD"),W2A("W2A"), W2UPI("W2UPI"), W2UPI_DEB("W2UPID"), W2UPI_CRED("W2UPIC");

    private String type;

    AckTxnTypes(String type) {
        this.type = type;
    }

    public String getType() {
        return this.type;
    }
}
