/**
 * 
 */
package com.wibmo.dfs.wallet.repository;

import java.util.List;

import com.wibmo.dfs.wallet.entity.BeneficiaryBankAccounts;
import com.wibmo.dfs.wallet.model.W2AVerificationRequest;

/**
 * @author ajay.mahto
 *
 */

public interface BeneficaryBankAccountsRepository {
	
	int save(BeneficiaryBankAccounts benefBankAcc, int id);
	
	List<BeneficiaryBankAccounts> fetchBeneficaryBankAccByCustId(String customerId, int bankId);
	
	boolean isBankAccountExist(String customerId, String accountNumber, int bankId);

	BeneficiaryBankAccounts fetchBeneficiaryBankAccByBenefId(String customerId, int bankId, int beneficiaryId);

	BeneficiaryBankAccounts fetchBeneficaryBankAccByBenefInfo(String customerId, int bankId, W2AVerificationRequest w2AVerificationRequest);

}
