package com.wibmo.dfs.wallet.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.wibmo.dfs.wallet.entity.AuditApiReq;

@Repository
public class AuditApiReqRepositoryImpl implements AuditApiReqRepository {

	private static final String INSERT_QUERY = "insert into audit_api_req(req_for,req_body) values(?,?)";

	private static final String UPDATE_QUERY = "update audit_api_req set req_status=?, remarks=? where id=? ";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int save(AuditApiReq auditReq) {
		KeyHolder keyHolder = new GeneratedKeyHolder();

		jdbcTemplate.update(connection -> {
			PreparedStatement ps = connection.prepareStatement(INSERT_QUERY, Statement.RETURN_GENERATED_KEYS);
			int i = 1;
			ps.setString(i++, auditReq.getReqFor());
			ps.setString(i++, auditReq.getReqBody());

			return ps;
		}, keyHolder);
		
		Number value =keyHolder.getKey();
		return null != value ? value.intValue():0;
	}

	@Override
	public AuditApiReq fetchById(int id) {
		BeanPropertyRowMapper<AuditApiReq> rowMapper = BeanPropertyRowMapper.newInstance(AuditApiReq.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<AuditApiReq> li = jdbcTemplate.query("select * from audit_api_req where id = ?",new PreparedStatementSetter() {
	     	   
	     	   public void setValues(PreparedStatement preparedStatement) throws SQLException {
	     	      preparedStatement.setInt(1, id);
	     	   }
	     	},
				rowMapper);
		return !li.isEmpty() ? li.get(0) : null;
	}

	@Override
	public boolean updateApiReq(AuditApiReq auditApiReq) {
		int cnt = jdbcTemplate.update(UPDATE_QUERY, auditApiReq.getReqStatus(), auditApiReq.getRemarks(),
				auditApiReq.getId());
		return cnt == 1;
	}

}
