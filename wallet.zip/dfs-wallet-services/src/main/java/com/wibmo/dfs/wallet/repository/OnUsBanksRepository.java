/**
 * 
 */
package com.wibmo.dfs.wallet.repository;

import java.util.List;

/**
 * @author rajasekhar.kaniti
 *
 */

public interface OnUsBanksRepository {
	
	List<String> getAllOnUsBankIds();

}
