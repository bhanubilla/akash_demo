/**
 * 
 */
package com.wibmo.dfs.wallet.entity;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
public class BankBinMapping implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int id;
	private String bin;
	private String countryCode;
	private String cardType;
	private int status=1;
	private String cardUnion;
	private String bankName;
	private String cardAssociation;
	private int onUs;
	private Date binAddedDate;
	private Date binUpdatedDate;
	
}
