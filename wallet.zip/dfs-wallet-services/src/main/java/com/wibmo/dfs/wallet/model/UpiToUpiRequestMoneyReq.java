package com.wibmo.dfs.wallet.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UpiToUpiRequestMoneyReq implements Serializable{

		
	private static final long serialVersionUID = 1L;
		//upi to upi
		private String token;
		private String msgHash;
		private String payeeVirtualAddress;
		private String payeeAccountId;
		private String deviceId;
		private String mobileNo;
		private String simId;
		private String geoCode;
		private String location;
		private String ip;
		private String os;
		private String deviceType;
		private String appName;
		private String capability;
		private String payerVirtualAddress;
		private String txnAmount;
		private String expiryTime;
		private String transactionNote;
		private String deviceName;
		private String payerName;
		private String currency;
}
