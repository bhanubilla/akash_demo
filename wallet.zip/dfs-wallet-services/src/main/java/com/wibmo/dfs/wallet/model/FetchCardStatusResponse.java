package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FetchCardStatusResponse {

	private String customerId;
	private int walletId;
	private int status;
	private String statusDesc;
}
