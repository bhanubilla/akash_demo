package com.wibmo.dfs.wallet.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CitrusPrepaidBlockCardRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	private int messageCode;
	private String clientId;
	private String secureCode;
	private String clientTxnId;
	private long requestDateTime;
	private int bankId;
	private int entityId;
	private String customerId;
	private String last4Digits;
	private int urn;
	private String blockType;
	private String reserved1;
	private String reserved2;

}
