package com.wibmo.dfs.wallet.repository;

import java.util.List;

import com.wibmo.dfs.wallet.entity.BankAccounts;

public interface BankAccountsRepository {

	int save(BankAccounts account);
	
	boolean delete(int id, String customerId);
	
	BankAccounts fetchById(int id);
	
	List<BankAccounts> fetchByCustId(String customerId);
	
	List<BankAccounts> fetchByCustIdOrId(String customerId, int id);
	
	BankAccounts fetchByCustIdAndId(String customerId, int id);
}
