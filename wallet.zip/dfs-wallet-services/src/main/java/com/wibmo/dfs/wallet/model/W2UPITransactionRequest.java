package com.wibmo.dfs.wallet.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class W2UPITransactionRequest {
	private int beneficiaryId;
	private String txnType;
	private long txnAmt;
	private int sourceRefId;
	private String vpaName;
}
