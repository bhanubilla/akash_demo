/**
 * 
 */
package com.wibmo.dfs.wallet.bean;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserSubscriptionResponse {
	private int resCode;
	private String resDesc;
	private String errorMessage;
	private List<SubscriptionDetails> data;
}
