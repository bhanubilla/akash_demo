package com.wibmo.dfs.wallet.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.platform.service.notification.NotificationServiceCall;
import com.wibmo.dfs.platform.service.notification.model.NotificationRequest;
import com.wibmo.dfs.wallet.adapter.UpiIntegrationServiceAdapter;
import com.wibmo.dfs.wallet.adapter.response.VpaTxnInfo;
import com.wibmo.dfs.wallet.aero.beans.InitiateUpiCollectResponse;
import com.wibmo.dfs.wallet.bean.InitiateCollectApproveResponse;
import com.wibmo.dfs.wallet.bean.RMAcceptConfirmResponse;
import com.wibmo.dfs.wallet.bean.RMCollectListResponse;
import com.wibmo.dfs.wallet.bean.RMWalletListResponse;
import com.wibmo.dfs.wallet.common.ProgramParamConstants;
import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.entity.RequestMoneyTxnInfo;
import com.wibmo.dfs.wallet.entity.WalletCard;
import com.wibmo.dfs.wallet.helper.PushNotificationHelper;
import com.wibmo.dfs.wallet.kafka.KafkaProducer;
import com.wibmo.dfs.wallet.kafka.model.TxnDetails;
import com.wibmo.dfs.wallet.model.*;
import com.wibmo.dfs.wallet.repository.*;
import com.wibmo.dfs.wallet.util.ApiManagerUtil;
import com.wibmo.dfs.wallet.util.CommonUtil;
import com.wibmo.dfs.wallet.validation.BLValidator;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpHeaders;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import javax.ws.rs.core.MediaType;
import java.net.URI;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.wibmo.dfs.wallet.constants.Constants.X_ACCOUNT_NUMBER;
import static com.wibmo.dfs.wallet.constants.Constants.X_PROGRAM_ID;

@Slf4j
@Service
public class RequestMoneyServiceImpl implements RequestMoneyService {

	private static final String PENDING = "P";

	private static final String ACCEPT = "A";
	public static final String REQUEST_MONEY_TXN_TYPE_TXN_MODE_IS_NOT_VALID = "Request Money Txn Type/Txn Mode is not valid";
	public static final String EXCEPTION = "Exception : ";
	public static final String SUCCESS = "SUCCESS";
	public static final String DECLINE = "DECLINE";
	public static final String REQACCEPT = "ACCEPT";
	public static final String BLOCK = "BLOCK";
	public static final String D_M_YYYY_H_M_S = "d-M-yyyy H:m:s";
	public static final String NUMBER_REGEX = ".*[0-9].*";
	public static final String ALPHABET_REGEX = ".*[A-Z].*";


	@Value("${resource.url.upi}")
	private String upiUrl;

	@Value("${resource.url.notification}")
	private String notificationUrl;

	@Value("${resource.url.onboarding}")
	private String onboardingUrl;

	@Value("${resource.url.txnHistory}")
	private String txnHistoryUrl;

	@Autowired
	private RequestMoneyRepository requestMoneyRepository;

	@Autowired
	private UserAccountInfoRepository userAccountInfoRepository;

	@Autowired
	private WalletCardRepository walletCardRepository;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private ProgramParametersRepository progParamRespository;

	@Autowired
	private WalletServiceFactory findService;

	@Autowired
	private DozerBeanMapper dozerBeanMapper;

	@Autowired
	private ApiManagerUtil apiManagerUtil;

	@Autowired
	private UpiIntegrationServiceAdapter upiIntegrationServiceAdapter;

	@Autowired
	private BlockedMobileNumberDetailsService blockedMobileNumberDetailsService;

	@Autowired
	private KafkaProducer kafkaProducer;

	@Autowired
	private PushNotificationHelper helper;

	@Autowired
	private WalletTxnInfoRepository walletTxnInfoRepository;

	@Autowired
	private RMPendingResponseMapper mapper;

	@Autowired
	private BLValidator blValidator;

	private static final String SUCCESS_MSG = "Got response from UPI Service";
	private static final String FAILURE_MSG = "Failure";
	private static final String EXCEPTION_MSG = "Upi api exception : {}";
	private static final String INTERNAL_ERROR_MSG = "Internal Server Error";

	@Override
	public WibmoResponse processRequestMoney(RMRequest requestMoneyReq, WibmoResponse response, String bankId) {
		try {
			// Do Validation of fields depending on the txn mode
			switch (requestMoneyReq.getTxnMode()) {
				case Constants.W2W:
					RequestMoneyTxnInfo txnInfo = new RequestMoneyTxnInfo();

					// Create wibmoTxnID
					txnInfo.setTxnId(CommonUtil.generateTxnId());

					// Insert into DB by setting value to request money txn info
					txnInfo.setRequsterCustomerId(requestMoneyReq.getRequesterCustomerId());
					txnInfo.setAmount(requestMoneyReq.getAmount());
					txnInfo.setReqType(requestMoneyReq.getTxnMode());
					txnInfo.setRmStatus(PENDING);
					txnInfo.setCreatedDt(new Date());
					txnInfo.setInitiateFrom(requestMoneyReq.getInitiateFrom() != null ? requestMoneyReq.getInitiateFrom() : "RM");
					processWalletToWalletRequestMoney(requestMoneyReq, txnInfo, response, bankId);
					break;
				case Constants.V2V:
					response = processUpiToUpiRequestMoney(requestMoneyReq.getUpiReq(), bankId);
					break;
				case Constants.W2V:
					// make a method call
					break;
				case Constants.V2W:
					// make a method call
					break;
				default:
					response.setResCode(100);
					response.setResDesc(REQUEST_MONEY_TXN_TYPE_TXN_MODE_IS_NOT_VALID);
					break;
			}

		} catch (Exception e) {
			log.error(EXCEPTION + e);
			response.setResCode(500);
			response.setResDesc("Internal Error Server");
		}

		return response;
	}

	private WibmoResponse processWalletToWalletRequestMoney(RMRequest requestMoneyReq, RequestMoneyTxnInfo txnInfo,
															WibmoResponse response, String bankId) {

		log.info("RequestMoneyServiceImpl :: processWalletToWalletRequestMoney : {}, {}", requestMoneyReq, txnInfo);
		txnInfo.setRequsterCustomerId(requestMoneyReq.getRequesterCustomerId());
		CustomerMiniProfile requesteeUserInfo = apiManagerUtil.fetchUserProfile(bankId, null, requestMoneyReq.getRequesteeMobile());
		if (StringUtils.isBlank(requestMoneyReq.getRequesteeCustomerId())) {

			if (requesteeUserInfo != null && requesteeUserInfo.getCustomerId() != null) {
				txnInfo.setRequsteeCustomerId(requesteeUserInfo.getCustomerId());
			} else {
				response.setResCode(150);
				response.setResDesc("User don't have wallet");
				return response;
			}
		} else {
			txnInfo.setRequsteeCustomerId(requestMoneyReq.getRequesteeCustomerId());
		}
		txnInfo.setSourceType(fetchSourceAndDestination(txnInfo.getRequsteeCustomerId(), bankId));
		txnInfo.setDestinationType(fetchSourceAndDestination(txnInfo.getRequsterCustomerId(), bankId));

		int saveToDB = requestMoneyRepository.saveRequestMoney(txnInfo);
		txnInfo.setId(saveToDB);
		WibmoResponse blockedResponse = isUserBlockedPayer(requestMoneyReq.getRequesteeMobile(), bankId, requestMoneyReq.getRequesterCustomerId());
		if(blockedResponse.getResCode() == 200 && null != blockedResponse.getData()){
			log.info("Blocked by {} blocked mobile number {}",requestMoneyReq.getRequesterCustomerId(),requestMoneyReq.getRequesteeMobile());
			txnInfo.setRmStatus("D");
			txnInfo.setRemarks("Auto rejected. Since it is blocked");
			requestMoneyRepository.updateRequestMoneyTxnInfo(txnInfo);
		}
		RequestMoneyTxnInfoModel reqModel = dozerBeanMapper.map(txnInfo, RequestMoneyTxnInfoModel.class);
		if (saveToDB != 0) {
			response.setResCode(200);
			response.setResDesc("Request Money Success");
			response.setData(reqModel);
			//Write a kafka call to insert request money details with txnId()
			// (This txnId will be used to update this entry when user takes an action)
			//
			WalletCard requesteeWalletCard = walletCardRepository.fetchByCustIdAndProduct(reqModel.getRequsteeCustomerId(), Constants.PRODUCT_TYPE_RW, bankId);
			WalletCard requesterWalletCard = walletCardRepository.fetchByCustIdAndProduct(reqModel.getRequsterCustomerId(), Constants.PRODUCT_TYPE_RW, bankId);
			String payeeCard = requesteeWalletCard.getCardNumber();
			String payerCard = requesterWalletCard.getCardNumber();
			W2WTransactionRequest wtr = new W2WTransactionRequest();
			wtr.setCustomerId(Integer.valueOf(txnInfo.getRequsterCustomerId()));
			wtr.setSourceAccount(payeeCard);
			wtr.setDestAccount(payerCard);
			wtr.setPaymentTxnId(txnInfo.getTxnId());
			wtr.setAuthZTxnId(null);
			wtr.setPpTxnId(txnInfo.getTxnId());
			wtr.setTxnType("RM");
			wtr.setTxnCategory("RMC");
			wtr.setPaymentMode("RW");
			wtr.setTxnDesc(getTxnDescription(txnInfo.getRmStatus(),requestMoneyReq,requesteeUserInfo));
			wtr.setTxnAmount(txnInfo.getAmount());
			wtr.setTxnStatus(getTxnStatus(txnInfo.getRmStatus()));
			wtr.setTxnFlow(Constants.TXN_IN_FLOW);
			wtr.setOriginalTxnId(txnInfo.getTxnId());
			wtr.setTxnDate(new Timestamp(System.currentTimeMillis()));
			wtr.setTxnShortDesc(requesteeUserInfo.getFirstName());
			Timestamp txnDate = new Timestamp(new Date().getTime());
			wtr.setTxnDate(txnDate);
			wtr.setMobile(requestMoneyReq.getRequesteeMobile());
			wtr.setRemarks(requestMoneyReq.getRemarks());
			txnDateFormatAndSave(wtr, txnDate);
			prepareTxnHistoryData(wtr, bankId);
			
			CustomerMiniProfile requesterUserProfile = apiManagerUtil.fetchUserProfile(bankId, Integer.toString(wtr.getCustomerId()), null);
			log.info("checking if requested user is blocked user or not");
			WibmoResponse blockedUserDetResp = blockedMobileNumberDetailsService.fetchBlockedMobileNumber(reqModel.getRequsteeCustomerId(), requesterUserProfile.getMobileNo());
			if(blockedUserDetResp.getResCode()== 200 && blockedUserDetResp.getData()==null) {
				//notification alert to send user regarding request money received
	            log.debug("sending notification alert to user regarding W2W requested money initiation");
	            CustomerMiniProfile payeeMinProfile = apiManagerUtil.fetchUserProfile(bankId, txnInfo.getRequsterCustomerId(), null);
	            log.info("payerMinProfile : {}", payeeMinProfile);
	            Map<String, String> placeHolder = new HashMap<>();
				placeHolder.put("XYZ", payeeMinProfile.getFirstName());
				placeHolder.put("AMOUNT", Constants.CURRENCY_IND+CommonUtil.decimalFormat(txnInfo.getAmount()));
	            NotificationRequest aRequest = NotificationRequest.builder()
	    		        .mobileNumber(requesteeUserInfo.getMobileNo())
	    		        .programId(Integer.valueOf(bankId))
	    		        .eventId(Integer.valueOf(Constants.RM_ALERT_EVENT_ID))
	    		        .emailId(requesteeUserInfo.getEmailId())
	    		        .whatsappEnabled(false)
	    		        .placeHolders(placeHolder).build();
	    		NotificationServiceCall notificationServiceCall = new NotificationServiceCall();
	    		notificationServiceCall.send(aRequest, notificationUrl);
	    		
	    		CustomerMiniProfile payerMinProfile = apiManagerUtil.fetchUserProfile(bankId, null, requestMoneyReq.getRequesteeMobile());
				helper.sendPushNotification(bankId, payerMinProfile.getCustomerId(), reqModel.getAmount()+"", payeeMinProfile.getFirstName(), Constants.RECEIVE_MONEY_EVENT_ID, buildPushNotificationData(reqModel), payeeMinProfile.getMobileNo());
			}
    		
		} else {
			response.setResCode(100);
			response.setResDesc("Failed to insert to DB");
		}

		return response;
	}
	private String getTxnDescription(String status, RMRequest requestMoneyReq, CustomerMiniProfile requesteeUserInfo){
		log.info("getTxnDescription :: {}",status);
		if(status.equalsIgnoreCase("D"))
			return Constants.REQUESTED +Constants.RS_SYMBOL +CommonUtil.decimalFormat(requestMoneyReq.getAmount())+" is declined by "+requesteeUserInfo.getFirstName();
		return Constants.REQUESTED +Constants.RS_SYMBOL +CommonUtil.decimalFormat(requestMoneyReq.getAmount())+" to "+requesteeUserInfo.getFirstName();
	}
	private String getTxnStatus(String status){
		log.info("getTxnStatus :: {}",status);
		if(Constants.TXN_STATUS_DECLINE.equalsIgnoreCase(status))
			return Constants.TXN_STATUS_DECLINE;
		return Constants.PENDING;
	}
	private void prepareTxnHistoryData(W2WTransactionRequest wtr, String programId) {
		// insert into txn history
		log.info("RequestMoneyServiceImpl :: prepareTxnHistoryData");

		TxnDetails txnDetails = new TxnDetails();
		txnDetails.setProgramId(programId);
		txnDetails.setTxnType("RMC");
		txnDetails.setData(wtr);



		Runnable runnable = () -> kafkaProducer.publishWalletTxn(txnDetails);
		new Thread(runnable).start();
	}

	private String fetchSourceAndDestination(String customerId, String bankId) {
		WalletCard cardInfo = walletCardRepository.fetchByCustIdAndProduct(customerId, "RW", bankId);
		if (cardInfo != null) {
			return String.valueOf(cardInfo.getId());
		}
		return null;
	}

	private WibmoResponse processUpiToUpiRequestMoney(UpiToUpiRequestMoneyReq requestMoneyReq, String bankId) {

		WibmoResponse response = new WibmoResponse();

		MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
		custHeader.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
		custHeader.add(Constants.X_API_KEY, progParamRespository.fetchParamValueByParamName(bankId,ProgramParamConstants.UPI_API_KEY));
		custHeader.add(Constants.X_AUTH_TOKEN, requestMoneyReq.getToken());

		URI uri = URI.create(upiUrl + progParamRespository.fetchParamValueByParamName(bankId,ProgramParamConstants.UPI_COLLECT_REQUEST_EP));
		HttpEntity<UpiToUpiRequestMoneyReq> httpReq = new HttpEntity<>(requestMoneyReq, custHeader);

		InitiateUpiCollectResponse res = null;
		try {
			res = restTemplate.postForObject(uri, httpReq, InitiateUpiCollectResponse.class);
		} catch (Exception e) {
			log.error(EXCEPTION_MSG, e.getMessage());
		}

		if (null != res) {
			if (res.getRespCode().equalsIgnoreCase("000")) {
				response.setResCode(200);
				response.setResDesc(SUCCESS_MSG);
			} else {
				response.setResCode(100);
				response.setResDesc(FAILURE_MSG);
			}
			response.setData(res);
			return response;
		} else {
			response.setResCode(100);
			response.setResDesc("Account service not responded..");
		}
		return response;

	}

	@Override
	public WibmoResponse fetchRequestMoneyDetails(FetchRMRequest fetchRMRequest, WibmoResponse response, String bankId) {

		FetchRMResponse rmResponse = new FetchRMResponse();

		try {
			rmResponse.setWalletListResponse(fetchRMFromWalletService(fetchRMRequest, bankId));
			rmResponse.setWalletServiceError(false);
		} catch (Exception e) {
			log.error(EXCEPTION + e.getMessage());
			rmResponse.setWalletServiceError(true);
		}

		try {
			RMCollectListResponse res = fetchRMFromUpiService(fetchRMRequest, bankId);
			rmResponse.setUpiServiceError(true);
			if (null != res && res.getRespCode().equalsIgnoreCase("000")) {
				rmResponse.setUpiServiceError(false);
			}
			rmResponse.setCollectListResponse(res);

		} catch (Exception e) {
			rmResponse.setUpiServiceError(true);
		}

		if (rmResponse.isUpiServiceError() && rmResponse.isWalletServiceError()) {
			response.setResCode(100);
			response.setResDesc("Failed To Fetch Pending List");
		} else {
			response.setResCode(200);
			response.setResDesc("Success");
			response.setData(rmResponse);
		}

		return response;
	}

	private List<RMWalletListResponse> fetchRMFromWalletService(FetchRMRequest fetchRMRequest, String programId) {

		List<RMWalletListResponse> walletListRes = new ArrayList<>();

		List<RequestMoneyTxnInfo> txnInfoList = requestMoneyRepository
				.fetchByRequesteeCustomerId(fetchRMRequest.getCustomerId(), PENDING);
		if (txnInfoList != null) {
			log.info("Txn List From Wallet Service");
			RMWalletListResponse rmRes = null;
			for (RequestMoneyTxnInfo txnInfo : txnInfoList) {
				rmRes = new RMWalletListResponse();
				rmRes.setTxnMode(Constants.W2W);
				rmRes.setTxnAmt(txnInfo.getAmount());
				rmRes.setPayeeId(String.valueOf(txnInfo.getId()));
				//MP-7298: bug fix
				try {
					CustomerMiniProfile miniProfile = apiManagerUtil.fetchUserProfile(programId, txnInfo.getRequsterCustomerId(), null);
					rmRes.setPayeeDetails(null != miniProfile ? miniProfile.getMobileNo(): null);
				} catch (Exception e) {
					log.error("exception on fetchCustId :{}, error :{}",txnInfo.getRequsterCustomerId(),e);
				}
				rmRes.setTxnDate(txnInfo.getCreatedDt().getTime());

				walletListRes.add(rmRes);
			}

		}

		return walletListRes;

	}

	private RMCollectListResponse fetchRMFromUpiService(FetchRMRequest fetchRMRequest, String bankId) {

		MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
		custHeader.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
		custHeader.add(Constants.X_API_KEY, progParamRespository.fetchParamValueByParamName(bankId,ProgramParamConstants.UPI_API_KEY));
		custHeader.add(Constants.X_AUTH_TOKEN, fetchRMRequest.getToken());

		URI uri = URI.create(upiUrl + progParamRespository.fetchParamValueByParamName(bankId,ProgramParamConstants.UPI_PENDING_COLLECT_LIST_EP));
		HttpEntity<FetchRMRequest> httpReq = new HttpEntity<>(fetchRMRequest, custHeader);

		RMCollectListResponse res = null;
		try {
			res = restTemplate.postForObject(uri, httpReq, RMCollectListResponse.class);
		} catch (Exception e) {
			log.error(EXCEPTION_MSG, e.getMessage());
			return res;
		}
		return res;
	}

	@Override
	public WibmoResponse acceptRequestMoney(RMAcceptRequest rmAcceptRequest, WibmoResponse response, String bankId) {

		switch (rmAcceptRequest.getTxnMode()) {
			case Constants.W2W:
				acceptWalletToWalletRequestMoney(rmAcceptRequest, response, bankId);
				break;
			case Constants.V2V:
				rmAcceptRequest.getRmUpiAcceptRequest().setApprovalStatus(rmAcceptRequest.getCollectStatus());
				acceptUpiToUpiRequestMoney(rmAcceptRequest.getRmUpiAcceptRequest(), response, rmAcceptRequest.getTxnMode(), bankId);
				break;
			case Constants.W2V:
				// make a method call
				break;
			case Constants.V2W:
				// make a method call
				break;
			default:
				response.setResCode(100);
				response.setResDesc(REQUEST_MONEY_TXN_TYPE_TXN_MODE_IS_NOT_VALID);
				break;
		}

		return response;
	}

	private WibmoResponse acceptWalletToWalletRequestMoney(RMAcceptRequest rmAcceptRequest, WibmoResponse response,
														   String bankId) {

		RMInitResponse initResponse = new RMInitResponse();
		try {
			log.info("rmAcceptRequest.getPayeeId() :: {}", rmAcceptRequest.getPayeeId());
			RequestMoneyTxnInfo txnInfo = requestMoneyRepository.fetchById(rmAcceptRequest.getPayeeId());
			if(txnInfo!=null) {
				ObjectMapper obj = new ObjectMapper();
				String reqJson = obj.writeValueAsString(txnInfo);
				log.debug("txnInfo : {}",reqJson);
			}
			log.info("acceptWalletToWalletRequestMoney : txnInfo : {}", txnInfo);
			if (txnInfo == null) {
				response.setResCode(100);
				response.setResDesc("PayeeId is invalid/Payee details not found");
				return response;
			}
			String eventId = null;
			Map<String, String> placeHolder = new HashMap<>();
			CustomerMiniProfile payerMinProfile = apiManagerUtil.fetchUserProfile(bankId, txnInfo.getRequsteeCustomerId(), null);
			CustomerMiniProfile payeeMinProfile = apiManagerUtil.fetchUserProfile(bankId, txnInfo.getRequsterCustomerId(), null);
			placeHolder.put("PAYER", payerMinProfile.getFirstName());
			placeHolder.put("AMOUNT", Constants.CURRENCY_IND+CommonUtil.decimalFormat(txnInfo.getAmount()));
			if(rmAcceptRequest.getCollectStatus().equalsIgnoreCase("A")) {
				collectReqAccept(rmAcceptRequest, response, bankId, initResponse, txnInfo, placeHolder);
				eventId = Constants.REQ_MONEY_APPROVE_ALERT_EVENT;
				int updateRmTxnInfo = requestMoneyRepository.updateRequestMoneyTxnInfo(txnInfo);
				log.info("Update Request Money Txn Info :" + updateRmTxnInfo);
			} else if(rmAcceptRequest.getCollectStatus().equalsIgnoreCase("R")) {
				txnInfo.setRmStatus("D");
				txnInfo.setRemarks("Rejected by User");
				collectReqReject(txnInfo, response, bankId, placeHolder);
				eventId = Constants.REQ_MONEY_REJECT_ALERT_EVENT;
			}
			log.info("send notification alert to user regarding requested money status");
			sendNotificationAlert(bankId, payeeMinProfile, Integer.parseInt(eventId), placeHolder);
			initResponse.setTxnMode(rmAcceptRequest.getTxnMode());
			response.setData(initResponse);
			///
		} catch (Exception e) {
			log.error(EXCEPTION_MSG + e.getMessage());
			response.setResCode(500);
			response.setResDesc(INTERNAL_ERROR_MSG);
		}

		return response;
	}

	private void collectReqReject(RequestMoneyTxnInfo txnInfo, WibmoResponse response, String bankId, Map<String, String> placeHolder) {
		int cnt = requestMoneyRepository.updateRequestMoneyTxnInfo(txnInfo);
		CustomerMiniProfile payerMinProfile = apiManagerUtil.fetchUserProfile(bankId, txnInfo.getRequsteeCustomerId(), null);
		if(cnt == 1) {
			response.setResCode(200);
			response.setResDesc(SUCCESS);
			sendPushNotification(bankId, txnInfo.getRequsterCustomerId(), txnInfo, payerMinProfile.getFirstName(), placeHolder);
			//kafka call to update RMD status as decline entry using TxnRefNumber
			WalletCard requesteeWalletCard = walletCardRepository.fetchByCustIdAndProduct(txnInfo.getRequsteeCustomerId(), Constants.PRODUCT_TYPE_RW, bankId);
			WalletCard requesterWalletCard = walletCardRepository.fetchByCustIdAndProduct(txnInfo.getRequsterCustomerId(), Constants.PRODUCT_TYPE_RW, bankId);
			String payeeCard = requesteeWalletCard.getCardNumber();
			String payerCard = requesterWalletCard.getCardNumber();//
			String txnDesc = "Requested "+Constants.RS_SYMBOL +CommonUtil.decimalFormat(txnInfo.getAmount())+" to "+payerMinProfile.getFirstName();
	        CreditMoneyTxnDetailsRequest cm = new CreditMoneyTxnDetailsRequest();
	        cm.setSourceAccount(payeeCard);
	        cm.setDestAccount(payerCard);
	        cm.setCustomerId(txnInfo.getRequsterCustomerId());
	        cm.setOriginalTxnId(txnInfo.getTxnId());
	        cm.setTxnCategory("RMC");
	        cm.setTxnStatus("D");
	        cm.setTxnDesc(txnDesc);
	        cm.setTxnAmount(txnInfo.getAmount());
	        cm.setTxnType("RM");
	        cm.setPaymentMode("RW");
	        cm.setTxnDate(new Timestamp(System.currentTimeMillis()));
			log.info("fetching requestee user info");
			CustomerMiniProfile user = apiManagerUtil.fetchUserProfile(bankId, txnInfo.getRequsteeCustomerId(), null);
			if(null != user) {
				cm.setTxnDesc("Requested "+Constants.RS_SYMBOL+CommonUtil.decimalFormat(txnInfo.getAmount())+" is declined by "+user.getFirstName());
				cm.setTxnShortDesc(user.getFirstName());
			}

			cm.setTxnAmount(txnInfo.getAmount());
			cm.setTxnFlow(Constants.TXN_IN_FLOW);
			cm.setOriginalTxnId(txnInfo.getTxnId());
			cm.setMerCategory("Request Declined");
			cm.setTxnDate(new Timestamp(System.currentTimeMillis()));
			log.info("kafka call to prepare transaction history");
			TxnDetails txnDetails = new TxnDetails();
	        txnDetails.setProgramId(bankId);
	        txnDetails.setTxnType(Constants.CREDIT_MONEY_CBS_ONUS);
	        txnDetails.setData(cm);
	        Runnable payeeRunnable = () -> kafkaProducer.publishWalletTxn(txnDetails);
            new Thread(payeeRunnable).start();
		} else {
			response.setResCode(100);
			response.setResDesc("Decline request has some issue");
		}

	}

	private void collectReqAccept(RMAcceptRequest rmAcceptRequest, WibmoResponse response, String bankId, RMInitResponse initResponse, RequestMoneyTxnInfo txnInfo, Map<String, String> placeHolder) {
		// set values to send money pojo
		P2PRequest sendMoney = new P2PRequest();
		sendMoney.setSenderCustomerId(txnInfo.getRequsteeCustomerId());
		sendMoney.setSenderWalletId(rmAcceptRequest.getWalletId());
		sendMoney.setInitiateFrom("RM");
		sendMoney.setRecipientMobileNo(fetchMobileNumberByCustomerId(txnInfo.getRequsterCustomerId(), bankId));
		sendMoney.setAmount(rmAcceptRequest.getTxnAmt());
		sendMoney.setTxnRefNumber(rmAcceptRequest.getTxnRefNumber());

		WalletCard walletCard = walletCardRepository.fetchById(Integer.parseInt(txnInfo.getSourceType()), bankId);
		if (walletCard != null && walletCard.getProductType() != null) {
			sendMoney.setProductType(walletCard.getProductType());
		}

		// make call to send money
		WalletService ws = findService.getService(bankId);
		WibmoResponse res = ws.processP2P(sendMoney);
		if (res == null) {
			txnInfo.setRemarks("Send Money failed or Null response");
			response.setResCode(100);
			response.setResDesc("Send Money failed or Null response");
		} else {
			if (res.getResCode() == 200) {
				txnInfo.setRmStatus(ACCEPT);
				response.setResCode(200);
				response.setResDesc(SUCCESS);
				CustomerMiniProfile payerMinProfile = apiManagerUtil.fetchUserProfile(bankId, txnInfo.getRequsteeCustomerId(), null);
				sendPushNotification(bankId, txnInfo.getRequsterCustomerId(), txnInfo, payerMinProfile.getFirstName(), placeHolder);
				initResponse.setSendMoneyResponse(dozerBeanMapper.map(res.getData(), SendMoneyResponse.class));
				//Need to write kafka call to update RMD status as Accept entry using TxnRefNumber in txn_history table
				WalletCard requesteeWalletCard = walletCardRepository.fetchByCustIdAndProduct(txnInfo.getRequsteeCustomerId(), Constants.PRODUCT_TYPE_RW, bankId);
				WalletCard requesterWalletCard = walletCardRepository.fetchByCustIdAndProduct(txnInfo.getRequsterCustomerId(), Constants.PRODUCT_TYPE_RW, bankId);
				String payeeCard = requesteeWalletCard.getCardNumber();
				String payerCard = requesterWalletCard.getCardNumber();
				prepareTxnHistoryDataForCollectAccept(bankId, payeeCard, payerCard, txnInfo);
			} else {
				response.setResCode(res.getResCode());
				response.setResDesc(res.getResDesc());
			}

			txnInfo.setRemarks(res.getResDesc() + ":" + res.getResCode());
		}
	}

	private void sendNotificationAlert(String bankId, CustomerMiniProfile payeeMinProfile, int eventId, Map<String, String> placeHolder) {
		
		NotificationRequest aRequest = NotificationRequest.builder()
		        .mobileNumber(payeeMinProfile.getMobileNo())
		        .programId(Integer.valueOf(bankId))
		        .eventId(eventId)
		        .emailId(payeeMinProfile.getEmailId())
		        .whatsappEnabled(false)
		        .placeHolders(placeHolder).build();
		NotificationServiceCall notificationServiceCall = new NotificationServiceCall();
		notificationServiceCall.send(aRequest, notificationUrl);
	}

	private WibmoResponse acceptUpiToUpiRequestMoney(RMUpiAcceptRequest rmUpiAcceptRequest, WibmoResponse response,
													 String txnMode, String bankId) {

		RMInitResponse initResponse = new RMInitResponse();
		try {
			MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
			custHeader.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
			custHeader.add(Constants.X_API_KEY, progParamRespository.fetchParamValueByParamName(bankId,ProgramParamConstants.UPI_API_KEY));
			custHeader.add(Constants.X_AUTH_TOKEN, rmUpiAcceptRequest.getToken());

			URI uri = URI
					.create(upiUrl + progParamRespository.fetchParamValueByParamName(bankId,ProgramParamConstants.UPI_COLLECT_APPROVE_INIT_EP));
			HttpEntity<RMUpiAcceptRequest> httpReq = new HttpEntity<>(rmUpiAcceptRequest, custHeader);

			InitiateCollectApproveResponse res = null;

			res = restTemplate.postForObject(uri, httpReq, InitiateCollectApproveResponse.class);

			if (null != res) {
				if ("000".equalsIgnoreCase(res.getRespCode())) {
					response.setResCode(200);
					response.setResDesc(SUCCESS_MSG);
				} else {
					response.setResCode(100);
					response.setResDesc(FAILURE_MSG);
				}
				initResponse.setUpiCollectResponse(res);

			} else {
				response.setResCode(100);
				response.setResDesc("Null Response from UPI Service");
			}
			initResponse.setTxnMode(txnMode);
			response.setData(initResponse);

		} catch (Exception e) {
			log.error(EXCEPTION_MSG, e.getMessage());
			response.setResCode(500);
			response.setResDesc(INTERNAL_ERROR_MSG);
			return response;
		}
		return response;
	}

	private String fetchMobileNumberByCustomerId(String customerId, String programId) {
		CustomerMiniProfile userInfo = apiManagerUtil.fetchUserProfile(programId, customerId, null);
		if (userInfo != null && userInfo.getMobileNo() != null) {
			return userInfo.getMobileNo();
		}
		return null;
	}

	@Override
	public WibmoResponse acceptUpiRequestMoneyConfirm(RMAcceptConfirmRequest rmAcceptConfirmRequest,
													  WibmoResponse response, String bankId) {
		try {
			MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
			custHeader.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
			custHeader.add(Constants.X_API_KEY, progParamRespository.fetchParamValueByParamName(bankId,ProgramParamConstants.UPI_API_KEY));
			custHeader.add(Constants.X_AUTH_TOKEN, rmAcceptConfirmRequest.getToken());

			URI uri = URI.create(
					upiUrl + progParamRespository.fetchParamValueByParamName(bankId,ProgramParamConstants.UPI_COLLECT_APPROVE_CONFIRM_EP));
			HttpEntity<RMAcceptConfirmRequest> httpReq = new HttpEntity<>(rmAcceptConfirmRequest, custHeader);

			RMAcceptConfirmResponse res = null;

			res = restTemplate.postForObject(uri, httpReq, RMAcceptConfirmResponse.class);

			if (null != res) {
				if ("000".equalsIgnoreCase(res.getRespCode())) {
					response.setResCode(200);
					response.setResDesc(SUCCESS_MSG);
				} else {
					response.setResCode(100);
					response.setResDesc(FAILURE_MSG);
				}
				response.setData(res);
			} else {
				response.setResCode(100);
				response.setResDesc("Null Response from UPI Service");
			}

		} catch (Exception e) {
			log.error(EXCEPTION_MSG, e.getMessage());
			response.setResCode(500);
			response.setResDesc(INTERNAL_ERROR_MSG);
			return response;
		}
		return response;
	}

	@Override
	public WibmoResponse incomingCollectRequest(String bankId, String accountId, IncomingCollectRequest incomingCollectRequest) {
		log.info("incomingCollectRequest called for account number :: {}, txnMode :: {}, collectionStatus :: {}", accountId, incomingCollectRequest.getTxnMode(), incomingCollectRequest.getCollectStatus());
		//validate incomingCollectRequest object
		WibmoResponse response = null;
		switch (incomingCollectRequest.getTxnMode().toUpperCase()){
			case "W2W":

				log.info("Calling existing w2w service ");
				RMAcceptRequest rmAcceptRequest = new RMAcceptRequest();
				response = new WibmoResponse();
				isBlocked(bankId,accountId,incomingCollectRequest, response);
				//If not blocked proceed with normal Accept / decline
				if(response.getResCode() != 200) {
					// Default is reject that means Decline
					rmAcceptRequest.setCollectStatus(incomingCollectRequest.getCollectStatus().equals(REQACCEPT) ? "A" : "R");
					rmAcceptRequest.setTxnMode(incomingCollectRequest.getTxnMode());
					rmAcceptRequest.setTxnAmt(incomingCollectRequest.getTxnAmount());
					rmAcceptRequest.setPayeeId(incomingCollectRequest.getTxnRefNumber());
					rmAcceptRequest.setWalletId(Integer.parseInt(incomingCollectRequest.getWalletId()));
					rmAcceptRequest.setTxnRefNumber(incomingCollectRequest.getTxnRefNumber());
					acceptRequestMoney(rmAcceptRequest, response, bankId);
					if (response.getResCode() == 200) {
						log.info("Success w2w action converting RMInitResponse to UpiIncomingCollectResponse");
						UpiIncomingCollectResponse upiICResp = new UpiIncomingCollectResponse();
						try {
							//For ACCEPT We will get data so we will set this data
							RMInitResponse rmInitResponse = RMInitResponse.class.cast(response.getData());
							upiICResp.setTxnDate(rmInitResponse.getSendMoneyResponse().getTxnDate());
							upiICResp.setTxnAmount(String.valueOf(rmInitResponse.getSendMoneyResponse().getAmount()));
							upiICResp.setTxnId(rmInitResponse.getSendMoneyResponse().getTxnId());
						} catch (Exception ex) {
							//For DECLINE We will not get data so we will request date and current timestamp
							log.info("Exception .. : {}", ex);
							upiICResp.setTxnId(incomingCollectRequest.getTxnRefNumber());
							upiICResp.setTxnAmount(String.valueOf(incomingCollectRequest.getTxnAmount()));

						}
						upiICResp.setRemarks(incomingCollectRequest.getRemarks());
						upiICResp.setApprovalStatus(incomingCollectRequest.getCollectStatus());
						upiICResp.setPayeeMobileNumber(incomingCollectRequest.getPayeeMobileNumber());
						upiICResp.setTxnDate(new Date().getTime());//CurrentDate
						response.setData(upiICResp);
					}
				}
				break;
			case "UPI":
				//call upi-integration-service incoming collect request
				log.info("Preparing  UPI service data for incoming request money");
				UpiIncomingCollectResponse upiICReq = new UpiIncomingCollectResponse();
				upiICReq.setRemarks(incomingCollectRequest.getRemarks());
				upiICReq.setCurrency(incomingCollectRequest.getCurrency());
				upiICReq.setApprovalStatus(incomingCollectRequest.getCollectStatus());
				upiICReq.setPayeeVpa(incomingCollectRequest.getPayeeVPA());
				upiICReq.setPayerVpa(incomingCollectRequest.getPayerVPA());
				upiICReq.setTxnId(incomingCollectRequest.getTxnRefNumber());
				upiICReq.setTxnAmount(String.valueOf(incomingCollectRequest.getTxnAmount()));
				upiICReq.setWalletId(incomingCollectRequest.getWalletId());
				response = handleUpiIncomingRequest(bankId, accountId, upiICReq);

				break;
			default:
				log.info("Invalid txnMode found in request :: {} ",incomingCollectRequest.getTxnMode().toUpperCase());
				response = new WibmoResponse();
				response.setResCode(100);
				response.setResDesc("Txn Mode is not valid");
				break;
		}
		return response;
	}
	private WibmoResponse handleUpiIncomingRequest(String bankId, String accountId, UpiIncomingCollectResponse upiICRequest){
		WibmoResponse response = null;
		String approvalStatus = upiICRequest.getApprovalStatus().toUpperCase();
		log.info("user action :: {}",approvalStatus);

		if(approvalStatus.equals(REQACCEPT) || approvalStatus.equals(DECLINE)|| approvalStatus.equals(BLOCK)) {
			log.info("calling upi request");
			response = upiIntegrationServiceAdapter.incomingCollectRequest(bankId, accountId, upiICRequest);
		}else{
			log.info("Invalid user action type :: {}",upiICRequest.getApprovalStatus().toUpperCase());
			response = new WibmoResponse();
			response.setResCode(100);
			response.setResDesc("Txn Mode is not valid");
		}
		return response;
	}

	@Override
	public WibmoResponse initiateRequestMoney(OutgoingCollectRequest request, String bankId, String userId) {
		WibmoResponse response = new WibmoResponse();
		WibmoResponse validationRes = blValidation(request, bankId, userId);
		if(validationRes != null)
			return validationRes;
		try{
			//validate wallet card status
			if(request.getTxnMode().equals("W2W"))
			{
				RMRequest rmRequest = new RMRequest();
				rmRequest.setRequesterCustomerId(userId);
				rmRequest.setAmount((long) Double.parseDouble(request.getTxnAmount()));
				rmRequest.setTxnMode(request.getTxnMode());
				log.info("request.getTxnAmount() :: {}",request.getTxnAmount());
				rmRequest.setRequesteeMobile(request.getPayeeMobileNumber());
				rmRequest.setRemarks(request.getRemarks());
				processRequestMoney(rmRequest, response, bankId);
				if(response.getResCode() == 200) {
					log.info("Converting data ... W2W");
					RequestMoneyTxnInfoModel reqModel = RequestMoneyTxnInfoModel.class.cast(response.getData());
					OutgoingCollectResponse incomingCollectResponse = new OutgoingCollectResponse();
					incomingCollectResponse.setTxnAmount(String.valueOf(reqModel.getAmount()));
					incomingCollectResponse.setTxnRefNum(reqModel.getTxnId());
					incomingCollectResponse.setPayeeMobileNumber(request.getPayeeMobileNumber());
					incomingCollectResponse.setTxnDate(String.valueOf(reqModel.getCreatedDt()));
					response.setData(incomingCollectResponse);
				}
			}
			else if(request.getTxnMode().equals("UPI"))
			{
				log.info("===== It's a UPI RequestMoney ======");
				if(request.getCurrency()==null)
					request.setCurrency(progParamRespository.fetchParamValueByParamName(bankId, ProgramParamConstants.CURRENCY));
				RequestMoneyResponse upiRespose = upiIntegrationServiceAdapter.invokeUPIRequestMoney(request, bankId, userId);
				response.setResCode(upiRespose.getWibmoResCode());
				response.setResDesc(upiRespose.getWibmoResDesc());
				if(upiRespose.getWibmoResCode()==200) {
					log.info("Setting data");
					response.setData(upiRespose);
				}else{
					log.info("Setting error message");
					response.setErrorMessage(upiRespose.getWibmoErrorMessage());
				}

			}else{
				response.setResCode(100);
				response.setResDesc(REQUEST_MONEY_TXN_TYPE_TXN_MODE_IS_NOT_VALID);
			}
		}
		catch (Exception e) {
			log.error(EXCEPTION + e);
			response.setResCode(500);
			response.setResDesc("Internal Error Server");
		}
		return response;
	}
	private WibmoResponse blValidation(OutgoingCollectRequest request, String bankId, String userId){
		WibmoResponse senderWalletStatus = blValidator.validateCardStatus(bankId,userId,100,"RECEIVER - CARD TEMPORARY BLOCK");
		if(senderWalletStatus != null)
			return senderWalletStatus;
		if(request.getTxnMode().equals("W2W"))
		{
			log.info("It is w2w txn so checking payer wallet status :: {}",request.getPayeeMobileNumber());
			CustomerMiniProfile payerMinProfile = apiManagerUtil.fetchUserProfile(bankId, null, request.getPayeeMobileNumber());
			senderWalletStatus = blValidator.validateCardStatus(bankId,payerMinProfile.getCustomerId(),100,"SENDER - CARD TEMPORARY BLOCK");
			return senderWalletStatus;
		}

		return null;
	}
	private WibmoResponse isUserBlockedPayer(String payerMobileNumber, String bankId, String userId) {
		CustomerMiniProfile loggedUserMinProfile = apiManagerUtil.fetchUserProfile(bankId, userId, null);
		log.info("payeeMinProfile.getMobileNo() :: {} {}",loggedUserMinProfile.getMobileNo(), loggedUserMinProfile.getCustomerId());
		CustomerMiniProfile payerMinProfile = apiManagerUtil.fetchUserProfile(bankId, null, payerMobileNumber);
		log.info("payerMinProfile.getMobileNo() :: {} {}",payerMinProfile.getMobileNo() ,payerMinProfile.getCustomerId());
		return blockedMobileNumberDetailsService.fetchBlockedMobileNumber(payerMinProfile.getCustomerId(), loggedUserMinProfile.getMobileNo());

	}

	@Override
	public WibmoResponse fetchRequestMoneyDetails(String userId, WibmoResponse response, String bankId, PendingCollectMoneyRequest pendingCollectMoneyRequest) {

		try {
			List<PendingCollectResponse> totalPendingCollectlist = new ArrayList<>();
			List<PendingCollectResponse> w2wPendingCollectlist = new ArrayList<>();
			String expiredTime = progParamRespository.fetchParamValueByParamName(bankId, ProgramParamConstants.COLLECT_REQ_EXP_MINUTES);
			long expiryTime = Long.parseLong(expiredTime);
			//Fetch W2W pending
			List<RequestMoneyTxnInfo> txnInfoList = requestMoneyRepository
					.fetchByRequesteeCustomerId(userId, PENDING);
			if(txnInfoList != null){
				log.info("W2W has some pending txns..");
				txnInfoList.stream().forEach(txnInfo-> {
					PendingCollectResponse w2wPendingCollectResponse = new PendingCollectResponse();
					w2wPendingCollectResponse.setDesc(txnInfo.getRemarks());
					w2wPendingCollectResponse.setExpiryDate(txnInfo.getCreatedDt().getTime()+(expiryTime * 60 * 1000));//Temporary fix(These no expiry for w2w as now . This is just for UI)
					w2wPendingCollectResponse.setRequestedDate(txnInfo.getCreatedDt().getTime());
					try {
						CustomerMiniProfile miniProfile = apiManagerUtil.fetchUserProfile(bankId, txnInfo.getRequsterCustomerId(), null);
						w2wPendingCollectResponse.setPayeeMobileNumber((null != miniProfile ? miniProfile.getMobileNo(): null));
					} catch (Exception e) {
						log.error("exception on fetchCustId :{}, error :{}",txnInfo.getRequsterCustomerId(),e);
					}
					w2wPendingCollectResponse.setTxnMode("W2W");
					w2wPendingCollectResponse.setTxnAmount(String.valueOf(txnInfo.getAmount()));
					w2wPendingCollectResponse.setTxnRefNumber(String.valueOf(txnInfo.getId()));
					if(!checkExpiredRecord(txnInfo, expiryTime)){
						w2wPendingCollectlist.add(w2wPendingCollectResponse);
					} else {
						txnInfo.setRmStatus(Constants.RM_STATUS_DECLINE);
						txnInfo.setRemarks(Constants.EXPIRED);
						requestMoneyRepository.updateRequestMoneyTxnInfo(txnInfo);
					}
				});
			}
			if(!w2wPendingCollectlist.isEmpty())
				totalPendingCollectlist.addAll(w2wPendingCollectlist);
			//Fetch UPI
			List<PendingCollectResponse> upiPendingCollectlist = upiIntegrationServiceAdapter.pendingCollectRequests(bankId,userId);
			if(upiPendingCollectlist != null && !upiPendingCollectlist.isEmpty())
				totalPendingCollectlist.addAll(upiPendingCollectlist);
			totalPendingCollectlist.sort(Comparator.comparing(PendingCollectResponse::getRequestedDate).reversed());
			response.setResCode(200);
			response.setResDesc(SUCCESS);
			response.setData(totalPendingCollectlist);
			return response;
		}catch (Exception exception){
			log.error("exception while getting pending request money details. {}", exception);
			response.setResCode(100);
			response.setResDesc("Fetch failed");
			return response;
		}
	}

	@Override
	public WibmoResponse fetchQuickPayDetails(String bankId, String userId, QuickPayRequest quickPayRequest) {
		log.debug("UpiServiceImpl : fetchVpaTransaction : userId -{} bankId : {}", userId, bankId);
		WibmoResponse wibmoResponse = new WibmoResponse();
		MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
		custHeader.add(X_PROGRAM_ID, bankId);
		custHeader.add(X_ACCOUNT_NUMBER, userId);
		TxnHistoryRequest request = new TxnHistoryRequest();
		request.setCustomerId(userId);
		HttpEntity<Object> entity = new HttpEntity<>(request, custHeader);
		ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(txnHistoryUrl + "/txnHistory/fetch/v1", HttpMethod.POST,entity,WibmoResponse.class);
		WibmoResponse resp =  responseEntity.getBody();

		List<TxnHistoryResponse> txnHistoryResponseList = Collections.emptyList();
		if (null == resp) {
			log.error("fetch TxnHistoryResponse returns null response");
		} else {
			log.info("fetch TxnHistoryResponse respCode: {}, respDesc:{}", resp.getResCode(), resp.getResDesc());
			if(resp.getResCode() == Constants.SUCCESS_RESPONSE_CODE) {
				txnHistoryResponseList = new ObjectMapper().convertValue(resp.getData(), new TypeReference<List<TxnHistoryResponse>>(){});
			}
		}
		switch (quickPayRequest.getActionType()){
			case "SMRMI":
				setSMRMIResponse(bankId,userId,wibmoResponse,txnHistoryResponseList);
				break;

			case "RMO":
				setRMOResponse(bankId,wibmoResponse,txnHistoryResponseList);
				break;
			default:
				log.info("Unsupported.. action type :: {}",quickPayRequest.getActionType());
		}

		return wibmoResponse;
	}
	private void setRMOResponse(String bankId, WibmoResponse wibmoResponse ,List<TxnHistoryResponse> txnHistoryResponseList){
		String numberOfTxnsAllowed = progParamRespository.fetchParamValueByParamName(bankId, Constants.NUMBER_OF_TXNS_ALLOWED);
		List<TxnHistoryResponse> sortedList = txnHistoryResponseList.stream()
				.filter(txnFlow -> ("I").equals(txnFlow != null ? txnFlow.getTxnFlow() : null))
				.filter(txnType -> ("RM").equals(txnType != null ? txnType.getTxnType() : null))
				.sorted(Comparator.comparingLong(TxnHistoryResponse::getTxnDate).reversed())
				.collect(Collectors.toList());
		List<TxnHistoryResponse> recentRecentTxnList = null;
		if(sortedList.size() > Integer.parseInt(numberOfTxnsAllowed))
			recentRecentTxnList = sortedList.subList(0, Integer.parseInt(numberOfTxnsAllowed));
		else
			recentRecentTxnList = sortedList;

		List<QuickpayResponse> responseList = new ArrayList<>();
		populateRequestMoneyResponse(recentRecentTxnList, responseList);
		wibmoResponse.setResCode(Constants.SUCCESS_RESPONSE_CODE);
		wibmoResponse.setResDesc(Constants.RESPONSE_DESC_SUCCESS);
		wibmoResponse.setData(responseList);
		log.debug("RequestMoneyServiceImpl : fetchQuickPayDetails : response :{}", wibmoResponse);
	}
	private void setSMRMIResponse(String bankId, String userId, WibmoResponse wibmoResponse, List<TxnHistoryResponse> txnHistoryResponseList){
		PendingCollectMoneyRequest pendingCollectMoneyRequest = new PendingCollectMoneyRequest();
		List<PendingCollectResponse> rmPendingCollectlist = null;
		try {
			String numberOfTxnsAllowed = progParamRespository.fetchParamValueByParamName(bankId, Constants.NUMBER_OF_TXNS_ALLOWED);
			WibmoResponse rmResponse = fetchRequestMoneyDetails(userId, wibmoResponse, bankId, pendingCollectMoneyRequest);
			if(rmResponse.getResCode() == Constants.SUCCESS_RESPONSE_CODE) {
				rmPendingCollectlist = new ObjectMapper().convertValue(rmResponse.getData(), new TypeReference<List<PendingCollectResponse>>(){});
			}
			List<TxnHistoryResponse> pendingCollectList = mapper.map(rmPendingCollectlist);

			List<TxnHistoryResponse> quickPayList = Stream.concat(pendingCollectList.stream(), txnHistoryResponseList.stream().filter(txn->
				"O".equals(txn!=null?txn.getTxnFlow():null) && !"LM".equals(txn.getTxnCategory())
			))
					.collect(Collectors.toList());

			List<TxnHistoryResponse> sortedList = quickPayList.stream()
					.sorted(Comparator.comparingLong(TxnHistoryResponse::getTxnDate).reversed())
					.collect(Collectors.toList());
			List<TxnHistoryResponse> recentTxnList = null;
			if(sortedList.size() > Integer.parseInt(numberOfTxnsAllowed))
				recentTxnList = sortedList.subList(0,Integer.parseInt(numberOfTxnsAllowed));
			else
				recentTxnList = sortedList;

			List<QuickpayResponse> responseList = new ArrayList<>();
			populateQuickPayResponse(bankId, recentTxnList, responseList);
			wibmoResponse.setResCode(Constants.SUCCESS_RESPONSE_CODE);
			wibmoResponse.setResDesc(Constants.RESPONSE_DESC_SUCCESS);
			wibmoResponse.setData(responseList);
			log.debug("RequestMoneyServiceImpl : fetchQuickPayDetails : response :{}", wibmoResponse);
		} catch (Exception e) {
			log.error("Exception in fetchQuickPayDetails method :::: {} ", e);
			wibmoResponse.setResCode(100);
			wibmoResponse.setResDesc("Fetch failed");
		}
	}

	private void populateQuickPayResponse(String bankId, List<TxnHistoryResponse> recentFiveTxnList, List<QuickpayResponse> responseList) {

		for (TxnHistoryResponse txns : recentFiveTxnList) {
			try{
				//prepare response
				QuickpayResponse quickpayResponse = new QuickpayResponse();
				log.info("txns.getTxnCategory() :: {}",txns.getTxnCategory());
				switch (txns.getTxnCategory()){
					case "P2PD":
						quickpayResponse.setTxnCategory("SM");
						setTxnTypeForPayTab(txns,quickpayResponse);
						quickpayResponse.setMcc(txns.getMcc());
						quickpayResponse.setTxnReference(txns.getTxnReference());
						quickpayResponse.setRefUrl(txns.getRefUrl());
						quickpayResponse.setRefCategory(txns.getRefCategory());
						quickpayResponse.setPayeeName(txns.getTxnShortDesc());
						quickpayResponse.setDescription(txns.getTxnDesc());
						quickpayResponse.setPayeeMobileNumber(txns.getMobile());
						quickpayResponse.setAmount(txns.getTxnAmount());
						quickpayResponse.setStatus(txns.getTxnStatus());
						quickpayResponse.setTxnDate(txns.getTxnDate());
						break;
					case "W2UPID":
						String txnId = txns.getOriginalTxnId().indexOf("PUO") == 0 ? txns.getOriginalTxnId() : "PUO"+txns.getOriginalTxnId();
						VpaTxnInfo vpaTxnInfo = upiIntegrationServiceAdapter.fetchVpaTxnDetails(bankId,txnId);
						quickpayResponse.setTxnCategory("SM");
						quickpayResponse.setMcc(vpaTxnInfo.getPayeeMcc());
						setTxnTypeForPayTab(txns,quickpayResponse);
						quickpayResponse.setTxnReference(txns.getTxnReference());
						quickpayResponse.setRefUrl(vpaTxnInfo.getRefUrl());
						quickpayResponse.setRefCategory(txns.getRefCategory());
						quickpayResponse.setPayeeName(txns.getTxnShortDesc());
						quickpayResponse.setDescription(vpaTxnInfo.getMessage());
						setTxnTypeForPayTab(txns,quickpayResponse);
						if( vpaTxnInfo != null && (vpaTxnInfo.getTransactionType().equals("INTENT_PAY")||vpaTxnInfo.getTransactionType().equals("SCAN_PAY"))){
							log.info("It is {}",vpaTxnInfo.getTransactionType());
							quickpayResponse.setTxnType(vpaTxnInfo.getTransactionType());
						}
						quickpayResponse.setAmount(txns.getTxnAmount());
						quickpayResponse.setTxnDate(txns.getTxnDate());
						setW2UPIDDestinationDetails(bankId,quickpayResponse,txns);
						quickpayResponse.setStatus(txns.getTxnStatus());
						quickpayResponse.setTxnDate(txns.getTxnDate());
						break;
					case ("RMD"),("RM"):
						setRMDdetails(quickpayResponse,txns);
						break;
					default:
						log.info("UNKNOWN category :: {}",txns.getTxnCategory());
				}
				responseList.add(quickpayResponse);
			}catch (Exception ex){
				log.error("Exception while preparing quick pay response :: {}",ex);
			}

		}
	}

	private void setW2UPIDDestinationDetails(String bankId,QuickpayResponse quickpayResponse, TxnHistoryResponse txns){
		if(txns.getDestAccount().contains(".ifsc.npci")){
			String maskPattern = "";
			maskPattern = progParamRespository
					.fetchParamValueByParamName(bankId, ProgramParamConstants.CARD_MASK_PATTERN);
			quickpayResponse.setBeneficiaryAccountNumber(txns.getDestAccount().substring(0,txns.getDestAccount().indexOf("@")));
			quickpayResponse.setIfsc(txns.getDestAccount().substring(txns.getDestAccount().indexOf("@")+1, txns.getDestAccount().indexOf(".")));
			quickpayResponse.setBeneficiaryMaskedAccountNumber(CommonUtil.maskCardNumberWOPlaceHolder(quickpayResponse.getBeneficiaryAccountNumber(), maskPattern));
		}else{
			quickpayResponse.setPayeeVpa(txns.getDestAccount());
		}
	}

	private void setRMDdetails(QuickpayResponse quickpayResponse, TxnHistoryResponse txns){
		if(txns.getTxnStatus().equalsIgnoreCase("S")){
			log.info("Success RM");
			if(txns.getDestAccount() != null && txns.getDestAccount().contains("@")) {
				log.info("Destination is having vpa");
				quickpayResponse.setTxnType("W2UPI");
				quickpayResponse.setAmount(txns.getTxnAmount());
				quickpayResponse.setStatus(txns.getTxnStatus());
				quickpayResponse.setTxnCategory("SM");
				quickpayResponse.setPayeeVpa(txns.getDestAccount());
				quickpayResponse.setPayeeName(txns.getTxnShortDesc());
				quickpayResponse.setMcc(txns.getMcc());
				quickpayResponse.setTxnDate(txns.getTxnDate());
			}else{
				log.info("treating it as w2w request money");
				quickpayResponse.setTxnType("W2W");
				quickpayResponse.setAmount(txns.getTxnAmount());
				quickpayResponse.setStatus(txns.getTxnStatus());
				quickpayResponse.setTxnCategory("SM");
				quickpayResponse.setPayeeMobileNumber(txns.getMobile());
				quickpayResponse.setPayeeName(txns.getTxnShortDesc());
				quickpayResponse.setTxnDate(txns.getTxnDate());
			}
		}else{
			log.info("Request Money pending state....");
			if(txns.getDestAccount() != null && txns.getDestAccount().contains("@")) {
				quickpayResponse.setTxnType("UPI");
				quickpayResponse.setAmount(txns.getTxnAmount());
				quickpayResponse.setStatus(txns.getTxnStatus());
				quickpayResponse.setTxnCategory("RM");
				quickpayResponse.setPayeeVpa(txns.getDestAccount());
				quickpayResponse.setPayerVpa(txns.getSourceAccount());
				quickpayResponse.setPayeeName(txns.getTxnShortDesc());
				quickpayResponse.setTxnReference(txns.getTxnRefNumber());
				quickpayResponse.setTxnDate(txns.getTxnDate());
				quickpayResponse.setMcc(txns.getMcc());
			}else{
				quickpayResponse.setTxnType("W2W");
				quickpayResponse.setAmount(txns.getTxnAmount());
				quickpayResponse.setStatus(txns.getTxnStatus());
				quickpayResponse.setTxnCategory("RM");
				quickpayResponse.setPayeeMobileNumber(txns.getMobile());
				quickpayResponse.setTxnReference(txns.getTxnRefNumber());
				quickpayResponse.setPayeeName(txns.getTxnShortDesc());
				quickpayResponse.setTxnDate(txns.getTxnDate());
				quickpayResponse.setMcc(txns.getMcc());
			}
		}
	}

	private void populateRequestMoneyResponse(List<TxnHistoryResponse> recentFiveTxnList, List<QuickpayResponse> responseList) {

		for (TxnHistoryResponse txns : recentFiveTxnList) {
			try{
				//prepare response
				QuickpayResponse quickpayResponse = new QuickpayResponse();
				if (txns.getTxnCategory().equals("RMC")) {
					quickpayResponse.setTxnCategory("RM");
					setTxnTypeForRMTab(txns,quickpayResponse);
				}
				quickpayResponse.setPayerVpa(txns.getSourceAccount());
				quickpayResponse.setPayerMobileNumber(txns.getMobile());
				quickpayResponse.setPayeeName(txns.getTxnShortDesc());
				quickpayResponse.setStatus(txns.getTxnStatus());
				quickpayResponse.setAmount(txns.getTxnAmount());
				quickpayResponse.setDescription(txns.getTxnDesc());
				quickpayResponse.setTxnDate(txns.getTxnDate());
				responseList.add(quickpayResponse);
			}catch (Exception ex){
				log.error("Exception while preparing quickPay response :: {}",ex);
			}
		}
	}
	private void setTxnTypeForRMTab(TxnHistoryResponse txns, QuickpayResponse quickpayResponse){
		if(txns.getDestAccount()!=null && txns.getDestAccount().contains("@payu")){
			log.info("setting txn type as UPI");
			quickpayResponse.setTxnType("UPI");
		}else if(txns.getDestAccount().contains("ifsc.npci")){
			log.info("setting txn type as W2A");
			quickpayResponse.setTxnType("W2A");
		}else{
			log.info("setting txn type as W2W");
			quickpayResponse.setTxnType("W2W");
		}
	}
	private void setTxnTypeForPayTab(TxnHistoryResponse txns, QuickpayResponse quickpayResponse){
		if (txns.getDestAccount()!=null && txns.getDestAccount().contains("ifsc.npci"))
			quickpayResponse.setTxnType("W2A");
		else if(txns.getDestAccount()!=null && txns.getDestAccount().contains("@")){
			quickpayResponse.setTxnType("W2UPI");
		}else
			quickpayResponse.setTxnType("W2W");
	}

	private void isBlocked(String bankId,String accountId, IncomingCollectRequest incomingCollectRequest, WibmoResponse response){
		try {
			if(incomingCollectRequest.getCollectStatus().equals(BLOCK)){
				log.info("user is trying to block this mobile number :: {}",incomingCollectRequest.getPayeeMobileNumber());
				BlockedMobileDetailsReq blockedMobileDetailsReq = new BlockedMobileDetailsReq();
				blockedMobileDetailsReq.setAccountNumber(accountId);
				blockedMobileDetailsReq.setBlockedMobileNumber(incomingCollectRequest.getPayeeMobileNumber());
				WibmoResponse blockedResponse = blockedMobileNumberDetailsService.block(bankId,blockedMobileDetailsReq);
				if (blockedResponse.getResCode() == 200 ){
					log.info("Blocked successfully ... {}",blockedResponse.getData());
					log.info("blocked this mobile :: {} for account number :: {}, hence we are going to decline the all pending transaction ",incomingCollectRequest.getPayeeMobileNumber(),accountId);
					CustomerMiniProfile payeeMinProfile = apiManagerUtil.fetchUserProfile(bankId, null, incomingCollectRequest.getPayeeMobileNumber());
					if(payeeMinProfile!=null) {
						List<RequestMoneyTxnInfo> listOfPending = requestMoneyRepository.fetchBlockedUserPendingList(payeeMinProfile.getCustomerId(), accountId, "P");
						listOfPending.stream().forEach(txnInfo -> {
							txnInfo.setRmStatus("D");
							txnInfo.setRemarks("Auto rejected. Since it is blocked");
							try {
								requestMoneyRepository.updateRequestMoneyTxnInfo(txnInfo);
							} catch (Exception exception) {
								log.error("Exception while updating TxnId:: {}", txnInfo.getTxnId(), exception);
							}

						});
					}
					UpiIncomingCollectResponse upiICResp = new UpiIncomingCollectResponse();
					setPayeeName(payeeMinProfile, upiICResp);

					upiICResp.setTxnDate(new Date().getTime());
					upiICResp.setTxnAmount(String.valueOf(incomingCollectRequest.getTxnAmount()));
					upiICResp.setTxnId(incomingCollectRequest.getTxnRefNumber());
					upiICResp.setApprovalStatus(incomingCollectRequest.getCollectStatus());
					upiICResp.setPayeeMobileNumber(incomingCollectRequest.getPayeeMobileNumber());
					response.setResCode(200);
					response.setResDesc(SUCCESS);
					response.setData(upiICResp);
				}
			}
		}catch (Exception exception){
			log.info("Exception :: {}",exception);
		}
	}

	/**
	 * check record is expired or not
	 * @param requestMoneyTxnInfo
	 * @param expiryTimeInMin
	 * @return
	 */
	private boolean checkExpiredRecord(RequestMoneyTxnInfo requestMoneyTxnInfo, long expiryTimeInMin) {
		boolean flag = false;
		long timeInMillis = new Timestamp(new Date().getTime()).getTime();
		long timeDifferenceInMillis = timeInMillis - requestMoneyTxnInfo.getCreatedDt().getTime();
		long expiryTimeInMillis = expiryTimeInMin * 60 * 1000;
		long timeDiffInSeconds = TimeUnit.MILLISECONDS.toSeconds(timeDifferenceInMillis);
		long expiryInSeconds = TimeUnit.MILLISECONDS.toSeconds(expiryTimeInMillis);
		if (timeDiffInSeconds > expiryInSeconds) {
			flag = Boolean.TRUE;
		}
		return flag;
	}

	public void sendPushNotification(String programId, String accountNumber, RequestMoneyTxnInfo request, String payerName, Map<String, String> placeHolder){
		UserProfileResponse userProfileResponse = null;
		log.debug(" UpiServiceImpl : sendPushNotification : programId :{} , accountNumber : {}, request : {}, payerName :: {}", programId, accountNumber, request,payerName);
		try{
			MultiValueMap<String, String> userProfileDetailsHeader = new LinkedMultiValueMap<>();
			userProfileDetailsHeader.add("Content-Type", String.valueOf(org.springframework.http.MediaType.APPLICATION_JSON));
			userProfileDetailsHeader.add("X-PROGRAM-ID", programId);
			userProfileDetailsHeader.add("X-ACCOUNT-NUMBER", accountNumber);
			HttpEntity<String> entity = new HttpEntity<>(userProfileDetailsHeader);
			ResponseEntity<UserProfileResponse> result = this.restTemplate.exchange(onboardingUrl + "/onboarding/userProfile/fetchUserProfileDetails/v1", HttpMethod.GET, entity, UserProfileResponse.class);
			userProfileResponse = result.getBody();
			if ( userProfileResponse != null) {
				AlertRequest alertRequest = new AlertRequest();
				if(request.getRmStatus().equals(ACCEPT))
					alertRequest.setEventId(Integer.parseInt(Constants.RM_ACCEPT_EVENT_ID));
				else
					alertRequest.setEventId(Integer.parseInt(Constants.RM_REJECT_EVENT_ID));
				alertRequest.setFcmToken(userProfileResponse.getFcmId());
				alertRequest.setAccountNumber(Long.parseLong(accountNumber));
				alertRequest.setDeviceId(userProfileResponse.getDeviceId());
				alertRequest.setWhatsappEnabled(false);
				alertRequest.setPlaceHolders(placeHolder);
				callToNotificationSendAlert(programId, alertRequest);
			}
		}
		catch (Exception ex) {
			log.error("Issue while fetching userProfileDetails " + ex.getMessage());
		}
	}

	private void callToNotificationSendAlert(String programId, AlertRequest alertRequest) {
		try {
			MultiValueMap<String, String> customNotificationHeader = new LinkedMultiValueMap<>();
			customNotificationHeader.add("Content-Type", String.valueOf(org.springframework.http.MediaType.APPLICATION_JSON));
			customNotificationHeader.add("X-PROGRAM-ID", programId);
			HttpEntity<Object> notificationEntity = new HttpEntity<>(alertRequest, customNotificationHeader);
			ResponseEntity<WibmoResponse> resp = this.restTemplate.exchange(notificationUrl + "/notification-service/notification/sendAlert", HttpMethod.POST, notificationEntity, WibmoResponse.class);
			WibmoResponse wibmoResponse = resp.getBody();
			if (resp.getStatusCodeValue() != 200 && wibmoResponse!=null) {
				log.debug("Notification sending failed: {}", (wibmoResponse).getErrorMessage());
			}
		} catch (Exception var6) {
			log.error("Issue while sending notification " + var6.getMessage());
		}
	}

	private PushNotificationData buildPushNotificationData(RequestMoneyTxnInfoModel reqModel) {
		PushNotificationData data = new PushNotificationData();
		try {
			data.setTxnRefNumber(String.valueOf(reqModel.getId()));
			data.setTxnMode("W2W");
		} catch (Exception e) {
			log.error("Exception while buildPushNotificationData : {}", e);
		}
		return data;
	}

	private void prepareTxnHistoryDataForCollectAccept(String programId, String payeeCard, String payerCard, RequestMoneyTxnInfo txnInfo) {
		log.info("RequestMoneyServiceImpl : prepareTxnHistoryDataForCollectAccept : {}", txnInfo);
		// updating the existing record in txn history
		log.info("RequestMoneyServiceImpl :: prepareTxnHistoryDataForCollectAccept : {}");
		CreditMoneyTxnDetailsRequest cm = new CreditMoneyTxnDetailsRequest();
		cm.setCustomerId(txnInfo.getRequsteeCustomerId());
		cm.setSourceAccount(payeeCard);
		cm.setDestAccount(payerCard);
		cm.setTxnType("RM");
		cm.setTxnCategory("RMC");
		cm.setPaymentMode("RW");
		log.info("fetching requestee user info");
		CustomerMiniProfile user = apiManagerUtil.fetchUserProfile(programId, txnInfo.getRequsteeCustomerId(), null);
		if (null != user) {
			cm.setTxnDesc("Recieved amount " + Constants.RS_SYMBOL + CommonUtil.decimalFormat(txnInfo.getAmount()) + " from " + user.getFirstName());
			cm.setTxnShortDesc(user.getFirstName());
		}

		cm.setTxnAmount(txnInfo.getAmount());
		cm.setTxnStatus("S");
		cm.setMerCategory("Request Accepted");
		cm.setTxnFlow(Constants.TXN_IN_FLOW);
		cm.setOriginalTxnId(txnInfo.getTxnId());
		cm.setTxnDate(new Timestamp(System.currentTimeMillis()));
		log.info("kafka call to prepare transaction history");
		TxnDetails txnDetails = new TxnDetails();
		txnDetails.setProgramId(programId);
		txnDetails.setTxnType(Constants.CREDIT_MONEY_CBS_ONUS);
		txnDetails.setData(cm);
		Runnable payeeRunnable = () -> kafkaProducer.publishWalletTxn(txnDetails);
		new Thread(payeeRunnable).start();
	}

	private void setPayeeName(CustomerMiniProfile payeeMinProfile, UpiIncomingCollectResponse upiICResp) {
		if(payeeMinProfile !=null)
			upiICResp.setPayeeName(payeeMinProfile.getFirstName()+" "+(payeeMinProfile.getLastName()!=null? payeeMinProfile.getLastName():""));
	}

	/**
	 * saving txnDateStr in w2wTxn request pojo
	 * @param wtr
	 * @param txnDate
	 */
	private void txnDateFormatAndSave(W2WTransactionRequest wtr, Timestamp txnDate) {
		log.info("RequestMoneyServiceImpl : txnDateFormatAndSave request: {} txnDate: {}", wtr, txnDate);
		SimpleDateFormat formatter = new SimpleDateFormat(D_M_YYYY_H_M_S);
		String txnDateString = formatter.format(txnDate);
		wtr.setTxnDateStr(txnDateString);
	}

	public static boolean checkPayeeIdHasAlphabet(String txnId) {
		String number = NUMBER_REGEX;
		String alphabet = ALPHABET_REGEX;
		return txnId.matches(number) && txnId.matches(alphabet);
	}
}

