package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ComplaintDetails {

	private String complaintID;
	private String status;
	private String wibmoTxnID;
	private String billerType;
	private String paymentType;
	private String rcReferenceId;
	private String createdDate;

}