package com.wibmo.dfs.wallet.model;

import java.util.List;

import com.wibmo.dfs.wallet.entity.UserLinkedCardInfo;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FetchLinkedCardsResponse {
	
	private List<UserLinkedCardInfo> linkedCards;
}
