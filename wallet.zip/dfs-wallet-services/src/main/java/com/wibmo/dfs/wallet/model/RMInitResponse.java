package com.wibmo.dfs.wallet.model;

import com.wibmo.dfs.wallet.bean.InitiateCollectApproveResponse;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RMInitResponse {

	private String txnMode;
	private SendMoneyResponse sendMoneyResponse;
	private InitiateCollectApproveResponse upiCollectResponse;
}
