package com.wibmo.dfs.wallet.aero.beans;

import java.io.Serializable;

/**
 * 
 * @author meriyala.raghavendra
 *
 */
public class CreateCardResponse extends AeroResponse implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private StringBuilder cardNumber=new StringBuilder(20);
    private StringBuilder cardExpiry=new StringBuilder();
    private StringBuilder cardCVV2=new StringBuilder();
    private int cardProfileId;
    private long loadAmount;
    private long availableBalance;
    private long availableCashLimit;

    public long getLoginProfId() {
        return loginProfId;
    }

    public void setLoginProfId(long loginProfId) {
        this.loginProfId = loginProfId;
    }

    private long loginProfId;

    public StringBuilder getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(StringBuilder cardNumber) {
        this.cardNumber=cardNumber;
    }

    public StringBuilder getCardExpiry() {
        return cardExpiry;
    }

    public void setCardExpiry(StringBuilder cardExpiry) {
        this.cardExpiry=cardExpiry;
    }

    public StringBuilder getCardCVV2() {
        return cardCVV2;
    }

    public void setCardCVV2(StringBuilder cardCVV2) {
        this.cardCVV2=cardCVV2;
    }

   public void clearCardExpiry() {        
        this.cardExpiry.setLength(0);
        this.cardExpiry.append("000000");
        this.cardExpiry.setLength(0);
        this.cardExpiry.trimToSize();
    }
    
    public void clearCardCvv2() {
        if (this.cardCVV2 != null) {
            this.cardCVV2.setLength(0);
            this.cardCVV2.append("000000");
            this.cardCVV2.setLength(0);
            this.cardCVV2.trimToSize();
        }
    }
    
     public void clearCardNumber() {        
        this.cardNumber.setLength(0);
        this.cardNumber.append("00000000000000000000");
        this.cardNumber.setLength(0);
        this.cardNumber.trimToSize();
    }
    
    public void clearCreateCardResponse() {
        this.clearCardNumber();
        this.clearCardExpiry();
        this.clearCardCvv2();
    }   

    public int getCardProfileId() {
        return cardProfileId;
    }

    public void setCardProfileId(int cardProfileId) {
        this.cardProfileId = cardProfileId;
    }

    public long getLoadAmount() {
        return loadAmount;
    }

    public void setLoadAmount(long loadAmount) {
        this.loadAmount = loadAmount;
    }

    public long getAvailableBalance() {
        return availableBalance;
    }

    public void setAvailableBalance(long availableBalance) {
        this.availableBalance = availableBalance;
    }

    public long getAvailableCashLimit() {
        return availableCashLimit;
    }

    public void setAvailableCashLimit(long availableCashLimit) {
        this.availableCashLimit = availableCashLimit;
    }

}
