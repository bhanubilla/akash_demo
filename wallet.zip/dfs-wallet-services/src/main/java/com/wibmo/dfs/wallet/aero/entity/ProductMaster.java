package com.wibmo.dfs.wallet.aero.entity;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ProductMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	private String bankId;
	private String productType;
	private String productId;
	private String productName;
	
}
