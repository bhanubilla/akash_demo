/**
 * 
 */
package com.wibmo.dfs.wallet.repository;

import java.sql.PreparedStatement;
import java.sql.Statement;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.wibmo.dfs.wallet.entity.FetchTxnDetails;
import com.wibmo.dfs.wallet.entity.WalletTxnInfo;
import com.wibmo.dfs.wallet.util.CommonUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * @author rajasekhar.kaniti
 *
 */
@Repository
@Slf4j
public class WalletTxnInfoRepositoryImpl implements WalletTxnInfoRepository {
	
	private static final String WALLET_INFO_INSERT_QUERY = "INSERT INTO WALLET_TXN_INFO (TXN_ID,USER_ID,WALLET_ID,ORIGINAL_TXN_ID,"
			+"TXN_TYPE,AMOUNT,STATUS,STATUS_DESC,COMMENTS,IF_IMPL_ID,OF_IMPL_ID,CMS_REFERENCE,MERCHANT_ID,PP_TXN_ID)"
			+" VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	
	private static final String WALLET_INFO_UPDATE_QUERY = "UPDATE WALLET_TXN_INFO SET"
			+" STATUS =?, STATUS_DESC =?,CMS_REFERENCE=?,COMMENTS=? WHERE ID =?;";
	
	private static final String FETCH_DATA_BY_TXN_ID = "SELECT USER_ID, TXN_TYPE, COMMENTS FROM WALLET_TXN_INFO where date(CREATED_DT) between ? and ? and TXN_ID =?";
	
	private static final String MONTH_PARAMS = "from month : {}, to month : {}";

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	/*
	 * This method will save data into wallet_txn_info tables
	 * 
	 * @param walletTxnInfo
	 * 
	 * @return int
	 */
	@Override
	public int save(WalletTxnInfo walletTxnInfo) {
		KeyHolder keyHolder = new GeneratedKeyHolder();

		jdbcTemplate.update(connection -> {
			PreparedStatement ps = connection.prepareStatement(WALLET_INFO_INSERT_QUERY, Statement.RETURN_GENERATED_KEYS);
			int i=1;
		
			ps.setString(i++, walletTxnInfo.getTxnId());
			ps.setString(i++, walletTxnInfo.getUserId());
			ps.setLong(i++, walletTxnInfo.getWalletId());
			ps.setString(i++, walletTxnInfo.getOriginalTxnId());
			ps.setString(i++, walletTxnInfo.getTxnType());
			ps.setLong(i++, walletTxnInfo.getAmount());
			ps.setInt(i++, walletTxnInfo.getStatus());
			ps.setString(i++, walletTxnInfo.getStatusDesc());
			ps.setString(i++, walletTxnInfo.getComments());
			if(StringUtils.isNotEmpty(walletTxnInfo.getInflowImplId())) {
				ps.setString(i++, walletTxnInfo.getInflowImplId());
			}else {
				ps.setObject(i++, null);
			}
			if(walletTxnInfo.getOutflowImplId() >0) {
				ps.setInt(i++, walletTxnInfo.getOutflowImplId());
			}else {
				ps.setObject(i++, null);
			}
			ps.setString(i++, walletTxnInfo.getCmsRef());
			ps.setString(i++, walletTxnInfo.getMerchantId());
			ps.setString(i++, walletTxnInfo.getPpTxnId());
			return ps;
		}, keyHolder);

		Number value =keyHolder.getKey();
		return null != value ? value.intValue():0;
	}
	
	/*
	 * This method will update data into wallet_txn_info tables based on the wallet id
	 * 
	 * @param walletTxnInfo
	 * 
	 * @return int
	 */
	@Override
	public int update(WalletTxnInfo walletTxnInfo) {
        
		return jdbcTemplate.update(connection -> {
			PreparedStatement ps = connection.prepareStatement(WALLET_INFO_UPDATE_QUERY, Statement.RETURN_GENERATED_KEYS);
			int i=1;
		
			ps.setInt(i++, walletTxnInfo.getStatus());
			ps.setString(i++, walletTxnInfo.getStatusDesc());
			ps.setString(i++, walletTxnInfo.getCmsRef());
			ps.setString(i++, walletTxnInfo.getComments());
			ps.setInt(i++, walletTxnInfo.getId());
			
			return ps;
		});

		
	}

	@Override
	public FetchTxnDetails fetchTxnInfoByTxnId(String txnId) {
		BeanPropertyRowMapper<FetchTxnDetails> rowMapper = BeanPropertyRowMapper.newInstance(FetchTxnDetails.class);
        rowMapper.setPrimitivesDefaultedForNullValue(true);
        int endDt = CommonUtil.lastDayOfMonth(Integer.valueOf(txnId.substring(0, 4)), Integer.valueOf(txnId.substring(4, 6))-1, Integer.valueOf(txnId.substring(6,8)));
        String fromMonth = txnId.substring(0, 4) + "-" + txnId.substring(4, 6) + "-01";
        String toMonth = txnId.substring(0, 4) + "-" + txnId.substring(4, 6) + "-"+ endDt;
        log.debug(MONTH_PARAMS,fromMonth, toMonth);
        return jdbcTemplate.queryForObject(FETCH_DATA_BY_TXN_ID, rowMapper,fromMonth, toMonth, txnId);
	}

}
