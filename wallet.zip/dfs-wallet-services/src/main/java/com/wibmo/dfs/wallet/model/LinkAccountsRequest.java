package com.wibmo.dfs.wallet.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class LinkAccountsRequest {
	@ApiModelProperty(required = false, dataType="String", hidden = true)
	private String customerId;
	
	@ApiModelProperty(required = true, dataType="String", example="ac", notes="possible value is either ac,lc,wc or all")
	private String category;
	
	@ApiModelProperty(required = true, dataType="String", notes="if category value is ac")
	private BankAccountsInfo accounts;
	
	@ApiModelProperty(required = true, dataType="String", notes="if category value is lc")
	private LinkedCardInfo linkedCardInfo;
}
