package com.wibmo.dfs.wallet.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserProfile {
	@ApiModelProperty(required = true, dataType="String")
	private String firstName;
	
	@ApiModelProperty(required = false, dataType="String")
	private String middleName;
	
	@ApiModelProperty(required = false, dataType="String")
	private String lastName;
	
	@ApiModelProperty(required = false, dataType="String", hidden = true)
	private String mobile;
	
	@ApiModelProperty(required = true, dataType="String")
	private String email;
	
	@ApiModelProperty(required = true, dataType="String", example="12-10-2020")
	private String dob;
	
	@ApiModelProperty(required = true, dataType="String", example="M")
	private String gender;
}
