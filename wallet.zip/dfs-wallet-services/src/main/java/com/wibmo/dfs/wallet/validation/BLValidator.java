package com.wibmo.dfs.wallet.validation;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.model.FetchCardResponse;
import com.wibmo.dfs.wallet.model.FetchWalletsRequest;
import com.wibmo.dfs.wallet.model.WibmoResponse;
import com.wibmo.dfs.wallet.service.AccountsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Component
@Slf4j
public class BLValidator {
    @Autowired
    AccountsService accountsService;

    public WibmoResponse validateCardStatus(String bankId, String userId,int errorCode,String errorResponseDesc){
        WibmoResponse response = null;
        FetchWalletsRequest fetchWalletsRequest = new FetchWalletsRequest();
        fetchWalletsRequest.setCustomerId(userId);
        WibmoResponse senderCardDetails = accountsService.fetchWallets(fetchWalletsRequest, bankId);
        if(senderCardDetails != null && senderCardDetails.getResCode() == 200){
            log.info("Card details are fetched for userId :: {}",userId);
            ObjectMapper objectMapper = new ObjectMapper();
            FetchCardResponse[] senderCards= objectMapper.convertValue(senderCardDetails.getData(),FetchCardResponse[].class);
            FetchCardResponse senderRwCard = Arrays.stream(senderCards).filter(c-> c.getProductType().equals(Constants.PRODUCT_TYPE_RW)).findFirst().get();
            if(senderRwCard.getWalletStatus().equalsIgnoreCase("Temp Blocked")) {
                log.info("Card is temp blocked for userId :: {}",userId);
                response = new WibmoResponse();
                response.setResCode(errorCode);
                response.setResDesc(errorResponseDesc);
                return response;
            }
        }
        return response;
    }
}
