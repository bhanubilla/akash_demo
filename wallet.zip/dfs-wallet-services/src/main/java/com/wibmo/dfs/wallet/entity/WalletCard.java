package com.wibmo.dfs.wallet.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class WalletCard implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;
	private String customerId;
	private String kycLevel;
	private String cardNumber;
	private String expiryMm;
	private String expiryYyyy;
	private String cardType;
	private String productType;
	private String bankUrn;
	private int ppBankId;
	private String cmsRefNo;
	private boolean debitAllowed;
	private boolean creditAllowed;
	private String reasonCode;
	private Timestamp createdDate;
	private Timestamp updatedDate;
	private String walletCardType;
	private String hostCustomerId;
}
