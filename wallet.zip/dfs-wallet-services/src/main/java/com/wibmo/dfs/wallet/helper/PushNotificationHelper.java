package com.wibmo.dfs.wallet.helper;

import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.model.AlertRequest;
import com.wibmo.dfs.wallet.model.PushNotificationData;
import com.wibmo.dfs.wallet.model.UserProfileResponse;
import com.wibmo.dfs.wallet.model.WibmoResponse;
import com.wibmo.dfs.wallet.repository.ProgramParametersRepository;
import com.wibmo.dfs.wallet.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Component
public class PushNotificationHelper {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private ProgramParametersRepository progParamDao;

    @Value("${resource.url.onboarding}")
    private String onboardingUrl;

    @Value("${resource.url.notification}")
    private String notificationUrl;

    public void sendPushNotification(String programId, String accountNumber, String amount, String name, String eventId, PushNotificationData pushNotificationData, String mobileNumber) {
        UserProfileResponse userProfileResponse = null;
        log.debug(" UpiServiceImpl : sendPushNotification : programId :{} , accountNumber : {}, name : {} amount :{} eventId : {}", programId, accountNumber, name, amount,  eventId);
        try {
            MultiValueMap<String, String> userProfileDetailsHeader = new LinkedMultiValueMap<>();
            userProfileDetailsHeader.add("Content-Type", String.valueOf(MediaType.APPLICATION_JSON));
            userProfileDetailsHeader.add("X-PROGRAM-ID", programId);
            userProfileDetailsHeader.add("X-ACCOUNT-NUMBER", accountNumber);
            HttpEntity<String> entity = new HttpEntity<>(userProfileDetailsHeader);
            ResponseEntity<UserProfileResponse> result = this.restTemplate.exchange(onboardingUrl + "/onboarding/userProfile/fetchUserProfileDetails/v1", HttpMethod.GET, entity, UserProfileResponse.class);
            userProfileResponse = result.getBody();
            if (userProfileResponse != null) {
                String programParams = progParamDao.fetchParamValueByParamName(programId, Constants.COLLECT_REQ_EXP_MINUTES);
                long expiryTimeInMin = Long.parseLong(programParams);
                Timestamp createTimeStamp = new Timestamp( new Date().getTime());

                Map<String, String> placeHolder = new HashMap<>();
                placeHolder.put("XYZ", name);
                placeHolder.put("AMOUNT", Constants.CURRENCY_IND+CommonUtil.decimalFormat(Long.parseLong(amount)));
                placeHolder.put("txnRefNumber", pushNotificationData.getTxnRefNumber());
                placeHolder.put("payeeName", name);
                placeHolder.put("txnMode", pushNotificationData.getTxnMode());
                placeHolder.put("txnAmount", amount);
                placeHolder.put("requestedDate", String.valueOf(createTimeStamp.getTime()));
                placeHolder.put("expiryDate",String.valueOf(createTimeStamp.getTime() + (expiryTimeInMin * 60 * 1000)));
                placeHolder.put("desc", "PushNotification");
                placeHolder.put("payeeMobileNumber", mobileNumber);
                placeHolder.put("actionCode", "1");
                AlertRequest alertRequest = new AlertRequest();
                alertRequest.setEventId(Integer.parseInt(eventId));
                alertRequest.setFcmToken(userProfileResponse.getFcmId());
                alertRequest.setAccountNumber(Long.parseLong(accountNumber));
                alertRequest.setDeviceId(userProfileResponse.getDeviceId());
                alertRequest.setWhatsappEnabled(false);
                alertRequest.setPlaceHolders(placeHolder);
                callToNotificationSendAlert(programId, alertRequest);
            }
        } catch (Exception ex) {
            log.error("Issue while fetching sendPushNotification : {} ", ex);
        }

    }

    private void callToNotificationSendAlert(String programId, AlertRequest alertRequest) {
        try {
            MultiValueMap<String, String> customNotificationHeader = new LinkedMultiValueMap<>();
            customNotificationHeader.add("Content-Type", String.valueOf(MediaType.APPLICATION_JSON));
            customNotificationHeader.add("X-PROGRAM-ID", programId);
            HttpEntity<Object> notificationEntity = new HttpEntity<>(alertRequest, customNotificationHeader);
            ResponseEntity<WibmoResponse> resp = this.restTemplate.exchange(notificationUrl + "/notification-service/notification/sendAlert", HttpMethod.POST, notificationEntity, WibmoResponse.class);
           WibmoResponse res = resp.getBody();
            if (res !=null && resp.getStatusCodeValue() != 200) {
                log.debug("Notification sending failed: {}", res.getErrorMessage());
            }
        } catch (Exception var6) {
            log.error("Issue while sending callToNotificationSendAlert : {}", var6);
        }
    }
}
