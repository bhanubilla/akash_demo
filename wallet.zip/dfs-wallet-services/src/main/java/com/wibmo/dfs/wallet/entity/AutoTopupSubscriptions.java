package com.wibmo.dfs.wallet.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
public class AutoTopupSubscriptions  implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private long id;
	private long walletId;
	private String customerId;
	private String cardNumber;
	private String merchantRefId;
	private String wibmoTxnId;
	private String remarks;
	private int thresholdAmt;
	private long topupAmt;
	private String status;
	private String subDesc;
	private int retryCount;
	private String refundStatus;
	private long paymentRefId;
	private Timestamp createdTime;
	private Timestamp updatedTime;
	
}
