package com.wibmo.dfs.wallet.listener;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.platform.fw.multitenantconfig.ThreadLocalStorage;
import com.wibmo.dfs.wallet.entity.AuditStatement;
import com.wibmo.dfs.wallet.service.WalletStatementService;
import lombok.extern.slf4j.Slf4j;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class KafkaConsumer {

	@Autowired
	private DozerBeanMapper mapper;

	@Autowired
	private WalletStatementService walletStatementService;

    @Value("${kafka.topicName.statusUpdate}")
	private String topicName;


	@KafkaListener(topics = "${kafka.topicName.statusUpdate}", groupId = "test-wallet-consumer", containerFactory = "kafkaStatementUpdateListenerContainerFactory")
	public void consumeTxnDetailsJson(String notificationStatus) {
		log.info("Consumed JSON Message: {}", notificationStatus);
		AuditStatement auditStatus = null;
		try {
			auditStatus = new ObjectMapper().readValue(notificationStatus, AuditStatement.class);
		} catch (Exception e) {
			log.error("Mapping Exception :{}", e.toString());
		}
		if (null != notificationStatus) {
			try {
				// Temp solution until other pods complete multitenancy
				if (auditStatus != null) {
					int programId = auditStatus.getProgramId();
					ThreadLocalStorage.setTenantId(programId);
					walletStatementService.updateAudit(auditStatus.getProgramId(), auditStatus.getCustomerId(), auditStatus.getStatus(), auditStatus.getUpdatedDate(), auditStatus.getWalletStatementId());
				}
			} finally {
				ThreadLocalStorage.clear();
			}

		}

	}
}
