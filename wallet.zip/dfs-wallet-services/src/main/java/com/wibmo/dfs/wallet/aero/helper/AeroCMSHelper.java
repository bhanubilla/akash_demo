package com.wibmo.dfs.wallet.aero.helper;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Random;

import com.wibmo.dfs.wallet.aero.beans.*;
import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.model.*;
import org.apache.commons.lang.StringUtils;


import com.google.gson.GsonBuilder;
import com.wibmo.dfs.wallet.aero.constants.AeroConstants;
import com.wibmo.dfs.wallet.aero.entity.AeroCMSConf;
import com.wibmo.dfs.wallet.aero.entity.ProductMaster;
import com.wibmo.dfs.wallet.common.Currency;
import com.wibmo.dfs.wallet.constants.CardTypes;
import com.wibmo.dfs.wallet.entity.AuditApiReq;
import com.wibmo.dfs.wallet.entity.PrepaidBankMapping;
import com.wibmo.dfs.wallet.entity.UserAccountInfo;
import com.wibmo.dfs.wallet.entity.WalletCard;
import com.wibmo.dfs.wallet.entity.WalletTxnInfo;
import com.wibmo.dfs.wallet.util.CommonUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AeroCMSHelper {
	private static final String YYYY_M_MDDHHMMSS = "yyyyMMddhhmmss";
	public static final String RIGHT = "right";


	private AeroCMSHelper() {}


	/**
	 * 
	 * @param createCard
	 * @param cmsConfig
	 * @param productConfig
	 * @param cardCardRequest
	 * @return
	 */
	public static CreateCardRequest prepareCreateCardRequest(CreateCard createCard,
                                                             AeroCMSConf cmsConfig, ProductMaster productConfig, CreateCardRequest cardCardRequest) {
		log.info("AeroCMSHelper -  prepareCreateCardRequest ...");
		var yyyyMMddhhmmss = new SimpleDateFormat(YYYY_M_MDDHHMMSS);
		populateCommon(cardCardRequest, yyyyMMddhhmmss, cmsConfig);
		cardCardRequest.setProductId(productConfig.getProductId());
		cardCardRequest.setMessageCode(AeroConstants.REQUEST_CREATE_CARD);

	    String txnId = generateUniqueTxnId(AeroConstants.REQUEST_CREATE_CARD);
		cardCardRequest.setClientTxnId(txnId);

		String sourceAccount = cmsConfig.getSourceAccount();
		String sourceAccountType = cmsConfig.getSourceAccountType();

		cardCardRequest.setLoadAmount(createCard.getLoadAmt());
		cardCardRequest.setCustomerId(createCard.getUser().getAccount().getCustomerId());
		// segregate kyc & profile.
		String kycLevel = createCard.getUser().getAccount().getKycLevel();
		cardCardRequest.setCardProfileId(convertToKYCLevel(kycLevel));

		cardCardRequest.setSourceAccount(sourceAccount);
		cardCardRequest.setSourceAccountType(sourceAccountType);
		
		String cardHolderAddress = createCard.getUser().getAddress().getAddressLine();

		UserProfile up = createCard.getUser().getProfile();
		String mobileInfo = up.getMobile();
		String emailInfo = up.getEmail();
		var ch = composeCardHolder(up.getDob(), up.getFirstName(), up.getMiddleName(), up.getLastName(), cardHolderAddress);

		if (mobileInfo != null) {
			ch.setCardholderMobile(mobileInfo);
		}
		if (emailInfo != null) {
			ch.setCardholderEmail(emailInfo);
		}
		String gender = up.getGender();		
		ch.setCardholderGender(gender);			
		cardCardRequest.setCardHolder(ch);
		
		return cardCardRequest;
	}

	public static String convertToKYCLevel(String kycLevel){
		if(kycLevel==null || kycLevel.equals("100")) {
			log.info("mapping to 150");
			log.info("kyclevel : {}", kycLevel );
			return "150";
		} else if (kycLevel.equals("30")){
			log.info("mapping to 200");
			log.info("kyclevel : {}", kycLevel );
			 return "200";
		} else {
			log.info("unknown kyc level: {}", kycLevel);
			return kycLevel;
		}
	}

	public static CardHolder composeCardHolder(String dob, String firstName, String middleName, String lastName, String address) {

		if (firstName == null) {
			firstName = "";
		}

		if (middleName == null) {
			middleName = "";
		}

		if (lastName == null) {
			lastName = "";
		}

		var cardHolder = new CardHolder();
		// DOB in Wibmo is in YYYYMMDD format, prepaid wants in DD-MM-YYYY
		if (dob != null) {
			cardHolder.setCardholderDateOfBirth(dob);
		}

		if ((firstName.length() + middleName.length()) <= 49) {
			cardHolder.setCardholderFirstName(firstName + " " + middleName);
		} else if (firstName.length() <= 50) {
			cardHolder.setCardholderFirstName(firstName);
		} else {
			cardHolder.setCardholderFirstName(firstName.substring(0, 50));
		}

		if (lastName.length() <= 50) {
			cardHolder.setCardholderLastName(lastName);
		} else {
			cardHolder.setCardholderLastName(lastName.substring(0, 50));
		}
		
		cardHolder.setCardholderAddress(address);
		return cardHolder;
	}

	/**
	 * @param response
	 * @param cardInquiryResponse
	 */
	public static void prepareCMSResponse(CMSResponse response, CardInquiryResponse cardInquiryResponse) {
		var cd = new CardDetail();
		populateCardNumber(cardInquiryResponse, cd);
		if (cardInquiryResponse.getCardExpiry() != null && cardInquiryResponse.getCardExpiry().length() > 0) {
			cd.setExpiryMM(new StringBuilder(cardInquiryResponse.getCardExpiry().substring(0, 2)));
			cd.setExpiryYYYY(
					new StringBuilder(CommonUtil.getYYYYfromYY(cardInquiryResponse.getCardExpiry().substring(2))));
		}
		if (cardInquiryResponse.getCardCVV2() != null && cardInquiryResponse.getCardCVV2().length() > 0) {
			cd.setCvv2(new StringBuilder(cardInquiryResponse.getCardCVV2()));
		}

		var cardStatus = 0;
		var statusDesc = "";

		try {
			cardStatus = Integer.parseInt(cardInquiryResponse.getCardStatus());
		} catch (Exception ex) {
			log.warn("Error parsing card status :{0}" + cardInquiryResponse.getCardStatus(), ex);
		}

		cd.setStatus(cardStatus);
		populateStatusDesc(cd, cardStatus, statusDesc);

		var cardHolder = cardInquiryResponse.getCardHolder();
		// profile data
		if (null != cardHolder) {
			cd.setProfileId(
					cardHolder.getCardProfileId() != null ? Integer.parseInt(cardHolder.getCardProfileId()) : 0);
			cd.setFirstName(cardHolder.getCardholderFirstName());
			cd.setLastName(cardHolder.getCardholderLastName());
			cd.setDob(cardHolder.getCardholderDateOfBirth());
			cd.setMobile(cardHolder.getCardholderMobile());
			cd.setEmail(cardHolder.getCardholderEmail());
		}
		response.setCardDetail(cd);

		List<CardTransactionProfile> cardServList = new ArrayList<>();

		if (cardInquiryResponse.getCardTransactionProfile() != null
				&& !cardInquiryResponse.getCardTransactionProfile().isEmpty()) {
			List<CardTransactionProfile> cardTxnProfile = cardInquiryResponse.getCardTransactionProfile();
			populateServiceTypes(response, cardServList, cardTxnProfile);
			response.setCardTransactionProfile(cardServList);

		} else {
			log.info("cardTransactionProfileResponse was null, Hence val setting to null");
			response.setCardTransactionProfile(null);
		}
	}

	private static void populateServiceTypes(CMSResponse response, List<CardTransactionProfile> cardServList, List<CardTransactionProfile> cardTxnProfile) {
		for (int i = 0; i < cardTxnProfile.size(); i++) {
			var cardTransactionProfile = cardTxnProfile.get(i);

			cardTransactionProfile.setTransactionProfileId(cardTransactionProfile.getTransactionProfileId());
			cardTransactionProfile.setTransactionType(cardTransactionProfile.getTransactionType());
			cardTransactionProfile.setTransactionRegionName(cardTransactionProfile.getTransactionRegionName());
			cardTransactionProfile.setStatus(cardTransactionProfile.isStatus());
			if(!cardTransactionProfile.isStatus()) response.getCardDetail().setStatusDesc("BLOCKED");
			cardServList.add(cardTransactionProfile);

		}
	}

	private static void populateStatusDesc(CardDetail cd, int cardStatus, String statusDesc) {
		switch (cardStatus) {
		case AeroConstants.CARD_STATUS_ACTIVE:
			statusDesc = "Active";
			break;
		case AeroConstants.CARD_STATUS_CUSTOM_BLOCKED:
			statusDesc = "User Blocked";
			break;
		case AeroConstants.CARD_STATUS_PERMANENT_BLOCKED:
			statusDesc = "Blocked";
			break;
		case AeroConstants.CARD_STATUS_TEMP_BLOCKED:
			statusDesc = "Temp Blocked";
			break;
		default:
			log.info("Unknown status code {0}", cardStatus);
			break;
		}
		cd.setStatusDesc(statusDesc);
	}


	private static void populateCardNumber(CardInquiryResponse cardInquiryResponse, CardDetail cd) {
		if (cardInquiryResponse.getCardNumber() != null && cardInquiryResponse.getCardNumber().length() > 0) {
			cd.setCardnumber(new StringBuilder(cardInquiryResponse.getCardNumber()));
		}
	}

	/**
	 * @param wibmoTxnId
	 * @param cardNumber
	 * @param wc
	 * @param cmsConfig
	 * @param cardInquiryRequest
	 * @return
	 */
	public static CardInquiryRequest prepareCardInquiryReq(String wibmoTxnId,
                                                           String cardNumber, WalletCard wc, AeroCMSConf cmsConfig, CardInquiryRequest cardInquiryRequest) {
		SimpleDateFormat yyyyMMddhhmmss = new SimpleDateFormat(YYYY_M_MDDHHMMSS);
		if (wibmoTxnId == null) {
			wibmoTxnId = generateUniqueTxnId(AeroConstants.REQUEST_CARD_INQUIRY);
		}

		populateCommon(cardInquiryRequest, yyyyMMddhhmmss, cmsConfig);
		cardInquiryRequest.setMessageCode(AeroConstants.REQUEST_CARD_INQUIRY);
		cardInquiryRequest.setClientTxnId(wibmoTxnId);
		if (cardNumber != null && cardNumber.length() > 0) {
			cardInquiryRequest.setLast4Digits(cardNumber.substring(cardNumber.length() - 4));
		}
		cardInquiryRequest.setUrn(wc.getBankUrn());
		cardInquiryRequest.setCustomerId(wc.getCustomerId());
		cardInquiryRequest.setBankId(cmsConfig.getPpBankCode());
		return cardInquiryRequest;
	}

	public static String generateRequestTime(SimpleDateFormat sdf) {
		return sdf.format(new Date());
	}

	public static AeroRequest populateCommon(AeroRequest request, SimpleDateFormat sdfFormat, AeroCMSConf cmsConfig) {
		request.setClientId(cmsConfig.getClientId());
		request.setSecureCode(cmsConfig.getSecureCode());
		request.setRequestDateTime(generateRequestTime(sdfFormat));
		request.setBankId(cmsConfig.getPpBankCode());
		request.setEntityId(cmsConfig.getEntityId());
		return request;
	}

	public static String generateUniqueTxnId(String messageCode) {
		return new StringBuilder().append(messageCode).append("-").append(java.util.UUID.randomUUID().toString())
				.toString();
	}

	/**
	 * @param auditStatus
	 * @param auditId
	 * @return
	 */
	public static AuditApiReq updateAuditReq(int auditId, String auditStatus, String remarks) {
		var updateReq = new AuditApiReq();

		updateReq.setId(auditId);
		updateReq.setReqStatus(auditStatus);
		updateReq.setRemarks(remarks);
		return updateReq;
	}

	/**
	 * @param createCard
	 * @param auditReq
	 */
	public static void setAuditReq(CreateCard createCard, AuditApiReq auditReq) {
		auditReq.setReqFor("Card Creation");
		var gson = new GsonBuilder().create();
		String json = gson.toJson(createCard);
		auditReq.setReqBody(json);
	}

	/**
	 * @param createCard
	 * @param card
	 * @param info
	 */
	public static void setUserInfo(CreateCard createCard, WalletCard card, UserAccountInfo info) {
		info.setCustomerId(card.getCustomerId());
		info.setMobile(createCard.getUser().getProfile().getMobile());
		log.debug("user info, customer Id: {}, kyclevel:{}",card.getCustomerId(),createCard.getUser().getAccount().getKycLevel());
		info.setKycLevel(Integer.parseInt(createCard.getUser().getAccount().getKycLevel()));
	}

	public static void prepareResponse(CreateCard createCard, CardDetails cardDetail, WalletCard card) {
		cardDetail.setCustomerId(card.getCustomerId());
		cardDetail.setMobile(createCard.getUser().getProfile().getMobile());
		cardDetail.setWalletId(card.getId());
		cardDetail.setWalletCardType(card.getWalletCardType());
		if(!card.getWalletCardType().equals("CLOSED_LOOP")) {
			cardDetail.setCardNumber(card.getCardNumber());
			cardDetail.setCardExpiry(card.getExpiryMm().concat(card.getExpiryYyyy()));
		}
		StringBuilder name =new StringBuilder(StringUtils.trim(createCard.getUser().getProfile().getFirstName()));
		if(!StringUtils.isBlank(createCard.getUser().getProfile().getMiddleName())) name.append(" ").append(createCard.getUser().getProfile().getMiddleName());
		if(!StringUtils.isBlank(createCard.getUser().getProfile().getLastName())) name.append(" ").append(createCard.getUser().getProfile().getLastName());
		cardDetail.setName(name.toString());
	}

	public static void setCardDetails(CreateCardResponse createCardResponse, AeroCMSConf cmsConfig,
			ProductMaster productConfig, WalletCard card) {
		card.setCustomerId(createCardResponse.getCustomerId());
		card.setKycLevel(String.valueOf(createCardResponse.getCardProfileId()));
		card.setCardNumber(createCardResponse.getCardNumber().toString());
		card.setExpiryMm(createCardResponse.getCardExpiry().toString().substring(0, 2));
		card.setExpiryYyyy(CommonUtil.getYYYYfromYY(createCardResponse.getCardExpiry().toString().substring(2)));
		card.setCardType(CardTypes.VISA.getType());
		card.setProductType(productConfig.getProductType());
		card.setBankUrn(String.valueOf(createCardResponse.getUrn()));
		card.setPpBankId(cmsConfig.getPpBankId());
		card.setCmsRefNo(createCardResponse.getAccosaRefNo());
		card.setDebitAllowed(true);
		card.setCreditAllowed(true);
	}

	/**
	 * @param cardResp
	 * @param response
	 * @param cardInquiryResponse
	 * @param wc
	 */
	public static void prepareFetchCardResp(FetchCardResponse cardResp, CMSResponse response,
                                            CardInquiryResponse cardInquiryResponse, WalletCard wc) {
		var cd = response.getCardDetail();
		cardResp.setWalletStatus(cd.getStatusDesc());
		cardResp.setBalance(cardInquiryResponse.getAvailableBalance());
		cardResp.setWalletCardType(wc.getWalletCardType());
		cardResp.setCardNumber(cd.getCardnumber().toString());
		cardResp.setCardExpiry(cd.getExpiryMM().toString().concat(cd.getExpiryYYYY().toString()));
		cardResp.setWalletId(wc.getId());
		cardResp.setCustomerId(wc.getCustomerId());
		cardResp.setMobile(cd.getMobile());
		cardResp.setProductType(wc.getProductType());
		cardResp.setKycLevel(Integer.valueOf(cardInquiryResponse.getCardHolder().getCardProfileId()));
		var name =new StringBuilder(StringUtils.trim(cd.getFirstName()));
		if(!StringUtils.isBlank(cd.getLastName())) name.append(" ").append(cd.getLastName());
		cardResp.setName(name.toString());

		List<ServiceTypes> serviceList = new ArrayList<>();
		List<CardTransactionProfile> ctpList = response.getCardTransactionProfile();
		if (null != ctpList) {
			for (CardTransactionProfile ctp : ctpList) {
				var type = new ServiceTypes();
				type.setStatus(ctp.isStatus());
				type.setType(ctp.getTransactionType());
				serviceList.add(type);
			}
		}
		cardResp.setTxnProfile(serviceList);
	}

	/**
	 *
	 * @param fundRequest
	 * @param txnAuditReq
	 */
	public static void setWalletTxnAuditReq(FundRequest fundRequest, AuditApiReq txnAuditReq)  {
		txnAuditReq.setReqFor("Funds Load/Unload");
		var gson = new GsonBuilder().create();
		String json = gson.toJson(fundRequest);
		txnAuditReq.setReqBody(json);
	}

	/**
	 * @param loadUnloadRes
	 * @return string
	 */
	public static String convertToJson(LoadUnloadResponse loadUnloadRes) {
		var gson = new GsonBuilder().create();
		return gson.toJson(loadUnloadRes);
	}

	public static WalletTxnInfo prepareWalletInfo(long amount, WalletCard cardDetails) {
		// setting data into walletTxnInfo
		var walletTxnInfo = new WalletTxnInfo();
		walletTxnInfo.setUserId(cardDetails.getCustomerId());
		walletTxnInfo.setAmount(amount);
		walletTxnInfo.setWalletId(cardDetails.getId());
		walletTxnInfo.setTxnId(CommonUtil.generateTxnId());
		walletTxnInfo.setOriginalTxnId(walletTxnInfo.getTxnId());

		return walletTxnInfo;
	}

	public static LoadUnloadRequest populateCommon(LoadUnloadRequest request, SimpleDateFormat sdfFormat,
                                                   AeroCMSConf cmsConfig) {
		request.setClientId(cmsConfig.getClientId());
		request.setSecureCode(cmsConfig.getSecureCode());
		request.setRequestDateTime(CommonUtil.generateRequestTime(sdfFormat));
		request.setBankId(cmsConfig.getPpBankCode());
		request.setEntityId(cmsConfig.getEntityId());
		request.setSourceAccount(cmsConfig.getSourceAccount());
		request.setSourceAccountType(cmsConfig.getSourceAccountType());
		return request;
	}

	public static void prepareFetchCardStatus(FetchCardStatusResponse cardResp, CMSResponse response,
			 WalletCard wc) {
		CardDetail cd = response.getCardDetail();
		cardResp.setStatusDesc(cd.getStatusDesc());
		cardResp.setStatus(cd.getStatus());
		cardResp.setWalletId(wc.getId());
		cardResp.setCustomerId(wc.getCustomerId());
	}

	public static void prepareFetchCardBalance(FetchCardBalanceResponse cardResp,
			CardInquiryResponse cardInquiryResponse, WalletCard wc) {
		cardResp.setBalance(cardInquiryResponse.getAvailableBalance());
		cardResp.setWalletId(wc.getId());
		cardResp.setCustomerId(wc.getCustomerId());
		cardResp.setKycLevel(Integer.valueOf(cardInquiryResponse.getCardHolder().getCardProfileId()));
		cardResp.setProductType(wc.getProductType());
		cardResp.setMobile(cardInquiryResponse.getCardHolder().getCardholderMobile());
	}

	public static void prepareFetchCardCVV(FetchCardCVVResponse cardResp,
			CardInquiryResponse cardInquiryResponse, WalletCard wc) {
		cardResp.setCvv(cardInquiryResponse.getCardCVV2().toString());
		cardResp.setWalletId(wc.getId());
		cardResp.setCustomerId(wc.getCustomerId());
	}

	/**
	 *
	 * @param sendMoneyReq
	 * @param txnAuditReq
	 */
	public static void setWalletTxnAuditReq(SendMoneyRequest sendMoneyReq, AuditApiReq txnAuditReq){
		txnAuditReq.setReqFor(sendMoneyReq.getInitiateFrom() != null ? "RM" : "P2P");
		var gson = new GsonBuilder().create();
		String json = gson.toJson(sendMoneyReq);
		txnAuditReq.setReqBody(json);
	}	
	
	
	/**
	 * @param fundTransRes
	 * @return string
	 */
	public static String convertSendMoneyResponseToJson(FundTransferResponse fundTransRes) {
		var gson = new GsonBuilder().create();
		return gson.toJson(fundTransRes);
	}	
		
	/**	 
	 * This method is used for prepare CMS Transaction History Request
	 * 
	 * @param mapping
	 * @param wibmoTxnId
	 * @param cardDetails
	 * @param cmsConfig
	 * @param txnHistoryReq
	 * @param cmsTxnHistoryReq
	 * @param noOfMonth
	 * @return transactionHistoryRequest
	 */
	public static TransactionHistoryRequest prepareTxnHistoryRequest(PrepaidBankMapping mapping, String wibmoTxnId,
			WalletCard cardDetails, AeroCMSConf cmsConfig, FetchTransactionHistoryRequest txnHistoryReq, TransactionHistoryRequest cmsTxnHistoryReq, int noOfMonth) {
		log.info("execute prepareTxnHistoryRequest");
		SimpleDateFormat dateFormat = new SimpleDateFormat(YYYY_M_MDDHHMMSS);
		if (wibmoTxnId == null) {
			wibmoTxnId = generateUniqueTxnId(AeroConstants.REQUEST_STATEMENT_INQUIRY);
		}

		populateCommon(cmsTxnHistoryReq, dateFormat, cmsConfig);
		cmsTxnHistoryReq.setMessageCode(AeroConstants.REQUEST_STATEMENT_INQUIRY);
		cmsTxnHistoryReq.setClientTxnId(wibmoTxnId);				
		if (cardDetails.getCardNumber() != null && cardDetails.getCardNumber().length() > 0) {
			cmsTxnHistoryReq.setLast4Digits(cardDetails.getCardNumber().substring(cardDetails.getCardNumber().length() - 4));
		}
		cmsTxnHistoryReq.setUrn(cardDetails.getBankUrn());
		cmsTxnHistoryReq.setCustomerId(cardDetails.getCustomerId());
		cmsTxnHistoryReq.setBankId(mapping.getBankId());
	
		String fromDate = null;
		String toDate = null;	
		if(null != txnHistoryReq.getFromDay() && null != txnHistoryReq.getFromMonth() && null != txnHistoryReq.getFromYear()
				&& null != txnHistoryReq.getToDay() && null != txnHistoryReq.getToMonth() && null != txnHistoryReq.getToYear()) {
			fromDate = dateFormatter( txnHistoryReq.getFromDay(), txnHistoryReq.getFromMonth(), txnHistoryReq.getFromYear());
            toDate = dateFormatter(txnHistoryReq.getToDay(), txnHistoryReq.getToMonth(), txnHistoryReq.getToYear());			
		}else {
			var currentDate = Calendar.getInstance().getTime(); 
			String curDateStr = dateFormat.format(currentDate);	 
            try {	                
                var calendar = Calendar.getInstance();	              
                calendar.setTime(currentDate);            
                calendar.add(Calendar.MONTH, noOfMonth);
                var fewMonthBackDate = calendar.getTime();      
	            
	            
	            var fromDay = dateFormat.format(fewMonthBackDate).substring(6, 8);	     
	            var fromMonth = dateFormat.format(fewMonthBackDate).substring(4, 6);	            
	            var fromYear = dateFormat.format(fewMonthBackDate).substring(0,4);     
	           
	            var toDay = curDateStr.substring(6, 8);
	            var toMonth = curDateStr.substring(4, 6);
	            var toYear = curDateStr.substring(0, 4);
	            
	            fromDate = dateFormatter(fromDay, fromMonth, fromYear);
	            toDate = dateFormatter(toDay, toMonth, toYear);        
				 
            } catch (Exception e) {
                log.error("bad format of day, month and year, Error:{}", e);	                    
            }
	                
		}
		cmsTxnHistoryReq.setFromDate(fromDate);
		cmsTxnHistoryReq.setToDate(toDate);
		cmsTxnHistoryReq.setOpenAuthSettleCreditsRequired(false);
		log.debug("retun prepareTxnHistoryRequest");
		return cmsTxnHistoryReq;
	}
	
	/**
	 * This method is used for prepare Transaction History Response
	 * @param wibmoResponse
	 * @param cmsTxnHistoryRes
	 * @param cardDetails
	 * @param currency
	 */
	public static void prepareTxnHistoryResponse(WibmoResponse wibmoResponse, TransactionHistoryResponse cmsTxnHistoryRes, WalletCard cardDetails, Currency currency) {
		log.info("execute prepareTxnHistoryResponse");
		var txnHistoryRes = new FetchTransactionHistoryResponse();
		List<TransactionHistory> txnHistoryList = new ArrayList<>();	
		StatementDetails details = null;
		TransactionHistory txnHistory = null;
		
		txnHistoryRes.setCustomerId(cmsTxnHistoryRes.getCustomerId());
		txnHistoryRes.setRefNumber(cmsTxnHistoryRes.getClientTxnId());
		txnHistoryRes.setWalletId(cardDetails.getId()); 
		txnHistoryRes.setCount(cmsTxnHistoryRes.getCount());
		txnHistoryRes.setPageNumber(cmsTxnHistoryRes.getPageNumber());
	    txnHistoryRes.setAvailableBalance(cmsTxnHistoryRes.getAvailableBalance());
	    txnHistoryRes.setAvailableBalanceFormatted(currencyFormat(cmsTxnHistoryRes.getAvailableBalance(),currency));
	    txnHistoryRes.setOpeningBalance(cmsTxnHistoryRes.getOpeningBalance());
	    txnHistoryRes.setOpeningBalanceFormatted(currencyFormat(cmsTxnHistoryRes.getOpeningBalance(),currency));
	    txnHistoryRes.setClosingBalance(cmsTxnHistoryRes.getClosingBalance());
	    txnHistoryRes.setClosingBalanceFormatted(currencyFormat(cmsTxnHistoryRes.getClosingBalance(),currency));
	    for (int i = 0; i < cmsTxnHistoryRes.getStatementDetails().size(); i++) {	            	
            details = cmsTxnHistoryRes.getStatementDetails().get(i);
            txnHistory = new TransactionHistory();
            txnHistory.setTransactionId(details.getClientTxnId());
            if("CR".equals(details.getTransactionType())) {
            	txnHistory.setDepositAmount(details.getTransactionAmount());
            	txnHistory.setDepositAmountFormatted(currencyFormat(details.getTransactionAmount(),currency));
            	txnHistory.setTxnFlow("I");
            }else if("DR".equals(details.getTransactionType())) {
            	txnHistory.setWithdrawalAmount(details.getTransactionAmount());
            	txnHistory.setWithdrawalAmountFormatted(currencyFormat(details.getTransactionAmount(),currency));  
            	txnHistory.setTxnFlow("O");
            }	         
            txnHistory.setCurrencyUnicode(currency.getCurrencyUnicode());
            txnHistory.setCurrencyHtmlCode(currency.getCurrencyHtmlcode());
            txnHistory.setMerchantName(details.getMerchantName());
            txnHistory.setTransactionDate(details.getTransactionDate());
            txnHistory.setTxnRefNumber(details.getTransRefNumber());
            txnHistory.setTransactionDesc(details.getReserved2());
            txnHistory.setOpeningBalance(details.getOpenningBalance());
        	txnHistory.setOpeningBalanceFormatted(currencyFormat(details.getOpenningBalance(),currency));        		
            txnHistory.setClosingBalance(details.getClosingBalance());
        	txnHistory.setClosingBalanceFormatted(currencyFormat(details.getClosingBalance(),currency));        		
            txnHistory.setNarration(details.getTransactionNarration());
            txnHistory.setEventId(details.getEventId());
            txnHistory.setRrn(details.getRrn());
            txnHistory.setStan(details.getStan());
        	txnHistory.setReversal(details.isReversal());
            txnHistory.setIsMerchantTxn(details.getIsMerchantTxn());
            if(details.getIsMerchantTxn() == 0){
            	txnHistory.setTransactionCategory("W");
            }else if(details.getIsMerchantTxn() == 1){
            	txnHistory.setTransactionCategory("C");
            }       	            
           
            txnHistoryList.add(txnHistory);	                
        }	            
		txnHistoryRes.setTxnHistoryList(txnHistoryList);
		wibmoResponse.setData(txnHistoryRes);	
		log.debug("return from prepareTxnHistoryResponse");
	}
	
	public static String currencyFormat(long value, Currency currency){
        if(value == 0) {
            return "0.00";
        }
        if(currency != null && currency.getCurrencyFormatString() == null) {      
            return amountFormat(value,currency.getCurrencyFormatString());
        }        
        return amountFormat(value,"#,###.00");
    }
    
    
    
    private static String amountFormat(long d, String currencyFormatString) {
		return new DecimalFormat(currencyFormatString).format(d);
	}


	private static String dateFormatter(String dayStr, String month, String year){   
        String dateStr;
        var day = 1;
        if(dayStr != null) {
        	day = Integer.parseInt(dayStr);
        }       
        if (day <= 9) {
            dateStr = "" + 0 + day + "/" + month + "/" + year;
        } else {
            dateStr = "" + day + "/" + month + "/" + year;
        }
        return dateStr;
    }


	public static UserVelocityCheck prepareVelocityCheckReq(String customerId, long amount, String txnType,
			String cardNumber, int kycLevel, String bankId) {
		var velocityReq = new UserVelocityCheck();
		velocityReq.setCustomerId(customerId);
		velocityReq.setCardNumber(cardNumber);
		velocityReq.setKycLevel(kycLevel);
		velocityReq.setTxnType(txnType);
		velocityReq.setVal(amount);
		velocityReq.setBankId(bankId);
		return velocityReq;
	}

}
