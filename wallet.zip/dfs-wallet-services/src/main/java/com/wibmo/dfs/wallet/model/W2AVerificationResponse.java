package com.wibmo.dfs.wallet.model;

import lombok.Data;

@Data
public class W2AVerificationResponse {
    private long txnAmt;
    private boolean isCoolingPeriod;
    private int beneficiaryId;
    private String beneficiaryName;
    private String beneficiaryAccountNumber;
    private String beneficiaryVpa;
    private long feeAmount;
    private long gst;
    private long cgst;
    private long sgst;
    private long totalTxnAmount;
    private String message;
    private String limitKey;
    private String feeGstPercentage;
    private String productType;
}
