package com.wibmo.dfs.wallet.model;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RMAcceptRequest implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private String txnRefNumber;
	private String txnMode;
	private long txnAmt;
	private String payeeDetails;
	private String payeeId;
	private int walletId;
	@ApiModelProperty(required = true, notes = "A for Accept, R for Reject")
	private String collectStatus;
	private RMUpiAcceptRequest rmUpiAcceptRequest;
}
