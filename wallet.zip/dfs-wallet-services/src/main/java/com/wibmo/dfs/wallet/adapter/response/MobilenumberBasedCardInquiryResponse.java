package com.wibmo.dfs.wallet.adapter.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MobilenumberBasedCardInquiryResponse {
 private Boolean reKyc;
 private String kycName;
 private String clientId;
 private String clientTxnId;
 private String cardStatus;
 private int bankId;
 private String responseDateTime;
 private long urn;
 private String customerId;
 private long accosaTransactionId;
 private String responseCode;
 private String responseMessage;
 private String description;
 private long availableBalance;
 private CardHolder cardHolder;
 private String last4Digits;
 private String entityName;
 private String clientName;
 private String programName;
 private int messageCode;
 private String hostException;
}
