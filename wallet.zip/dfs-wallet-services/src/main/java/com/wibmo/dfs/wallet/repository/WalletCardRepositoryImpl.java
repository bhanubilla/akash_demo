package com.wibmo.dfs.wallet.repository;

import com.wibmo.dfs.cache_client.manager.DfsCacheManager;
import com.wibmo.dfs.hsm_client.CryptoException;
import com.wibmo.dfs.hsm_client.CryptoHandler;
import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.entity.PrepaidBankMapping;
import com.wibmo.dfs.wallet.entity.WalletCard;
import com.wibmo.dfs.wallet.request.HSMRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collections;
import java.util.List;

@Slf4j
@Repository
public class WalletCardRepositoryImpl implements WalletCardRepository {

	private static final String INSERT_QUERY = "INSERT INTO wallet_cards (customer_id,pp_bank_id,card_number,"
			+ "expiry_mm,expiry_yyyy,card_type,product_type,bank_urn," + "cms_ref_no,debit_allowed,credit_allowed,host_customer_id)"
			+ " VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	CryptoHandler hsm;

	@Autowired
	private PrepaidBankMappingRepository ppBankRepo;

	@Autowired
	private DfsCacheManager cacheManager;

	private static final String CACHE_KEY = "WALLET_CARD";

	@Override
	public int save(WalletCard walletCard, String programId) {

		KeyHolder keyHolder = new GeneratedKeyHolder();
		HSMRequest request = new HSMRequest();

		jdbcTemplate.update(connection -> {

			PreparedStatement ps = connection.prepareStatement(INSERT_QUERY, Statement.RETURN_GENERATED_KEYS);
			int i = 1;
			try {
				PrepaidBankMapping ppBankMap = ppBankRepo.fetchById(walletCard.getPpBankId(), programId);
				if (ppBankMap == null)
					return null;
				int bankId = Integer.parseInt(programId);
				ps.setString(i++, walletCard.getCustomerId());
				ps.setInt(i++, walletCard.getPpBankId());
				request.setData(walletCard.getCardNumber());
				ps.setString(i++, hsm.secureData(bankId, request.getData(), false));
				request.setData(walletCard.getExpiryMm());
				ps.setString(i++, hsm.secureData(bankId, request.getData(), false));
				request.setData(walletCard.getExpiryYyyy());
				ps.setString(i++, hsm.secureData(bankId, request.getData(), false));
				ps.setString(i++, walletCard.getCardType());
				ps.setString(i++, walletCard.getProductType());
				ps.setString(i++, walletCard.getBankUrn());
				ps.setString(i++, walletCard.getCmsRefNo());
				ps.setBoolean(i++, walletCard.isDebitAllowed());
				ps.setBoolean(i++, walletCard.isCreditAllowed());
				ps.setString(i++,walletCard.getHostCustomerId());
			} catch (CryptoException ce) {
				log.error(ce.getMessage());
				return null;
			} catch (Exception ex) {
				log.error(ex.getMessage());
				return null;
			}
			return ps;
		}, keyHolder);
		Number key = keyHolder.getKey();
		return null != key ? key.intValue() : 0;

	}
	@Override
	public boolean reloadWalletWithId(String programId, int walletId) {
		Object obj = cacheManager.remove(CACHE_KEY + Constants.UNDER_SCORE + programId + Constants.UNDER_SCORE + walletId);
		if(obj instanceof Boolean) {
			log.info("Successfully Removed from cache - programId:{} walletId:{}",programId,walletId);
			return (Boolean)obj;
		}
		else return false;
	}

    @Override
    public boolean reloadWalletWithCustIdAndProdType(String programId, String custId, String productType) {
        Object obj = cacheManager.remove(CACHE_KEY + Constants.UNDER_SCORE + programId + Constants.UNDER_SCORE + custId + Constants.UNDER_SCORE + productType);
        if(obj instanceof Boolean) {
            log.info("Successfully Removed from cache - programId:{} custId:{}, productType:{}",programId,custId, productType);
            return (Boolean)obj;
        }
        else return false;
    }

	@Override
	public WalletCard fetchById(int id, String programId) {
		WalletCard value = (WalletCard) cacheManager.get(CACHE_KEY + Constants.UNDER_SCORE + programId + Constants.UNDER_SCORE + id);
		if (null != value) {
			return value;
		}
		log.info("NFC - going to DB programId:{} id:{}",programId, id);
		BeanPropertyRowMapper<WalletCard> rowMapper = BeanPropertyRowMapper.newInstance(WalletCard.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<WalletCard> li = jdbcTemplate.query("select * from wallet_cards where id = ?",
				new PreparedStatementSetter() {

					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setInt(1, id);
					}
				}, rowMapper);
		WalletCard wc = !li.isEmpty() ? li.get(0) : null;
		if (null != wc) {
			HSMRequest request = new HSMRequest();
			try {
				int bankId = Integer.parseInt(programId);
				request.setData(wc.getCardNumber());
				wc.setCardNumber(hsm.getClearData(bankId, request.getData(), false));
				request.setData(wc.getExpiryMm());
				wc.setExpiryMm(hsm.getClearData(bankId, request.getData(), false));
				request.setData(wc.getExpiryYyyy());
				wc.setExpiryYyyy(hsm.getClearData(bankId, request.getData(), false));
			} catch (CryptoException ce) {
				log.error(ce.getMessage());
				return null;
			} catch (Exception ex) {
				log.error(ex.getMessage());
				return null;
			}
		}
		//setting into cache
		cacheManager.put(CACHE_KEY + Constants.UNDER_SCORE + programId + Constants.UNDER_SCORE + id, wc);
		return wc;

	}

	@Override
	public WalletCard fetchByCustIdAndProduct(String custId, String productType, String programId) {
		WalletCard value = (WalletCard) cacheManager.get(CACHE_KEY + Constants.UNDER_SCORE + programId + Constants.UNDER_SCORE + custId+ Constants.UNDER_SCORE + productType);
		if (null != value) {
			return value;
		}
		log.info("NFC - going to DB programId:{} ,custId:{}, productType:{}",programId, custId, productType);
		BeanPropertyRowMapper<WalletCard> rowMapper = BeanPropertyRowMapper.newInstance(WalletCard.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<WalletCard> li = jdbcTemplate.query(
				"select * from wallet_cards where customer_id = ? and product_type = ?", new PreparedStatementSetter() {

					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setString(1, custId);
						preparedStatement.setString(2, productType);
					}
				}, rowMapper);
		WalletCard wc = !li.isEmpty() ? li.get(0) : null;
		if (null != wc) {
			HSMRequest request = new HSMRequest();
			try {
				int bankId = Integer.parseInt(programId);
				request.setData(wc.getCardNumber());
				wc.setCardNumber(hsm.getClearData(bankId, request.getData(), false));
				request.setData(wc.getExpiryMm());
				wc.setExpiryMm(hsm.getClearData(bankId, request.getData(), false));
				request.setData(wc.getExpiryYyyy());
				wc.setExpiryYyyy(hsm.getClearData(bankId, request.getData(), false));
			} catch (CryptoException ce) {
				log.error(ce.getMessage());
				return null;
			} catch (Exception ex) {
				log.error(ex.getMessage());
				return null;
			}
		}
		// setting into cache
		cacheManager.put(CACHE_KEY + Constants.UNDER_SCORE + programId + Constants.UNDER_SCORE + custId+ Constants.UNDER_SCORE + productType, wc);
		return wc;
	}

	@Override
	public List<WalletCard> fetchByCustId(String custId, String programId) {
		BeanPropertyRowMapper<WalletCard> rowMapper = BeanPropertyRowMapper.newInstance(WalletCard.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<WalletCard> wcs = jdbcTemplate.query("select * from wallet_cards where customer_id = ? ",
				new PreparedStatementSetter() {

					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setString(1, custId);
					}
				}, rowMapper);
		if (!wcs.isEmpty()) {
			for (WalletCard wc : wcs) {
				HSMRequest request = new HSMRequest();
				try {
					PrepaidBankMapping ppBankMap = ppBankRepo.fetchById(wc.getPpBankId(), programId);
					if (ppBankMap == null)
						return Collections.emptyList();
					int bankId = Integer.parseInt(programId);
					request.setData(wc.getCardNumber());
					wc.setCardNumber(hsm.getClearData(bankId, request.getData(), false));
					request.setData(wc.getExpiryMm());
					wc.setExpiryMm(hsm.getClearData(bankId, request.getData(), false));
					request.setData(wc.getExpiryYyyy());
					wc.setExpiryYyyy(hsm.getClearData(bankId, request.getData(), false));
				} catch (CryptoException ce) {
					log.error(ce.getMessage());
				} catch (Exception ex) {
					log.error(ex.getMessage());
				}
			}

		}
		return wcs;
	}

	@Override
	public WalletCard fetchByCustIdAndId(String custId, int id, String programId) {
		log.info(" custId :: {}, id :: {}, programId :: {}",custId,id,programId);
		BeanPropertyRowMapper<WalletCard> rowMapper = BeanPropertyRowMapper.newInstance(WalletCard.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<WalletCard> li = jdbcTemplate.query("select * from wallet_cards where id = ? and customer_id = ? ",
				new PreparedStatementSetter() {

					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setInt(1, id);
						preparedStatement.setString(2, custId);
					}
				}, rowMapper);
		WalletCard wc = !li.isEmpty() ? li.get(0) : null;
		if (null != wc) {
			HSMRequest request = new HSMRequest();
			try {
				PrepaidBankMapping ppBankMap = ppBankRepo.fetchById(wc.getPpBankId(), programId);
				if (ppBankMap == null)
					return null;
				int bankId = Integer.parseInt(programId);
				request.setData(wc.getCardNumber());
				wc.setCardNumber(hsm.getClearData(bankId, request.getData(), false));
				request.setData(wc.getExpiryMm());
				wc.setExpiryMm(hsm.getClearData(bankId, request.getData(), false));
				request.setData(wc.getExpiryYyyy());
				wc.setExpiryYyyy(hsm.getClearData(bankId, request.getData(), false));
			} catch (CryptoException ce) {
				log.error(ce.getMessage());
				return null;
			} catch (Exception ex) {
				log.error(ex.getMessage());
				return null;
			}
		}
		return wc;
	}

	@Override
	public WalletCard fetchByCardNumber(String cardNumber, String bankId) {
		BeanPropertyRowMapper<WalletCard> rowMapper = BeanPropertyRowMapper.newInstance(WalletCard.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		HSMRequest request = new HSMRequest();
		request.setData(cardNumber);
		WalletCard walletCard = null;
		int bnkId = Integer.parseInt(bankId);
		try {
			String encryptedCardNumer = hsm.secureData(bnkId, request.getData(), false);
			List<WalletCard> li = jdbcTemplate.query("select * from wallet_cards where card_number = ?",
					new PreparedStatementSetter() {

						public void setValues(PreparedStatement preparedStatement) throws SQLException {
							preparedStatement.setString(1, encryptedCardNumer);
						}
					}, rowMapper);
			walletCard = !li.isEmpty() ? li.get(0) : null;
			if (null != walletCard) {
				request.setData(walletCard.getCardNumber());
				walletCard.setCardNumber(hsm.getClearData(bnkId, request.getData(), false));
				request.setData(walletCard.getExpiryMm());
				walletCard.setExpiryMm(hsm.getClearData(bnkId, request.getData(), false));
				request.setData(walletCard.getExpiryYyyy());
				walletCard.setExpiryYyyy(hsm.getClearData(bnkId, request.getData(), false));
			}

		} catch (CryptoException e) {
			log.error("exception :{}",e);
			return null;
		}

		return walletCard;
	}

}
