package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TransactionHistory {
	
	private String transactionDate;
    private String narration;
    private String txnRefNumber;   
    
    private String merchantName;

    private String transactionId;
    private String txnFlow;
    private String transactionCategory;
    private String transactionDesc;
    private int transactionStatus;
    private boolean reversal; 
    
    private String currencyUnicode;
    private String currencyHtmlCode;
    
    private long withdrawalAmount;
    private String withdrawalAmountFormatted;
    
    private long depositAmount;
    private String depositAmountFormatted;
    
    private long openingBalance;
    private String openingBalanceFormatted;
    
    private long closingBalance;
    private String closingBalanceFormatted;  
    
    private String eventId; 
    private String rrn;
    private String stan;
    private int isMerchantTxn; 
      
 
}
