package com.wibmo.dfs.wallet.aero.beans;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InitiateUpiCollectResponse implements Serializable {
	 
	private static final long serialVersionUID = 1L;
		
	private String pspRefNo;
	private String upiTxnRefNo;
	private String status; // S = Success , F = Failure, T = Time out, P = Pending
	private String statusDescription;
	private String customerRefNo; // RRN Number
	
	private String txnAmount;
	private long txnDate;
	private String transactionNote;
	
	private String respCode;
	private String respDesc;
	private String msgHash ="NA";
	
	private CommonInfo commonInfo;
}
