package com.wibmo.dfs.wallet.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;


@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserProfileDetailsResponse implements Serializable {

    private boolean bankCustomer;
    private long accountNumber;
    private String firstName;
    private String middleName;
    private String lastName;
    private String gender;
    private int allowEdit;
    private String mobile;
    private String emailId;
    private String preferredLanguage;
    private String dob;
    private int kycLevel;
    private String kycName;
    private String kycDisplayName;
    private String ageCategory;
    private String txnInfo;
    private String walletDetails;
}