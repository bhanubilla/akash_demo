package com.wibmo.dfs.wallet.controller;

import com.wibmo.dfs.wallet.service.UserConsumptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wibmo.dfs.wallet.model.UserVelocityCheck;
import com.wibmo.dfs.wallet.model.WibmoResponse;
import com.wibmo.dfs.wallet.util.CommonUtil;
import com.wibmo.dfs.wallet.util.WibmoResponseUtil;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/wallet/limit")
public class WalletLimitController {

	@Autowired
	private UserConsumptionService service;
	
	@ApiOperation(value="fetch Consumption API", response=WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 200, message = "Success",response =WibmoResponse.class),
			@ApiResponse(code = 300, message = "Your max amount per transaction limit is Rs %s. Please enter a smaller amount. (or) Your remaining limit is Rs %s for this month. Please enter a smaller amount."
					+ " (or) Your remaining limit is Rs %s for today. Please enter a smaller amount. (or) You are not allowed any more transactions this month. Please retry next month."
					+ " (or) You are not allowed any more transactions today. Please retry tomorrow. (or) KYC limits are not found",response =WibmoResponse.class),
			
	        @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class)
	})
	@PostMapping("/fetch/consumption/api/v1")
	public ResponseEntity<WibmoResponse> fetchConsumption(@RequestBody UserVelocityCheck request,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		request.setCustomerId(userId);
		Thread.currentThread().setName("fetchConsumption");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), request.getCustomerId());
		WibmoResponse response = new WibmoResponse();
		if (response.getResCode() > 0) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		request.setBankId(bankId);
		return WibmoResponseUtil.frameResponse(service.chkVelocityLimits(request, bankId));
	}
	
	@PostMapping("/update/consumption/api/v1")
	public ResponseEntity<WibmoResponse> updateConsumption(@RequestBody UserVelocityCheck request,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		request.setCustomerId(userId);
		Thread.currentThread().setName("updateConsumption");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), request.getCustomerId());
		request.setBankId(bankId);
		boolean status = service.updateUserConsumption(request);
		WibmoResponse response = new WibmoResponse();
		if(status) {
			response.setResCode(200);
			response.setResDesc("updated successfully..");
		} else {
			response.setResCode(100);
			response.setResDesc("update Failed");
		}
		return WibmoResponseUtil.frameResponse(response);
	}
}
