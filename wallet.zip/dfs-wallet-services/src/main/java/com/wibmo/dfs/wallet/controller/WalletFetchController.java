package com.wibmo.dfs.wallet.controller;

import com.wibmo.dfs.wallet.model.*;
import com.wibmo.dfs.wallet.service.AccountsService;
import com.wibmo.dfs.wallet.service.WalletService;
import com.wibmo.dfs.wallet.service.WalletServiceFactory;
import com.wibmo.dfs.wallet.service.WalletStatementService;
import com.wibmo.dfs.wallet.util.CommonUtil;
import com.wibmo.dfs.wallet.util.WibmoResponseUtil;
import com.wibmo.dfs.wallet.validation.RequestValidator;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/wallet/fetch")
public class WalletFetchController {

	private static final String ERROR_DESC = "Error Desc :{}";

	@Autowired
	private WalletServiceFactory findService;
	
	@Autowired
	private AccountsService service;

	@Autowired
	private RequestValidator validator;

	@Autowired
	private WalletStatementService walletStatementService;
	/**
	 * This API is used to fetch SVC details
	 * @param inquiry
	 * @param bankId
	 * @return WibmoResponse
	 */
	@ApiOperation(value="Fetch Card API", response=WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 1, message = "fetch card details successfully",response =WibmoResponse.class),
			@ApiResponse(code = 3, message = "internal server error",response =WibmoResponse.class),
			@ApiResponse(code = 10, message = "customerid/walletid or product type is mismatch",response =WibmoResponse.class),
			@ApiResponse(code = 11, message = "prepaid card details is null",response =WibmoResponse.class),
			@ApiResponse(code = 20, message = "request is empty",response =WibmoResponse.class),
			@ApiResponse(code = 39, message = "product type or customer id is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class)
	})
	@PostMapping("/card/api/v1")
	public ResponseEntity<WibmoResponse> inquiry(@RequestBody FetchCardRequest inquiry,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		inquiry.setCustomerId(userId);
		Thread.currentThread().setName("FetchCard");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), inquiry.getCustomerId());
		WibmoResponse response = new WibmoResponse();
		validator.validateCardInquiryRequest(inquiry, response, bankId);
		if (response.getResCode() > 0) {
			log.info(ERROR_DESC,response.getResDesc());
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		WalletService ws = findService.getService(bankId);
		return WibmoResponseUtil.frameResponse(ws.inquiry(inquiry));

	}
	
	/**
	 * This API is used to fetch SVC status
	 * @param inquiry
	 * @param bankId
	 * @return WibmoResponse
	 */
	@ApiOperation(value="Fetch Card Status API", response=WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 1, message = "fetch card details successfully",response =WibmoResponse.class),
			@ApiResponse(code = 3, message = "internal server error",response =WibmoResponse.class),
			@ApiResponse(code = 10, message = "customerid/walletid or product type is mismatch",response =WibmoResponse.class),
			@ApiResponse(code = 11, message = "card not found",response =WibmoResponse.class),
			@ApiResponse(code = 20, message = "request is empty",response =WibmoResponse.class),
			@ApiResponse(code = 39, message = "product type or customer id is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class)
	})
	@PostMapping("/status/api/v1")
	public ResponseEntity<WibmoResponse> fetchCardStatus(@RequestBody FetchCardStatusRequest inquiry,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		inquiry.setCustomerId(userId);
		Thread.currentThread().setName("FetchCardStatus");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), inquiry.getCustomerId());
		WibmoResponse response = new WibmoResponse();
		validator.validateCardStatusRequest(inquiry, response, bankId);
		if (response.getResCode() > 0) {
			log.info(ERROR_DESC,response.getResDesc());
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		WalletService ws = findService.getService(bankId);
		return WibmoResponseUtil.frameResponse(ws.fetchCardStatus(inquiry));

	}
	
	/**
	 * This API is used to fetch SVC Balance 
	 * @param inquiry
	 * @param bankId
	 * @return WibmoResponse
	 */
	@ApiOperation(value="Fetch Card Balance API", response=WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 1, message = "fetch card details successfully",response =WibmoResponse.class),
			@ApiResponse(code = 2, message = "rrn is empty",response =WibmoResponse.class),
			@ApiResponse(code = 3, message = "internal server error",response =WibmoResponse.class),
			@ApiResponse(code = 10, message = "card not found",response =WibmoResponse.class),
			@ApiResponse(code = 11, message = "prepaid card details not found",response =WibmoResponse.class),
			@ApiResponse(code = 20, message = "request is empty",response =WibmoResponse.class),
			@ApiResponse(code = 36, message = "rrn is empty",response =WibmoResponse.class),
			@ApiResponse(code = 39, message = "product type or customer id is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class)
	})
	@PostMapping("/balance/api/v1")
	public ResponseEntity<WibmoResponse> fetchCardBalance(@RequestBody FetchCardBalanceRequest inquiry,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		inquiry.setCustomerId(userId);
		Thread.currentThread().setName("FetchCardBalance");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), inquiry.getCustomerId());
		WibmoResponse response = new WibmoResponse();
		validator.validateCardBalanceRequest(inquiry, response, bankId);
		if (response.getResCode() > 0) {
			log.info(ERROR_DESC,response.getResDesc());
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		WalletService ws = findService.getService(bankId);
		return WibmoResponseUtil.frameResponse(ws.fetchCardBalance(inquiry));

	}
	
	/**
	 * This API is used to fetch CVV details for a SVC
	 * @param inquiry
	 * @param bankId
	 * @return WibmoResponse
	 */
	@ApiOperation(value="Fetch CardCVV API", response=WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 1, message = "fetch card details successfully",response =WibmoResponse.class),
			@ApiResponse(code = 3, message = "internal server error",response =WibmoResponse.class),
			@ApiResponse(code = 11, message = "prepaid card details not found",response =WibmoResponse.class),
			@ApiResponse(code = 20, message = "request is empty",response =WibmoResponse.class),
			@ApiResponse(code = 39, message = "product type or customer id is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class)
	})
	@PostMapping("/cvv/api/v1")
	public ResponseEntity<WibmoResponse> fetchCardCvv(@RequestBody FetchCardCVVRequest inquiry,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		inquiry.setCustomerId(userId);
		Thread.currentThread().setName("FetchCardCVV");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), inquiry.getCustomerId());
		WibmoResponse response = new WibmoResponse();
		validator.validateCardCVVRequest(inquiry, response, bankId);
		if (response.getResCode() > 0) {
			log.info(ERROR_DESC,response.getResDesc());
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		WalletService ws = findService.getService(bankId);
		return WibmoResponseUtil.frameResponse(ws.fetchCardCVV(inquiry));

	}
	
	@ApiOperation(value="Fetch WalletCards API", response=WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 26, message = "customer id is empty",response =WibmoResponse.class),
			@ApiResponse(code = 200, message = "User Wallet cards fetched Successfully",response =WibmoResponse.class),
			@ApiResponse(code = 400, message = "request is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class)
	})
	@PostMapping("/cards/api/v1")
	public ResponseEntity<WibmoResponse> fetchWalletCards(@RequestBody FetchWalletsRequest request,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		request.setCustomerId(userId);
		Thread.currentThread().setName("fetchWalletCards");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), request.getCustomerId());
		WibmoResponse response = new WibmoResponse();
		validator.validateFetchWalletsRequest(request, response, bankId);
		if (response.getResCode() > 0) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		return WibmoResponseUtil.frameResponse(service.fetchWallets(request, bankId));
	}

	@PostMapping("/v1/statement")
	public WibmoResponse fetchWalletStatement(@RequestBody TransactionParams params, @RequestHeader(value = "X-PROGRAM-ID") int programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		return walletStatementService.fetchWalletStatement(params.getFromDate(), params.getToDate(), programId, userId, params.getEmailId());

	}
}
