package com.wibmo.dfs.wallet.repository;

import com.wibmo.dfs.cache_client.manager.DfsCacheManager;
import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.entity.PrepaidMaster;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

@Repository
@Slf4j
public class PrepaidMasterRepositoryImpl implements PrepaidMasterRepository{

	@Autowired
    private JdbcTemplate jdbcTemplate;

	@Autowired
	private DfsCacheManager cacheManager;

	private static final String CACHE_KEY = "PP_MSTR";
	
	@Override
	public PrepaidMaster fetchById(int id, String programId) {
		PrepaidMaster value = (PrepaidMaster) cacheManager.get(CACHE_KEY + Constants.UNDER_SCORE + programId + Constants.UNDER_SCORE + id);
		if (null != value) {
			return value;
		}
		log.info("NFC - going to DB programId:{} id:{}",programId,id);
		return loadFromDB(id, programId);
	}

	private PrepaidMaster loadFromDB(int id, String programId) {
		BeanPropertyRowMapper<PrepaidMaster> rowMapper = BeanPropertyRowMapper.newInstance(PrepaidMaster.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<PrepaidMaster> li = jdbcTemplate.query("select * from prepaid_master where id = ?", new PreparedStatementSetter() {
			public void setValues(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setInt(1, id);
			}
		}, rowMapper);
		PrepaidMaster ppm = !li.isEmpty() ? li.get(0) : null;
		if(null != ppm) cacheManager.put(CACHE_KEY + Constants.UNDER_SCORE + programId + Constants.UNDER_SCORE + id, ppm);
		return ppm;
	}

	@Override
	public int save(PrepaidMaster pmaster) {
		return 0;
	}

	@Override
	public boolean reloadPPMaster(String programId, int ppId) {
		Object obj = cacheManager.remove(CACHE_KEY + Constants.UNDER_SCORE + programId + Constants.UNDER_SCORE + ppId);
		if(obj instanceof Boolean) {
			log.info("Successfully Removed from cache - programId:{} ppId:{}",programId,ppId);
			return (Boolean)obj;
		}
		else return false;
	}

}
