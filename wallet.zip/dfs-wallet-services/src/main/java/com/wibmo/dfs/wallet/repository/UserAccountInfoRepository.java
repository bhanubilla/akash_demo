package com.wibmo.dfs.wallet.repository;

import com.wibmo.dfs.wallet.entity.UserAccountInfo;

public interface UserAccountInfoRepository {

	int save(UserAccountInfo userAccount);
	
	int checkAndSave(UserAccountInfo userAccount);
	
	UserAccountInfo fetchByCustId(String custId);
	
	UserAccountInfo fetchByMobileNo(String mobileNo);
}
