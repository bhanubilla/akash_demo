package com.wibmo.dfs.wallet.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class VerificationRequest {
	@NotNull(message = "Source RefId  cannot be null")
    @ApiModelProperty(required = true, dataType="String")
    private String sourceRefId;

    @ApiModelProperty(required = false, dataType="String", allowEmptyValue = true, notes = "This is used for internal validation. Not required for request")
    private String txnType;

    @Positive(message = "Beneficiary Id should be positive")
    @ApiModelProperty(required = true, dataType="int", allowEmptyValue = true, notes = "This is conditional.")
    private int beneficiaryId;

    @Positive(message = "Transaction amount should be positive")
    @ApiModelProperty(required = true, dataType="long", allowEmptyValue = false)
    private long txnAmt;

    @ApiModelProperty(required = false, dataType="String", allowEmptyValue = true)
    private String beneficiaryAccountNumber;

    @ApiModelProperty(required = false, dataType="String", allowEmptyValue = true)
    private String beneficiaryIfscCode;

    @ApiModelProperty(required = false, dataType="String", allowEmptyValue = true)
    private String beneficiaryName;

    @ApiModelProperty(required = false, dataType="String", allowEmptyValue = true)
    private String vpa;
}
