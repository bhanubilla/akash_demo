package com.wibmo.dfs.wallet.repository;

import com.wibmo.dfs.wallet.entity.BlockedDetails;
import com.wibmo.dfs.wallet.model.BlockedMobileDetailsReq;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

@Slf4j
@Repository
public class BlockedMobileNumberDetailsRepoImpl implements BlockedMobileNumberDetailsRepo{

    private static final String INSERT_QUERY = "insert into  blocked_mobile_details(account_number,blocked_mobile_number,blocked_user_name) values(?,?,?)";
    private static final String DELETE_RECORD = "delete from blocked_mobile_details where blocked_mobile_number=? and account_number=?";
    @Autowired
    private JdbcTemplate jdbcTemplate;


    @Override
    public int save(BlockedMobileDetailsReq blockedMobileDetailsReq) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        log.info("blockedMobileDetailsReq :: aC/NO :: {}, BlockedNumber :: {}, blockedUsername :: {}",blockedMobileDetailsReq.getAccountNumber(), blockedMobileDetailsReq.getBlockedMobileNumber(), blockedMobileDetailsReq.getBlockedUserName());
            jdbcTemplate.update(connection -> {
                PreparedStatement ps = connection.prepareStatement(INSERT_QUERY, Statement.RETURN_GENERATED_KEYS);
                int i = 1;
                ps.setString(i++, blockedMobileDetailsReq.getAccountNumber());
                ps.setString(i++, blockedMobileDetailsReq.getBlockedMobileNumber());
                ps.setString(i++, blockedMobileDetailsReq.getBlockedUserName());
                return ps;
            }, keyHolder);

            Number value =keyHolder.getKey();
            return null != value ? value.intValue():0;
    }

    @Override
    public List<BlockedDetails> fetchBlockedMobileNumbers(String accountNumber) {
        log.info("accountNumber {}",accountNumber);
        BeanPropertyRowMapper<BlockedDetails> rowMapper = BeanPropertyRowMapper.newInstance(BlockedDetails.class);
        rowMapper.setPrimitivesDefaultedForNullValue(true);

        return jdbcTemplate.query("select * from blocked_mobile_details where account_number = ?", new PreparedStatementSetter() {

            @Override
            public void setValues(PreparedStatement ps) throws SQLException {
                ps.setString(1,accountNumber);
            }
        },rowMapper);
    }

    @Override
    public BlockedDetails fetchBlockedMobileNumber(String accountNumber, String blockedMobileNumber) {
        log.info("accountNumber {}, blockedMobileNumber {}",accountNumber,blockedMobileNumber);
        BeanPropertyRowMapper<BlockedDetails> rowMapper = BeanPropertyRowMapper.newInstance(BlockedDetails.class);
        rowMapper.setPrimitivesDefaultedForNullValue(true);
        List<BlockedDetails> list = jdbcTemplate.query("select * from blocked_mobile_details where account_number = ? and blocked_mobile_number = ?"
       , new PreparedStatementSetter() {

            @Override
            public void setValues(PreparedStatement ps) throws SQLException {
                ps.setString(1,accountNumber);
                ps.setString(2,blockedMobileNumber);

            }
        },rowMapper);
        return !list.isEmpty() ? list.get(0) : null;
    }

    @Override
    public int delete( String accountNumber,String unBlockMobileNumber) {

        log.info("blockedMobileDetailsReq :: aC/NO :: {}, unBlockMobileNumber :: {}",accountNumber, unBlockMobileNumber);
       return jdbcTemplate.update(DELETE_RECORD,unBlockMobileNumber,accountNumber);

    }
}
