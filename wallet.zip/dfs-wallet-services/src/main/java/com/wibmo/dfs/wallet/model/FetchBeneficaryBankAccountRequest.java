package com.wibmo.dfs.wallet.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FetchBeneficaryBankAccountRequest {
	@ApiModelProperty(required = false, dataType="String", hidden = true)
	private String customerId;
}
