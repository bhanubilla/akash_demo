package com.wibmo.dfs.wallet.entity;

import java.io.Serializable;
import java.sql.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class LMUserConsumption implements Serializable {

	private static final long serialVersionUID = 1L;

	private String customerId;
	private String limitKey;
	private String productType;
	private long total;
	private Date txnTime;
	
	public LMUserConsumption(String customerId, String limitKey, long total, String productType) {
		this.customerId = customerId;
		this.limitKey = limitKey;
		this.total = total;
		this.productType = productType;
	}
}
