package com.wibmo.dfs.wallet.adapter.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CardHolder {
    private int cardProfileId;
    private String cardholderMobile;
    private String cardholderFirstName;
    private String cardholderLastName;
    private String cardholderDateOfBirth;
    private String cardholderEmail;
    private String cardholderAddress;
    private String cardholderCity;
    private String cardholderState;
    private String cardholderCountry;
    private String cardholderZipCode;
}
