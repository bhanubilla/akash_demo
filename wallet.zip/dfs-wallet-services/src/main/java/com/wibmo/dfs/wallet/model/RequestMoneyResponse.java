package com.wibmo.dfs.wallet.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class RequestMoneyResponse {
    private String txnDate;
    private int wibmoResCode;
    private String wibmoResDesc;
    private String wibmoErrorMessage;
    private String txnRefNum;
    private String payeeName;
    private String txnDesc;
    private String txnAmount ;
    private String payeeMobileNumber;
    private String payeeVPA;
    private String payerVPA;
}

