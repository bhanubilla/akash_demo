package com.wibmo.dfs.wallet.model;

import java.io.Serializable;
import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class W2WTransactionRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	//payee customerId
	private int customerId;
	private String sourceAccount;
	private String destAccount;
	private String merTxnId;
	private String paymentTxnId;
	private String authZTxnId;
	private String ppTxnId;
    private String txnType;
    private String txnCategory;
    private String paymentMode;
    private String txnDesc;
    private Long txnAmount;
    private long settlmentAmount;
    private Timestamp txnDate;
    private String txnDateStr;
    private String merId;
    private String merName;
    private String mcc;
    private String merCategory;
    private String txnStatus;
    private String txnFlow;
    private String originalTxnId;
    private Timestamp updatedDate;
    private String remarks;
    private String mobile;
    private String txnShortDesc;
    private String additionalFields;
    private long closingBalance;
    private int sourceRefId;
    private String vpaName;

}
