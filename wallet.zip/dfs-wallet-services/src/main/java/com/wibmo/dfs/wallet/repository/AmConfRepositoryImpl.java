package com.wibmo.dfs.wallet.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.wibmo.dfs.wallet.entity.AmConf;

@Repository
public class AmConfRepositoryImpl implements AmConfRepository{

	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	@Override
	public AmConf fetchByBankId(String bankId) {
		BeanPropertyRowMapper<AmConf> rowMapper = BeanPropertyRowMapper.newInstance(AmConf.class);
        rowMapper.setPrimitivesDefaultedForNullValue(true);
        List<AmConf> li = jdbcTemplate.query("select * from AM_CONF where bank_id = ?", new PreparedStatementSetter() {
      	   
      	   public void setValues(PreparedStatement preparedStatement) throws SQLException {
      	     preparedStatement.setString(1, bankId);
      	   }
      	}, rowMapper);
        return !li.isEmpty() ? li.get(0) : null;
	}

	@Override
	public int save(AmConf amConf) {
		KeyHolder keyHolder = new GeneratedKeyHolder();

		Number value =keyHolder.getKey();
		return null != value ? value.intValue():0;
	}

}
