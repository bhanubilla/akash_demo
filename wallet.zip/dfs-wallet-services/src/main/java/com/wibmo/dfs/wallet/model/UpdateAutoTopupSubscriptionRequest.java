package com.wibmo.dfs.wallet.model;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class UpdateAutoTopupSubscriptionRequest {

	private long userId;
	private String merchantId;
	private long recurringPaymentRefId;
	 
	@ApiModelProperty(value ="status",
	        example = "Action code will be '1' or '0' or '2'. 1 = Enable Auto Pay," +
	                " '0' =Disable/Remove/Delete Auto Pay " +
	                "'2' = Pause Auto Pay")
	private int status;
	private String nickName;
	private long topUpAmount;
	private long durationForConsecutiveDebits;
	private Date expiryDate;
	private long maxAmount;
	private long minAmount;
	@ApiModelProperty(hidden = true)
	private int thresholdAmt;
}
