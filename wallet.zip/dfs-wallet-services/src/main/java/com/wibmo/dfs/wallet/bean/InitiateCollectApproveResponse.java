package com.wibmo.dfs.wallet.bean;

import java.io.Serializable;

import com.wibmo.dfs.wallet.aero.beans.CommonInfo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InitiateCollectApproveResponse implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	  private String reqPspRefNo;
	  private String upiTxnRefNo;
	  private String pspRefNo;
	  private String npciTxnId;
	  private String customerRefNo; // RRN Number
	  private String txnAmount;
	  private long txnApproveDate;
	  private String mobileNo;
	  private String payerBankName;
	  private String deviceId;
	  private String appName;
	  private String payerAddress;
	  private String payeeAddress;
	  private String payerName;
	  private String txnNote;
	  private String refId;
	  private String refURL;
	  private String accountNo;
	  private String credentialDataType;
	  private String credentialDataLength; // Length 4/6 Digits
	  private String status; // S = Success , F = Failure, T = Time out, P = Pending
	  private String statusDescription;
	  private String responseCode;
	  private String approvalNumber;
	  private String payerVirtualAddress;
	  private CommonInfo commonInfo;
	  
	  private String respCode;
	  private String respDesc;
	  private String msgHash ="NA";

}
