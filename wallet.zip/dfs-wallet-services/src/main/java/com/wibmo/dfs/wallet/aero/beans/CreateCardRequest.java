package com.wibmo.dfs.wallet.aero.beans;

import java.io.Serializable;

import lombok.Data;

/**
 * 
 * @author meriyala.raghavendra
 *
 */
@Data
public class CreateCardRequest extends AeroRequest implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private long loadAmount;
    private String productId;
    private CardHolder cardHolder;
    private String cardProfileId;
    private String sourceAccountType;
    private String sourceAccount;
    private CardIdentityProfile customerIdentityProfile;

    public long getLoadAmount() {
        return loadAmount;
    }

    public void setLoadAmount(long loadAmount) {
        this.loadAmount = loadAmount;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public CardHolder getCardHolder() {
        return cardHolder;
    }

    public void setCardHolder(CardHolder cardHolder) {
        this.cardHolder = cardHolder;
    }

    public String getCardProfileId() {
        return cardProfileId;
    }

    public void setCardProfileId(String cardProfileId) {
        this.cardProfileId = cardProfileId;
    }

    public String getSourceAccountType() {
        return sourceAccountType;
    }

    public void setSourceAccountType(String sourceAccountType) {
        this.sourceAccountType = sourceAccountType;
    }

    public String getSourceAccount() {
        return sourceAccount;
    }

    public void setSourceAccount(String sourceAccount) {
        this.sourceAccount = sourceAccount;
    }

	public CardIdentityProfile getCustomerIdentityProfile() {
		return customerIdentityProfile;
	}

	public void setCustomerIdentityProfile(CardIdentityProfile customerIdentityProfile) {
		this.customerIdentityProfile = customerIdentityProfile;
	}


}
