/**
 * 
 */
package com.wibmo.dfs.wallet.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubscriptionDetails {
	
	private String userId;
	private String merchantId;
	private String subscriberId;
	private int status;
	private String subscriptionData;
	private long recurringPaymentRefId;
	private SubscriptionInfo subscriptionInfo;     
}
