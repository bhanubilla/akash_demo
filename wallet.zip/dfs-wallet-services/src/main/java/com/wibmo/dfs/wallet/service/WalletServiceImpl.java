package com.wibmo.dfs.wallet.service;

import java.util.Collections;
import java.util.List;

import com.wibmo.dfs.wallet.model.*;
import org.springframework.stereotype.Service;

import com.wibmo.dfs.wallet.entity.WalletCard;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class WalletServiceImpl implements WalletService{


	WibmoResponse response = new WibmoResponse(3, "Api don't have default Implementation");

	public WibmoResponse create(CreateCard createCard) {
		log.info("Card Creation yet to implement");
		return response;
	}

	@Override
	public WibmoResponse inquiry(FetchCardRequest inquiry) {
		log.info("Card Inquiry yet to implement");
		return response;
	}

	@Override
	public WibmoResponse fundsUnload(FundRequest fundUnloadReq) {
		return response;
	}

	@Override
	public WibmoResponse fundsLoad(FundRequest fundLoadReq) {
		return response;
	}

	@Override
	public WibmoResponse fetchCardStatus(FetchCardStatusRequest inquiry) {
		return response;
	}

	@Override
	public WibmoResponse fetchCardBalance(FetchCardBalanceRequest inquiry) {
		return response;
	}

	@Override
	public WibmoResponse fetchCardCVV(FetchCardCVVRequest inquiry) {
		return response;
	}

	@Override
	public List<FetchCardResponse> fetchByWc(List<WalletCard> wcs) {
		return Collections.emptyList();
	}

	@Override
	public WibmoResponse sendMoney(SendMoneyRequest sendMoneyReq) {
		return response;
	}

	@Override
	public WibmoResponse processP2P(P2PRequest p2pRequest) {
		return response;
	}

	@Override
	public WibmoResponse updateServiceTypeFlag(ServiceTypeRequest serviceReq) {
		return response;
	}

	@Override
	public WibmoResponse checkAmlLimits(CheckUserAmlLimitsRequest request, String bankId)  {
		return response;
	}

	@Override
	public WibmoResponse checkUserLimits(CheckUserLimitsRequest request, String bankId)   {
		return response;
	}

	@Override
	public WibmoResponse updateCardHolderProfile(UpdateCardHolderProfileData profileUpdateRequest, String bankId) {
		return response;
	}

	@Override
	public WibmoResponse blockCard(BlockCardRequest request, String programId, String accountNumber) {
		return null;
	}

	@Override
	public WibmoResponse unBlockCard(UnBlockCardRequest request, String programId, String accountNumber) {
		return null;
	}

}
