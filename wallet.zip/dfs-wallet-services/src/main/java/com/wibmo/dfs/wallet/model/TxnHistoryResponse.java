package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TxnHistoryResponse {

	private String txnDesc;
	private String txnDateStr;
	private long txnDate;
	private String txnFlow;
	private String txnStatus;
	private long txnAmount;
	private String action;
	private String txnId;
	private String txnCategory;
	private String paymentMode;
	private String sourceAccount;
	private String destAccount;
	private String merCategory;
	private String merId;
	private String merName;
	private String txnShortDesc;
	private String originalTxnId;
	private String mobile;
	private String txnType;
	private String txnRefNumber;
	private String mcc;
	private String txnReference;
	private String refUrl;
	private String refCategory;
	private String additionalInfo;
	private String remarks;
}
