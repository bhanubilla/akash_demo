package com.wibmo.dfs.wallet.aero.beans;

import java.util.Date;

/**
 * 
 * @author meriyala.raghavendra
 *
 */
public class CardDetail implements java.io.Serializable {
	static final long serialVersionUID = 1L;
	private static final String ZERO ="000000";
	
	private StringBuilder cardnumber=new StringBuilder(20);
	private StringBuilder expiryMM=new StringBuilder();
	private StringBuilder expiryYYYY=new StringBuilder();
	private StringBuilder cvv2=new StringBuilder();
	
	private String cardAssociationId;
	private int status;
	private String urn;
	private String statusDesc;
        private long loadAmount;
        private long availableBalance;
        private long availableCashLimit;
        private String bankTxnId;
    private Date cardCreationTime;

    private int profileId;
    private String firstName;
    private String lastName;
    private String mobile;
    private String dob;
    private String email;

    public Date getCardCreationTime() {
        return cardCreationTime;
    }

    public void setCardCreationTime(Date cardCreationTime) {
        this.cardCreationTime = cardCreationTime;
    }

    public String getBankTxnId() {
            return bankTxnId;
        }

        public void setBankTxnId(String bankTxnId) {
            this.bankTxnId = bankTxnId;
        }

        public long getLoadAmount() {
            return loadAmount;
        }

        public void setLoadAmount(long loadAmount) {
            this.loadAmount = loadAmount;
        }

        public long getAvailableBalance() {
            return availableBalance;
        }

        public void setAvailableBalance(long availableBalance) {
            this.availableBalance = availableBalance;
        }

        public long getAvailableCashLimit() {
            return availableCashLimit;
        }

        public void setAvailableCashLimit(long availableCashLimit) {
            this.availableCashLimit = availableCashLimit;
        }

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public String getUrn() {
		return urn;
	}

	public void setUrn(String urn) {
		this.urn = urn;
	}


	/**
	 * @return the status
	 */
	public int getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(int status) {
		this.status = status;
	}
	
	

	/**
	 * @return the cardAssociationId
	 */
	public String getCardAssociationId() {
		return cardAssociationId;
	}

	/**
	 * @param cardAssociationId the cardAssociationId to set
	 */
	public void setCardAssociationId(String cardAssociationId) {
		this.cardAssociationId = cardAssociationId;
	}

	@Override
	public String toString() {
		return "CardDetail";
	}

    public StringBuilder getCardnumber() {
        return cardnumber;
    }

    public void setCardnumber(StringBuilder cardnumber) {
        this.cardnumber=cardnumber;
    }

    public StringBuilder getExpiryMM() {
        return expiryMM;
    }

    public void setExpiryMM(StringBuilder expiryMM) {
        this.expiryMM=expiryMM;
    }

    public StringBuilder getExpiryYYYY() {
        return expiryYYYY;
    }

    public void setExpiryYYYY(StringBuilder expiryYYYY) {
        this.expiryYYYY=expiryYYYY;
    }

    public StringBuilder getCvv2() {
        return cvv2;
    }

    public void setCvv2(StringBuilder cvv2) {
        this.cvv2=cvv2;
    }

    public int getProfileId() {
        return profileId;
    }

    public void setProfileId(int profileId) {
        this.profileId = profileId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void clearExpiryMM() {
        if (this.expiryMM != null) {
            this.expiryMM.setLength(0);
            this.expiryMM.append(ZERO);
            this.expiryMM.setLength(0);
            this.expiryMM.trimToSize();
        }
    }
    
    public void clearCvv2() {
        if (this.cvv2 != null) {
            this.cvv2.setLength(0);
            this.cvv2.append(ZERO);
            this.cvv2.setLength(0);
            this.cvv2.trimToSize();
        }
    }
    
    public void clearExpiryYYYY() {  
        if (this.expiryYYYY != null) {
            this.expiryYYYY.setLength(0);
            this.expiryYYYY.append(ZERO);
            this.expiryYYYY.setLength(0);
            this.expiryYYYY.trimToSize();
        }
    }
    
    public void clearCardNumber() {  
        if (this.cardnumber != null) {
            this.cardnumber.setLength(0);
            this.cardnumber.append("00000000000000000000");
            this.cardnumber.setLength(0);
            this.cardnumber.trimToSize();
        }
    }
    
    public void clearCardDetail() {
        this.clearCardNumber();
        this.clearExpiryYYYY();
        this.clearExpiryMM();
        this.clearCvv2();
    }
    
	
}