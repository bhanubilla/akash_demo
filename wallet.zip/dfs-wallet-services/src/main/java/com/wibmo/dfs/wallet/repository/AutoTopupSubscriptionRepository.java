/**
 * 
 */
package com.wibmo.dfs.wallet.repository;

import com.wibmo.dfs.wallet.entity.AutoTopupSubscriptions;

/**
 * @author rajasekhar.kaniti
 *
 */
public interface AutoTopupSubscriptionRepository {
	
	int save(AutoTopupSubscriptions autoTopupSubscriptions);
	boolean updateRefundStatus(AutoTopupSubscriptions autoTopupSubscriptions);
	AutoTopupSubscriptions fetchById(long id);
	AutoTopupSubscriptions fetchStatus(String customerId);
	AutoTopupSubscriptions fetchByMerRefIdAndCustId(String customerId, String merchantRefId);
	AutoTopupSubscriptions fetchByCustId(String customerId);
	boolean updateStatus(AutoTopupSubscriptions autoTopupSubscriptions);
	int update(AutoTopupSubscriptions autoTopupSubscriptions);
	AutoTopupSubscriptions fetchStatusByCustId(String customerId);
	boolean updateSubscription(AutoTopupSubscriptions autoTopupSubscriptions);
	
}
