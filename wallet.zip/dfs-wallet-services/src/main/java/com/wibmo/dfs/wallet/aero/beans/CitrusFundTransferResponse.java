package com.wibmo.dfs.wallet.aero.beans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CitrusFundTransferResponse {
        private long urn;
        private String customerId;
        private String responseCode;
        private long messageCode;
        private String clientTxnId;
        private String clientId;
        private String responseDateTime;
        private long accosaTransactionId;
        private String responseMessage;
        private long bankId;
        private long transactionAmount;
        private long errorFlag;
        private List<CirtrusFundTransferResposeSender> senders;
        private List<CirtrusFundTransferResposeReciever> receivers;
}
