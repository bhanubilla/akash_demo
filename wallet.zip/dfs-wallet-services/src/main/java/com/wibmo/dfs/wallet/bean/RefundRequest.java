package com.wibmo.dfs.wallet.bean;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class RefundRequest {
	
	private boolean initiateRefund;
	private String merchantId;
	private String merchantRefNumber;
	private String refundType;
	private int txnAmt;
	private String txnDate;
	
}
