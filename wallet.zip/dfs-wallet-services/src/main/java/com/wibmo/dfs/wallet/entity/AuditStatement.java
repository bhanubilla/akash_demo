package com.wibmo.dfs.wallet.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AuditStatement {

	private int programId;
	private int walletStatementId;
	private String customerId;
	private Timestamp requestDate;
	private String status;
	private Timestamp updatedDate;

}
