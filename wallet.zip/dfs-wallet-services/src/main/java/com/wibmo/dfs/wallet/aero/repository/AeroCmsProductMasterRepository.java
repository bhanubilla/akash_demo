package com.wibmo.dfs.wallet.aero.repository;

import com.wibmo.dfs.wallet.aero.entity.ProductMaster;

public interface AeroCmsProductMasterRepository {

	ProductMaster fetchByBankAndProdutType(String bankId, String productType);
}
