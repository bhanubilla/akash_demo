package com.wibmo.dfs.wallet.kafka.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = true)
public class P2PCreditEvent extends BaseDetails{

	private String destAccount;
	private String paymentTxnId;
	private String ppTxnId;
	private String originalTxnId;
}
