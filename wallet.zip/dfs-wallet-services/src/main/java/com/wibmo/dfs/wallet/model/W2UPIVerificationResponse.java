package com.wibmo.dfs.wallet.model;

import lombok.Data;

@Data
public class W2UPIVerificationResponse {
    private long txnAmt;
    private boolean isCoolingPeriod;
    private int beneficiaryId;
    private String beneficiaryName;
    private String beneficiaryAccountNumber;
    private String beneficiaryVpa;
    private long totalTxnAmount;
    private String message;
    private String limitKey;
    private String productType;
}
