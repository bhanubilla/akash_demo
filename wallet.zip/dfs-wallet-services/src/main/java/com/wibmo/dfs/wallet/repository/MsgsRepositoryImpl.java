/**
 * 
 */
package com.wibmo.dfs.wallet.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wibmo.dfs.cache_client.manager.DfsCacheManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.wibmo.dfs.wallet.entity.MsgDetails;
import org.springframework.util.StringUtils;

/**
 * @author rajasekhar.kaniti
 *
 */
@Repository
@Slf4j
public class MsgsRepositoryImpl implements MsgsRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private DfsCacheManager cacheManager;

	private static final String CACHE_KEY = "MSG_DTLS";
	private static final String UNDER_SCORE = "_";
	
	
	@Override
	public Map<String, String> getAllMsgDetails() {
		Map<String, String> params = new HashMap<>();
		BeanPropertyRowMapper<MsgDetails> rowMapper = BeanPropertyRowMapper.newInstance(MsgDetails.class);
        rowMapper.setPrimitivesDefaultedForNullValue(true);
        List<MsgDetails> listOfMsgs = jdbcTemplate.query("select * from msg_details",rowMapper);
        for(MsgDetails msg: listOfMsgs) {
        	params.put(msg.getMsgName(), msg.getMsgDesc());
        }
		
		return params;
	}

	@Override
	public String fetchMsgValueByMsgName(String programId, String msgName) {
		String value = (String) cacheManager.get(CACHE_KEY + UNDER_SCORE + programId + UNDER_SCORE + msgName);
		if (StringUtils.hasLength(value)) {
			return value;
		}
		log.info("NFC - going to DB programId:{} msgName:{}",programId,msgName);
		return loadFromDB(programId, msgName);
	}

	@Override
	public boolean reloadMsgDetail(String programId, String msgName) {
		Object obj = cacheManager.remove(CACHE_KEY + UNDER_SCORE + programId + UNDER_SCORE + msgName);
		if(obj instanceof Boolean) {
			log.info("Successfully Removed from cache - programId:{} msgName:{}",programId,msgName);
			return (Boolean)obj;
		}
		else return false;
	}

	private String loadFromDB(String programId, String msgName) {
		var msgDesc = jdbcTemplate.queryForObject("select msg_desc from msg_details where msg_name=?",String.class, msgName);
		cacheManager.put(CACHE_KEY + UNDER_SCORE + programId + UNDER_SCORE + msgName, msgDesc);
		return msgDesc;
	}

}
