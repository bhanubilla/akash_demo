package com.wibmo.dfs.wallet.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
public class AutoTopupRenewal implements Serializable {
	private static final long serialVersionUID = 1L;

	
	private long id;
	private long subId;
	private String txnId;
	private String txnDesc;
	private String authStatus;
	private String creditStatus;
	private String refundStatus;
	private Timestamp createdTime;
	private Timestamp updatedTime;

}
