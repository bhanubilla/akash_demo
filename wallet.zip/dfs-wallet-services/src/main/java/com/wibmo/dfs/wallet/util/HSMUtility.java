package com.wibmo.dfs.wallet.util;

import java.net.URI;

import com.wibmo.dfs.wallet.request.HSMRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class HSMUtility {
	@Autowired
	private Environment env;

	@Autowired
	private RestTemplate restTemplate;

	public String encrypt(HSMRequest data) {
		log.info("start hsmEncryption()");
		URI uri = URI.create(env.getProperty("encryption.url"));
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<HSMRequest> entity = new HttpEntity<>(data, headers);
		ResponseEntity<String> result = restTemplate.postForEntity(uri, entity, String.class);
		return result.getBody();
	}

	public String decrypt(HSMRequest data) {
		log.info("start hsmDecryption() ");
		URI uri = URI.create(env.getProperty("decryption.url"));
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<HSMRequest> entity = new HttpEntity<>(data, headers);
		ResponseEntity<String> result = restTemplate.postForEntity(uri, entity, String.class);
		return result.getBody();
	}
}