package com.wibmo.dfs.wallet.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.sql.Date;

@Data
@NoArgsConstructor
public class W2AConsumption implements Serializable {
    private static final long serialVersionUID = 1L;
    private int id;
    private String txnType;
    private int customerId;
    private int cntLmt;
    private long amtLmt;
    private String limitKey;
    private Date lastTxnTime;
}
