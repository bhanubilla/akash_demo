package com.wibmo.dfs.wallet.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class W2ADebitRequest {
    @ApiModelProperty(required = false, dataType="String", hidden = true)
    private String custId;

    @ApiModelProperty(required = true, dataType="int")
    private int walletId;

    @ApiModelProperty(required = true, dataType="long")
    private long finalAmount;

    @ApiModelProperty(required = true, dataType="long")
    private long txnAmount;

    @ApiModelProperty(required = false, dataType="String")
    private String mcc;

    @ApiModelProperty(required = true, dataType="String")
    private String rrn;

    @ApiModelProperty(required = true, dataType="String", example="Load Money", notes="possible values are Load Money, P2M, W2A, P2P Credit and P2P Debit, etc")
    private String txnType;

    @ApiModelProperty(required = true, dataType="String")
    private String merchantId;

    @ApiModelProperty(hidden = true, required = false, dataType="String")
    private String sourceAccount;

    @ApiModelProperty(hidden = true, required = true, dataType="String")
    private long feeAmount;

    @ApiModelProperty(hidden = true, required = true, dataType="String")
    private long gstAmount;

    @ApiModelProperty(hidden = true, required = true, dataType="String")
    private long cgstAmount;

    @ApiModelProperty(hidden = true, required = true, dataType="String")
    private long sgstAmount;

    @ApiModelProperty(hidden = true, required = true, dataType="String")
    private String feeGstPercentage;

    @ApiModelProperty(hidden = true, required = true, dataType="String", notes = "This is used for Txn history transaction description")
    private String beneficiaryAccountName;

    @ApiModelProperty(hidden = true, required = true, dataType="String", notes = "This is used for Txn history transaction description")
    private String beneficiaryVpaName;

    @ApiModelProperty(hidden = true, required = true, dataType="String", notes = "This is used for Txn history transaction description")
    private String beneficiaryAccountNumber;
    
    @ApiModelProperty(hidden = true, required = true, dataType="String", notes = "This is used for Txn history transaction description")
    private String beneficiaryVpa;


}