package com.wibmo.dfs.wallet.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class W2ATransactionRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	private int beneficiaryId;
    private String txnType;
    private long txnAmt;
    private int sourceRefId;
    private String vpaName;

}
