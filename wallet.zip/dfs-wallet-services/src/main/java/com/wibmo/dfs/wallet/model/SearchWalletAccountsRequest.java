package com.wibmo.dfs.wallet.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SearchWalletAccountsRequest {

	@ApiModelProperty(required = true, dataType="String", notes = "Mobile# is required")
	private String mobile;

	@ApiModelProperty(required = false, dataType="String")
	private String productType;
}
