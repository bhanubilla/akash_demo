/**
 * 
 */
package com.wibmo.dfs.wallet.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;

import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.entity.SMUserConsumption;
import com.wibmo.dfs.hsm_client.CryptoException;
import com.wibmo.dfs.hsm_client.CryptoHandler;
import com.wibmo.dfs.wallet.util.CommonUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * @author rajasekhar.kaniti
 *
 */
@Slf4j
@Repository
public class SMSenderConsumptionRepositoryImpl implements SMSenderConsumptionRepository {
	private static final String INSERT_QUERY = "INSERT INTO SM_SENDER_CONSUMPTION (CUSTOMER_ID, LIMIT_KEY, CARD_NUMBER, TOTAL) values(?,?,?,?)";
	private static final String UPDATE_QUERY = "UPDATE SM_SENDER_CONSUMPTION SET TOTAL=TOTAL + ? WHERE date(last_txn_time) between ? and ? and CUSTOMER_ID=? AND CARD_NUMBER=? AND LIMIT_KEY=?";
	private static final String FETCH_BY_CUST_CARD_KEY_QUERY = "SELECT * FROM SM_SENDER_CONSUMPTION WHERE date(last_txn_time) between ? and ? and CUSTOMER_ID=? AND CARD_NUMBER=? AND LIMIT_KEY=?";

	private static final String FETCH_BY_CUST_KEYS_QUERY = "SELECT * FROM SM_SENDER_CONSUMPTION WHERE date(last_txn_time) between ? and ? and CUSTOMER_ID=? AND CARD_NUMBER=? ";

	private static final String MONTH_PARAMS = "from month : {}, to month : {}";
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	CryptoHandler hsm;

	@Override
	public int saveOrUpdate(List<SMUserConsumption> smUserCon, int bankId) {
		int count = 0;
		for (SMUserConsumption cons : smUserCon) {
			SMUserConsumption ee = fetchByCustIdCardHashAndKey(cons.getCustomerId(), cons.getCardNumber(), bankId,
					cons.getLimitKey());
			if (null != ee) {
				log.debug("customer : {}, key : {} exists", cons.getCustomerId(), cons.getLimitKey());
				count += update(cons, bankId);
			} else {
				log.debug("customer : {}, doesn't have key :{} , saving now..", cons.getCustomerId(),
						cons.getLimitKey());
				count += save(cons, bankId);
			}
		}
		return count;
	}

	@Override
	public int save(SMUserConsumption smUserCon, int bankId) {
		try {
			smUserCon.setCardNumber(hsm.secureData(bankId, smUserCon.getCardNumber()));
		} catch (CryptoException e) {
			log.debug(e.getMessage());
		}
		return jdbcTemplate.update(INSERT_QUERY, smUserCon.getCustomerId(), smUserCon.getLimitKey(),
				smUserCon.getCardNumber(), smUserCon.getTotal());
	}

	@Override
	public int update(SMUserConsumption smUserCon, int bankId) {
		try {
			smUserCon.setCardNumber(hsm.secureData(bankId, smUserCon.getCardNumber()));
		} catch (CryptoException e) {
			log.debug(e.getMessage());
		}
		Map<String, String> dtsMap = CommonUtil.generateFromAndToDates();
		String fromMonth = dtsMap.get(Constants.START_DATE);
		String toMonth = dtsMap.get(Constants.END_DATE);
		log.debug(MONTH_PARAMS, fromMonth, toMonth);
		return jdbcTemplate.update(UPDATE_QUERY, smUserCon.getTotal(), fromMonth, toMonth, smUserCon.getCustomerId(),
				smUserCon.getCardNumber(), smUserCon.getLimitKey());
	}

	@Override
	public SMUserConsumption fetchByCustIdCardHashAndKey(String customerId, String cardNumber, int bankId, String key) {
		BeanPropertyRowMapper<SMUserConsumption> rowMapper = BeanPropertyRowMapper.newInstance(SMUserConsumption.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		String cardHash = null;
		try {
			cardHash = hsm.secureData(bankId, cardNumber);
		} catch (CryptoException e) {
			log.debug(e.getMessage());
		}
		Map<String, String> dtsMap = CommonUtil.generateFromAndToDates();
		String fromMonth = dtsMap.get(Constants.START_DATE);
		String toMonth = dtsMap.get(Constants.END_DATE);
		log.debug(MONTH_PARAMS, fromMonth, toMonth);
		String hsmCardHash = cardHash;
		List<SMUserConsumption> li = jdbcTemplate.query(FETCH_BY_CUST_CARD_KEY_QUERY, new PreparedStatementSetter() {

			public void setValues(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setString(1, fromMonth);
				preparedStatement.setString(2, toMonth);
				preparedStatement.setString(3, customerId);
				preparedStatement.setString(4, hsmCardHash);
				preparedStatement.setString(5, key);
			}
		}, rowMapper);

		SMUserConsumption userConsumption = !li.isEmpty() ? li.get(0) : null;
		if (null != userConsumption) {
			try {
				userConsumption.setCardNumber(hsm.getClearData(bankId, userConsumption.getCardNumber()));
			} catch (CryptoException e) {
				log.debug(e.getMessage());
			}
		}
		return userConsumption;
	}

	@Override
	public Map<String, Long> fetchByCustId(String customerId, String cardNumber, int bankId, String... keys) {
		Map<String, Long> custKeys = new HashMap<>();
		BeanPropertyRowMapper<SMUserConsumption> rowMapper = BeanPropertyRowMapper.newInstance(SMUserConsumption.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		String params = Arrays.stream(keys).map(x -> "'" + x + "'").collect(Collectors.joining(",", "(", ")"));
		String cardHash = null;
		try {
			cardHash = hsm.secureData(bankId, cardNumber);
		} catch (CryptoException e) {
			log.debug(e.getMessage());
		}
		Map<String, String> dtsMap = CommonUtil.generateFromAndToDates();
		String fromMonth = dtsMap.get(Constants.START_DATE);
		String toMonth = dtsMap.get(Constants.END_DATE);
		String hsmCardHash = cardHash;
		log.debug(MONTH_PARAMS, fromMonth, toMonth);
		List<SMUserConsumption> li = jdbcTemplate.query(FETCH_BY_CUST_KEYS_QUERY + "and limit_key in" + params,
				new PreparedStatementSetter() {

					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setString(1, fromMonth);
						preparedStatement.setString(2, toMonth);
						preparedStatement.setString(3, customerId);
						preparedStatement.setString(4, hsmCardHash);
					}
				}, rowMapper);
		for (SMUserConsumption smCons : li) {
			custKeys.put(smCons.getLimitKey(), smCons.getTotal());
		}
		return custKeys;
	}

}
