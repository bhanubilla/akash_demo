package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BlockedMobileDetailsReq {
    private String accountNumber;
    private String blockedMobileNumber;
    private String blockedUserName;
}
