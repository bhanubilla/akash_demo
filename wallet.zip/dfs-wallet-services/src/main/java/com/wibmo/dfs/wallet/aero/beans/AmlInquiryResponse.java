package com.wibmo.dfs.wallet.aero.beans;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 *
 * @author Kiran.mai
 */
@Data
@NoArgsConstructor
public class AmlInquiryResponse extends AeroResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    private String availableBalance;
    private String availableAmlLimit;
    private String cardStatus;
    private String lastActivityTimeStamp;
    private String availableDailyAmlLimit;
    private String availableMonthlyAmlLimit;
    private String availableYearlyAmlLimit;
    private String availableMonthlyAmlDebitLimit;
    private String availableDailyAmlDebitLimit;
    private String availableYearlyAmlDebitLimit;
}
