/**
 * 
 */
package com.wibmo.dfs.wallet.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.wibmo.dfs.wallet.entity.AutoTopupRenewal;

/**
 * @author rajasekhar.kaniti
 *
 */
@Repository
public class AutoTopUpAuditRepositoryImpl implements AutoTopUpRenewalRepository {
	
	
	private static final String INSERT_QUERY ="INSERT INTO AUTO_TOPUP_AUDIT ( TXN_ID, TXN_DESC) VALUES (?,?)";
	private static final String UPDATE_AUTH_STATUS_QUERY ="UPDATE AUTO_TOPUP_AUDIT SET TXN_DESC =?, AUTH_STATUS=?  WHERE ID=?";
	private static final String UPDATE_CREDIT_STATUS_QUERY ="UPDATE AUTO_TOPUP_AUDIT SET SUB_ID = ?,TXN_DESC =?,AUTH_STATUS=?, CREDIT_STATUS=? WHERE ID=?";
	private static final String UPDATE_REFUND_STATUS_QUERY ="UPDATE AUTO_TOPUP_AUDIT SET TXN_DESC =?, REFUND_STATUS=? WHERE ID=?";
	private static final String FETCH_BY_TXNID_QUERY ="SELECT * FROM AUTO_TOPUP_AUDIT WHERE TXN_ID = ?";
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int save(AutoTopupRenewal autoTopupAudit) {
		KeyHolder keyHolder = new GeneratedKeyHolder();

		jdbcTemplate.update(connection -> {
			PreparedStatement preparedStmt = connection.prepareStatement(INSERT_QUERY, Statement.RETURN_GENERATED_KEYS);
			int i=1;
			preparedStmt.setString(i++, autoTopupAudit.getTxnId());
			preparedStmt.setString(i++, autoTopupAudit.getTxnDesc());
			
			return preparedStmt;
		}, keyHolder);

		Number key = keyHolder.getKey();
		return null != key? key.intValue():0;
	}

	@Override
	public boolean updateAuthStatus(AutoTopupRenewal autoTopupAudit) {
		int noOfRowsUpdated = jdbcTemplate.update(UPDATE_AUTH_STATUS_QUERY,  autoTopupAudit.getTxnDesc(), autoTopupAudit.getAuthStatus(),
				autoTopupAudit.getId());
		return noOfRowsUpdated == 1;
	}

	@Override
	public boolean updateCreditStatus(AutoTopupRenewal autoTopupAudit) {
		int noOfRowsUpdated = jdbcTemplate.update(UPDATE_CREDIT_STATUS_QUERY, autoTopupAudit.getSubId(),autoTopupAudit.getTxnDesc(),autoTopupAudit.getAuthStatus(), autoTopupAudit.getCreditStatus(),
				autoTopupAudit.getId());
		return noOfRowsUpdated == 1;
	}

	@Override
	public boolean updateRefundStatus(AutoTopupRenewal autoTopupAudit) {
		int noOfRowsUpdated = jdbcTemplate.update(UPDATE_REFUND_STATUS_QUERY, autoTopupAudit.getTxnDesc(), autoTopupAudit.getRefundStatus(),
				autoTopupAudit.getId());
		return noOfRowsUpdated == 1;
	}

	@Override
	public AutoTopupRenewal fetchById(String txnId) {
		BeanPropertyRowMapper<AutoTopupRenewal> rowMapper = BeanPropertyRowMapper.newInstance(AutoTopupRenewal.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<AutoTopupRenewal> li = jdbcTemplate.query(FETCH_BY_TXNID_QUERY, new PreparedStatementSetter() {
	     	   
	     	   public void setValues(PreparedStatement preparedStatement) throws SQLException {
	     	     preparedStatement.setString(1, txnId);
	     	   }
	     	}, rowMapper);
		return !li.isEmpty() ? li.get(0) : null;
	}

}
