package com.wibmo.dfs.wallet.constants;

public enum CardTypes {
	MASTER_CARD("M"), VISA("V");

	private String type;
	
	CardTypes(String type) {
		this.type = type;
	}
	
	public String getType() {
		return this.type;
	}
	
}
