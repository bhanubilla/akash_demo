package com.wibmo.dfs.wallet.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FetchConfigurationResponse {
    private static final long serialVersionUID = 1L;

    private CoolingPeriod coolingPeriod;
    private FeeMaster feeMaster;
    private LimitMaster limitMaster;
}
