package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class QuickpayResponse {
	
	private String txnCategory;
	private String txnType;
	private String description;
	private String payeeVpa;
	private String payerVpa;
	private String payerMobileNumber;
	private long amount;
	private String payeeMobileNumber;
	private String payeeName;
	private String beneficiaryAccountNumber;
	private String beneficiaryMaskedAccountNumber;
	private String ifsc;
	private long txnDate;

	//newly added
	private String iconUrl;
	private String mcc;
	private String txnReference;
	private String refUrl;
	private String refCategory;
	private String udfParams;
	private String status;
}

 