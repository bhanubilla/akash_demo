/**
 * 
 */
package com.wibmo.dfs.wallet.bean;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
public class PaymentCardObjectDetails {
	
	private String cardType;
	private String countryCode;
	private String cardUnion;
	private String bankName;

}
