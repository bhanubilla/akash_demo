/**
 * 
 */
package com.wibmo.dfs.wallet.service;

import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.repository.UserAccountInfoRepository;
import com.wibmo.dfs.wallet.repository.WalletTxnInfoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wibmo.dfs.wallet.entity.FetchTxnDetails;
import com.wibmo.dfs.wallet.entity.UserAccountInfo;
import com.wibmo.dfs.wallet.model.FetchTxnInfoRequest;
import com.wibmo.dfs.wallet.model.FetchTxnInfoResponse;
import com.wibmo.dfs.wallet.model.WibmoResponse;

import lombok.extern.slf4j.Slf4j;

/**
 * @author rajasekhar.kaniti
 *
 */
@Slf4j
@Service
public class WalletTxnServiceImpl implements WalletTxnService {
	@Autowired
	private UserAccountInfoRepository userRepository;
	
	@Autowired
	private WalletTxnInfoRepository walletInfoRepository;
	
	@Override
	public WibmoResponse fetchTxnInfo(FetchTxnInfoRequest fetchTxnInfoRequest) {
		log.info("request for fetch txn info {} ",fetchTxnInfoRequest.getTxnId());
		WibmoResponse wibmoResponse = new WibmoResponse();
		if(Constants.FETCH_TXN_INFO_FOR_LOADMONEY.equalsIgnoreCase(fetchTxnInfoRequest.getCategory())) {
			//Need confirmation from product team, what to fetch and send back to app.
		}else if(Constants.FETCH_TXN_INFO_FOR_SENDMONEY.equalsIgnoreCase(fetchTxnInfoRequest.getCategory())) {
			FetchTxnDetails fetchTxnDetails = walletInfoRepository.fetchTxnInfoByTxnId(fetchTxnInfoRequest.getTxnId());
			if(null != fetchTxnDetails && null != fetchTxnDetails.getUserId()) {
				FetchTxnInfoResponse fetchTxnInfoResponse = new FetchTxnInfoResponse();
				UserAccountInfo userAccountInfo = userRepository.fetchByCustId(fetchTxnDetails.getUserId());
				if(Constants.FETCH_TXN_INFO_TXN_TYPE_SEND_MONEY.equals(fetchTxnDetails.getTxnType())) {
					fetchTxnInfoResponse.setTo(fetchTxnDetails.getComments());
					fetchTxnInfoResponse.setFrom(userAccountInfo.getMobile());
				}else if(Constants.FETCH_TXN_INFO_TXN_TYPE_P2P_CREDIT.equals(fetchTxnDetails.getTxnType())){
					fetchTxnInfoResponse.setFrom(fetchTxnDetails.getComments());
					fetchTxnInfoResponse.setTo(userAccountInfo.getMobile());
				}
				wibmoResponse.setResCode(200);
				wibmoResponse.setResDesc("Fetched Txn Info successfully");
				wibmoResponse.setData(fetchTxnInfoResponse);
				
			}
		}else {
			wibmoResponse.setResCode(100);
			wibmoResponse.setResDesc("unknown category type : "+fetchTxnInfoRequest.getCategory());
		}
		
		
		return wibmoResponse;
	}
	

}
