package com.wibmo.dfs.wallet.service;

import com.wibmo.dfs.wallet.model.BlockedMobileDetailsReq;
import com.wibmo.dfs.wallet.model.WibmoResponse;

public interface BlockedMobileNumberDetailsService {
    WibmoResponse block(String programId, BlockedMobileDetailsReq blockedMobileDetailsReq);
    WibmoResponse  fetchBlockedMobileNumbers(String programId, String accountNumber);
    WibmoResponse   fetchBlockedMobileNumber(String accountNumber,String blockedMobileNumber);
    WibmoResponse unBlockMobileNumber(String accountNumber,String unBlockMobileNumber);
}
