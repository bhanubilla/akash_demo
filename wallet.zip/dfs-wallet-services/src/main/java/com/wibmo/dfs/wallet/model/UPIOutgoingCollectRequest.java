package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UPIOutgoingCollectRequest {
    private String payeeVPA;
    private String payerVPA;
    private String payerName;
    private String payeeName;
    private String txnAmount;
    private String walletId;
    private String remarks;
    private String currency;
    private String udfParameters;
}
