package com.wibmo.dfs.wallet.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wibmo.dfs.wallet.model.ITPCheckRequest;
import com.wibmo.dfs.wallet.model.UserACSCheckRequest;
import com.wibmo.dfs.wallet.model.WibmoResponse;
import com.wibmo.dfs.wallet.service.UserACSService;
import com.wibmo.dfs.wallet.util.CommonUtil;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/wallet/itp")
public class WalletITPController {

	@Autowired
	private UserACSService userACSService;
	
	@ApiOperation(value="ITP Check API")
	@ApiResponses(value={
			@ApiResponse(code = 0, message = "Success",response =WibmoResponse.class),
			@ApiResponse(code = 101, message = "Card not found",response =WibmoResponse.class),
			@ApiResponse(code = 103, message = "cardNumber not passed (or) phoneNumber not passed (or) Internal error",response =WibmoResponse.class),
			@ApiResponse(code = 107, message = "Mobile number not found or not verified",response =WibmoResponse.class),
			
	})

	@PostMapping("/{bankId}/userCheck/v1")
	public String userCheck(@PathVariable("bankId") String bankId, @RequestBody ITPCheckRequest request){
		Thread.currentThread().setName("ITP Check");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), request.getPhoneNumber());
		StringBuilder resultString = new StringBuilder(50);
		Calendar cal = new GregorianCalendar();
		SimpleDateFormat ddMMyyyyHHmmssFormat = new SimpleDateFormat("ddMMyyyyHHmmss");
		resultString.append("response_timestamp=").append(ddMMyyyyHHmmssFormat.format(cal.getTime())).append("&");
		log.info("Bank Id : {} phoneNumber : {}",bankId,request.getPhoneNumber());

		if (StringUtils.isBlank(request.getPan())) {
			resultString.append("error_code=").append("103");
			resultString.append("&");
			resultString.append("error_desc=").append("cardNumber not passed");
			return resultString.toString();
		}

		if (StringUtils.isBlank(request.getPhoneNumber())) {
			resultString.append("error_code=").append("103");
			resultString.append("&");
			resultString.append("error_desc=").append("phoneNumber not passed");
			return resultString.toString();
		}
		
		UserACSCheckRequest userCheckACSReq = new UserACSCheckRequest();
		
		userCheckACSReq.setBankId(bankId);
		userCheckACSReq.setDob(request.getDob());
		userCheckACSReq.setMobileNo(request.getPhoneNumber());
		userCheckACSReq.setWalletCardNumber(request.getPan());
		
		return userACSService.userCheck(userCheckACSReq, resultString);
	}
}
