/**
 * 
 */
package com.wibmo.dfs.wallet.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.wibmo.dfs.wallet.entity.AutoTopupSubscriptions;

/**
 * @author rajasekhar.kaniti
 *
 */
@Repository
public class AutoTopupSubscriptionRepositoryImpl implements AutoTopupSubscriptionRepository {
	private static final String INSERT_QUERY = "INSERT INTO AUTO_TOPUP_SUBSCRIPTIONS (CUSTOMER_ID, MERCHANT_REF_ID, SUB_DESC) VALUES (?,?,?)";
	private static final String FETCH_BY_ID_QUERY = "SELECT * FROM AUTO_TOPUP_SUBSCRIPTIONS WHERE ID = ?";
	private static final String FETCH_STATUS_QUERY = "SELECT THRESHOLD_AMT, TOPUP_AMT,STATUS, CARD_NUMBER, REMARKS FROM AUTO_TOPUP_SUBSCRIPTIONS WHERE CUSTOMER_ID = ? AND STATUS='A'  ORDER BY ID DESC limit 1";
	private static final String UPDATE_REFUND_STATUS = "UPDATE AUTO_TOPUP_SUBSCRIPTIONS SET REFUND_STATUS=?,SUB_DESC =? WHERE ID=?";
	private static final String FETCH_BY_CUST_MERREF_ID = "SELECT * FROM AUTO_TOPUP_SUBSCRIPTIONS WHERE CUSTOMER_ID=? AND MERCHANT_REF_ID = ?";
	private static final String FETCH_BY_CUST_ID = "SELECT * FROM AUTO_TOPUP_SUBSCRIPTIONS WHERE CUSTOMER_ID=?  ORDER BY ID DESC limit 1";
	private static final String UPDATE_STATUS = "UPDATE AUTO_TOPUP_SUBSCRIPTIONS SET STATUS=?, REMARKS=?, SUB_DESC =?, PAYMENT_REF_ID=? WHERE ID=?";
	private static final String UPDATE_QUERY = "UPDATE AUTO_TOPUP_SUBSCRIPTIONS SET WALLET_ID=?,THRESHOLD_AMT=?, TOPUP_AMT=?, STATUS=?, CARD_NUMBER =?, WIBMO_TXN_ID=?, REMARKS=?,SUB_DESC =? WHERE ID=?";
	private static final String FETCH_STATUS_BY_CUSTID = "SELECT ID, THRESHOLD_AMT, TOPUP_AMT,STATUS, CARD_NUMBER, REMARKS FROM AUTO_TOPUP_SUBSCRIPTIONS WHERE CUSTOMER_ID = ? ORDER BY ID DESC limit 1";
	private static final String UPDATE_SUBSCRIPTION = "UPDATE AUTO_TOPUP_SUBSCRIPTIONS SET THRESHOLD_AMT=?, TOPUP_AMT=?, STATUS=?, PAYMENT_REF_ID=? WHERE ID=?";
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int save(AutoTopupSubscriptions autoTopupSubscriptions) {
		KeyHolder keyHolder = new GeneratedKeyHolder();

		jdbcTemplate.update(connection -> {
			PreparedStatement preparedStmt = connection.prepareStatement(INSERT_QUERY, Statement.RETURN_GENERATED_KEYS);
			int i = 1;
			preparedStmt.setString(i++, autoTopupSubscriptions.getCustomerId());
			preparedStmt.setString(i++, autoTopupSubscriptions.getMerchantRefId());
			preparedStmt.setString(i++, autoTopupSubscriptions.getSubDesc());

			return preparedStmt;
		}, keyHolder);

		Number key = keyHolder.getKey();
		return null != key ? key.intValue() : 0;
	}

	@Override
	public AutoTopupSubscriptions fetchById(long id) {
		BeanPropertyRowMapper<AutoTopupSubscriptions> rowMapper = BeanPropertyRowMapper
				.newInstance(AutoTopupSubscriptions.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<AutoTopupSubscriptions> li = jdbcTemplate.query(FETCH_BY_ID_QUERY, new PreparedStatementSetter() {

			public void setValues(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setLong(1, id);
			}
		}, rowMapper);
		return !li.isEmpty() ? li.get(0) : null;
	}

	@Override
	public AutoTopupSubscriptions fetchStatus(String customerId) {
		BeanPropertyRowMapper<AutoTopupSubscriptions> rowMapper = BeanPropertyRowMapper
				.newInstance(AutoTopupSubscriptions.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<AutoTopupSubscriptions> list = jdbcTemplate.query(FETCH_STATUS_QUERY, new PreparedStatementSetter() {

			public void setValues(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setString(1, customerId);
			}
		}, rowMapper);
		return !list.isEmpty() ? list.get(0) : null;
	}

	@Override
	public boolean updateRefundStatus(AutoTopupSubscriptions autoTopupSubscriptions) {
		int noOfRowsUpdated = jdbcTemplate.update(UPDATE_REFUND_STATUS, autoTopupSubscriptions.getRefundStatus(),
				autoTopupSubscriptions.getSubDesc(), autoTopupSubscriptions.getId());
		return noOfRowsUpdated == 1;
	}

	@Override
	public boolean updateSubscription(AutoTopupSubscriptions autoTopupSubscriptions) {
		int noOfRowsUpdated = jdbcTemplate.update(UPDATE_SUBSCRIPTION, autoTopupSubscriptions.getThresholdAmt(),
				autoTopupSubscriptions.getTopupAmt(), autoTopupSubscriptions.getStatus(),
				autoTopupSubscriptions.getPaymentRefId(), autoTopupSubscriptions.getId());
		return noOfRowsUpdated == 1;
	}

	@Override
	public AutoTopupSubscriptions fetchByMerRefIdAndCustId(String customerId, String merchantRefId) {
		BeanPropertyRowMapper<AutoTopupSubscriptions> rowMapper = BeanPropertyRowMapper
				.newInstance(AutoTopupSubscriptions.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<AutoTopupSubscriptions> li = jdbcTemplate.query(FETCH_BY_CUST_MERREF_ID, new PreparedStatementSetter() {

			public void setValues(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setString(1, customerId);
				preparedStatement.setString(2, merchantRefId);
			}
		}, rowMapper);
		return !li.isEmpty() ? li.get(0) : null;
	}

	@Override
	public AutoTopupSubscriptions fetchByCustId(String customerId) {
		BeanPropertyRowMapper<AutoTopupSubscriptions> rowMapper = BeanPropertyRowMapper
				.newInstance(AutoTopupSubscriptions.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<AutoTopupSubscriptions> li = jdbcTemplate.query(FETCH_BY_CUST_ID, new PreparedStatementSetter() {

			public void setValues(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setString(1, customerId);
			}
		}, rowMapper);
		return !li.isEmpty() ? li.get(0) : null;
	}

	@Override
	public boolean updateStatus(AutoTopupSubscriptions autoTopupSubscriptions) {
		int noOfRowsUpdated = jdbcTemplate.update(UPDATE_STATUS, autoTopupSubscriptions.getStatus(),
				autoTopupSubscriptions.getRemarks(), autoTopupSubscriptions.getSubDesc(),
				autoTopupSubscriptions.getPaymentRefId(), autoTopupSubscriptions.getId());
		return noOfRowsUpdated == 1;
	}

	@Override
	public int update(AutoTopupSubscriptions autoTopupSubscriptions) {
		return jdbcTemplate.update(UPDATE_QUERY, autoTopupSubscriptions.getWalletId(),
				autoTopupSubscriptions.getThresholdAmt(), autoTopupSubscriptions.getTopupAmt(),
				autoTopupSubscriptions.getStatus(), autoTopupSubscriptions.getCardNumber(),
				autoTopupSubscriptions.getWibmoTxnId(), autoTopupSubscriptions.getRemarks(),
				autoTopupSubscriptions.getSubDesc(), autoTopupSubscriptions.getId());
	}

	@Override
	public AutoTopupSubscriptions fetchStatusByCustId(String customerId) {
		BeanPropertyRowMapper<AutoTopupSubscriptions> rowMapper = BeanPropertyRowMapper
				.newInstance(AutoTopupSubscriptions.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<AutoTopupSubscriptions> li = jdbcTemplate.query(FETCH_STATUS_BY_CUSTID, new PreparedStatementSetter() {

			public void setValues(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setString(1, customerId);
			}
		}, rowMapper);
		return !li.isEmpty() ? li.get(0) : null;
	}

}
