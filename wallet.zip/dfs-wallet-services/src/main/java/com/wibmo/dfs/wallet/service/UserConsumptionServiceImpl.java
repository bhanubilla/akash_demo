package com.wibmo.dfs.wallet.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wibmo.dfs.wallet.repository.MsgsRepository;
import org.apache.http.HttpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.wallet.bean.UserLimitsRequest;
import com.wibmo.dfs.wallet.common.MsgConstants;
import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.entity.LMUserConsumption;
import com.wibmo.dfs.wallet.entity.SMUserConsumption;
import com.wibmo.dfs.wallet.model.FetchKycLimitsRequest;
import com.wibmo.dfs.wallet.model.UserVelocityCheck;
import com.wibmo.dfs.wallet.model.UserVelocityLimits;
import com.wibmo.dfs.wallet.model.WibmoResponse;
import com.wibmo.dfs.wallet.repository.LMUserConsumptionRepository;
import com.wibmo.dfs.wallet.repository.SMRecipientConsumptionRepository;
import com.wibmo.dfs.wallet.repository.SMSenderConsumptionRepository;
import com.wibmo.dfs.wallet.util.CommonUtil;

import lombok.extern.slf4j.Slf4j;

import javax.ws.rs.core.MediaType;

@Service
@Slf4j
public class UserConsumptionServiceImpl implements UserConsumptionService {

	private static final String DD_MMYYYY = "ddMMYYYY";

	private static final String MMYYYY = "MMYYYY";

	@Autowired
	private LMUserConsumptionRepository repository;

	@Autowired
	private SMSenderConsumptionRepository smConsumptionRepo;

	@Autowired
	private SMRecipientConsumptionRepository smRecipientConsumptionRepo;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private MsgsRepository msgsRepository;

	@Value("${resource.url.userlimits}")
	private String limitServiceUrl;

	@Override
	public WibmoResponse chkVelocityLimits(UserVelocityCheck request, String bankId) {
		long val = request.getVal();
		String txnType = request.getTxnType();
		int kycLevel = request.getKycLevel();
		String customerId = request.getCustomerId();
		String cardNumber = request.getCardNumber();
		WibmoResponse limitsResp = null;
		limitsResp = fetchLimits(request, txnType, kycLevel, customerId, cardNumber, limitsResp, bankId);
		UserVelocityLimits velocityLimits = null;
		WibmoResponse response = new WibmoResponse(200, "Success");
		if (null != limitsResp && null != limitsResp.getData()) {
			ObjectMapper mapper = new ObjectMapper();
			List<UserVelocityLimits> li = mapper.convertValue(limitsResp.getData(),
					new TypeReference<List<UserVelocityLimits>>() {
					});
			velocityLimits = li.get(0);

			// max Amt per txn chk
			if (val > velocityLimits.getMaxAmtPerTxn()) {
				String velocityAmt = CommonUtil.decimalFormat(velocityLimits.getMaxAmtPerTxn());
				response.setResCode(300);
				response.setResDesc(String.format(
						msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.MAX_AMT_PER_TXN_EXCEEDED), velocityAmt));
				return response;
			}

			String lmCntDaily = txnType + "_C_" + CommonUtil.generateFormat(DD_MMYYYY);
			String lmCntMonthly = txnType + "_C_" + CommonUtil.generateFormat(MMYYYY);
			String lmAmtDaily = txnType + "_A_" + CommonUtil.generateFormat(DD_MMYYYY);
			String lmAmtMonthly = txnType + "_A_" + CommonUtil.generateFormat(MMYYYY);
			Map<String, String> keys = new HashMap<>();
			keys.put("lmCntDaily", lmCntDaily);
			keys.put("lmCntMonthly", lmCntMonthly);
			keys.put("lmAmtDaily", lmAmtDaily);
			keys.put("lmAmtMonthly", lmAmtMonthly);
			// chking lm txn Amt&count daily, monthly
			Map<String, Long> custKeys = new HashMap<>();
			custKeys = fetchConsumptionKeys(request, cardNumber, lmCntDaily, lmCntMonthly, lmAmtDaily, lmAmtMonthly,
					custKeys);

			setMissingkeys(lmCntDaily, lmCntMonthly, lmAmtDaily, lmAmtMonthly, custKeys);

			validateVelocityLimits(val, velocityLimits, response, custKeys, keys, bankId);
		} else {
			// limits not found
			response.setResCode(300);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.KYC_LMT_NOT_FOUND));
		}
		return response;
	}

	private WibmoResponse validateVelocityLimits(long val, UserVelocityLimits velocityLimits, WibmoResponse response,
			Map<String, Long> custKeys, Map<String, String> keys, String bankId) {
		for (Map.Entry<String, Long> userCons : custKeys.entrySet()) {
			if (userCons.getKey().equals(keys.get("lmCntMonthly"))
					&& (velocityLimits.getMonthlyLimitCnt() < userCons.getValue() + 1)) {
				response.setResCode(300);
				response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.MONTHLY_LMT_CNT_EXCEEDED));
				return response;
			} else if (userCons.getKey().equals(keys.get("lmAmtMonthly"))
					&& (velocityLimits.getMonthlyLimitAmt() < userCons.getValue() + val)) {
				long amt = velocityLimits.getMonthlyLimitAmt() - userCons.getValue();
				String velocityAmt = CommonUtil.decimalFormat(amt);
				response.setResCode(300);
				response.setResDesc(String.format(
						msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.MONTHLY_LMT_AMT_EXCEEDED), velocityAmt));
				return response;
			} else if (userCons.getKey().equals(keys.get("lmCntDaily"))
					&& (velocityLimits.getDailyLimitCnt() < userCons.getValue() + 1)) {
				response.setResCode(300);
				response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.DAILY_LMT_CNT_EXCEEDED));
				return response;
			} else if (userCons.getKey().equals(keys.get("lmAmtDaily"))
					&& (velocityLimits.getDailyLimitAmt() < userCons.getValue() + val)) {
				long amt = velocityLimits.getDailyLimitAmt() - userCons.getValue();
				String velocityAmt = CommonUtil.decimalFormat(amt);
				response.setResCode(300);
				response.setResDesc(String.format(
						msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.DAILY_LMT_AMT_EXCEEDED), velocityAmt));
				return response;
			}
		}
		return null;
	}

	private void setMissingkeys(String lmCntDaily, String lmCntMonthly, String lmAmtDaily, String lmAmtMonthly,
			Map<String, Long> custKeys) {
		if (custKeys.size() < 4) {
			custKeys.computeIfAbsent(lmCntDaily, k -> 0l);
			custKeys.computeIfAbsent(lmCntMonthly, k -> 0l);
			custKeys.computeIfAbsent(lmAmtDaily, k -> 0l);
			custKeys.computeIfAbsent(lmAmtMonthly, k -> 0l);
		}
	}

	private Map<String, Long> fetchConsumptionKeys(UserVelocityCheck request, String cardNumber, String lmCntDaily,
			String lmCntMonthly, String lmAmtDaily, String lmAmtMonthly, Map<String, Long> custKeys) {
		String customerId = request.getCustomerId();
		String txnType = request.getTxnType();
		if ("LM".equalsIgnoreCase(txnType)) {
			custKeys = repository.fetchByCustId(customerId, request.getProductType(), lmCntMonthly, lmCntDaily,
					lmAmtMonthly, lmAmtDaily);
		} else if ("P2P".equalsIgnoreCase(txnType)) {
			custKeys = smConsumptionRepo.fetchByCustId(customerId, cardNumber, Integer.parseInt(request.getBankId()),
					lmCntMonthly, lmCntDaily, lmAmtMonthly, lmAmtDaily);
		} else if ("P2PR".equalsIgnoreCase(txnType)) {
			custKeys = smRecipientConsumptionRepo.fetchByCustId(customerId, cardNumber,
					Integer.parseInt(request.getBankId()), lmCntMonthly, lmCntDaily, lmAmtMonthly, lmAmtDaily);
		}
		return custKeys;
	}

	private WibmoResponse fetchLimits(UserVelocityCheck request, String txnType, int kycLevel, String customerId,
			String cardNumber, WibmoResponse limitsResp, String bankId) {
		if (txnType.equalsIgnoreCase("LM") || txnType.equalsIgnoreCase("P2PR")) {
			limitsResp = fetchKycLimits(request, bankId);
		} else if ("P2P".equalsIgnoreCase(txnType)) {
			limitsResp = fetchUserLimits(customerId, cardNumber, kycLevel, txnType, bankId);
		}
		return limitsResp;
	}

	private WibmoResponse fetchKycLimits(UserVelocityCheck request, String bankId) {
		FetchKycLimitsRequest kycreq = new FetchKycLimitsRequest();
		kycreq.setKycLevel(request.getKycLevel());
		kycreq.setTxnType(request.getTxnType());
		WibmoResponse limitsResp = null;
		try {

			limitsResp = CommonUtil.invokeApi(restTemplate, HttpMethod.POST, limitServiceUrl,
					Constants.FETCH_KYC_LIMITS_EP, bankId, kycreq);

		} catch (Exception e) {
			log.error("limit service api exception :" + e.getMessage());
		}
		return limitsResp;
	}

	@Override
	public boolean updateUserConsumption(UserVelocityCheck request) {
		String customerId = request.getCustomerId();
		long val = request.getVal();
		String txnType = request.getTxnType();
		String productType = request.getProductType();
		List<LMUserConsumption> cons = new ArrayList<>();
		cons.add(new LMUserConsumption(customerId, txnType + "_C_" + CommonUtil.generateFormat(DD_MMYYYY), 1,
				productType));
		cons.add(
				new LMUserConsumption(customerId, txnType + "_C_" + CommonUtil.generateFormat(MMYYYY), 1, productType));
		cons.add(new LMUserConsumption(customerId, txnType + "_A_" + CommonUtil.generateFormat(DD_MMYYYY), val,
				productType));
		cons.add(new LMUserConsumption(customerId, txnType + "_A_" + CommonUtil.generateFormat(MMYYYY), val,
				productType));
		int count = repository.saveOrUpdate(cons);
		return count == cons.size();
	}

	private WibmoResponse fetchUserLimits(String customerId, String cardNumber, int kycLevel, String txnType, String bankId) {
		WibmoResponse userLimitsResponse = null;
		UserLimitsRequest userLimits = new UserLimitsRequest();
		userLimits.setCardNumber(cardNumber);
		userLimits.setKycLevel(kycLevel);
		userLimits.setTxnType(txnType);
		userLimits.setDeafultKycLimits(true);
		try {
			MultiValueMap<String, String> custHeader = populateCustomHeaders(customerId, bankId);
			userLimitsResponse = CommonUtil.invokeApi(restTemplate, HttpMethod.POST, limitServiceUrl,
					Constants.FETCH_USR_LIMITS_EP,  userLimits, custHeader);
		} catch (Exception e) {
			log.error("UserLimit service exception :{} ", e.getMessage());
		}
		return userLimitsResponse;

	}

	@Override
	public boolean updateSMUserConsumption(String customerId, String cardNumber, long val, String txnType, int bankId) {
		log.info("UserConsumptionServiceImpl :: updateSMUserConsumption()");
		List<SMUserConsumption> cons = new ArrayList<>();
		cons.add(new SMUserConsumption(customerId, txnType + "_C_" + CommonUtil.generateFormat(DD_MMYYYY), cardNumber,
				1));
		cons.add(new SMUserConsumption(customerId, txnType + "_C_" + CommonUtil.generateFormat(MMYYYY), cardNumber, 1));
		cons.add(new SMUserConsumption(customerId, txnType + "_A_" + CommonUtil.generateFormat(DD_MMYYYY), cardNumber,
				val));
		cons.add(new SMUserConsumption(customerId, txnType + "_A_" + CommonUtil.generateFormat(MMYYYY), cardNumber,
				val));
		int count = 0;
		if ("P2P".equalsIgnoreCase(txnType)) {
			count = smConsumptionRepo.saveOrUpdate(cons, bankId);
		} else if ("P2PR".equalsIgnoreCase(txnType)) {
			count = smRecipientConsumptionRepo.saveOrUpdate(cons, bankId);
		}

		return count == cons.size();
	}

	private MultiValueMap<String, String> populateCustomHeaders(String customerId, String programId) {
		MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
		custHeader.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
		custHeader.add(Constants.PROGRAM_ID, programId);
		custHeader.add(Constants.USER_ID, customerId);
		return custHeader;
	}

}
