package com.wibmo.dfs.wallet.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TxnEnquiry {

	private String wibmoTxnId;
	private String merTxnId;
	private boolean chargeSuccess;
	private String cardType;
	private int txnAmt;
	private String pgTxnId;
	private String cardClassificationType;
	private String cardMasked;
	private String pgStatusCode;
}
