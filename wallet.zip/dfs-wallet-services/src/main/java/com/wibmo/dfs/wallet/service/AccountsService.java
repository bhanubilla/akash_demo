package com.wibmo.dfs.wallet.service;

import com.wibmo.dfs.wallet.model.*;

public interface AccountsService {

	WibmoResponse addAccount(LinkAccountsRequest request,int bankId);
	
	WibmoResponse fetchAccounts(FetchAccountsRequest request,int bankId);
	
	WibmoResponse deleteAccounts(UnlinkAccountsRequest request, String bankId);
	
	WibmoResponse updateNickName(UpdateNickNameRequest updateNickNameReq, String bankId);
	
	WibmoResponse fetchLinkedCards(FetchLinkedCardsRequest request, int bankId);
	
	WibmoResponse fetchWallets(FetchWalletsRequest request, String bankId);
	WibmoResponse autoLinkCard(BulkLinkAccountsRequest request, int bankId);
	
	WibmoResponse validateLinkedCard(ValidateLinkedCardRequest request, int bankId);

	WibmoResponse checkWalletCard(CheckWalletCardRequest request, String bankId);
	
	WibmoResponse searchWalletAccounts(SearchWalletAccountsRequest request, String bankId);
	
	WibmoResponse addBenficiaryBankAccount(BeneficaryBankAccountRequest request, int bankId);
	
	WibmoResponse fetchBenficiaryBankAccounts(String customerId, int bankId, FetchBeneficiary fetchBeneficiary);

	WibmoResponse fetchUserDetails(String customerId, String bankId);

	WibmoResponse fetchSpecificBeneficiaryBankAccount(String customerId, int bankId, int beneficiaryId);
}
