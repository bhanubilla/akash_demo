package com.wibmo.dfs.wallet.model;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class W2UPIVerificationRequest {
	@NotNull
	private String sourceRefId;
	@NotNull
	private String txnType;
	private int beneficiaryId;
	@NotNull
	private long txnAmt;
	private String beneficiaryAccountNumber;
	private String beneficiaryIfscCode;
	private String beneficiaryName;
	private String vpa;
}
