package com.wibmo.dfs.wallet.aero.beans;

import java.io.Serializable;

/**
 * 
 * @author meriyala.raghavendra
 *
 */
public class CardInquiryRequest extends AeroRequest implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
	private String blockType;
	private String reserved1;
	private String reserved2;

    public String getBlockType() {
        return blockType;
    }

    public void setBlockType(String blockType) {
        this.blockType = blockType;
    }

    public String getReserved1() {
        return reserved1;
    }

    public void setReserved1(String reserved1) {
        this.reserved1 = reserved1;
    }

    public String getReserved2() {
        return reserved2;
    }

    public void setReserved2(String reserved2) {
        this.reserved2 = reserved2;
    }

}
