package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PushNotificationData {
    private String txnRefNumber;
    private String payeeName;
    private long requestedDate;
    private long expiryDate;
    private String txnMode;
    private String txnAmount;
    private String desc;
    private String payeeMobileNumber;
    private String payeeVPA;
}
