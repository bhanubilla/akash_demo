/**
 * 
 */
package com.wibmo.dfs.wallet.entity;

import java.io.Serializable;
import java.sql.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
public class SMUserConsumption implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String customerId;
	private String limitKey;
	private String cardNumber;
	private long total;
	private Date txnTime;
	
	public SMUserConsumption(String customerId, String limitKey, String cardHash, long total) {
		this.customerId = customerId;
		this.limitKey = limitKey;
		this.cardNumber = cardHash;
		this.total = total;
	}
	
	

}
