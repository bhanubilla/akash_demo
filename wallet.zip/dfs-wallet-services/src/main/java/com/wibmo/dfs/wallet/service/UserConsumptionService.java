package com.wibmo.dfs.wallet.service;

import com.wibmo.dfs.wallet.model.UserVelocityCheck;
import com.wibmo.dfs.wallet.model.WibmoResponse;

public interface UserConsumptionService {

	WibmoResponse chkVelocityLimits(UserVelocityCheck request, String bankId);
	
	boolean updateUserConsumption(UserVelocityCheck request);
	
	boolean updateSMUserConsumption(String customerId,String cardNumber, long val, String txnType,int bankId);
}
