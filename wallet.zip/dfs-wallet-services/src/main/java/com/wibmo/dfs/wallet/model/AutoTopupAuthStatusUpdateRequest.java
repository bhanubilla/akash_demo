/**
 * 
 */
package com.wibmo.dfs.wallet.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
public class AutoTopupAuthStatusUpdateRequest {
	
	@ApiModelProperty(required = false, dataType="String", hidden = true)
	private String customerId;
	
	@ApiModelProperty(required = false, dataType="long")
	private long walletId;
	
	@ApiModelProperty(required = true, dataType="int")
	private int thresholdAmt;
	
	@ApiModelProperty(required = true, dataType="long")
	private long topupAmt;
	
	@ApiModelProperty(required = true, dataType="String")
	private String merchnatTxnId;
	
	@ApiModelProperty(required = true, dataType="String")
	private String wibmoTxnId;
	
	@ApiModelProperty(required = true, dataType="String")
	private String chargeAttempted;
	
	@ApiModelProperty(required = true, dataType="boolean")
	private boolean authentication;
	
	@ApiModelProperty(required = true, value = "txnDate",
	        example = "Txn Date should be like YYYYmmDD  Ex: 20210205")
	private String txnDate;
	
	@ApiModelProperty(required = true, dataType="long")
	private long recurringPaymentRefId;
	
	

}
