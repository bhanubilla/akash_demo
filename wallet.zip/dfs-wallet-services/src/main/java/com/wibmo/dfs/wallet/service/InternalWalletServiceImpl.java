package com.wibmo.dfs.wallet.service;

import com.wibmo.dfs.wallet.aero.entity.AeroCMSConf;
import com.wibmo.dfs.wallet.aero.entity.ProductMaster;
import com.wibmo.dfs.wallet.aero.repository.AeroCmsConfRepository;
import com.wibmo.dfs.wallet.aero.repository.AeroCmsProductMasterRepository;
import com.wibmo.dfs.wallet.constants.CardTypes;
import com.wibmo.dfs.wallet.entity.PrepaidBankMapping;
import com.wibmo.dfs.wallet.entity.WalletCard;
import com.wibmo.dfs.wallet.model.WalletDetailsRequest;
import com.wibmo.dfs.wallet.model.WibmoResponse;
import com.wibmo.dfs.wallet.repository.WalletCardRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class InternalWalletServiceImpl implements InternalWalletService{
    @Autowired
    private WalletCardRepository walletCardRepository;
    @Autowired
    private AeroCmsConfRepository aeroConfRepository;

    @Autowired
    private AeroCmsProductMasterRepository aeroPMRepository;

    @Autowired
    private WalletServiceFactory walletServiceFactory;

    @Override
    public WibmoResponse persistWalletDetails(WalletDetailsRequest request, String programId) {
        WalletCard walletCards = new WalletCard();
        WibmoResponse response = new WibmoResponse();
        try {
            walletServiceFactory.getService(programId);
            PrepaidBankMapping mapping = walletServiceFactory.fetchBankMapping();
            AeroCMSConf cmsConfig = aeroConfRepository.fetchByPPBankId(mapping.getId(), mapping.getBankId());
            ProductMaster productConfig = aeroPMRepository.fetchByBankAndProdutType(mapping.getBankId(),
                    request.getProductType());
            if (null == productConfig) {
                response.setResCode(6);
                response.setResDesc("Unknown Product Type : "+ request.getProductType());
                return response;
            }
            walletCards.setCardNumber(request.getLast4digits());
            walletCards.setCardType(CardTypes.VISA.getType());
            walletCards.setCustomerId(request.getCustomerId());
            walletCards.setPpBankId(cmsConfig.getPpBankId());
            walletCards.setProductType(productConfig.getProductType());
            walletCards.setBankUrn(Long.toString(request.getUrn()));
            walletCards.setDebitAllowed(true);
            walletCards.setCreditAllowed(true);
            walletCards.setHostCustomerId(request.getHostCustomerId());
            int walletId = walletCardRepository.save(walletCards, programId);
            log.info("Wallet has been created :: {}",walletId);
            response.setResCode(200);
            response.setResDesc("SUCCESS");
            response.setData(String.valueOf(walletId));
        }catch (Exception ex){
            log.info("Exception while persisting wallet details :: {}",ex);
            response.setResCode(500);
            response.setErrorMessage("Request could not be processed at this time, please retry again");
            return response;
        }
        return response;
    }
}
