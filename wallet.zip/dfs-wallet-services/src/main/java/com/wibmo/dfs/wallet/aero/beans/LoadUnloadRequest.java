/**
 * 
 */
package com.wibmo.dfs.wallet.aero.beans;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
public class LoadUnloadRequest extends AeroRequest implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private String agentComments;
    private long transactionAmount;
    private long destinationAccountType;
    private String sourceAccountType;
    private String sourceAccount;
    private String originalClientTxnId;
    private String reserved1;
    private String reserved2;
    private String reserved3;
    private String reserved4;
    private String reserved5;
    private String productId;

}
