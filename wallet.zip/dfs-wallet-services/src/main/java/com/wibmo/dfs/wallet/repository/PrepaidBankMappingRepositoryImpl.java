package com.wibmo.dfs.wallet.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.wibmo.dfs.cache_client.manager.DfsCacheManager;
import com.wibmo.dfs.wallet.constants.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;

import com.wibmo.dfs.wallet.entity.PrepaidBankMapping;
import com.wibmo.dfs.wallet.entity.PrepaidMaster;

@Repository
@Slf4j
public class PrepaidBankMappingRepositoryImpl implements PrepaidBankMappingRepository{

	@Autowired
    private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private PrepaidMasterRepository prepaidMasterRepository;

	@Autowired
	private DfsCacheManager cacheManager;

	private static final String CACHE_KEY = "PP_BNK_MPNG";
	
	@Override
	public PrepaidBankMapping fetchByBankId(String programId) {
		PrepaidBankMapping value = (PrepaidBankMapping) cacheManager.get(CACHE_KEY + Constants.UNDER_SCORE + programId );
		if (null != value) {
			return value;
		}
		log.info("NFC - going to DB programId:{} id:{}",programId);
		return loadFromDB(programId);
	}

	private PrepaidBankMapping loadFromDB(String programId) {
		BeanPropertyRowMapper<PrepaidBankMapping> rowMapper = BeanPropertyRowMapper.newInstance(PrepaidBankMapping.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<PrepaidBankMapping> li = jdbcTemplate.query("select * from prepaid_bank_mapping where bank_id = ?", new PreparedStatementSetter() {

			public void setValues(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setString(1, programId);
			}
		}, rowMapper);
		if(li.isEmpty()) {
			return null;
		}
		PrepaidMaster pm = prepaidMasterRepository.fetchById(li.get(0).getPpId(), programId);
		PrepaidBankMapping pbm = li.get(0);
		pbm.setPpMaster(pm);
		cacheManager.put(CACHE_KEY + Constants.UNDER_SCORE + programId, pbm);
		return pbm;
	}


	@Override
	public int save(PrepaidBankMapping pmaster) {
		return 0;
	}

	@Override
	public PrepaidBankMapping fetchById(int id, String programId) {
		PrepaidBankMapping value = (PrepaidBankMapping) cacheManager.get(CACHE_KEY + Constants.UNDER_SCORE + programId + Constants.UNDER_SCORE + id);
		if (null != value) {
			return value;
		}
		log.info("NFC - going to DB programId:{} id:{}",programId, id);
		return loadFromDB(id, programId);
	}

	@Override
	public boolean reloadPPBnkMapping(String programId, int ppBnkId) {
		Object obj = cacheManager.remove(CACHE_KEY + Constants.UNDER_SCORE + programId + Constants.UNDER_SCORE + ppBnkId);
		if(obj instanceof Boolean) {
			log.info("Successfully Removed from cache - programId:{} ppBnkId:{}",programId,ppBnkId);
			return (Boolean)obj;
		}
		else return false;
	}

	@Override
	public boolean reloadBankId(String programId) {
		Object obj = cacheManager.remove(CACHE_KEY + Constants.UNDER_SCORE + programId );
		if(obj instanceof Boolean) {
			log.info("Successfully Removed from cache - programId:{} ",programId);
			return (Boolean)obj;
		}
		else return false;
	}

	private PrepaidBankMapping loadFromDB(int id, String programId) {
		BeanPropertyRowMapper<PrepaidBankMapping> rowMapper = BeanPropertyRowMapper.newInstance(PrepaidBankMapping.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<PrepaidBankMapping> li = jdbcTemplate.query("select * from prepaid_bank_mapping where id = ?", new PreparedStatementSetter() {

			public void setValues(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setInt(1, id);
			}
		}, rowMapper);
		PrepaidBankMapping ppm = !li.isEmpty()? li.get(0) : null;
		if(null != ppm) cacheManager.put(CACHE_KEY + Constants.UNDER_SCORE + programId + Constants.UNDER_SCORE + id, ppm);
		return ppm;
	}

}
