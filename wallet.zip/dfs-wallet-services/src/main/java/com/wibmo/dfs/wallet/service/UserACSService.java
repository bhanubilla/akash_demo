/**
 * 
 */
package com.wibmo.dfs.wallet.service;

import com.wibmo.dfs.wallet.model.UserACSCheckRequest;

/**
 * @author rajasekhar.kaniti
 *
 */
public interface UserACSService {
	
	String userCheck(UserACSCheckRequest userCheckACSReq, StringBuilder resultString);

}
