package com.wibmo.dfs.wallet.aero.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;

import com.wibmo.dfs.wallet.aero.entity.ProductMaster;

@Repository
public class AeroCmsProductMasterRepositoryImpl implements AeroCmsProductMasterRepository{

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public ProductMaster fetchByBankAndProdutType(String bankId, String productType) {
		BeanPropertyRowMapper<ProductMaster> rowMapper = BeanPropertyRowMapper.newInstance(ProductMaster.class);
        rowMapper.setPrimitivesDefaultedForNullValue(true);
        List<ProductMaster> li = jdbcTemplate.query("select * from aero_cms_product_master where bank_id = ? and product_type=?", new PreparedStatementSetter() {
      	   
      	   public void setValues(PreparedStatement preparedStatement) throws SQLException {
      	      preparedStatement.setString(1, bankId);
      	     preparedStatement.setString(2, productType);
      	   }
      	},rowMapper);
        return !li.isEmpty() ? li.get(0) : null;
	}

}
