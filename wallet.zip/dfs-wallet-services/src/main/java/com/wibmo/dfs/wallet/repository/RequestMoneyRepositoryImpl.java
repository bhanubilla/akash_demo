package com.wibmo.dfs.wallet.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.List;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.wibmo.dfs.wallet.entity.RequestMoneyTxnInfo;

@Repository
@Slf4j
public class RequestMoneyRepositoryImpl implements RequestMoneyRepository {

	private static final String INSERT_INTO_REQUEST_MONEY_TXN_INFO = "INSERT INTO rm_txn_info"
			+ " (TXN_ID, requster_customer_id, requstee_customer_id, amount,"
			+ "rm_status, req_type, source_type, destination_type, CREATED_DT, REMARKS, INITIATE_FROM)"
			+ " VALUES (?,?,?,?,?,?,?,?,?,?,?)";

	private static final String SELECT_FROM_RM_TXN_INFO = "SELECT * FROM rm_txn_info ";
	private static final String SELECT_FROM_REQUESTEE_CUSTOMER_ID = SELECT_FROM_RM_TXN_INFO
			+ "WHERE requstee_customer_id = ? AND rm_status = ?";

	private static final String SELECT_FROM_BLOCKED_USER_PENDING_LIST = "SELECT * FROM rm_txn_info"
			+ " WHERE requstee_customer_id = ? AND requster_customer_id = ? AND rm_status = ?";

	private static final String SELECT_FROM_ID = SELECT_FROM_RM_TXN_INFO + "WHERE ID = ?";

	private static final String REQUEST_MONEY_UPDATE_QUERY = "UPDATE rm_txn_info SET"
			+ " rm_status =?, REMARKS =? WHERE ID = ? ";

	private static final String SELECT_FROM_TXN_ID = SELECT_FROM_RM_TXN_INFO + "WHERE TXN_ID = ?";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int saveRequestMoney(RequestMoneyTxnInfo txnInfo) {
		KeyHolder keyHolder = new GeneratedKeyHolder();

		jdbcTemplate.update(connection -> {
			PreparedStatement ps = connection.prepareStatement(INSERT_INTO_REQUEST_MONEY_TXN_INFO,
					Statement.RETURN_GENERATED_KEYS);
			int i = 1;

			ps.setString(i++, txnInfo.getTxnId());
			ps.setString(i++, txnInfo.getRequsterCustomerId());
			ps.setString(i++, txnInfo.getRequsteeCustomerId());
			ps.setLong(i++, txnInfo.getAmount());
			ps.setString(i++, txnInfo.getRmStatus());
			ps.setString(i++, txnInfo.getReqType());
			ps.setString(i++, txnInfo.getSourceType());
			ps.setString(i++, txnInfo.getDestinationType());
			ps.setTimestamp(i++, new Timestamp(txnInfo.getCreatedDt().getTime()));
			ps.setString(i++, txnInfo.getRemarks());
			ps.setString(i++, txnInfo.getInitiateFrom());

			return ps;
		}, keyHolder);

		Number value = keyHolder.getKey();
		return null != value ? value.intValue() : 0;

	}

	@Override
	public List<RequestMoneyTxnInfo> fetchByRequesteeCustomerId(String requesteeCustomerId, String status) {
		BeanPropertyRowMapper<RequestMoneyTxnInfo> rowMapper = BeanPropertyRowMapper
				.newInstance(RequestMoneyTxnInfo.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		return jdbcTemplate.query(SELECT_FROM_REQUESTEE_CUSTOMER_ID, new PreparedStatementSetter() {

			public void setValues(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setString(1, requesteeCustomerId);
				preparedStatement.setString(2, status);
			}
		}, rowMapper);
	}

	@Override
	public List<RequestMoneyTxnInfo> fetchBlockedUserPendingList(String requesteeCustomerId,String requesterCustomerId, String status) {
		BeanPropertyRowMapper<RequestMoneyTxnInfo> rowMapper = BeanPropertyRowMapper
				.newInstance(RequestMoneyTxnInfo.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		//requstee_customer_id = ? AND requster_customer_id = ? AND rm_status = ?
		return jdbcTemplate.query(SELECT_FROM_BLOCKED_USER_PENDING_LIST, new PreparedStatementSetter() {

			public void setValues(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setString(1, requesteeCustomerId);
				preparedStatement.setString(2, requesterCustomerId);
				preparedStatement.setString(3, status);
			}
		}, rowMapper);
	}

	@Override
	public RequestMoneyTxnInfo fetchById(String id) {
		log.info("RequestMoneyTxnInfo :: id ..... : {}",id);
		BeanPropertyRowMapper<RequestMoneyTxnInfo> rowMapper = BeanPropertyRowMapper
				.newInstance(RequestMoneyTxnInfo.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		return jdbcTemplate.queryForObject(SELECT_FROM_ID, rowMapper, id);
	}

	@Override
	public int updateRequestMoneyTxnInfo(RequestMoneyTxnInfo txnInfo) {
		return jdbcTemplate.update(connection -> {
			PreparedStatement ps = connection.prepareStatement(REQUEST_MONEY_UPDATE_QUERY,
					Statement.RETURN_GENERATED_KEYS);
			int i = 1;

			ps.setString(i++, txnInfo.getRmStatus());
			ps.setString(i++, txnInfo.getRemarks());
			ps.setInt(i++, txnInfo.getId());

			return ps;
		});
	}

	@Override
	public RequestMoneyTxnInfo fetchByTxnId(String id) {
		log.info("RequestMoneyTxnInfo :: fetchByTxnId  ..... txnId: {}",id);
		BeanPropertyRowMapper<RequestMoneyTxnInfo> rowMapper = BeanPropertyRowMapper
				.newInstance(RequestMoneyTxnInfo.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		return jdbcTemplate.queryForObject(SELECT_FROM_TXN_ID, rowMapper, id);
	}

}
