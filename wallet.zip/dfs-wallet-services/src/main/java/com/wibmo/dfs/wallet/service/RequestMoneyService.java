package com.wibmo.dfs.wallet.service;


import com.wibmo.dfs.wallet.model.*;


public interface RequestMoneyService {
	
	WibmoResponse processRequestMoney(RMRequest requestMoneyReq, WibmoResponse response, String bankId);
	
	WibmoResponse fetchRequestMoneyDetails(FetchRMRequest fetchRMRequest, WibmoResponse response, String bankId);
	
	WibmoResponse acceptRequestMoney(RMAcceptRequest rmAcceptRequest, WibmoResponse response, String bankId);
	
	WibmoResponse acceptUpiRequestMoneyConfirm(RMAcceptConfirmRequest rmAcceptConfirmRequest, WibmoResponse response, String bankId);

	WibmoResponse incomingCollectRequest(String bankId, String accountId, IncomingCollectRequest incomingCollectRequest);

	WibmoResponse initiateRequestMoney(OutgoingCollectRequest request, String bankId, String userId);

	WibmoResponse fetchRequestMoneyDetails(String userId, WibmoResponse response, String bankId, PendingCollectMoneyRequest pendingCollectMoneyRequest);

	WibmoResponse fetchQuickPayDetails(String bankId, String userId, QuickPayRequest quickPayRequest);
}
