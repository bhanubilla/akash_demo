package com.wibmo.dfs.wallet.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.wallet.adapter.util.AESGCMPayLoadEncryption;
import com.wibmo.dfs.wallet.aero.beans.EncLoadUnloadResponse;
import com.wibmo.dfs.wallet.model.*;
import com.wibmo.dfs.wallet.service.AccountsService;
import com.wibmo.dfs.wallet.service.TransactionService;
import com.wibmo.dfs.wallet.service.WalletService;
import com.wibmo.dfs.wallet.service.WalletServiceFactory;
import com.wibmo.dfs.wallet.service.WalletToAccountService;
import com.wibmo.dfs.wallet.util.CommonUtil;
import com.wibmo.dfs.wallet.util.WibmoResponseUtil;
import com.wibmo.dfs.wallet.validation.RequestValidator;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/wallet")
public class WalletController {
	

	private static final String ERROR_DESC = "Error Desc : {}";
	@Autowired
	private WalletServiceFactory findService;
	
	@Autowired
	private TransactionService transactionService;
	
	@Autowired
	WalletToAccountService walletToAccountService;
	
	@Autowired
	AccountsService accountService;

	@Autowired
	private RequestValidator validator;


	@Autowired
	AESGCMPayLoadEncryption aesgcmPayLoadEncryption;
	private String  privateKey = "KbPdSgVkYp3s6v9y";
	/**
	 * This API is used for virtual card creation.It creates the Static Virtual Card (SVC). It is applicable for debit cards only.
	 *  create wallet card if user does not have wallet card. 
	 *  else will return existing wallet card data 
	 * @param createCard Request Body
	 * @param bankId Client Id
	 * @return WibmoResponse
	 */

	@PostMapping("/message/decrypt")
	public String decryptResponse (@RequestBody EncLoadUnloadResponse encrptedResp ,
								   @RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId){
		return aesgcmPayLoadEncryption.decrypt(encrptedResp.getToken(),privateKey);
	}
	@ApiOperation(value="Create Card", response=WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 1, message = "card created successfully",response=WibmoResponse.class),
			@ApiResponse(code = 2, message = "impl id not found",response=WibmoResponse.class),
			@ApiResponse(code = 3, message = "internal server error",response=WibmoResponse.class),
			@ApiResponse(code = 5, message = "card is present already",response=WibmoResponse.class),
			@ApiResponse(code = 6, message = "Unknown Product Type",response=WibmoResponse.class),
			@ApiResponse(code = 20, message = "request is empty",response=WibmoResponse.class),
			@ApiResponse(code = 21, message = "product type is empty",response=WibmoResponse.class),
			@ApiResponse(code = 24, message = "Bad Request!!! user info is missing",response=WibmoResponse.class),
			@ApiResponse(code = 25, message = "account info is missing",response=WibmoResponse.class),
			@ApiResponse(code = 27, message = "kyc level is empty",response=WibmoResponse.class),
			@ApiResponse(code = 26, message = "customer id is empty",response=WibmoResponse.class),
			@ApiResponse(code = 31, message = "first name is empty",response=WibmoResponse.class),
			@ApiResponse(code = 33, message = "email id is empty",response=WibmoResponse.class),
			@ApiResponse(code = 34, message = "invalid date format",response=WibmoResponse.class),
			@ApiResponse(code = 35, message = "gender is empty",response=WibmoResponse.class),
			@ApiResponse(code = 42, message = "addresslinee is empty",response=WibmoResponse.class),
			@ApiResponse(code = 43, message = "city code is empty",response=WibmoResponse.class),
			@ApiResponse(code = 44, message = "zip code is empty",response=WibmoResponse.class),
			@ApiResponse(code = 45, message = "country code is empty",response=WibmoResponse.class),
			@ApiResponse(code = 30, message = "profile info is missing",response=WibmoResponse.class),
			@ApiResponse(code = 40, message = "address info is missing",response=WibmoResponse.class)
			
	})

	@PostMapping("/create/api/v1")
	public ResponseEntity<WibmoResponse> create(@RequestBody CreateCard createCard,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId)  {
		// setting userId
		createCard.getUser().getAccount().setCustomerId(userId);
		Thread.currentThread().setName("CreateCard");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), createCard.getUser().getAccount().getCustomerId());
		WibmoResponse response = new WibmoResponse();
		validator.validateCreateCard(createCard, response, bankId);
		if (response.getResCode() > 0) {
			log.info(ERROR_DESC,response.getResDesc());
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		WalletService ws = findService.getService(bankId);
		return WibmoResponseUtil.frameResponse(ws.create(createCard));

	}

	/**
	 * This API is used to process transfer debit transactions from SVC
	 * @param fundUnloadReq
	 * @param bankId
	 * @return WibmoResponse
	 */
	@ApiOperation(value = "Debit Fund", response = WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 1, message = "funds debited successfully",response=WibmoResponse.class),
			@ApiResponse(code = 2, message = "Invalid wallet Id Passed (or) impl id not found (or) debit funds is disabled for this card"
					+ "impl id not found (or) card not found (or) Failure (or) prepaid response is null",response=WibmoResponse.class),
			@ApiResponse(code = 3, message = "internal server error",response=WibmoResponse.class),
			@ApiResponse(code = 20, message = "request is empty",response=WibmoResponse.class),
			@ApiResponse(code = 26, message = "customer id is empty",response=WibmoResponse.class),
			@ApiResponse(code = 37, message = "amount is zero",response=WibmoResponse.class),
			@ApiResponse(code = 38, message = "wallet id is zero",response=WibmoResponse.class),
			@ApiResponse(code =36 , message = "rrn is empty",response=WibmoResponse.class),
			@ApiResponse(code =101 , message = "txn type is empty",response=WibmoResponse.class),
			@ApiResponse(code =102 , message = "Merchant Id is empty",response=WibmoResponse.class)
	})
	@PostMapping("/debit/api/v1")
	public ResponseEntity<WibmoResponse> debitFund(@RequestBody FundRequest fundUnloadReq,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		fundUnloadReq.setCustId(userId);
		Thread.currentThread().setName("DebitFund");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), fundUnloadReq.getCustId());
		WibmoResponse response = new WibmoResponse();
		validator.validateCreditDebitRequest(fundUnloadReq, response, bankId);
		if (response.getResCode() > 0) {
			log.info(ERROR_DESC,response.getResDesc());
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		WalletService ws = findService.getService(bankId);	
		
		return WibmoResponseUtil.frameResponse(ws.fundsUnload(fundUnloadReq));

	}

	/**
	 * This API is used to process transfer credit transactions from SVC
	 * @param fundLoadReq
	 * @param bankId
	 * @return WibmoResponse
	 */
	@ApiOperation(value = "Credit Fund", response = WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 1, message = "funds credited successfully",response=WibmoResponse.class),
			@ApiResponse(code = 2, message = "Invalid wallet Id Passed (or) credit funds is disabled for this card"
					+ "impl id not found (or) prepaid card details is null (or) Failure (or) prepaid response is null",response=WibmoResponse.class),
			@ApiResponse(code = 3, message = "internal server error",response=WibmoResponse.class),
			@ApiResponse(code = 20, message = "request is empty",response=WibmoResponse.class),
			@ApiResponse(code = 26, message = "customer id is empty",response=WibmoResponse.class),
			@ApiResponse(code = 37, message = "amount is zero",response=WibmoResponse.class),
			@ApiResponse(code = 38, message = "wallet id is zero",response=WibmoResponse.class),
			@ApiResponse(code =35 , message = "mcc is empty",response=WibmoResponse.class),
			@ApiResponse(code =36 , message = "rrn is empty",response=WibmoResponse.class),
			@ApiResponse(code =101 , message = "txn type is empty",response=WibmoResponse.class)
			
	})
	@PostMapping("/credit/api/v1")
	public ResponseEntity<WibmoResponse> creditFund(@RequestBody FundRequest fundLoadReq,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		fundLoadReq.setCustId(userId);
		Thread.currentThread().setName("CreditFund");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), fundLoadReq.getCustId());
		WibmoResponse response = new WibmoResponse();
		validator.validateCreditDebitRequest(fundLoadReq, response, bankId);
		if (response.getResCode() > 0) {
			log.info(ERROR_DESC,response.getResDesc());
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		fundLoadReq.setBankId(bankId);
		WalletService ws = findService.getService(bankId);
		
		return WibmoResponseUtil.frameResponse(ws.fundsLoad(fundLoadReq));

	}
	
	/**
	 * This API is used to Transfer money from one wallet to another wallet
	 * @param sendMoneyReq
	 * @param bankId
	 * @return WibmoResponse
	 */
	@ApiOperation(value = "Send Money", response = WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 2, message = "sender wallet card not found (or) impl id not found (or) card not found "
					+ "(or) Failure (or) prepaid response is null",response=WibmoResponse.class),
			@ApiResponse(code = 3, message = "internal server error",response=WibmoResponse.class),
			@ApiResponse(code = 20, message = "request is empty",response=WibmoResponse.class),
			@ApiResponse(code = 26, message = "customer id is empty",response=WibmoResponse.class),
			@ApiResponse(code = 36, message = "rrn is empty",response=WibmoResponse.class),
			@ApiResponse(code = 37, message = "amount is zero",response=WibmoResponse.class),
			@ApiResponse(code = 38, message = "wallet id is zero",response=WibmoResponse.class),
			@ApiResponse(code = 41, message = "recipient first name is empty",response=WibmoResponse.class),
			@ApiResponse(code = 42, message = "recipient last name is empty",response=WibmoResponse.class),
			@ApiResponse(code = 43, message = "recipient address line1 is empty",response=WibmoResponse.class),
			@ApiResponse(code = 44, message = "recipient city is empty",response=WibmoResponse.class),
			@ApiResponse(code = 45, message = "recipient country is empty",response=WibmoResponse.class),
			@ApiResponse(code = 46, message = "recipient country subdivision is empty",response=WibmoResponse.class),
			@ApiResponse(code = 47, message = "recipient nationality is empty",response=WibmoResponse.class),
			@ApiResponse(code = 48, message = "recipient postal code is empty",response=WibmoResponse.class),
			@ApiResponse(code = 150, message = "sender user account details not available for this mobile number (or) sender user id mismatch for this mobile number"
					+ " (or) The recipient is not a registered Citrus wallet user."
					+ "",response=WibmoResponse.class),
			@ApiResponse(code = 200, message = "money transfered successfully!",response=WibmoResponse.class),
			@ApiResponse(code = 250, message = "debit funds is disabled for this card (or) credit funds is disabled for this card",response=WibmoResponse.class),
			@ApiResponse(code = 300, message = "Your max amount per transaction limit is Rs %s. Please enter a smaller amount. (or) Your remaining limit is Rs %s for this month. Please enter a smaller amount."
					+ " (or) Your remaining limit is Rs %s for today. Please enter a smaller amount. (or) You are not allowed any more transactions this month. Please retry next month."
					+ " (or) You are not allowed any more transactions today. Please retry tomorrow. (or) KYC limits are not found",response =WibmoResponse.class),
			@ApiResponse(code = 350, message = "recipient card number not found",response=WibmoResponse.class)
			
	})
	@PostMapping("/sendmoney/api/v1")
	public ResponseEntity<WibmoResponse> sendMoney(@RequestBody SendMoneyRequest sendMoneyReq,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		sendMoneyReq.setSenderCustomerId(userId);
		Thread.currentThread().setName("SendMoney");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), sendMoneyReq.getSenderCustomerId());
		WibmoResponse response = new WibmoResponse();
		validator.validateSendMoneyRequest(sendMoneyReq, response, bankId);
		if (response.getResCode() > 0) {
			log.info(ERROR_DESC, response.getResDesc());
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		WalletService ws = findService.getService(bankId);	
		
		return WibmoResponseUtil.frameResponse(ws.sendMoney(sendMoneyReq));

	}
	/**
	 * This API is used to Transfer money from one wallet to another wallet
	 * @param p2pRequest
	 * @param bankId
	 * @return WibmoResponse
	 */
	@ApiOperation(value = "send money version #2", response = WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 2, message = "sender wallet card not found (or) impl id not found (or) card not found "
					+ "(or) Failure (or) prepaid response is null",response=WibmoResponse.class),
			@ApiResponse(code = 3, message = "internal server error",response=WibmoResponse.class),
			@ApiResponse(code = 26, message = "customer id is empty",response=WibmoResponse.class),
			@ApiResponse(code = 37, message = "amount is zero",response=WibmoResponse.class),
			@ApiResponse(code = 38, message = "wallet id is zero",response=WibmoResponse.class),
			@ApiResponse(code = 150, message = "sender user account details not available for this mobile number (or) sender user id mismatch for this mobile number"
					+ " (or) The recipient is not a registered Citrus wallet user."
					+ "",response=WibmoResponse.class),
			@ApiResponse(code = 200, message = "money transfered successfully!",response=WibmoResponse.class),
			@ApiResponse(code = 250, message = "debit funds is disabled for this card (or) credit funds is disabled for this card",response=WibmoResponse.class),
			@ApiResponse(code = 300, message = "Your max amount per transaction limit is Rs %s. Please enter a smaller amount. (or) Your remaining limit is Rs %s for this month. Please enter a smaller amount."
					+ " (or) Your remaining limit is Rs %s for today. Please enter a smaller amount. (or) You are not allowed any more transactions this month. Please retry next month."
					+ " (or) You are not allowed any more transactions today. Please retry tomorrow. (or) KYC limits are not found",response =WibmoResponse.class),
			@ApiResponse(code = 350, message = "recipient card number not found",response=WibmoResponse.class),
			@ApiResponse(code = 400, message = "request is empty",response=WibmoResponse.class)
			
	})
	@PostMapping("/sendmoney/api/v2")
	public ResponseEntity<WibmoResponse> processP2P(@RequestBody P2PRequest p2pRequest,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		p2pRequest.setSenderCustomerId(userId);
		Thread.currentThread().setName("sendmoney V2");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), p2pRequest.getSenderCustomerId());
		WibmoResponse response = new WibmoResponse();
		validator.validateP2PRequest(p2pRequest, response, bankId);
		if (response.getResCode() > 0) {
			log.info(ERROR_DESC, response.getResDesc());
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		WalletService ws = findService.getService(bankId);	
		
		return WibmoResponseUtil.frameResponse(ws.processP2P(p2pRequest));

	}
	
	/**
	 * Update flag for Service types Ex: E-com
	 * @param serviceReq
	 * @param bankId
	 * @return
	 */
	@ApiOperation(value = "Update Service Type flag", response = WibmoResponse.class)
	@ApiResponses(value={
	        @ApiResponse(code = 200, message = "flag updated successfully",response =WibmoResponse.class),
	        @ApiResponse(code = 100, message = "Operation failed. Blank response from Aero",response =WibmoResponse.class),
	        @ApiResponse(code = 150, message = "flag updation failed",response =WibmoResponse.class),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class),
	        @ApiResponse(code = 26, message = "customer id is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 38, message = "wallet id is zero",response =WibmoResponse.class),
	        @ApiResponse(code = 400, message = "Request is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 300, message = "Service is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 301, message = "Service type is empty",response =WibmoResponse.class)
	})
	@PostMapping("/update/servicetype/v1")
	public ResponseEntity<WibmoResponse> updateServiceFlag(@RequestBody ServiceTypeRequest serviceReq,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		serviceReq.setCustomerId(userId);
		Thread.currentThread().setName("Update service");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), serviceReq.getCustomerId());
		WibmoResponse response = new WibmoResponse();
		validator.validateServiceTypeUpdate(serviceReq, response, bankId);
		if (response.getResCode() > 0) {
			log.info(ERROR_DESC, response.getResDesc());
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		WalletService ws = findService.getService(bankId);	
		
		return WibmoResponseUtil.frameResponse(ws.updateServiceTypeFlag(serviceReq));
	}
	
	
	@PostMapping("/v1/transaction/sendMoney")
	public ResponseEntity<WibmoResponse> sendMoney(@RequestBody SendMoneyTransactionRequest sendMoneyTransactionReq,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		ObjectMapper obj = new ObjectMapper();
		String sendMoneyTransactionRequestJson;
		try {
			sendMoneyTransactionRequestJson = obj.writeValueAsString(sendMoneyTransactionReq);
			log.debug("sendMoneyTransactionRequest obj : {}", sendMoneyTransactionRequestJson);
		} catch (JsonProcessingException e) {
			log.error("exception in converting sendMoneyTransactionRequest obj to json string format");
			e.printStackTrace();
		}
		Thread.currentThread().setName("v1TransactionsendMoneyService");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), sendMoneyTransactionReq.getBeneficiaryAccountNumber());

		WibmoResponse wr = transactionService.makeTransaction(sendMoneyTransactionReq, bankId, userId);
		return WibmoResponseUtil.frameResponse(wr);
	}

	
	@ApiOperation(value = "Check WalletCard exists or not and retrieve VPA Details of the WalletCard", response = WibmoResponse.class)
	@ApiResponses(value={
	        @ApiResponse(code = 200, message = "Card Validated Successfully",response =WibmoResponse.class),
	        @ApiResponse(code = 100, message = "Card Not found",response =WibmoResponse.class),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class),
	        @ApiResponse(code = 21, message = "product type is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 150, message = "Mobile# or Customer Id is Mandatory",response =WibmoResponse.class),
	})
	@PostMapping("/v1/searchaccounts")
	public ResponseEntity<WibmoResponse> searchWalletAccounts(@RequestBody SearchWalletAccountsRequest request,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId) {
		
		Thread.currentThread().setName("searchWalletAccounts");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), request.getProductType());
		WibmoResponse response = new WibmoResponse();
		//validating the request
		validator.checkWalletAccountDetails(request, response, bankId);
		if (response.getResCode() > 0) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		return WibmoResponseUtil.frameResponse(accountService.searchWalletAccounts(request, bankId));
	}

	@PostMapping("v1/card/block")
	public ResponseEntity<WibmoResponse> blockCard(@RequestBody BlockCardRequest request,
												   @RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber) {

		Thread.currentThread().setName("v1BlockCardService");

		WalletService ws = findService.getService(programId);

		return WibmoResponseUtil.frameResponse(ws.blockCard(request, programId, accountNumber));
	}

	@PostMapping("v1/card/unblock")
	public ResponseEntity<WibmoResponse> unBlockCard(@RequestBody UnBlockCardRequest request,
												   @RequestHeader(value = "X-PROGRAM-ID") String programId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String accountNumber) {

		Thread.currentThread().setName("v1BlockCardService");

		WalletService ws = findService.getService(programId);

		return WibmoResponseUtil.frameResponse(ws.unBlockCard(request, programId, accountNumber));
	}

}
