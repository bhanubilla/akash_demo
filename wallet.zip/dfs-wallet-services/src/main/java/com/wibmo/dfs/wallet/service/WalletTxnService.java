/**
 * 
 */
package com.wibmo.dfs.wallet.service;

import com.wibmo.dfs.wallet.model.FetchTxnInfoRequest;
import com.wibmo.dfs.wallet.model.WibmoResponse;

/**
 * @author rajasekhar.kaniti
 *
 */
public interface WalletTxnService {
	
	WibmoResponse fetchTxnInfo(FetchTxnInfoRequest fetchTxnInfoRequest);

}
