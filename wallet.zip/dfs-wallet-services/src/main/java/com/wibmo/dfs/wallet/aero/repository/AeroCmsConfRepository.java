package com.wibmo.dfs.wallet.aero.repository;

import com.wibmo.dfs.wallet.aero.entity.AeroCMSConf;


public interface AeroCmsConfRepository {

	AeroCMSConf fetchByPPBankId(int ppBankId, String programId);
	boolean reloadAeroCMSConf(String programId, int ppBankId);
}
