package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FetchKycLimitsRequest {

	private String txnType;
	private int kycLevel;
	
}
