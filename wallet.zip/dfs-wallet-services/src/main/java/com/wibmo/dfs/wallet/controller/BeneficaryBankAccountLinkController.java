package com.wibmo.dfs.wallet.controller;

import com.wibmo.dfs.wallet.model.FetchBeneficiary;
import com.wibmo.dfs.wallet.service.AccountsService;
import com.wibmo.dfs.wallet.validation.RequestValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.wibmo.dfs.wallet.model.BeneficaryBankAccountRequest;
import com.wibmo.dfs.wallet.model.WibmoResponse;
import com.wibmo.dfs.wallet.util.CommonUtil;
import com.wibmo.dfs.wallet.util.WibmoResponseUtil;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/wallet/ac")
public class BeneficaryBankAccountLinkController {

	@Autowired
		private AccountsService service;

	@Autowired
	private RequestValidator validator;
	
	@PostMapping("/addbeneficiary/v1")
	@ApiOperation(value = "Add Benificiary Account", response = WibmoResponse.class)
	@ApiResponses(value={
	        @ApiResponse(code = 200, message = "Beneficiary Accounts added successfully",response =WibmoResponse.class),
	        @ApiResponse(code = 150, message = "Beneficiary Accounts addition  failed",response =WibmoResponse.class)
	        
	})
	public ResponseEntity<WibmoResponse> addBankAccount(@RequestBody BeneficaryBankAccountRequest request,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		request.setCustomerId(userId);
		Thread.currentThread().setName("addBeneficiaryAccount");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), request.getCustomerId());
		WibmoResponse response = new WibmoResponse();
		validator.validateBeneficiaryBankAccounts(request, response, bankId);
		if (response.getResCode() > 0) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		return WibmoResponseUtil.frameResponse(service.addBenficiaryBankAccount(request, Integer.parseInt(bankId)));
	}	
	
	@PostMapping("/fetchbeneficiary/v1")
	@ApiOperation(value = "Fetch Benificiary Account(s)", response = WibmoResponse.class)
	@ApiResponses(value={
	        @ApiResponse(code = 200, message = "Beneficiary Accounts fetched successfully",response =WibmoResponse.class),
	        @ApiResponse(code = 150, message = "Beneficiary Accounts not available",response =WibmoResponse.class)
	        
	})
	public ResponseEntity<WibmoResponse> fetchlinkedAccounts(@RequestBody FetchBeneficiary fetchBeneficiary, @RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		Thread.currentThread().setName("fetchBeneficiaryAccounts");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), userId);
		WibmoResponse response = new WibmoResponse();
		validator.validateCustomerId(userId, response, bankId);
		if (response.getResCode() > 0) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		return WibmoResponseUtil.frameResponse(service.fetchBenficiaryBankAccounts(userId, Integer.parseInt(bankId), fetchBeneficiary));
	}
	@GetMapping("/v1/fetch/specificBeneficiary")
	@ApiOperation(value = "Fetch Beneficiary Accounts By Beneficiary Id", response = WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 200, message = "Beneficiary Accounts fetched successfully",response =WibmoResponse.class),
			@ApiResponse(code = 150, message = "Beneficiary Accounts not available",response =WibmoResponse.class)

	})
	public ResponseEntity<WibmoResponse> fetchSpecificBeneficiary(@RequestHeader(value = "BENEFICIARY-ID") int beneficiaryId, @RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		Thread.currentThread().setName("fetchSpecificBeneficiary");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), userId);
		WibmoResponse response = new WibmoResponse();
		validator.validateSpecificBeneficiaryId(beneficiaryId, response,userId , bankId);
		if (response.getResCode() > 0) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		return WibmoResponseUtil.frameResponse(service.fetchSpecificBeneficiaryBankAccount(userId, Integer.parseInt(bankId), beneficiaryId));
	}
}
