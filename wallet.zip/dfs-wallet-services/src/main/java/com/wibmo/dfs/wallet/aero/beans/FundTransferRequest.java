package com.wibmo.dfs.wallet.aero.beans;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author Ajay Mahto
 * 
 */
@Data
@NoArgsConstructor
public class FundTransferRequest extends AeroRequest implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private String agentComments;
    private long transactionAmount;
    private String originalClientTxnId;
    private String sourceAccountType;
    private String sourceAccount;
    
    private Sender[] senders;
    private Receiver[] receivers;
  
}
