package com.wibmo.dfs.wallet.adapter.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EncMobileNoBasedCardInquiryResponse {
    private String token;
}
