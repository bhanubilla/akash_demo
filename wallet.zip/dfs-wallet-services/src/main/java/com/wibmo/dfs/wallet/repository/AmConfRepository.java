package com.wibmo.dfs.wallet.repository;

import com.wibmo.dfs.wallet.entity.AmConf;


public interface AmConfRepository {

	AmConf fetchByBankId(String bankId);
	
	int save(AmConf amConf);
}
