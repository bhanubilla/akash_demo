package com.wibmo.dfs.wallet.aero.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AeroCMSConf implements Serializable {
	private static final long serialVersionUID = 1L;

	private String bankId;
	private String url;
	private String secureCode;
	private String clientId;
	private String entityId;
	private int ppBankId;
	private String sourceAccount;
	private String sourceAccountType;
	private String ppBankCode;
	private Timestamp createdDate;
	private Timestamp updatedDate;
	@JsonIgnore
	private int auditId;
}
