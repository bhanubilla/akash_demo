package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class W2AWholeConsumption {
    private String txnType;
    private int customerId;
    private int beneficiaryId;
    private int beneficiaryCntLmt;
    private long beneficiaryAmtLmt;
    private int dailyCntLmt;
    private long dailyAmtLmt;
    private long weeklyCntLmt;
    private long weeklyAmtLmt;
    private long monthlyCntLmt;
    private long monthlyAmtLmt;
    private String limitKey;
}
