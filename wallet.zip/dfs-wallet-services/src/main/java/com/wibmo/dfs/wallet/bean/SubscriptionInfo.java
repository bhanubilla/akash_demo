/**
 * 
 */
package com.wibmo.dfs.wallet.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubscriptionInfo {
	private String autoPayDesc;
	private String cardAliasName;	
	private String cardMaskedNumber;	
	private String cardRefId;	
	private String merchantName;
	private String nameOnCard;	
	private String nickName;
	private String subscriberName;
	private long recurringPaymentRefId;
	private String merchantId;
	private String subscriberId;
}
