package com.wibmo.dfs.wallet.validation;

import com.wibmo.dfs.wallet.common.MsgConstants;
import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.model.*;
import com.wibmo.dfs.wallet.repository.MsgsRepository;
import com.wibmo.dfs.wallet.util.ApiManagerUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.validator.GenericValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Calendar;
import java.util.Date;


@Component
@Slf4j
public class RequestValidator {

	@Autowired
	private MsgsRepository msgsRepository;

	@Autowired
	private ApiManagerUtil apiManagerUtil;

	public void validateCreateCard(CreateCard createCard, WibmoResponse response, String bankId) {
		if (null == createCard) {
			// bad request
			response.setResCode(20);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if (response.getResCode() == 0)
			validateProduct(createCard.getProductType(), response, bankId);
		if (response.getResCode() == 0)
			validateUser(createCard.getUser(), response, bankId);
	}

	private void validateProduct(String productType, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(productType)) {
			response.setResCode(21);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.PRODUCTTYPE_IS_EMPTY));
		}
	}

	private void validateUser(UserInfo user, WibmoResponse response, String bankId) {
		if (null == user) {
			response.setResCode(24);
			response.setResDesc("Bad Request!!! "
					+ msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.USER_INFO_IS_MISSING));
		} else {
			// chk account level info
			if (response.getResCode() == 0)
				validateAccount(user.getAccount(), response, bankId);
			// chk profile level info
			if (response.getResCode() == 0)
				validateProfile(user.getProfile(), response, bankId);
			// chk address level info
			if (response.getResCode() == 0)
				validateAddress(user.getAddress(), response, bankId);
		}
	}

	private void validateAddress(UserAddress address, WibmoResponse response, String bankId) {
		if (null == address) {
			response.setResCode(40);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.ADDRESS_INFO_IS_MISSING));
		} else {
			if (response.getResCode() == 0)
				validateAddressline(address.getAddressLine(), response, bankId);
			if (response.getResCode() == 0)
				validateCityCode(address.getCityCode(), response, bankId);
			if (response.getResCode() == 0)
				validateZipCode(address.getZipCode(), response, bankId);
			if (response.getResCode() == 0)
				validateCountry(address.getCountry(), response, bankId);
		}
	}

	private void validateAddressline(String line, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(line)) {
			response.setResCode(42);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.ADDRESSLINEE_IS_EMPTY));
		}

	}

	private void validateCityCode(String city, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(city)) {
			response.setResCode(43);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.CITY_CODE_IS_EMPTY));
		}
	}

	private void validateZipCode(String zipCode, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(zipCode)) {
			response.setResCode(44);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.ZIP_CODE_IS_EMPTY));
		}
	}

	private void validateCountry(String country, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(country)) {
			response.setResCode(45);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.COUNTRY_IS_EMPTY));
		}

	}

	private void validateAccount(UserAccount account, WibmoResponse response, String bankId) {
		if (null == account) {
			response.setResCode(25);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.ACCOUNT_INFO_IS_MISSING));
		} else {
			if (response.getResCode() == 0)
				validateCustomerId(account.getCustomerId(), response, bankId);
		}
	}

	public void validateCustomerId(String customerId, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(customerId)) {
			response.setResCode(26);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.CUSTOMER_ID_IS_EMPTY));
		}

	}

	private void validateProfile(UserProfile profile, WibmoResponse response, String bankId) {
		if (null == profile) {
			response.setResCode(30);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.PROFILE_INFO_IS_MISSING));
		} else {
			if (response.getResCode() == 0)
				validateName(profile.getFirstName(), response, bankId);
			if (response.getResCode() == 0)
				validateEmail(profile.getEmail(), response, bankId);
			if (response.getResCode() == 0)
				validateGender(profile.getGender(), response, bankId);
			if (response.getResCode() == 0)
				validateDOB(profile.getDob(), response, bankId);
		}
	}

	private void validateGender(String gender, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(gender)) {
			response.setResCode(35);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.GENDER_IS_EMPTY));
		}

	}

	private void validateName(String name, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(name)) {
			response.setResCode(31);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.FIRST_NAME_IS_EMPTY));
		}
	}

	private void validateMobile(String mobile, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(mobile)) {
			response.setResCode(32);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.MOBILE_NUMBER_IS_EMPTY));
		}
	}

	private void validateEmail(String email, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(email)) {
			response.setResCode(33);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.EMAIL_ID_IS_EMPTY));
		}
	}

	private void validateDOB(String dob, WibmoResponse response, String bankId) {
		if (!StringUtils.isBlank(dob) && (!GenericValidator.isDate(dob, "dd-MM-yyyy", true))) {
			response.setResCode(34);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.INVALID_DATE_FORMAT) + " " + dob);
		}
	}

	private void validateRrn(String rrn, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(rrn)) {
			response.setResCode(36);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.RRN_IS_EMPTY));
		}
	}

	private void validateAmount(long amount, WibmoResponse response, String bankId) {
		if (amount < 100) {
			response.setResCode(37);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.AMOUNT_IS_LESS_THAN_ONE));
		}
	}

	private void validateWalletId(int walletId, WibmoResponse response, String bankId) {
		if (walletId <= 0) {
			response.setResCode(38);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.WALLET_ID_IS_ZERO));
		}
	}

	private void validateProductTypeAndCustId(String productType, String custId,
											  WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(productType) || StringUtils.isBlank(custId)) {
			response.setResCode(39);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.PRODUCT_TYPE_OR_CUST_ID_IS_EMPTY));
		}
	}

	/**
	 * Validate Credit and Debit request
	 */
	public void validateCreditDebitRequest(FundRequest fundRequest, WibmoResponse response, String bankId) {
		if (null == fundRequest) {
			response.setResCode(20);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if (response.getResCode() == 0)
			validateCustomerId(fundRequest.getCustId(), response, bankId);
		if (response.getResCode() == 0)
			validateWalletId(fundRequest.getWalletId(), response, bankId);
		if (response.getResCode() == 0)
			validateAmount(fundRequest.getAmount(), response, bankId);
		if (response.getResCode() == 0)
			validateRrn(fundRequest.getRrn(), response, bankId);
		if (response.getResCode() == 0)
			validateTxnType(fundRequest.getTxnType(), response, bankId);
		if (response.getResCode() == 0 && fundRequest.getTxnType().equals(Constants.W2A_REFUND)) {
			validateOriginalRRN(fundRequest.getOriginalRRN(), response, bankId);
			if(response.getResCode() == 0)
				validateAccountName(fundRequest.getBeneficiaryName(), response, bankId);
		}
	}

	private void validateOriginalRRN(String originalRRN, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(originalRRN)) {
			response.setResCode(74);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.ORIGINAL_RRN_IS_EMPTY));
		}
	}
	/**
	 * Validate CardInquiry Request
	 */
	public void validateCardInquiryRequest(FetchCardRequest request, WibmoResponse response, String bankId) {
		if (null == request) {
			response.setResCode(20);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if (response.getResCode() == 0 && request.getWalletId() < 0) {
			validateProductTypeAndCustId(request.getProductType(), request.getCustomerId(), response, bankId);
		}
	}

	/**
	 * Validate CardStatus Request
	 */
	public void validateCardStatusRequest(FetchCardStatusRequest request, WibmoResponse response, String bankId) {
		if (null == request) {
			response.setResCode(20);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if (response.getResCode() == 0 && request.getWalletId() < 0) {
			validateProductTypeAndCustId(request.getProductType(), request.getCustomerId(), response, bankId);
		}
	}

	/**
	 * Validate CardBalance Request
	 */
	public void validateCardBalanceRequest(FetchCardBalanceRequest request, WibmoResponse response, String bankId) {
		if (null == request) {
			response.setResCode(20);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if (response.getResCode() == 0 && request.getWalletId() < 0) {
			validateProductTypeAndCustId(request.getProductType(), request.getCustomerId(), response, bankId);
		}
	}

	/**
	 * Validate CardCVV Request
	 */
	public void validateCardCVVRequest(FetchCardCVVRequest request, WibmoResponse response, String bankId) {
		if (null == request) {
			response.setResCode(20);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if (response.getResCode() == 0 && request.getWalletId() < 0) {
			validateProductTypeAndCustId(request.getProductType(), request.getCustomerId(), response, bankId);
		}
	}

	public void validateLinkAccount(LinkAccountsRequest request, WibmoResponse response, String bankId) {
		if (null == request) {
			response.setResCode(20);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
		} else {
			if (response.getResCode() == 0)
				validateCustomerId(request.getCustomerId(), response, bankId);
			if (response.getResCode() == 0)
				validateCategory(request.getCategory(), response, bankId);
			if (request.getCategory().equals(Constants.BANK_ACCOUNT)) {
				response.setResCode(300);
				response.setResDesc("unsupported category");
			} else if (request.getCategory().equalsIgnoreCase(Constants.LINKED_CARD) && response.getResCode() == 0) {
				validateLinkedCard(request.getLinkedCardInfo(), response, bankId);
			}

		}
	}

	private void validateCategory(String category, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(category)) {
			response.setResCode(50);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.CATEGORY_IS_EMPTY));
		}
	}

	@SuppressWarnings("unused")
	private void validateBankAccounts(BankAccountsInfo actInfo, WibmoResponse response, String bankId) {
		if (null == actInfo) {
			response.setResCode(51);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.BANK_ACCOUNT_IS_EMPTY));
		} else {
			if (response.getResCode() == 0)
				validateAccountNum(actInfo.getAccountNumber(), response, bankId);
			if (response.getResCode() == 0)
				validateAccountName(actInfo.getAccountName(), response, bankId);
			if (response.getResCode() == 0)
				validateIfsc(actInfo.getIfscCode(), response, bankId);
			if (response.getResCode() == 0)
				validateBankName(actInfo.getBankName(), response, bankId);
			if (response.getResCode() == 0)
				validateAccountType(actInfo.getAccountType(), response, bankId);
		}
	}

	private void validateAccountNum(String actNum, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(actNum)) {
			response.setResCode(52);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.ACCOUNT_NUMBER_IS_EMPTY));
		}
	}

	private void validateAccountName(String actName, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(actName)) {
			response.setResCode(53);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.ACCOUNT_NAME_IS_EMPTY));
		}
	}

	private void validateIfsc(String ifsc, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(ifsc)) {
			response.setResCode(54);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.IFSC_CODE_IS_EMPTY));
		}
	}

	private void validateBankName(String bnkName, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(bnkName)) {
			response.setResCode(55);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.BANK_NAME_IS_EMPTY));
		}
	}

	private void validateAccountType(String actType, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(actType)) {
			response.setResCode(56);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.ACCOUNT_TYPE_IS_EMPTY));
		}
	}

	private void validateLinkedCard(LinkedCardInfo linkedCardInfo, WibmoResponse response, String bankId) {
		if (null == linkedCardInfo) {
			response.setResCode(57);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.LINKEDCARD_INFO_IS_EMPTY));
		} else {
			if (response.getResCode() == 0)
				validateCardNumber(linkedCardInfo.getCardNumber(), response, bankId);
			if (response.getResCode() == 0)
				validateExpiryMM(linkedCardInfo.getCardExpiryMM(), response, bankId);
			if (response.getResCode() == 0)
				validateExpiryYYYY(linkedCardInfo.getCardExpiryYYYY(), response, bankId);
			if (response.getResCode() == 0)
				validateCardExpiryMmAndYyyy(linkedCardInfo.getCardExpiryMM(), linkedCardInfo.getCardExpiryYYYY(),
						response, bankId);
			if (response.getResCode() == 0)
				validateNameOnCard(linkedCardInfo.getNameOnCard(), response, bankId);
			if (response.getResCode() == 0)
				validateAddedSource(linkedCardInfo.getAddedSource(), response, bankId);

		}
	}

	public void validateCardNumber(String cardNumber, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(cardNumber)) {
			response.setResCode(58);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.CARD_NUMBER_IS_EMPTY));
		}
	}

	public void validateExpiryMM(String expiryMM, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(expiryMM)) {
			response.setResCode(59);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.CARD_EXPITY_MM_IS_EMPTY));
		}
	}

	public void validateExpiryYYYY(String expiryYYYY, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(expiryYYYY)) {
			response.setResCode(60);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.CARD_EXPITY_YYYY_IS_EMPTY));
		}
	}

	public void validateNameOnCard(String nameOnCard, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(nameOnCard)) {
			response.setResCode(61);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.NAME_ON_CARD_IS_EMPTY));
		}
	}

	/**
	 * Validate Send Money request
	 */
	public void validateSendMoneyRequest(SendMoneyRequest sendMoneyRequest, WibmoResponse response, String bankId) {
		if (null == sendMoneyRequest) {
			response.setResCode(20);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if (response.getResCode() == 0)
			validateMobile(sendMoneyRequest.getSenderMobileNo(), response, bankId);
		if (response.getResCode() == 0)
			validateAmount(sendMoneyRequest.getAmount(), response, bankId);
		if (response.getResCode() == 0)
			validateWalletId(sendMoneyRequest.getSenderWalletId(), response, bankId);
		if (response.getResCode() == 0)
			validateCustomerId(sendMoneyRequest.getSenderCustomerId(), response, bankId);
		if (response.getResCode() == 0)
			validateMobile(sendMoneyRequest.getRecipientMobileNo(), response, bankId);
		if (response.getResCode() == 0)
			validateRecipientFirstName(sendMoneyRequest.getRecipientFirstName(), response, bankId);
		if (response.getResCode() == 0)
			validateRecipientLastName(sendMoneyRequest.getRecipientLastName(), response, bankId);
		if (response.getResCode() == 0)
			validateRecipientAddrLine1(sendMoneyRequest.getRecipientAddressLine1(), response, bankId);
		if (response.getResCode() == 0)
			validateRecipientCity(sendMoneyRequest.getRecipientCity(), response, bankId);
		if (response.getResCode() == 0)
			validateRecipientCountry(sendMoneyRequest.getRecipientCountry(), response, bankId);
		if (response.getResCode() == 0)
			validateRecipientCountrySubdivision(sendMoneyRequest.getRecipientCountrySubdivision(), response, bankId);
		if (response.getResCode() == 0)
			validateRecipientNationality(sendMoneyRequest.getRecipientNationality(), response, bankId);
		if (response.getResCode() == 0)
			validateRecipientPostalCode(sendMoneyRequest.getRecipientPostalCode(), response, bankId);
		if (response.getResCode() == 0)
			validateRrn(sendMoneyRequest.getRrn(), response, bankId);
	}

	/**
	 */
	public void validateSendMoneyTransactionRequest(SendMoneyTransactionRequest sendMoneyTransactionRequest, WibmoResponse response, String bankId) {
		log.info("validating sendMoneyTransactionRequest");
		if (null == sendMoneyTransactionRequest) {
			response.setResCode(20);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if (response.getResCode() == 0)
			validateMobile(sendMoneyTransactionRequest.getRecipientMobileNo(), response, bankId);
		if (response.getResCode() == 0)
			validateAmount(sendMoneyTransactionRequest.getAmount(), response, bankId);
		if (response.getResCode() == 0)
			validateWalletId(sendMoneyTransactionRequest.getSenderWalletId(), response, bankId);
	}

	public void validateW2UPIDebitRequest(SendMoneyTransactionRequest sendMoneyTransactionRequest, WibmoResponse response, String bankId) {
		if (null == sendMoneyTransactionRequest) {
			response.setResCode(20);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if (response.getResCode() == 0)
			validateWalletId(sendMoneyTransactionRequest.getSenderWalletId(), response, bankId);
		if (response.getResCode() == 0)
			validateAmount(sendMoneyTransactionRequest.getAmount(), response, bankId);
		if (response.getResCode() == 0 && sendMoneyTransactionRequest.getTransactionType().equals(Constants.W2UPI))
			validateRecipientVpa(sendMoneyTransactionRequest.getRecipientvpa(), response, bankId);
	}

	public void validateUPITransactionRequest(SendMoneyTransactionRequest sendMoneyTransactionRequest, WibmoResponse response, String bankId) {
		if (null == sendMoneyTransactionRequest) {
			response.setResCode(20);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if (response.getResCode() == 0 && sendMoneyTransactionRequest.getTransactionType().equals(Constants.W2UPI))
			validateRecipientVpa(sendMoneyTransactionRequest.getRecipientvpa(), response, bankId);
		if (response.getResCode() == 0)
			validateWalletId(sendMoneyTransactionRequest.getSenderWalletId(), response, bankId);
		if (response.getResCode() == 0)
			validateAmount(sendMoneyTransactionRequest.getAmount(), response, bankId);
		if (response.getResCode() == 0 && sendMoneyTransactionRequest.getTransactionType().equals(Constants.W2A))
			validateIfsc(sendMoneyTransactionRequest.getIfsc(), response, bankId);
		if(response.getResCode() == 0 && sendMoneyTransactionRequest.getTransactionType().equals(Constants.W2A))
			validateAccountNum(sendMoneyTransactionRequest.getBeneficiaryAccountNumber(), response, bankId);
		if(response.getResCode() == 0 && sendMoneyTransactionRequest.getTransactionType().equals(Constants.W2A))
			validateAccountName(sendMoneyTransactionRequest.getBeneficiaryName(), response, bankId);
	}

	private void validateRecipientFirstName(String firstName, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(firstName)) {
			response.setResCode(41);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.RECIPIENT_FIRST_NAME_IS_EMPTY));
		}
	}

	private void validateRecipientLastName(String lastName, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(lastName)) {
			response.setResCode(42);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.RECIPIENT_LAST_NAME_IS_EMPTY));
		}
	}

	private void validateRecipientAddrLine1(String addr1esssLine1, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(addr1esssLine1)) {
			response.setResCode(43);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.RECIPIENT_ADDRESS_LINE_ONE_IS_EMPTY));
		}
	}

	private void validateRecipientCity(String city, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(city)) {
			response.setResCode(44);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.RECIPIENT_CITY_IS_EMPTY));
		}
	}

	private void validateRecipientCountry(String country, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(country)) {
			response.setResCode(45);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.RECIPIENT_COUNTRY_IS_EMPTY));
		}
	}

	private void validateRecipientCountrySubdivision(String subdivision, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(subdivision)) {
			response.setResCode(46);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.RECIPIENT_COUNTRY_SUB_DIVISION_IS_EMPTY));
		}
	}

	private void validateRecipientNationality(String nationality, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(nationality)) {
			response.setResCode(47);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.RECIPIENT_NATIONALITY_IS_EMPTY));
		}
	}

	private void validateRecipientPostalCode(String postalCode, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(postalCode)) {
			response.setResCode(48);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.RECIPIENT_POSTAL_CODE_IS_EMPTY));
		}
	}

	private void validateRecipientVpa(String recipientVpa, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(recipientVpa)) {
			response.setResCode(75);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.RECIPIENT_VPA_IS_EMPTY));
		}
	}

	private void validateCardExpiryMmAndYyyy(String cardExpiryMM, String cardExpiryYYYY,
											 WibmoResponse response, String bankId) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(new Date());
		int currentYear = calendar.get(Calendar.YEAR);
		int currentMonth = calendar.get(Calendar.MONTH) + 1;

		if (Integer.parseInt(cardExpiryYYYY) < currentYear) {
			response.setResCode(62);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.CARD_EXPIRY_YEAR_LESS_THAN_CURRENT_YEAR));
			return;
		}

		if (Integer.parseInt(cardExpiryYYYY) == currentYear && Integer.parseInt(cardExpiryMM) < currentMonth) {
			response.setResCode(63);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.CARD_EXPIRY_MONTH_LESS_THAN_CURRENT_MONTH));
		}
	}

	private void validateAddedSource(String addedSource, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(addedSource)) {
			response.setResCode(64);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.CARD_ADDED_SOURCE_IS_EMPTY));
		}
	}

	public void validateFetchAccount(FetchAccountsRequest request, WibmoResponse response, String bankId) {
		if (null == request) {
			response.setResCode(20);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
		} else {
			if (response.getResCode() == 0)
				validateCustomerId(request.getCustomerId(), response, bankId);
		}


	}

	public void validateUnLinkAccount(UnlinkAccountsRequest request, WibmoResponse response, String bankId) {
		if (null == request) {
			response.setResCode(20);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
		} else {
			if (response.getResCode() == 0)
				validateCustomerId(request.getCustomerId(), response, bankId);
			if (response.getResCode() == 0)
				validateId(request.getId(), response, bankId);
			if (response.getResCode() == 0)
				validateCategory(request.getCategory(), response, bankId);
		}
	}

	private void validateId(int id, WibmoResponse response, String bankId) {
		if (id <= 0) {
			response.setResCode(26);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.CARD_ID_IS_EMPTY));
		}

	}

	public void validateUserACSCheckReq(UserACSCheckRequest userCheckACSReq, WibmoResponse response, String bankId) {
		if (null == userCheckACSReq) {
			response.setResCode(20);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
		} else {
			if (response.getResCode() == 0)
				validateBankId(userCheckACSReq.getBankId(), response, bankId);
			if (response.getResCode() == 0)
				validateMobile(userCheckACSReq.getMobileNo(), response, bankId);
			if (response.getResCode() == 0)
				validateCardNumber(userCheckACSReq.getWalletCardNumber(), response, bankId);
		}

	}

	private void validateBankId(String bankId, WibmoResponse response, String bank) {
		if (StringUtils.isBlank(bankId)) {
			response.setResCode(65);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bank,MsgConstants.BANK_ID_IS_EMPTY));
		}

	}

	/**
	 * Validate Txn History request
	 */
	public void validateTxnHistoryRequest(FetchTransactionHistoryRequest txnHistoryReq,
										  WibmoResponse response, String bankId) {
		if (null == txnHistoryReq) {
			response.setResCode(20);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if (response.getResCode() == 0 && txnHistoryReq.getWalletId() < 0) {
			validateProductTypeAndCustId(txnHistoryReq.getProductType(), txnHistoryReq.getCustomerId(), response, bankId);
		}
	}

	public void validateNickNameRequest(UpdateNickNameRequest updateNickNameReq,
										WibmoResponse response, String bankId) {
		if (null == updateNickNameReq) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}

		if (response.getResCode() == 0)
			validateCustomerId(updateNickNameReq.getCustomerId(), response, bankId);
		if (response.getResCode() == 0)
			validateCardRefId(updateNickNameReq.getCardRefId(), response, bankId);
		if (response.getResCode() == 0)
			validateNickName(updateNickNameReq.getNickName(), response, bankId);
	}

	private void validateNickName(String nickName, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(nickName)) {
			response.setResCode(65);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.USER_NICKNAME_IS_EMPTY));
		}

	}

	private void validateCardRefId(long cardRefId, WibmoResponse response, String bankId) {
		if (cardRefId <= 0) {
			response.setResCode(66);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.CARD_ID_IS_EMPTY));
		}

	}

	public void validateP2PRequest(P2PRequest p2pRequest, WibmoResponse response, String bankId) {
		if (null == p2pRequest) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}

		if (response.getResCode() == 0)
			validateCustomerId(p2pRequest.getSenderCustomerId(), response, bankId);
		if (response.getResCode() == 0)
			validateWalletId(p2pRequest.getSenderWalletId(), response, bankId);
		if (response.getResCode() == 0)
			validateMobile(p2pRequest.getRecipientMobileNo(), response, bankId);
		if (response.getResCode() == 0)
			validateAmount(p2pRequest.getAmount(), response, bankId);


	}

	public void validateFetchTxnInfo(FetchTxnInfoRequest fetchTxnInfoRequest, WibmoResponse response, String bankId) {
		if (null == fetchTxnInfoRequest) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}

		if (response.getResCode() == 0)
			validateTxnId(fetchTxnInfoRequest.getTxnId(), response, bankId);
		if (response.getResCode() == 0)
			validateCategory(fetchTxnInfoRequest.getCategory(), response, bankId);
	}

	private void validateTxnId(String txnId, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(txnId)) {
			response.setResCode(65);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.TXN_ID_IS_EMPTY));
		}

	}

	public void validateFetchWalletsRequest(FetchWalletsRequest request, WibmoResponse response, String bankId) {
		if (null == request) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}

		if (response.getResCode() == 0)
			validateCustomerId(request.getCustomerId(), response, bankId);

	}

	public void validateAutoTopupAuthStatusReq(
			AutoTopupAuthStatusUpdateRequest autoTopupAuthStatusUpdateRequest, WibmoResponse response, String bankId) {

		if (null == autoTopupAuthStatusUpdateRequest) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}

		if (response.getResCode() == 0)
			validateCustomerId(autoTopupAuthStatusUpdateRequest.getCustomerId(), response, bankId);
		if (response.getResCode() == 0)
			validateThresholdAmt(autoTopupAuthStatusUpdateRequest.getThresholdAmt(), response, bankId);
		if (response.getResCode() == 0)
			validateTopupAmt(autoTopupAuthStatusUpdateRequest.getTopupAmt(), response, bankId);
		if (response.getResCode() == 0)
			validateMerchantTxnId(autoTopupAuthStatusUpdateRequest.getMerchnatTxnId(), response, bankId);
		if (response.getResCode() == 0)
			validateWibmoTxnId(autoTopupAuthStatusUpdateRequest.getWibmoTxnId(), response, bankId);
		if (response.getResCode() == 0)
			validateChargeAttempted(autoTopupAuthStatusUpdateRequest.getChargeAttempted(), response, bankId);
		if (response.getResCode() == 0)
			validateAuth(autoTopupAuthStatusUpdateRequest.isAuthentication(), response, bankId);
		if (response.getResCode() == 0)
			validateTxndate(autoTopupAuthStatusUpdateRequest.getTxnDate(), response, bankId);
		if (response.getResCode() == 0)
			checkThresholdAndTopupAmt(autoTopupAuthStatusUpdateRequest.getThresholdAmt(),
					autoTopupAuthStatusUpdateRequest.getTopupAmt(), response, bankId);

	}

	private void validateChargeAttempted(String charge, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(charge)) {
			response.setResCode(66);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.CHARGE_ATTEMPT_IS_EMPTY));
		}
	}

	private void validateWibmoTxnId(String txnId, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(txnId)) {
			response.setResCode(67);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.WIBMO_TXN_ID_IS_EMPTY));
		}
	}

	private void validateMerchantTxnId(String merchantTxnId, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(merchantTxnId)) {
			response.setResCode(68);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.MERCHANT_TXN_ID_IS_EMPTY));
		}

	}

	private void validateTopupAmt(long topupAmt, WibmoResponse response, String bankId) {
		if (topupAmt <= 0) {
			response.setResCode(69);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.TOPUP_AMT_IS_ZERO));
		}

	}

	private void validateThresholdAmt(int thresholdAmt, WibmoResponse response, String bankId) {
		if (thresholdAmt <= 0) {
			response.setResCode(70);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.THRESHOLD_AMT_IS_ZERO));
		}
	}

	private void validateAuth(Boolean auth, WibmoResponse response, String bankId) {
		if (null == auth) {
			response.setResCode(71);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.AUTHENTICATION_IS_EMPTY));
		}
	}

	private void validateTxndate(String date, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(date)) {
			response.setResCode(72);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.TXN_DATE_IS_EMPTY));
		}
	}

	private void checkThresholdAndTopupAmt(int thresholdAmt, long topupAmt, WibmoResponse response, String bankId) {
		if (topupAmt < thresholdAmt) {
			response.setResCode(73);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.THRESHOLD_AMT_AND_TOPUP_AMT_CHECK));
		}
	}

	public void validateAutoTopupSubStatusReq(AutoTopupStatusRequest autoTopupStatusRequest,
											  WibmoResponse response, String bankId) {
		if (null == autoTopupStatusRequest) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}

		if (response.getResCode() == 0)
			validateCustomerId(autoTopupStatusRequest.getCustomerId(), response, bankId);
		if (response.getResCode() == 0)
			validateCountryCode(autoTopupStatusRequest.getCountryCode(), response, bankId);

	}

	public void validateAutoTopupInitReq(AutoTopupInitRequest initRequest, WibmoResponse response, String bankId) {
		if (null == initRequest) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if (response.getResCode() == 0)
			validateCustomerId(initRequest.getCustomerId(), response, bankId);


	}

	private void validateTxnType(String txnType, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(txnType)) {
			response.setResCode(101);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.TXN_TYPE_IS_EMPTY));
		}
	}

	private void validateCountryCode(int countryCode, WibmoResponse response, String bankId) {
		if (countryCode <= 0) {
			response.setResCode(102);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.COUNTRY_CODE_IS_ZERO));
		}
	}
	private void validateBeneficiaryId(int beneficiaryId, WibmoResponse response, String bankId) {
		if (beneficiaryId <= 0) {
			response.setResCode(120);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.BENEFICIARY_ID_MANDATORY));
		}
	}

	public void validateServiceTypeUpdate(ServiceTypeRequest request, WibmoResponse response, String bankId) {
		if (null == request) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if (response.getResCode() == 0)
			validateCustomerId(request.getCustomerId(), response, bankId);
		if (response.getResCode() == 0)
			validateWalletId(request.getWalletId(), response, bankId);
		if (response.getResCode() == 0)
			validateServiceType(request.getService(), response, bankId);

	}

	private void validateServiceType(ServiceTypes request, WibmoResponse response, String bankId) {
		if (null == request) {
			response.setResCode(300);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.SERVICE_IS_EMPTY));
			return;
		}
		if (response.getResCode() == 0)
			validateServiceType(request.getType(), response, bankId);
		if (response.getResCode() == 0)
			validateServiceStatus(request.isStatus(), response, bankId);
	}

	private void validateServiceType(String type, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(type)) {
			response.setResCode(301);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.SERVICE_TYPE_IS_EMPTY));
		}
	}

	private void validateServiceStatus(Boolean status, WibmoResponse response, String bankId) {
		if (null == status) {
			response.setResCode(302);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.STATUS_IS_EMPTY));
		}
	}

	public void validatecardDetails(ValidateLinkedCardRequest request, WibmoResponse response, String bankId) {
		if (null == request) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if (response.getResCode() == 0)
			validateCustomerId(request.getCustomerId(), response, bankId);
		if (response.getResCode() == 0)
			validateCardRefId(request.getCardRefId(), response, bankId);
		if (response.getResCode() == 0)
			validateCardNumber(request.getCardNumber(), response, bankId);
		if (response.getResCode() == 0)
			validateExpiryMM(request.getExpiryMM(), response, bankId);
		if (response.getResCode() == 0)
			validateExpiryYYYY(request.getExpiryYYYY(), response, bankId);
	}

	public void checkWalletCardDetails(CheckWalletCardRequest request, WibmoResponse response, String bankId) {
		if (null == request) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if (response.getResCode() == 0)
			validateProduct(request.getProductType(), response, bankId);
		if (response.getResCode() == 0)
			validateCustIdAndMobile(request.getMobile(), request.getCustomerId(), response, bankId);
	}

	public void checkWalletAccountDetails(SearchWalletAccountsRequest request, WibmoResponse response, String bankId) {
		if (null == request) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if (response.getResCode() == 0)
			validateMobile(request.getMobile(), response, bankId);
	}

	private void validateCustIdAndMobile(String mobile, String custId, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(mobile) && StringUtils.isBlank(custId)) {
			response.setResCode(150);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.MOBILE_OR_CUST_ID_IS_EMPTY));
		}
	}

	public void validateBeneficiaryBankAccounts(BeneficaryBankAccountRequest request,
												WibmoResponse response, String bankId) {
		if (null == request) {
			response.setResCode(51);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.BANK_ACCOUNT_IS_EMPTY));
		} else {
			if (response.getResCode() == 0)
				validateCustomerId(request.getCustomerId(), response, bankId);
			if (response.getResCode() == 0)
				validateAccountNum(request.getAccountNumber(), response, bankId);
			if (response.getResCode() == 0)
				validateAccountName(request.getAccountName(), response, bankId);
			if (response.getResCode() == 0)
				validateIfsc(request.getIfscCode(), response, bankId);
		}
	}

	public void validateInitRequestMoneyApi(RMRequest request, WibmoResponse response, String bankId) {
		if (null == request) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}

		if (response.getResCode() == 0 && ("W2W").equalsIgnoreCase(request.getTxnMode()))
			validateRequestForW2W(request, response, bankId);
	}

	private void validateRequestForW2W(RMRequest request, WibmoResponse response, String bankId) {
		if((StringUtils.isBlank(request.getRequesterCustomerId()))
				|| StringUtils.isBlank(request.getRequesteeMobile())) {
			response.setResCode(150);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.MOBILE_OR_CUST_ID_IS_EMPTY));
		}

	}

	public void validateFetchRMApi(FetchRMRequest fetchRMRequest, WibmoResponse response, String bankId) {
		if(null == fetchRMRequest) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}

		if(response.getResCode() == 0) validateCustIdAndMobile(fetchRMRequest.getMobileNo(), fetchRMRequest.getCustomerId(), response, bankId);
	}

	public void validateAutoTopupModifySubsReq(ModifyAutotopupRequest request, WibmoResponse response, String bankId) {
		if (null == request) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
		} else {

			chkModifySubParams(request, response, bankId);
		}
	}

	private void chkModifySubParams(ModifyAutotopupRequest request, WibmoResponse response, String bankId) {
		if (response.getResCode() == 0)
			validateCustomerId(request.getCustomerId(), response, bankId);
		if (response.getResCode() == 0)
			validateThresholdAmt(request.getThresholdAmt(), response, bankId);
		if (response.getResCode() == 0)
			validateTopupAmt(request.getTopupAmt(), response, bankId);
		if (response.getResCode() == 0)
			validateMerchantId(request.getMerchantId(), response, bankId);
		if (response.getResCode() == 0)
			validateStatus(request.getStatus(), response, bankId);
		if (response.getResCode() == 0)
			validatePaymntRefId(request.getRecurringPaymentRefId(), response, bankId);
		if (response.getResCode() == 0)
			checkThresholdAndTopupAmt(request.getThresholdAmt(),
					request.getTopupAmt(), response, bankId);
	}

	private void validateMerchantId(String merchantId, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(merchantId)) {
			response.setResCode(80);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.MERCHANT_ID_IS_EMPTY));
		}

	}

	private void validatePaymntRefId(long refId, WibmoResponse response, String bankId) {
		if (refId < 0) {
			response.setResCode(81);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.PAYMENT_REF_ID_IS_ZERO));
		}

	}

	private void validateStatus(String status, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(status)) {
			response.setResCode(82);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.SUB_STATUS_IS_EMPTY));
		}

	}

	public void validateUpdateSubscription(UpdateAutoTopupSubscriptionRequest request, WibmoResponse response, String bankId) {
		if (null == request) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
		} else {

			if (response.getResCode() == 0)
				validateUserId(request.getUserId(), response, bankId);
			if (response.getResCode() == 0)
				validateTopupAmt(request.getTopUpAmount(), response, bankId);
			if (response.getResCode() == 0)
				validateMerchantId(request.getMerchantId(), response, bankId);
			if (response.getResCode() == 0)
				validateSubsStatus(request.getStatus(), response, bankId);
			if (response.getResCode() == 0)
				validatePaymntRefId(request.getRecurringPaymentRefId(), response, bankId);
		}
	}

	private void validateUserId(long userId, WibmoResponse response, String bankId) {
		if (userId < 0) {
			response.setResCode(83);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.USER_ID_IS_ZERO));
		}

	}

	private void validateSubsStatus(long userId, WibmoResponse response, String bankId) {
		if (userId < 0) {
			response.setResCode(84);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.SUB_STATUS_IS_ZERO));
		}

	}

	public void validateRMAcceptApi(RMAcceptRequest rmAcceptRequest, WibmoResponse response, String bankId) {
		if (null == rmAcceptRequest) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if (response.getResCode() == 0)
			validateCollectStatus(rmAcceptRequest.getCollectStatus(), response, bankId);
	}

	private void validateCollectStatus(String collectStatus, WibmoResponse response, String bankId) {
		if(StringUtils.isBlank(collectStatus)) {
			response.setResCode(100);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.COLLECT_STATUS_IS_EMPTY));
		}
	}

	public WibmoResponse validateRMAcceptConfirm(RMAcceptConfirmRequest rmAcceptConfirmRequest, WibmoResponse response, String bankId) {
		if (null == rmAcceptConfirmRequest) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
		}
		return response;
	}

	public void validateSBInitiationApi(SBRequest request, WibmoResponse response, String bankId) {
		if (null == request) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
		}
	}

	public void validateUserLimits(CheckUserLimitsRequest request, WibmoResponse response, String bankId) {
		if (null == request) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if (response.getResCode() == 0)
			validateAmount(request.getTxnAmount(),  response, bankId);
		if (response.getResCode() == 0)
			validateTxnType(request.getTxnType(), response, bankId);
		if (response.getResCode() == 0)
			validateTxnFlow(request.getTxnFlow(), response, bankId);
		if (response.getResCode() == 0 && request.getWalletId() < 0) {
			validateProductTypeAndCustId(request.getProductType(), request.getCustomerId(), response, bankId);
		}

	}

	private void validateTxnFlow(String txnFlow, WibmoResponse response, String bankId) {
		if (StringUtils.isBlank(txnFlow)) {
			response.setResCode(110);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.TXN_FLOW_IS_EMPTY));
		}
	}
	public void validateW2ARequest(W2AVerificationRequest request, String bankId, WibmoResponse response){
		if (null == request) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if(response.getResCode() == 0 && StringUtils.isBlank(bankId)) {
			response.setResCode(65);
			response.setResDesc(MsgConstants.BANK_ID_IS_EMPTY);
		}
		if (response.getResCode() == 0)
			validateAmount(request.getTxnAmt(),  response, bankId);
		if(request.getBeneficiaryId() == 0 && response.getResCode() == 0)
		{
			processRequest(request, response, bankId);
		}
	}

	private void processRequest(W2AVerificationRequest request, WibmoResponse response, String bankId) {
		if (!StringUtils.isBlank(request.getVpa())) {
			request.setTxnType(Constants.W2UPI);
		} else {
			validateAccountNum(request.getBeneficiaryAccountNumber(), response, bankId);
			if (response.getResCode() == 0)
				validateIfsc(request.getBeneficiaryIfscCode(), response, bankId);
			if (response.getResCode() == 0)
				validateAccountName(request.getBeneficiaryName(), response, bankId);
			if (response.getResCode() == 0) request.setTxnType(Constants.W2A);
		}
	}

	public void validateW2UPIRequest(W2UPIVerificationRequest request, String bankId, WibmoResponse response){
		if (null == request) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if(response.getResCode() == 0 && StringUtils.isBlank(bankId)) {
			response.setResCode(65);
			response.setResDesc(MsgConstants.BANK_ID_IS_EMPTY);
		}
		if (response.getResCode() == 0)
			validateAmount(request.getTxnAmt(),  response, bankId);
		if(request.getBeneficiaryId() == 0 && response.getResCode() == 0 && !StringUtils.isBlank(request.getVpa()))
		{
			request.setTxnType(Constants.W2UPI);

		}
	}
	public void validateConsumptionRequest(LimitConsumptionRequest request, String bankId, WibmoResponse response){
		if (null == request) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if(response.getResCode() == 0 && StringUtils.isBlank(bankId)) {
			response.setResCode(65);
			response.setResDesc(MsgConstants.BANK_ID_IS_EMPTY);
		}
		if (response.getResCode() == 0) validateAmount(request.getTxnAmt(),  response, bankId);
		if (response.getResCode() == 0) validateTxnType(request.getTxnType(), response, bankId);
		if (request.isBenefIsInCoolingPeriod() && response.getResCode() == 0) validateBeneficiaryId(request.getBeneficiaryId(), response, bankId);
	}
	public void validateSpecificBeneficiaryId(int beneficiaryId, WibmoResponse response, String customerId, String bankId) {

		validateCustomerId(customerId, response, bankId);
		if (response.getResCode() == 0) validateBeneficiaryId(beneficiaryId,  response, bankId);
	}

	public void validateW2ARequest(W2ADebitRequest request, String bankId, WibmoResponse response){
		if (null == request) {
			response.setResCode(400);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.REQUEST_EMPTY));
			return;
		}
		if(response.getResCode() == 0 && StringUtils.isBlank(bankId)) {
			response.setResCode(65);
			response.setResDesc(MsgConstants.BANK_ID_IS_EMPTY);
		}
		if (response.getResCode() == 0)
			validateAmount(request.getTxnAmount(),  response, bankId);

	}
}
