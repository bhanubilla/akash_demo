package com.wibmo.dfs.wallet.controller;

import com.wibmo.dfs.wallet.service.AccountsService;
import com.wibmo.dfs.wallet.validation.RequestValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.wibmo.dfs.wallet.model.BulkLinkAccountsRequest;

import com.wibmo.dfs.wallet.model.FetchLinkedCardsRequest;
import com.wibmo.dfs.wallet.model.LinkAccountsRequest;
import com.wibmo.dfs.wallet.model.UnlinkAccountsRequest;
import com.wibmo.dfs.wallet.model.UpdateNickNameRequest;
import com.wibmo.dfs.wallet.model.WibmoResponse;
import com.wibmo.dfs.wallet.util.CommonUtil;
import com.wibmo.dfs.wallet.util.WibmoResponseUtil;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/wallet/lc")
public class WalletLinkController {

	@Autowired
	private AccountsService service;

	@Autowired
	private RequestValidator validator;
	
	@ApiOperation(value="Link-Account API", response=WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 1, message = "card linked successfully",response =WibmoResponse.class),
			@ApiResponse(code = 2, message = "payment card type api response failed",response =WibmoResponse.class),
			@ApiResponse(code = 20, message = "request is empty",response =WibmoResponse.class),
			@ApiResponse(code = 57, message = "linked card info is empty",response =WibmoResponse.class),
			@ApiResponse(code = 58, message = "card number is empty",response =WibmoResponse.class),
			@ApiResponse(code = 59, message = "card expiry mm is empty",response =WibmoResponse.class),
			@ApiResponse(code = 60, message = "card expiry yyyy is empty",response =WibmoResponse.class),
			@ApiResponse(code = 61, message = "name on card is empty",response =WibmoResponse.class),
			@ApiResponse(code = 62, message = "card expiry year is less than current year",response =WibmoResponse.class),
			@ApiResponse(code = 63, message = "card expiry month is less than current month",response =WibmoResponse.class),
			@ApiResponse(code = 64, message = "card added source is empty",response =WibmoResponse.class),
			@ApiResponse(code = 300, message = "unsupported category",response =WibmoResponse.class),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class)
	})
	@PostMapping("/link/api/v1")
	public ResponseEntity<WibmoResponse> addAccount(@RequestBody LinkAccountsRequest request,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		request.setCustomerId(userId);
		Thread.currentThread().setName("linkAccount");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), request.getCustomerId());
		WibmoResponse response = new WibmoResponse();
		validator.validateLinkAccount(request, response, bankId);
		if (response.getResCode() > 0) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		return WibmoResponseUtil.frameResponse(service.addAccount(request, Integer.valueOf(bankId)));
	}
	
	@ApiOperation(value="Un-linkAccount API", response=WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 20, message = "request is empty",response =WibmoResponse.class),
			@ApiResponse(code = 26, message = "customer id is empty",response =WibmoResponse.class),
			@ApiResponse(code = 50, message = "category is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class)
	})
	@PostMapping("/unlink/api/v1")
	public ResponseEntity<WibmoResponse> deleteAccount(@RequestBody UnlinkAccountsRequest request,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting UserId
		request.setCustomerId(userId);
		Thread.currentThread().setName("unlinkAccount");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), request.getCustomerId());
		WibmoResponse response = new WibmoResponse();
		validator.validateUnLinkAccount(request, response, bankId);
		if (response.getResCode() > 0) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		return WibmoResponseUtil.frameResponse(service.deleteAccounts(request, bankId));
	}
	
	@ApiOperation(value="Update NickName API", response=WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 26, message = "customer id is empty",response =WibmoResponse.class),
			@ApiResponse(code = 65, message = "user nick name is empty",response =WibmoResponse.class),
			@ApiResponse(code = 66, message = "card id is empty",response =WibmoResponse.class),
			@ApiResponse(code = 200, message = "User Linked cards fetched Successfully",response =WibmoResponse.class),
			@ApiResponse(code = 400, message = "request is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class)
	})
	@PostMapping("/nickname/api/v1")
	public ResponseEntity<WibmoResponse> updateNickName(@RequestBody UpdateNickNameRequest updateNickNameReq,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		updateNickNameReq.setCustomerId(userId);
		Thread.currentThread().setName("updateNickName");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), updateNickNameReq.getCustomerId());
		WibmoResponse response = new WibmoResponse();
		validator.validateNickNameRequest(updateNickNameReq, response, bankId);
		if (response.getResCode() > 0) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		return WibmoResponseUtil.frameResponse(service.updateNickName(updateNickNameReq, bankId));
	}
	
	@ApiOperation(value="Fetch LinkedCards API", response=WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 200, message = "User Linked cards fetched Successfully",response =WibmoResponse.class),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class)
	})
	@PostMapping("/fetch/api/v1")
	public ResponseEntity<WibmoResponse> fetchlinkedCards(@RequestBody FetchLinkedCardsRequest request,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		request.setCustomerId(userId);
		Thread.currentThread().setName("fetchlinkedCards");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), request.getCustomerId());
		WibmoResponse response = new WibmoResponse();
		if (response.getResCode() > 0) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		return WibmoResponseUtil.frameResponse(service.fetchLinkedCards(request, Integer.valueOf(bankId)));
	}
	
	@ApiOperation(value="Auto Link API", response=WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 1, message = "card linked successfully",response =WibmoResponse.class),
			@ApiResponse(code = 2, message = "payment card type api response failed",response =WibmoResponse.class),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class)
	})
	@PostMapping("/autoLinkCard/api/v1")
	public ResponseEntity<WibmoResponse> autoLinkCard(@RequestBody BulkLinkAccountsRequest request,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		request.setCustomerId(userId);
		Thread.currentThread().setName("autoLink");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), request.getCustomerId());
		return WibmoResponseUtil.frameResponse(service.autoLinkCard(request, Integer.valueOf(bankId)));
	}
}
