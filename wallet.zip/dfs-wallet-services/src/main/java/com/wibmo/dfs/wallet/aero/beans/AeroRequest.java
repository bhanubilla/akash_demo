package com.wibmo.dfs.wallet.aero.beans;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 
 * @author meriyala.raghavendra
 *
 */
public class AeroRequest implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private String messageCode;
    private String clientId;
    private String clientTxnId;
    private String requestDateTime;
    private String bankId;
    private String secureCode;
    
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String last4Digits;
    
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String entityId;
    
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String urn;
    
    private String customerId;
    
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String txnFee;
    
    public String getMessageCode() {
        return messageCode;
    }

    public void setMessageCode(String messageCode) {
        this.messageCode = messageCode;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getClientTxnId() {
        return clientTxnId;
    }

    public void setClientTxnId(String clientTxnId) {
        this.clientTxnId = clientTxnId;
    }

    public String getRequestDateTime() {
        return requestDateTime;
    }

    public void setRequestDateTime(String requestDateTime) {
        this.requestDateTime = requestDateTime;
    }

    public String getBankId() {
        return bankId;
    }

    public void setBankId(String bankId) {
        this.bankId = bankId;
    }

    public String getSecureCode() {
        return secureCode;
    }

    public void setSecureCode(String secureCode) {
        this.secureCode = secureCode;
    }

    public String getLast4Digits() {
        return last4Digits;
    }

    public void setLast4Digits(String last4Digits) {
        this.last4Digits = last4Digits;
    }

    public String getEntityId() {
        return entityId;
    }

    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }

    public String getUrn() {
        return urn;
    }

    public void setUrn(String urn) {
        this.urn = urn;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getTxnFee() {
        return txnFee;
    }

    public void setTxnFee(String txnFee) {
        this.txnFee = txnFee;
    }
}
