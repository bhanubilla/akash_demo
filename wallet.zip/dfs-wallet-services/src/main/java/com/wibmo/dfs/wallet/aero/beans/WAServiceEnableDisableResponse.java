package com.wibmo.dfs.wallet.aero.beans;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;


@JsonIgnoreProperties(ignoreUnknown = true)
public class WAServiceEnableDisableResponse extends AeroResponse implements Serializable {

    private static final long serialVersionUID = 1L;

}

