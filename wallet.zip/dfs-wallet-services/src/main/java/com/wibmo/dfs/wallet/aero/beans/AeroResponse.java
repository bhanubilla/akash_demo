package com.wibmo.dfs.wallet.aero.beans;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * 
 * @author meriyala.raghavendra
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class AeroResponse implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private long urn;
    private String customerId;
    
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String description;
    private String responseCode;
    private int messageCode;
    private String clientTxnId;
    private String clientId;
    private String responseDateTime;
    private long accosaTransactionId;
    private String responseMessage;
    private int bankId;
    
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String accosaRefNo;
    
    public long getUrn() {
        return urn;
    }

    public void setUrn(long urn) {
        this.urn = urn;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public int getMessageCode() {
        return messageCode;
    }

    public void setMessageCode(int messageCode) {
        this.messageCode = messageCode;
    }

    public String getClientTxnId() {
        return clientTxnId;
    }

    public void setClientTxnId(String clientTxnId) {
        this.clientTxnId = clientTxnId;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getResponseDateTime() {
        return responseDateTime;
    }

    public void setResponseDateTime(String responseDateTime) {
        this.responseDateTime = responseDateTime;
    }

    public long getAccosaTransactionId() {
        return accosaTransactionId;
    }

    public void setAccosaTransactionId(long accosaTransactionId) {
        this.accosaTransactionId = accosaTransactionId;
    }

    public String getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }

    public int getBankId() {
        return bankId;
    }

    public void setBankId(int bankId) {
        this.bankId = bankId;
    }

    public String getAccosaRefNo() {
        return accosaRefNo;
    }

    public void setAccosaRefNo(String accosaRefNo) {
        this.accosaRefNo = accosaRefNo;
    }

}
