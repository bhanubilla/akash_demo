package com.wibmo.dfs.wallet.repository;

import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.entity.W2ACPConsumption;
import com.wibmo.dfs.wallet.entity.W2AConsumption;
import com.wibmo.dfs.wallet.model.LimitConsumptionRequest;
import com.wibmo.dfs.wallet.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

@Slf4j
@Repository
public class W2ACPLimitConsumptionRepositoryImpl implements W2ACPLimitConsumptionRepository {

        @Autowired
        JdbcTemplate jdbcTemplate;

        private static final String INSERT_QUERY = "INSERT INTO W2A_LIMIT_CP_CONSUMPTION(TXN_TYPE,CUSTOMER_ID,BENEFICIARY_ID,CNT_LMT,AMT_LMT,LIMIT_KEY)values(?,?,?,?,?,?)";

        private static final String UPDATE_QUERY = "UPDATE W2A_LIMIT_CP_CONSUMPTION SET CNT_LMT=?,AMT_LMT=? WHERE ID=? AND date(LAST_TXN_TIME) between ? and ?";

        private static final String SELECT_QUERY = "SELECT * FROM W2A_LIMIT_CP_CONSUMPTION WHERE TXN_TYPE=? AND CUSTOMER_ID=? AND BENEFICIARY_ID=? AND LIMIT_KEY=? AND date(LAST_TXN_TIME) between ? and ?";

        private static final String IS_CONSUMPTION_AVAILABLE = "SELECT * FROM W2A_LIMIT_CP_CONSUMPTION WHERE TXN_TYPE=? AND CUSTOMER_ID=? AND BENEFICIARY_ID=? AND LIMIT_KEY=? AND date(LAST_TXN_TIME) between ? and ?";

        @Override
        public int save(W2ACPConsumption w2AConsumption) {
                KeyHolder keyHolder = new GeneratedKeyHolder();
                int rv = 0;
                try {
                        rv = jdbcTemplate.update(connection -> {
                                PreparedStatement ps = connection.prepareStatement(INSERT_QUERY, Statement.RETURN_GENERATED_KEYS);
                                int i = 1;
                                ps.setString(i++, w2AConsumption.getTxnType());
                                ps.setInt(i++, w2AConsumption.getCustomerId());
                                ps.setInt(i++, w2AConsumption.getBeneficiaryId());
                                ps.setInt(i++, w2AConsumption.getCntLmt());
                                ps.setLong(i++, w2AConsumption.getAmtLmt());
                                ps.setString(i++, w2AConsumption.getLimitKey());
                                return ps;
                        }, keyHolder);
                } catch (DataAccessException e) {
                        log.error("Error occurred in saveDeviceInfo {}", e.getMessage());
                }
                return rv;
        }

        @Override
        public int update(W2ACPConsumption w2AConsumption, String startDate, String endDate) {
                KeyHolder keyHolder = new GeneratedKeyHolder();
                int rv = 0;
                try {
                        rv = jdbcTemplate.update(connection -> {
                                PreparedStatement ps = connection.prepareStatement(UPDATE_QUERY, Statement.RETURN_GENERATED_KEYS);
                                int i = 1;
                                ps.setInt(i++, w2AConsumption.getCntLmt());
                                ps.setLong(i++, w2AConsumption.getAmtLmt());
                                ps.setInt(i++, w2AConsumption.getId());
                                ps.setString(i++, startDate+" 00:00:00");
                                ps.setString(i++, endDate+" 23:59:59");
                                return ps;
                        }, keyHolder);
                } catch (DataAccessException e) {
                        log.error("Error occurred in updateDeviceInfo {}", e.getMessage());
                }
                return rv;
        }

        @Override
        public W2ACPConsumption fetch(int programId, String customerId, String txnType, int beneficiaryId, String limitKey, String startDate, String endDate) {
                BeanPropertyRowMapper<W2ACPConsumption> rowMapper = BeanPropertyRowMapper.newInstance(W2ACPConsumption.class);
                rowMapper.setPrimitivesDefaultedForNullValue(true);
                List<W2ACPConsumption> list = jdbcTemplate.query(SELECT_QUERY, preparedStatement -> {
                        int i = 1;
                        preparedStatement.setString(i++, txnType);
                        preparedStatement.setString(i++, customerId);
                        preparedStatement.setInt(i++, beneficiaryId);
                        preparedStatement.setString(i++, limitKey);
                        preparedStatement.setString(i++, startDate+" 00:00:00");
                        preparedStatement.setString(i++, endDate+" 23:59:59");
                }, rowMapper);
                if(!list.isEmpty())
                        return list.get(0);
                else{
                        W2ACPConsumption cpLimitConsumption = new W2ACPConsumption();
                        cpLimitConsumption.setCustomerId(Integer.parseInt(customerId));
                        cpLimitConsumption.setTxnType(txnType);
                        return cpLimitConsumption;
                }
        }

        @Override
        public W2ACPConsumption isConsumptionAvailable(LimitConsumptionRequest request, String customerId, String date, String startDate, String endDate) {
                BeanPropertyRowMapper<W2ACPConsumption> rowMapper = BeanPropertyRowMapper.newInstance(W2ACPConsumption.class);
                rowMapper.setPrimitivesDefaultedForNullValue(true);
                List<W2ACPConsumption> list = jdbcTemplate.query(IS_CONSUMPTION_AVAILABLE, preparedStatement -> {
                        int i = 1;
                        preparedStatement.setString(i++, request.getTxnType());
                        preparedStatement.setString(i++, customerId);
                        preparedStatement.setInt(i++, request.getBeneficiaryId());
                        preparedStatement.setString(i++, date);
                        preparedStatement.setString(i++, startDate);
                        preparedStatement.setString(i++, endDate);
                }, rowMapper);
                if(!list.isEmpty())
                        return list.get(0);
                else{
                        W2ACPConsumption cpLimitConsumption = new W2ACPConsumption();
                        cpLimitConsumption.setCustomerId(Integer.parseInt(customerId));
                        cpLimitConsumption.setTxnType(request.getTxnType());
                        return cpLimitConsumption;
                }
        }
}
