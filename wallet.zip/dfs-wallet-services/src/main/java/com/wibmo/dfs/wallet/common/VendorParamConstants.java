/**
 * 
 */
package com.wibmo.dfs.wallet.common;

/**
 * @author rajasekhar.kaniti
 *
 */
public class VendorParamConstants {
	
	private VendorParamConstants() {}
	
	public static final String PAYMENT_VENDOR_NAME = "payment";
	public static final String PAYMENT_SERVICE_BASE_URL ="PAYMENT_SERVICE_BASE_URL";
	public static final String PAYMENT_SERVICE_GET_CARDTYPE_URL ="PAYMENT_SERVICE_GET_CARDTYPE_URL";

}
