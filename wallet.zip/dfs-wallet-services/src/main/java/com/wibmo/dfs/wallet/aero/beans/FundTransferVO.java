package com.wibmo.dfs.wallet.aero.beans;

import com.wibmo.dfs.wallet.aero.entity.AeroCMSConf;
import com.wibmo.dfs.wallet.entity.PrepaidBankMapping;
import com.wibmo.dfs.wallet.entity.WalletCard;
import com.wibmo.dfs.wallet.entity.WalletTxnInfo;
import com.wibmo.dfs.wallet.model.CustomerMiniProfile;
import com.wibmo.dfs.wallet.model.SendMoneyRequest;
import com.wibmo.dfs.wallet.model.WibmoResponse;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FundTransferVO {

	private SendMoneyRequest sendMoneyReq;
	private PrepaidBankMapping mapping;
	private AeroCMSConf cmsConfig;
	private WibmoResponse response;
	private int auditId;
	private WalletTxnInfo recipientTxnInfo;
	private WalletCard senderCard;
	private WalletCard recipientCard;
	private CustomerMiniProfile recipientAccInfo;
	private FundTransferRequest fundTransferReq;
}
