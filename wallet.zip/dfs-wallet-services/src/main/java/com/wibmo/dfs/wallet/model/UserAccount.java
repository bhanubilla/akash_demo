package com.wibmo.dfs.wallet.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserAccount {
	@ApiModelProperty(required = false, dataType="String", hidden = true)
	private String customerId;
	
	@ApiModelProperty(required = false, dataType="String", example="30", hidden = true)
	private String kycLevel;
	
	@ApiModelProperty(required = false, dataType="String")
	private String currency;
}
