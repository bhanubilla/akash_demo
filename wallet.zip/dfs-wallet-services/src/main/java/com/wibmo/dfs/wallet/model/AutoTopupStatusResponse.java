/**
 * 
 */
package com.wibmo.dfs.wallet.model;

import com.wibmo.dfs.wallet.bean.SubscriptionInfo;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
public class AutoTopupStatusResponse {
	
	private String status;
	private int thresholdAmt;
	private long topupAmt;
	private String remarks;
	private SubscriptionInfo subscriptionInfo;
	
}
