package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ITPCheckRequest {

	private String pan;
	private String phoneNumber;
	private String dob;
}
