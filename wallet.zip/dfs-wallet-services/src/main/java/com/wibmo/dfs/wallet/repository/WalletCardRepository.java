package com.wibmo.dfs.wallet.repository;

import java.util.List;

import com.wibmo.dfs.wallet.entity.WalletCard;


public interface WalletCardRepository {

	int save(WalletCard walletCards, String programId);
	
	WalletCard fetchById(int id, String programId);
	
	WalletCard fetchByCustIdAndProduct(String custId, String productType, String programId);
	
	List<WalletCard> fetchByCustId(String custId, String programId);
	
	WalletCard fetchByCustIdAndId(String custId, int id, String programId);
	
	WalletCard fetchByCardNumber(String cardNumber, String programId);

	boolean reloadWalletWithId(String programId, int walletId);

	boolean reloadWalletWithCustIdAndProdType(String programId, String custId, String productType);
}
