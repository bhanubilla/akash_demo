
package com.wibmo.dfs.wallet.aero.beans;

import lombok.Data;

import java.io.Serializable;

@Data
public class CardHolderProfileUpdateRequest extends AeroRequest implements Serializable {

    private String messageCode;
    private String clientTxnId;
    private String last4Digits;
    private String urn;
    private String customerId;
    private CardHolder cardholder;
    private CustomerIdentityProfile customerIdentityProfile;

}
