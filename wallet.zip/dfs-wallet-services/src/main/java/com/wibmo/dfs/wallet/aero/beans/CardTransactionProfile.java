package com.wibmo.dfs.wallet.aero.beans;

import java.io.Serializable;

public class CardTransactionProfile implements Serializable {

    private static final long serialVersionUID = 1L;

    private boolean status;
    private int transactionProfileId;
    private String transactionType;
    private String transactionRegionName;

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public int getTransactionProfileId() {
        return transactionProfileId;
    }

    public void setTransactionProfileId(int transactionProfileId) {
        this.transactionProfileId = transactionProfileId;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public String getTransactionRegionName() {
        return transactionRegionName;
    }

    public void setTransactionRegionName(String transactionRegionName) {
        this.transactionRegionName = transactionRegionName;
    }
}
