package com.wibmo.dfs.wallet.repository;

import com.wibmo.dfs.wallet.entity.PrepaidMaster;

public interface PrepaidMasterRepository {

	PrepaidMaster fetchById(int id, String programId);
	
	int save(PrepaidMaster pmaster);
	boolean reloadPPMaster(String programId, int ppId);
}
