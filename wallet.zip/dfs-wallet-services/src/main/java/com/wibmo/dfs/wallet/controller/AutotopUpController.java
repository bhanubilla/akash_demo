/**
 * 
 */
package com.wibmo.dfs.wallet.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wibmo.dfs.wallet.model.AutoTopupAuthStatusUpdateRequest;
import com.wibmo.dfs.wallet.model.AutoTopupInitRequest;
import com.wibmo.dfs.wallet.model.AutoTopupStatusRequest;
import com.wibmo.dfs.wallet.model.ModifyAutotopupRequest;
import com.wibmo.dfs.wallet.model.WibmoResponse;
import com.wibmo.dfs.wallet.service.AutoTopupService;
import com.wibmo.dfs.wallet.util.CommonUtil;
import com.wibmo.dfs.wallet.util.WibmoResponseUtil;
import com.wibmo.dfs.wallet.validation.RequestValidator;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;

/**
 * @author rajasekhar.kaniti
 *
 */
@Slf4j
@RestController
@RequestMapping("/wallet/autoTopup")
public class AutotopUpController {
	
	private static final String REQUEST_VALIDATION_FAILED = "Request Validation Failed : {} ";
	@Autowired
	private AutoTopupService autoTopupService;

	@Autowired
	private RequestValidator validator;

	
	

	@ApiOperation(value="Auto Subscription Initiation", response=WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 26, message = "customer id is empty",response=WibmoResponse.class),
	        @ApiResponse(code = 100, message = "AutoTopup subscription Initiation failed.. Please try after some time."),
	        @ApiResponse(code = 200, message = "AutoTopup subscription Initiated Successfully",response =WibmoResponse.class),
	        @ApiResponse(code = 250, message = "auto topup subscription already enabled"),
	        @ApiResponse(code = 400, message = "request is empty"),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR")
	})
	@PostMapping("/subscription/init/v1")
	public ResponseEntity<WibmoResponse> autoTopupInit(@RequestBody AutoTopupInitRequest initRequest
			,@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		initRequest.setCustomerId(userId);
		Thread.currentThread().setName("AutoTopup Subscription Init");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), initRequest.getCustomerId());
		WibmoResponse response = new WibmoResponse();
		validator.validateAutoTopupInitReq(initRequest, response, bankId);
		if (response.getResCode() > 0) {
			log.info("Error Desc :{}",response.getResDesc());
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		log.debug("Request Validation succeded");
		return WibmoResponseUtil.frameResponse(autoTopupService.autoTopupInit(initRequest, bankId));
		
	}

	@ApiOperation(value="Auto Subscription Auth Status update", response=WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 26, message = "customer id is empty",response=WibmoResponse.class),
			@ApiResponse(code = 66, message = "charge attemted is empty",response=WibmoResponse.class),
			@ApiResponse(code = 67, message = "wibmo txn id is empty",response=WibmoResponse.class),
			@ApiResponse(code = 68, message = "merchant txn id is empty",response=WibmoResponse.class),
			@ApiResponse(code = 69, message = "topup amount should not be lessthan or equal to zero",response=WibmoResponse.class),
			@ApiResponse(code = 70, message = "threshold amount should not be lessthan or equal to zero",response=WibmoResponse.class),
			@ApiResponse(code = 71, message = "authentication is empty",response=WibmoResponse.class),
			@ApiResponse(code = 72, message = "txn date is empty",response=WibmoResponse.class),
			@ApiResponse(code = 73, message = "topup amount should be grater than the threshold amount",response=WibmoResponse.class),
	        @ApiResponse(code = 100, message = "Txn Details not found.. Please try with valid details"),
	        @ApiResponse(code = 150, message = "Authentication Failed or Authorization Failed"),
	        @ApiResponse(code = 200, message = "autotopup subscribed successfully",response =WibmoResponse.class),
	        @ApiResponse(code = 400, message = "request is empty"),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR")
	})	
	@PostMapping("/authStatus/update/v1")
	public ResponseEntity<WibmoResponse> authStatusUpdate(@RequestBody AutoTopupAuthStatusUpdateRequest autoTopupSubscriptionRequest,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId){
		//setting userId
		autoTopupSubscriptionRequest.setCustomerId(userId);
		Thread.currentThread().setName("AutoTopup Sub AuthStatus Update");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), autoTopupSubscriptionRequest.getCustomerId());
		log.info("Post Request came for Auto topup authstatus update for customer id : {}",autoTopupSubscriptionRequest.getCustomerId());
		WibmoResponse response = new WibmoResponse();
		validator.validateAutoTopupAuthStatusReq(autoTopupSubscriptionRequest, response, bankId);
		if (response.getResCode() > 0) {
			log.info(REQUEST_VALIDATION_FAILED,response.getResDesc());
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		return WibmoResponseUtil.frameResponse(autoTopupService.authStatusUpdate(autoTopupSubscriptionRequest, Integer.valueOf(bankId)));
	}
	
	@ApiOperation(value="Auto Subscription Status", response=WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 26, message = "customer id is empty",response=WibmoResponse.class),
	        @ApiResponse(code = 100, message = "FAILURE",response =WibmoResponse.class),
	        @ApiResponse(code = 102, message = "country code should not be zero",response=WibmoResponse.class),
	        @ApiResponse(code = 150, message = "status is inactive"),
	        @ApiResponse(code = 200, message = "SUCCESS",response =WibmoResponse.class),
	        @ApiResponse(code = 400, message = "request is empty"),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR")
	})	
	@PostMapping("/subscriptionStatus/v1")
	public ResponseEntity<WibmoResponse> subscriptionStatus(@RequestBody AutoTopupStatusRequest autoTopupStatusRequest,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId){
		//setting userId
		autoTopupStatusRequest.setCustomerId(userId);
		Thread.currentThread().setName("AutoTopup Subscription Status");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), autoTopupStatusRequest.getCustomerId());
		log.info("Post Request to fetch Auto topup subscription status for customer id : {}",autoTopupStatusRequest.getCustomerId());
		WibmoResponse response = new WibmoResponse();
		validator.validateAutoTopupSubStatusReq(autoTopupStatusRequest, response, bankId);
		if (response.getResCode() > 0) {
			log.info(REQUEST_VALIDATION_FAILED,response.getResDesc());
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		return WibmoResponseUtil.frameResponse(autoTopupService.fetchSubscriptionStatus(autoTopupStatusRequest, bankId));
	}
	
	@ApiOperation(value="Modify Auto Topup Subscription", response=WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 26, message = "customer id is empty",response=WibmoResponse.class),
			@ApiResponse(code = 68, message = "merchant txn id is empty",response=WibmoResponse.class),
			@ApiResponse(code = 69, message = "topup amount should not be lessthan or equal to zero",response=WibmoResponse.class),
			@ApiResponse(code = 70, message = "threshold amount should not be lessthan or equal to zero",response=WibmoResponse.class),
			@ApiResponse(code = 73, message = "topup amount should be grater than the threshold amount",response=WibmoResponse.class),
			@ApiResponse(code = 80, message = "merchant Id is Mandatory",response=WibmoResponse.class),
			@ApiResponse(code = 81, message = "Payment Ref Id Should be Greater than Zero",response=WibmoResponse.class),
			@ApiResponse(code = 82, message = "Subscription Status is Mandatory",response=WibmoResponse.class),
	        @ApiResponse(code = 100, message = "update Subscription Failed..",response =WibmoResponse.class),
	        @ApiResponse(code = 200, message = "Subscription updated Successfully..",response =WibmoResponse.class),
	        @ApiResponse(code = 400, message = "request is empty"),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR")
	})	
	@PostMapping("/modifysubscription/v1")
	public ResponseEntity<WibmoResponse> modifySubscription(@RequestBody ModifyAutotopupRequest modifyAutoTopupRequest,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId){
		//setting userId
		modifyAutoTopupRequest.setCustomerId(userId);
		Thread.currentThread().setName("ModifySubscription");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), modifyAutoTopupRequest.getCustomerId());
		log.info("Modify Auto topup subscription for customer id : {}",modifyAutoTopupRequest.getCustomerId());
		WibmoResponse response = new WibmoResponse();
		validator.validateAutoTopupModifySubsReq(modifyAutoTopupRequest, response, bankId);
		if (response.getResCode() > 0) {
			log.info(REQUEST_VALIDATION_FAILED,response.getResDesc());
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		return WibmoResponseUtil.frameResponse(autoTopupService.modifyAutoTopup(modifyAutoTopupRequest, bankId));
	}
}
