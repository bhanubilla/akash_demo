/**
 * 
 */
package com.wibmo.dfs.wallet.bean;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
public class UserLimitsRequest {
	private int kycLevel;
	private String txnType;
	private String cardNumber;
	private boolean deafultKycLimits;

}
