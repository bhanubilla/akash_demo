package com.wibmo.dfs.wallet.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;

import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.entity.LMUserConsumption;
import com.wibmo.dfs.wallet.util.CommonUtil;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class LMUserConsumptionRepositoryImpl implements LMUserConsumptionRepository {

	private static final String INSERT_QUERY = "insert into lm_user_consumption (customer_id,limit_key,product_type,total) values(?,?,?,?)";
	private static final String UPDATE_QUERY = "update lm_user_consumption set total=total + ? where date(last_txn_time) between ? and ? and customer_id=? and product_type=? and limit_key=?";
	private static final String FETCH_BY_CUST_KEY_QUERY = "select * from lm_user_consumption where date(last_txn_time) between ? and ? and customer_id=? and product_type=? and limit_key=?";

	private static final String FETCH_BY_CUST_KEYS_QUERY = "select * from lm_user_consumption where date(last_txn_time) between ? and ? and customer_id=? and product_type=? ";

	private static final String MONTH_PARAMS = "from month : {}, to month : {}";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int saveOrUpdate(List<LMUserConsumption> lmCons) {
		int count = 0;
		for (LMUserConsumption cons : lmCons) {
			LMUserConsumption ee = fetchByCustIdAndKey(cons.getCustomerId(), cons.getProductType(), cons.getLimitKey());
			if (null != ee) {
				log.debug("customer : {}, key : {} exists", cons.getCustomerId(), cons.getLimitKey());
				count += update(cons);
			} else {
				log.debug("customer : {}, doesn't have key :{} , saving now..", cons.getCustomerId(),
						cons.getLimitKey());
				count += save(cons);
			}
		}
		return count;
	}

	@Override
	public LMUserConsumption fetchByCustIdAndKey(String customerId, String productType, String key) {
		BeanPropertyRowMapper<LMUserConsumption> rowMapper = BeanPropertyRowMapper.newInstance(LMUserConsumption.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		Map<String, String> dtsMap = CommonUtil.generateFromAndToDates();
		String fromMonth = dtsMap.get(Constants.START_DATE);
		String toMonth = dtsMap.get(Constants.END_DATE);

		log.debug(MONTH_PARAMS, fromMonth, toMonth);
		List<LMUserConsumption> li = jdbcTemplate.query(FETCH_BY_CUST_KEY_QUERY, new PreparedStatementSetter() {

			public void setValues(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setString(1, fromMonth);
				preparedStatement.setString(2, toMonth);
				preparedStatement.setString(3, customerId);
				preparedStatement.setString(4, productType);
				preparedStatement.setString(5, key);
			}
		}, rowMapper);
		return !li.isEmpty() ? li.get(0) : null;
	}

	@Override
	public int save(LMUserConsumption lmCons) {
		return jdbcTemplate.update(INSERT_QUERY, lmCons.getCustomerId(), lmCons.getLimitKey(), lmCons.getProductType(),
				lmCons.getTotal());
	}

	@Override
	public int update(LMUserConsumption lmCons) {
		Map<String, String> dtsMap = CommonUtil.generateFromAndToDates();
		String fromMonth = dtsMap.get(Constants.START_DATE);
		String toMonth = dtsMap.get(Constants.END_DATE);

		log.debug(MONTH_PARAMS, fromMonth, toMonth);
		return jdbcTemplate.update(UPDATE_QUERY, lmCons.getTotal(), fromMonth, toMonth, lmCons.getCustomerId(),
				lmCons.getProductType(), lmCons.getLimitKey());
	}

	@Override
	public Map<String, Long> fetchByCustId(String customerId, String productType, String... keys) {
		Map<String, Long> custKeys = new HashMap<>();
		BeanPropertyRowMapper<LMUserConsumption> rowMapper = BeanPropertyRowMapper.newInstance(LMUserConsumption.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		String params = Arrays.stream(keys).map(x -> "'" + x + "'").collect(Collectors.joining(",", "(", ")"));
		Map<String, String> dtsMap = CommonUtil.generateFromAndToDates();
		String fromMonth = dtsMap.get(Constants.START_DATE);
		String toMonth = dtsMap.get(Constants.END_DATE);

		log.debug(MONTH_PARAMS, fromMonth, toMonth);
		List<LMUserConsumption> li = jdbcTemplate.query(FETCH_BY_CUST_KEYS_QUERY + "and limit_key in" + params,
				new PreparedStatementSetter() {

					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setString(1, fromMonth);
						preparedStatement.setString(2, toMonth);
						preparedStatement.setString(3, customerId);
						preparedStatement.setString(4, productType);
					}
				}, rowMapper);
		for (LMUserConsumption lm : li) {
			custKeys.put(lm.getLimitKey(), lm.getTotal());
		}
		return custKeys;
	}

}
