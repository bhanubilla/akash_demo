package com.wibmo.dfs.wallet.repository;

import com.wibmo.dfs.wallet.entity.AuditStatement;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;


@Repository
@Slf4j
public class AuditStatementRepositoryImpl implements AuditStatementRepository{

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private static final String AUDIT_STATEMENT_INSERT_QUERY = "INSERT INTO AUDIT_STATEMENT (CUSTOMER_ID,STATUS)"
			+" VALUES (?,?)";
	private static final String AUDIT_STATEMENT_UPDATE_QUERY = "UPDATE AUDIT_STATEMENT SET STATUS=?, UPDATED_DATE=? WHERE ID=?";
	
	@Override
	public int save(AuditStatement txn) {
		KeyHolder keyHolder = new GeneratedKeyHolder();

		jdbcTemplate.update(connection -> {
			PreparedStatement ps = connection.prepareStatement(AUDIT_STATEMENT_INSERT_QUERY, Statement.RETURN_GENERATED_KEYS);
			int i=1;
		
			ps.setString(i++, txn.getCustomerId());
			ps.setString(i++, txn.getStatus());
			return ps;
		}, keyHolder);

		Number value =keyHolder.getKey();
		return null != value ? value.intValue():0;
	}

	@Override
	public int updateAudit(AuditStatement txn) {
		KeyHolder keyHolder = new GeneratedKeyHolder();

		jdbcTemplate.update(connection -> {
			PreparedStatement ps = connection.prepareStatement(AUDIT_STATEMENT_UPDATE_QUERY, Statement.RETURN_GENERATED_KEYS);
			int i=1;

			ps.setString(i++, txn.getStatus());
			ps.setTimestamp(i++, txn.getUpdatedDate());
			ps.setInt(i++, txn.getWalletStatementId());
			return ps;
		}, keyHolder);

		Number value =keyHolder.getKey();
		return null != value ? value.intValue():0;
	}

}
