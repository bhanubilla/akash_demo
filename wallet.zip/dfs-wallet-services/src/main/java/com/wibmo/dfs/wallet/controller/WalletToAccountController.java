package com.wibmo.dfs.wallet.controller;

import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.constants.ServiceHttpStatus;
import com.wibmo.dfs.wallet.entity.W2AConsumption;
import com.wibmo.dfs.wallet.model.*;
import com.wibmo.dfs.wallet.service.WalletService;
import com.wibmo.dfs.wallet.service.WalletServiceFactory;
import com.wibmo.dfs.wallet.service.WalletToAccountService;
import com.wibmo.dfs.wallet.util.WibmoResponseUtil;
import com.wibmo.dfs.wallet.validation.RequestValidator;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/wallet/account")
@Slf4j
public class WalletToAccountController {

    @Autowired
    private RequestValidator validator;

    @Autowired
    private WalletToAccountService walletToAccountService;

    @Autowired
    private WalletServiceFactory findService;

    private static final String ERROR_DESC = "Error Desc : {}";

    @ApiOperation(value="W2A Verification API", response= WibmoResponse.class)
    @ApiResponses(value={
            @ApiResponse(code = 200, message = "Success", response = WibmoResponse.class),
            @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class),
            @ApiResponse(code = 37, message = "amount is zero",response =WibmoResponse.class),
            @ApiResponse(code = 65, message = "bank id is empty",response =WibmoResponse.class),
            @ApiResponse(code = 52, message = "account number is empty",response =WibmoResponse.class),
            @ApiResponse(code = 53, message = "account name is empty",response =WibmoResponse.class),
            @ApiResponse(code = 54, message = "IFSC code is empty",response =WibmoResponse.class),
            @ApiResponse(code = 400, message = "request is empty",response =WibmoResponse.class),
            @ApiResponse(code = 500, message = "Bad Request",response =WibmoResponse.class),
            @ApiResponse(code = 300, message = "Your remaining limit is Rs %s for today. Please enter a smaller amount.",response =WibmoResponse.class),
            @ApiResponse(code = 150, message = "Beneficiary Accounts addition  failed",response =WibmoResponse.class),
            @ApiResponse(code = 300, message = "You are not allowed any more transactions today. Please retry tomorrow.",response =WibmoResponse.class),
            @ApiResponse(code = 300, message = "Your remaining limit is Rs %s for this month. Please enter a smaller amount.",response =WibmoResponse.class),
            @ApiResponse(code = 300, message = "You are not allowed any more transactions this month. Please retry next month.",response =WibmoResponse.class),
            @ApiResponse(code = 300, message = "Your max amount per transaction limit is Rs %s. Please enter a smaller amount.",response =WibmoResponse.class),
            @ApiResponse(code = 300, message = "The total amount which can be transferred to newly added beneficiary is Rs %s for %s hours/mins.",response =WibmoResponse.class)
    })
    @PostMapping("/v1/verification")
    public WibmoResponse w2aVerification(@RequestBody W2AVerificationRequest request,
                                         @RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {

        WibmoResponse response = new WibmoResponse();
        try {
            validator.validateW2ARequest(request, bankId, response);
            if (response.getResCode() > 0) {
                log.info(ERROR_DESC, response.getResDesc());
                response = new WibmoResponse(response.getResCode(), response.getResDesc());
            } else {
                response = walletToAccountService.w2aVerification(request, Integer.parseInt(bankId), userId);
            }
        }
        catch(Exception e){
            log.error(Constants.ERR_DESC, e.getMessage());
            response = new WibmoResponse(ServiceHttpStatus.INTERNAL_ERROR, response.getResDesc());
        }
        return response;
    }

    @PostMapping("/v1/transaction")
    public WibmoResponse w2aTransaction(@RequestBody W2ADebitRequest request,
                                         @RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {

        WibmoResponse response = new WibmoResponse();

        try {
            WalletService ws = findService.getService(bankId);

            return walletToAccountService.w2aTransacation(request, ws, bankId, userId);
        }
        catch(Exception e){
            log.error(Constants.ERR_DESC, e.getMessage());
            response = new WibmoResponse(ServiceHttpStatus.INTERNAL_ERROR, response.getResDesc());
        }
        return response;
    }

    @ApiOperation(value="W2A update consumption API", response= WibmoResponse.class)
    @ApiResponses(value={
            @ApiResponse(code = 200, message = "Success", response = WibmoResponse.class),
            @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class),
            @ApiResponse(code = 65, message = "bank id is empty",response =WibmoResponse.class),
            @ApiResponse(code = 37, message = "amount is zero",response =WibmoResponse.class),
            @ApiResponse(code = 400, message = "request is empty",response =WibmoResponse.class),
            @ApiResponse(code = 101, message = "Transaction Type is Mandatory",response =WibmoResponse.class),
            @ApiResponse(code = 120, message = "Beneficiary id should not be zero.",response =WibmoResponse.class),
    })
    @PostMapping("/v1/update/consumption")
    public WibmoResponse consumptionUpdate(@RequestBody LimitConsumptionRequest request,
                                         @RequestHeader(value = "X-PROGRAM-ID") int bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {

        WibmoResponse response = new WibmoResponse();
        try {
            validator.validateConsumptionRequest(request, String.valueOf(bankId), response);
            if (response.getResCode() > 0) {
                log.info(ERROR_DESC, response.getResDesc());
                response = new WibmoResponse(response.getResCode(), response.getResDesc());
            } else {
                response = walletToAccountService.updateLimitConsumption(request, bankId, userId);
            }
        }
        catch(Exception e){
            log.error(Constants.ERR_DESC, e.getMessage());
            response = new WibmoResponse(ServiceHttpStatus.INTERNAL_ERROR, response.getResDesc());
        }
        return response;
    }   @ApiOperation(value="W2A update consumption API", response= WibmoResponse.class)
    @ApiResponses(value={
            @ApiResponse(code = 200, message = "Success", response = WibmoResponse.class),
            @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class),
            @ApiResponse(code = 65, message = "bank id is empty",response =WibmoResponse.class),
            @ApiResponse(code = 37, message = "amount is zero",response =WibmoResponse.class),
            @ApiResponse(code = 400, message = "request is empty",response =WibmoResponse.class),
            @ApiResponse(code = 101, message = "Transaction Type is Mandatory",response =WibmoResponse.class),
            @ApiResponse(code = 120, message = "Beneficiary id should not be zero.",response =WibmoResponse.class),
    })
    @PostMapping("/v1/revert/consumption")
    public WibmoResponse consumptionRevert(@RequestBody LimitConsumptionRequest request,
                                           @RequestHeader(value = "X-PROGRAM-ID") int bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {

        WibmoResponse response = new WibmoResponse();
        try {
            String programId = String.valueOf(bankId);
            validator.validateConsumptionRequest(request, programId, response);
            if (response.getResCode() > 0) {
                log.info(ERROR_DESC, response.getResDesc());
                response = new WibmoResponse(response.getResCode(), response.getResDesc());
            } else {
                response = walletToAccountService.revertLimitConsumption(request, programId, userId);
            }
        }
        catch(Exception e){
            log.error(Constants.ERR_DESC, e.getMessage());
            response = new WibmoResponse(ServiceHttpStatus.INTERNAL_ERROR, response.getResDesc());
        }
        return response;
    }
}
