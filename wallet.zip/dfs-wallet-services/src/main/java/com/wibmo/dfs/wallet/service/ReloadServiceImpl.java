package com.wibmo.dfs.wallet.service;

import com.wibmo.dfs.wallet.aero.repository.AeroCmsConfRepository;
import com.wibmo.dfs.wallet.repository.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ReloadServiceImpl implements ReloadService{

    @Autowired
    private ProgramParametersRepository progParamRepo;

    @Autowired
    private MsgsRepository msgRepository;

    @Autowired
    private AeroCmsConfRepository aeroRepo;

    @Autowired
    private PrepaidMasterRepository ppMasterRepo;

    @Autowired
    private PrepaidBankMappingRepository ppBankMappingRepo;

    @Autowired
    private WalletCardRepository wcRepo;

    @Override
    public boolean reloadProgParameter(String programId, String paramName) {
        return progParamRepo.reloadProgParamValues(programId, paramName);
    }

    @Override
    public boolean reloadMsgDetail(String programId, String msgName) {
        return msgRepository.reloadMsgDetail(programId, msgName);
    }

    @Override
    public boolean reloadAeroCMSConf(String programId, int ppBnkId) {
        return aeroRepo.reloadAeroCMSConf(programId, ppBnkId);
    }

    @Override
    public boolean reloadPPMaster(String programId, int ppId) {
        return ppMasterRepo.reloadPPMaster(programId, ppId);
    }

    @Override
    public boolean reloadPPBnkMapping(String programId, int ppBnkId) {
        return ppBankMappingRepo.reloadPPBnkMapping(programId, ppBnkId);
    }

    @Override
    public String fetchProgParameters(String programId, String paramName) {
        return progParamRepo.fetchParamValueByParamName(programId, paramName);
    }

    @Override
    public String fetchMsgDetails(String programId, String msgName) {
        return msgRepository.fetchMsgValueByMsgName(programId, msgName);
    }

    @Override
    public boolean reloadBankId(String programId) {
        return ppBankMappingRepo.reloadBankId(programId);
    }

    @Override
    public boolean reloadWalletWithId(String programId, int walletId) {
        return wcRepo.reloadWalletWithId(programId, walletId);
    }

    @Override
    public boolean reloadWalletWithCustIdAndProdType(String programId, String custId, String productType) {
        return wcRepo.reloadWalletWithCustIdAndProdType(programId, custId, productType);
    }
}
