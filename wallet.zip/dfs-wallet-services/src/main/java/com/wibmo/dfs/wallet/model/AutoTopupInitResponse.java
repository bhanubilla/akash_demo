/**
 * 
 */
package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
public class AutoTopupInitResponse {
	
	private String merchantId;
	private String merchantName;
	private String merchantTxnId;
}
