package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CardInquiry {

	private String customerId;
	private String productType;
	private int walletId;
}
