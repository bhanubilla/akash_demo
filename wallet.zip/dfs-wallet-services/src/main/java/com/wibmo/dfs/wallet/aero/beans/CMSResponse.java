package com.wibmo.dfs.wallet.aero.beans;

import java.util.List;

/**
 *
 * @author Preeti
 */
public class CMSResponse implements java.io.Serializable {

    private String resCode;
    private CardUserInfo cui;
    private String bankTransactionId;
    private long resAmount;
    private CardDetail cardDetail;
    private boolean hostDown;
    private List<CardTransactionProfile> cardTransactionProfile;
    
    private long availableBalance;
    private long availableCashLimit;
    private String responseMessage;
    private String repsonseDescription;


    public CardUserInfo getCui() {
        return cui;
    }

    public void setCui(CardUserInfo cui) {
        this.cui = cui;
    }
    

    public String getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }

    public String getRepsonseDescription() {
        return repsonseDescription;
    }

    public void setRepsonseDescription(String repsonseDescription) {
        this.repsonseDescription = repsonseDescription;
    }


    public CardDetail getCardDetail() {
        return cardDetail;
    }

    public void setCardDetail(CardDetail cardDetail) {
        this.cardDetail = cardDetail;
    }


    public boolean isHostDown() {
        return hostDown;
    }

    public void setHostDown(boolean hostDown) {
        this.hostDown = hostDown;
    }


    public long getResAmount() {
        return resAmount;
    }

    public void setResAmount(long resAmount) {
        this.resAmount = resAmount;
    }

    public String getResCode() {
        return resCode;
    }

    public void setResCode(String resCode) {
        this.resCode = resCode;
    }

    public String getBankTransactionId() {
        return bankTransactionId;
    }

    public void setBankTransactionId(String bankTransactionId) {
        this.bankTransactionId = bankTransactionId;
    }

    public long getAvailableBalance() {
        return availableBalance;
    }

    public void setAvailableBalance(long availableBalance) {
        this.availableBalance = availableBalance;
    }

    public long getAvailableCashLimit() {
        return availableCashLimit;
    }

    public void setAvailableCashLimit(long availableCashLimit) {
        this.availableCashLimit = availableCashLimit;
    }

    public List<CardTransactionProfile> getCardTransactionProfile() {
        return cardTransactionProfile;
    }

    public void setCardTransactionProfile(List<CardTransactionProfile> cardTransactionProfile) {
        this.cardTransactionProfile = cardTransactionProfile;
    }
}
