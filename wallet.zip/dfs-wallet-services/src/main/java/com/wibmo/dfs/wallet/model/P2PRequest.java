/**
 * 
 */
package com.wibmo.dfs.wallet.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class P2PRequest {
	
	@ApiModelProperty(required = false, dataType="String", hidden = true)
	private String senderCustomerId;
	
	@ApiModelProperty(required = true, dataType="int")
	private int senderWalletId ;
	
	@ApiModelProperty(required = true, dataType="String")
	private String recipientMobileNo;
	
	@ApiModelProperty(required = true, dataType="long")
	private long amount;
	
	@ApiModelProperty(required = false, dataType="String")
	private String remarks;
	
	@ApiModelProperty(required = true, dataType="String", example="RW", notes="possible value are RW,FC,GC,OT")
	private String productType;
	
	@ApiModelProperty(hidden = true)
	private String initiateFrom;

	private String txnRefNumber;

}
