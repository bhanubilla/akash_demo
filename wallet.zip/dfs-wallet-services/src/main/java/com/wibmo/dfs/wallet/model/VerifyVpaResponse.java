package com.wibmo.dfs.wallet.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class VerifyVpaResponse {

    private String merchantId;
    private String merchantChannelId;
    private String gatewayTransactionId;
    private String gatewayResponseStatus;
    private String gatewayResponseCode;
    private String gatewayResponseMessage;
    private String vpa;
    private String name;
    private String ifsc;
    private String iin;
    private boolean isMerchant;
    private boolean isMerchantVerified;
    private boolean isMandateSupported;
    private String mcc;
    private String udfParameters;
    @JsonIgnore
    private String customGatewayStatusCode;

}
