package com.wibmo.dfs.wallet.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ChargeOrEnquiryResponse {

	private int resCode;
	private String resDesc;
	private String errorMessage;
	private TxnEnquiry data;
}
