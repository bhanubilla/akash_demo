package com.wibmo.dfs.wallet.constants;

public class Constants {


    private Constants() {}

	public static final String BANK_ACCOUNT = "ac";
	public static final String LINKED_CARD = "lc";
	public static final String WALLET_CARD = "wc";
	public static final String ALL = "all";

	public static final String UNDER_SCORE = "_";


	public static final int CLIENT_RESPONSE_CODE_INTERNAL_ERROR = 3;

	public static final int RESPONSE_CODE_SUCCESS = 1;
	public static final String RESPONSE_DESC_SUCCESS = "SUCCESS";
	public static final int SUCCESS_RESPONSE_CODE = 200;
	public static final String USER_LIMIT_CHK_SUCCESS_RESPONSE_DESC = "allow transaction";

	//fetch Txn info
	public static final String FETCH_TXN_INFO_FOR_LOADMONEY = "lm";
	public static final String FETCH_TXN_INFO_FOR_SENDMONEY = "sm";
	public static final String FETCH_TXN_INFO_TXN_TYPE_SEND_MONEY = "P2P Debit";
	public static final String FETCH_TXN_INFO_TXN_TYPE_P2P_CREDIT = "P2P Credit";
	
	public static final String AUTHN_SUCCESS= "Authentication Success";
	public static final String AUTHN_FAILED= "Authentication Failed";
	public static final String AUTHERIZATION_SUCCESS ="Autherization Success";
	public static final String AUTHERIZATION_FAILED ="Autherization Failed";
	public static final String REFUND_SUCCESSFULLY= "Refund Success";
	public static final String REFUND_FAILURE= "Refund Fail";
	public static final String AUTHZ_SUCCESS= "Y";
	public static final String AUTHZ_FAILED= "N";
	public static final String CREDIT_SUCCESS= "Y";
	public static final String CREDIT_FAILED= "N";
	public static final String REFUND_SUCCESS= "Y";
	public static final String REFUND_FAILED= "N";
	public static final String AUTOTOPUP_STATUS_ACTIVE =  "A";
	public static final String AUTOTOPUP_STATUS_INACTIVE =  "I";
	
	public static final String START_DATE =  "startDate";
	public static final String END_DATE =  "endDate";
	
	public static final String BANK_ID = "bankId";
	public static final String X_PROGRAM_ID = "X-PROGRAM-ID";
	public static final String X_ACCOUNT_NUMBER = "X-ACCOUNT-NUMBER";
	public static final String X_MOBILE_NUMBER = "X-MOBILE-NUMBER";
	
	public static final String CHRG_ENQUIRY_EP="/payments/charge/enquiry/v1";
	public static final String REFUND_EP="/payments/refund/enquiry/v1";
	public static final String FETCH_SUBS_EP="/payments/recurring/user/subscriptions/v1";
	public static final String FETCH_USR_LIMITS_EP="/limits/fetchUser/api/v1";
	public static final String FETCH_KYC_LIMITS_EP="/limits/fetchKyc/api/v1";
	public static final String UPDATE_SUBS_EP="/payments/recurring/user/merchant/subscription/details/v1";
	public static final String FETCH_USER_DETAILS_EP = "/onboarding/userProfile/fetchDetails/v1";
	public static final String FETCH_CUST_MINI_PROFILE = "/onboarding/internal/fetch-cust-mini-profile/v1";
	public static final String REQUEST_MONEY = "/upi/transaction/v1/requestMoney";
	public static final String INCOMING_REQUEST_MONEY = "/collectrequest/v1/incoming";
	public static final String PENDING_REQUEST_MONEY = "/upi/transaction/v1/listPendingCollectRequests";
	public static final String FETCHING_ALL_BLOCKED_VPA_LIST = "/upi/accountmanagement/v1/vpa/fetchallblockedvpalist";
	public static final String VERIFY_VPA = "/upi/transaction/v1/verifyVpa";
	public static final String FETCH_USER_PROFILE_INFO = "/fetchUserProfileDetails/v1";
	
	public static final String PG_SUCCESS_CODE="50020";
	
	public static final String X_API_KEY="X-API-KEY";
	public static final String X_AUTH_TOKEN="X-Auth-Token";
	public static final String PROGRAM_ID = "X-PROGRAM-ID";
	public static final String USER_ID = "X-ACCOUNT-NUMBER";
	public static final String TXN_TYPE = "TXN-TYPE";
	
	public static final String V2W = "V2W";

	public static final String W2V = "W2V";

	public static final String V2V = "V2V";

	public static final String W2W = "W2W";

	public static final String UPI = "UPI";


	public static final String TXN_STATUS_SUCCESS = "S";
	public static final String TXN_STATUS_FAILURE = "F";
	public static final String TXN_STATUS_PENDING = "P";
	public static final String TXN_STATUS_DECLINE = "D";

	public static final String TXN_IN_FLOW = "I";
	public static final String TXN_OUT_FLOW = "O";

	public static final String ADMIN_FETCH_CONFIG_URL = "/admin/prog-attribute/fetch/configuration/v1?txnType={1}&condition={2}";
	public static final String DATE_FORMAT="ddMMYYYY";
	public static final String DATE_FORMAT_FOR_CP="ddMMYYYY_HHmm";
	public static final String W2A = "W2A";
	public static final String W2UPI = "W2UPI";
	public static final String ALL_CONFIG = "ALL";
	public static final String OTHERS = "Others";
	public static final String W2A_DEBIT = "W2A Debit";
	public static final String W2UPI_DEBIT = "W2UPI Debit";
	public static final String PENDING = "P";
	public static final String ERR_DESC = "Error Occurred {}";
	public static final String FEE_AMT = "feeAmount";
	public static final String IGST_AMT = "gstAmount";
	public static final String CGST_AMT = "cgstAmount";
	public static final String SGST_AMT = "sgstAmount";
	public static final String FEE_GST_PERCENTAGE = "feeGstPercentage";
	public enum LIMIT_WINDOW { DAILY, WEEKLY,MONTHLY };
	public static final String W2AD = "W2AD";
	public static final String W2UPID = "W2UPID";
	public static final String REFUND = "Refund";
	public static final String OUT_TXN_FLOW = "O";
	public static final String SENT = "Sent ";
	public static final String TO = " to ";
	public static final String W2A_REFUND = "W2A Refund";
	public static final String W2UPI_REFUND = "W2IPI Refund";
	public static final String PRODUCT_TYPE_RW = "RW";
	public static final String P2P_PAY = "P2P_PAY";
	public static final String P2M_PAY = "P2M_PAY";
	public static final String P2P_DEBIT= "P2P Debit";
	public static final String P2P_CREDIT="P2P Credit";
	public static final String INTENT_PAY="INTENT_PAY";
	public static final String SCAN_PAY = "SCAN_PAY";
	public static final String DECLINE = "DECLINE";
	public static final String EXPIRED = "EXPIRED";
	public static final String RM_STATUS_DECLINE = "D";
	public static final String RM_INITIATE = "RMI";
	public static final String REQUESTED = "Requested ";
	public static final String RS_SYMBOL = "\u20B9";
	public static final String CURRENCY_IND = "Rs.";

	public static final String RM_REJECT_EVENT_ID = "1103";
	public static final String RM_ACCEPT_EVENT_ID = "1102";
	public static final String RM_ALERT_EVENT_ID = "6001";
	public static final String FAILURE = "FAILURE";
	public static final String RM_PAYER_ALERT_EVENT_ID = "1104";

	public static final String APPLICATION_JSON = "application/json";
	public static final String RECEIVE_MONEY_EVENT_ID = "6001";
	public static final String COLLECT_REQ_EXP_MINUTES = "COLLECT_REQ_EXP_MINUTES";
	
	public static final String CREDIT_MONEY_CBS_OFFUS = "CREDIT_MONEY_CBS_OFFUS";
	public static final String CREDIT_MONEY_CBS_ONUS = "CREDIT_MONEY_CBS_ONUS";
	public static final String REQ_MONEY_REJECT_ALERT_EVENT = "1103";
	public static final String REQ_MONEY_APPROVE_ALERT_EVENT = "1102";
	public static final String NUMBER_OF_TXNS_ALLOWED = "NUMBER_OF_TXNS_ALLOWED";
}
