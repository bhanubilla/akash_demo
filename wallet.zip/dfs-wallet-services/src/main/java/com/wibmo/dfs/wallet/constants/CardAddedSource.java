/**
 * 
 */
package com.wibmo.dfs.wallet.constants;

/**
 * @author rajasekhar.kaniti
 *
 */
public enum CardAddedSource {
	SELF("SELF"), ONFLY("ONFLY");

	private String type;
	
	CardAddedSource(String type) {
		this.type = type;
	}
	
	public String getType() {
		return this.type;
	}

}
