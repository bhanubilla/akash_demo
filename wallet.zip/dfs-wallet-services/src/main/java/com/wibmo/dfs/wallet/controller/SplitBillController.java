package com.wibmo.dfs.wallet.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.wibmo.dfs.wallet.model.SBRequest;
import com.wibmo.dfs.wallet.model.WibmoResponse;
import com.wibmo.dfs.wallet.service.SplitBillService;
import com.wibmo.dfs.wallet.util.CommonUtil;
import com.wibmo.dfs.wallet.util.WibmoResponseUtil;
import com.wibmo.dfs.wallet.validation.RequestValidator;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("wallet/sb")
public class SplitBillController {
	
	@Autowired
	private SplitBillService service;

	@Autowired
	private RequestValidator validator;

	@ApiOperation(value="Split Bill API", response=WibmoResponse.class)
	@ApiResponses(value={
	        @ApiResponse(code = 200, message = "SUCCESS",response =WibmoResponse.class),
	        @ApiResponse(code = 100, message = "Split bill Txn Type/Txn Mode is not valid",response =WibmoResponse.class),
	        @ApiResponse(code = 120, message = "Mobile# or Customer Id is Mandatory",response =WibmoResponse.class),
	        @ApiResponse(code = 400, message = "Request is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class)
	})
	@PostMapping(path = "/initiate/v1")
	public ResponseEntity<WibmoResponse> initiateSplitBill(
			@RequestBody SBRequest sbRequest,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId , @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		sbRequest.setRequesterCustomerId(userId);
		Thread.currentThread().setName("splitbill");
				
		WibmoResponse response = new WibmoResponse();
		validator.validateSBInitiationApi(sbRequest, response, bankId);
		
		if (response.getResCode() > 0) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), sbRequest.getTxnMode(), sbRequest.getRequesterCustomerId());
		
		return WibmoResponseUtil.frameResponse(service.raiseSpiltBill(sbRequest, bankId));
	}
}
