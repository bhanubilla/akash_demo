package com.wibmo.dfs.wallet.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CheckWalletCardRequest {

	@ApiModelProperty(required = true, dataType="String", notes = "Mobile# or Customer Id is required")
	private String mobile;

	@ApiModelProperty(required = false, dataType="String", notes = "Customer Id is required", hidden = true)
	private String customerId;
	
	@ApiModelProperty(required = true, dataType="String")
	private String productType;
}
