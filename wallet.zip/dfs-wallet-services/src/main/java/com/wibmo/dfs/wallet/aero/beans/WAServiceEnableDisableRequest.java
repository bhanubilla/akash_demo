package com.wibmo.dfs.wallet.aero.beans;

import java.io.Serializable;
import java.util.List;


public class WAServiceEnableDisableRequest extends AeroRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    private List<CardTransactionProfile> cardTransactionProfile;

    public List<CardTransactionProfile> getCardTransactionProfile() {
        return cardTransactionProfile;
    }

    public void setCardTransactionProfile(List<CardTransactionProfile> cardTransactionProfile) {
        this.cardTransactionProfile = cardTransactionProfile;
    }

}
