package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TransactionInfo{

	private long transactionAmount;
	private String orgTxnId;
	
	private String senderUserId;
	private long senderBalAmt;
	private long senderUrn;
	
	private String recipientUserId;
	private long recipientBalAmt;
	private long recipientUrn;
	

}