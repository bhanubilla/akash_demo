package com.wibmo.dfs.wallet.constants;

/**
 *
 * @author ajay mahto
 */
public enum InflowImplConstant {	
	
	P2P_CREDIT("10014"),
	LOAD_MONEY("10003");
	
	private String implId;
	InflowImplConstant(String implId){
		this.implId=implId;
	}
	
	public String getImplId() {
		return this.implId;
	}
	
}

