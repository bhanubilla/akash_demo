package com.wibmo.dfs.wallet.aero.service;

import com.wibmo.dfs.wallet.aero.beans.CardInquiryRequest;
import com.wibmo.dfs.wallet.aero.beans.CardInquiryResponse;
import com.wibmo.dfs.wallet.aero.beans.CreateCardRequest;
import com.wibmo.dfs.wallet.aero.beans.CreateCardResponse;
import com.wibmo.dfs.wallet.aero.beans.FundTransferRequest;
import com.wibmo.dfs.wallet.aero.beans.FundTransferResponse;
import com.wibmo.dfs.wallet.aero.beans.LoadUnloadRequest;
import com.wibmo.dfs.wallet.aero.beans.LoadUnloadResponse;
import com.wibmo.dfs.wallet.aero.beans.TransactionHistoryRequest;
import com.wibmo.dfs.wallet.aero.beans.TransactionHistoryResponse;
import com.wibmo.dfs.wallet.aero.beans.WAServiceEnableDisableRequest;
import com.wibmo.dfs.wallet.aero.beans.WAServiceEnableDisableResponse;

import feign.Headers;
import feign.Param;
import feign.RequestLine;

/**
 * 
 * @author meriyala.raghavendra
 *
 */
public interface PrepaidAeroService {
    
	@RequestLine("POST /v1/{bankId}/createCard/{custIdLast4Digit}/{clientTxnId}")
    @Headers({"Content-Type: application/json"})
    public CreateCardResponse createCard(
            @Param("bankId") String bankId, @Param("custIdLast4Digit") String custIdLast4Digit, 
            @Param("clientTxnId") String clientTxnId, CreateCardRequest createCardRequest);
    
    @RequestLine("POST /v1/{bankId}/cardInquiry/{custIdLast4Digit}/{clientTxnId}")
    @Headers({"Content-Type: application/json"})
    public CardInquiryResponse cardInquiry(
            @Param("bankId") String bankId, @Param("custIdLast4Digit") String custIdLast4Digit, 
            @Param("clientTxnId") String clientTxnId, CardInquiryRequest cardInquiryRequest);

	
    @RequestLine("POST /v1/{bankId}/creditAccount/{customerId}/{custIdLast4Digit}")
    @Headers({"Content-Type: application/json"})
    public LoadUnloadResponse creditAccount(
    		 @Param("bankId") String bankId, @Param("customerId") String customerId, @Param("custIdLast4Digit") String custIdLast4Digit,
			LoadUnloadRequest loadUnloadRequest);
    
    @RequestLine("POST /v1/{bankId}/debitAccount/{customerId}/{custIdLast4Digit}")
    @Headers({"Content-Type: application/json"})
    public LoadUnloadResponse debitAccount(
    		@Param("bankId") String bankId, @Param("customerId") String customerId,
    		@Param("custIdLast4Digit") String custIdLast4Digit, 
            LoadUnloadRequest unloadRequest);
    
    @RequestLine("POST /v1/{bankId}/fundTransfer/{custIdLast4Digit}/{clientTxnId}")
    @Headers({"Content-Type: application/json"})
    public FundTransferResponse sendMoney(
    		@Param("bankId") String bankId, @Param("custIdLast4Digit") String custIdLast4Digit, 
    		@Param("clientTxnId") String clientTxnId,
            FundTransferRequest fundTransferRequest);

    @RequestLine("POST /v1/{bankId}/statementInquiry/{custIdLast4Digit}/{clientTxnId}")
    @Headers({"Content-Type: application/json"})
    public TransactionHistoryResponse walletStatementInquiry(
            @Param("bankId") String bankId, @Param("custIdLast4Digit") String custIdLast4Digit,
            @Param("clientTxnId") String clientTxnId, TransactionHistoryRequest transactionHistoryRequest);
    
    @RequestLine("POST /v1/{bankId}/cardTransactionProfile/{custIdLast4Digit}/{clientTxnId}")
    @Headers({"Content-Type: application/json"})
    public WAServiceEnableDisableResponse cardTransactionProfile(
            @Param("bankId") String bankId, @Param("custIdLast4Digit") String custIdLast4Digit,
            @Param("clientTxnId") String clientTxnId, WAServiceEnableDisableRequest waServiceEnableDisableRequest);

   
	
    


}
