package com.wibmo.dfs.wallet.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
//IncomingCollectResponse
public class OutgoingCollectResponse {
    private String txnAmount;
    private String payeeMobileNumber;
    private String payeeVpa;
    private String payeeName;
    private String txnDesc;
    private String txnDate;
    private String txnRefNum;
    private String payerVpa;
    @JsonIgnore
    private int resCode;
    @JsonIgnore
    private String resDesc;
}
