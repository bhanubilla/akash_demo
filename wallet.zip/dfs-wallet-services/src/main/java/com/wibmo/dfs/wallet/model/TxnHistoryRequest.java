package com.wibmo.dfs.wallet.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TxnHistoryRequest {

	@ApiModelProperty(required = false, hidden = true)
	private String customerId;
	private List<String> paymentMode;
	@ApiModelProperty(required = false, example = "2021-01-01",notes = "should be yyyy-MM-dd format")
	private String fromDate;
	@ApiModelProperty(required = false, example = "2021-01-01",notes = "should be yyyy-MM-dd format")
	private String toDate;
	private List<String> merCategory;
	private List<String> action;
	private List<String> txnFlow;
	private List<String> txnStatus;
	private List<String> txnCategory;
}
