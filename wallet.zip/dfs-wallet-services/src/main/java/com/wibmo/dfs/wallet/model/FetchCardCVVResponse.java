package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FetchCardCVVResponse {

	private String customerId;
	private int walletId;
	private String cvv;
}
