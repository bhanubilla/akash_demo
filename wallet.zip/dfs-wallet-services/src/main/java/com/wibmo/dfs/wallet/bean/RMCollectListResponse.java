package com.wibmo.dfs.wallet.bean;

import java.io.Serializable;
import java.util.List;

import com.wibmo.dfs.wallet.aero.beans.CommonInfo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RMCollectListResponse implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String pspRefNo;
	private String status; // S = Success , F = Failure, T = Time out, P = Pending
	private String statusDescription;
	private List<RMCollectPendingList> pendingList;
	  
	private String respCode;
	private String respDesc;
	private String msgHash ="NA";
	
	private CommonInfo commonInfo;
}
