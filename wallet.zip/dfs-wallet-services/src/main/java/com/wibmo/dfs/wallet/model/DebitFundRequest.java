package com.wibmo.dfs.wallet.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DebitFundRequest {
	private String custId;
	private int walletId;
	private long finalAmount;
	private long txnAmount;
	private String rrn;
	private String txnType;
	private String merchantId;
	private String sourceAccount;
	private long feeAmount;
	private long gstAmount;
	private long cgstAmount;
	private long sgstAmount;
	private String feeGstPercentage;
	private String beneficiaryAccountName;
	private String beneficiaryVpaName;
	private String beneficiaryAccountNumber;
	private String beneficiaryVpa;
}