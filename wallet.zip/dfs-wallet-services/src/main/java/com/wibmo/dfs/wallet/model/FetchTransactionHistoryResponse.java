package com.wibmo.dfs.wallet.model;

import java.util.List;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FetchTransactionHistoryResponse {

	private String customerId;
	private int walletId;
	private String refNumber;

	private long availableBalance;
	private String availableBalanceFormatted;
	private long openingBalance;
	private String openingBalanceFormatted;
	private long closingBalance;
	private String closingBalanceFormatted;
	
	private int count;
	private int pageNumber;	
    
    private List<TransactionHistory> txnHistoryList;
 
    private ComplaintDetails complaintDetails;
    
}
