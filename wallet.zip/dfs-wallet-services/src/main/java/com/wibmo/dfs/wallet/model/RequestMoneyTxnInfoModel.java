package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class RequestMoneyTxnInfoModel {

    private int id;
    private String txnId;
    private String requsterCustomerId;
    private String requsteeCustomerId;
    private long amount;
    private String rmStatus;
    private String reqType;
    private String sourceType;
    private String destinationType;
    private long createdDt;
    private String remarks;
    private String initiateFrom;
    private String gatewayTransactionId ;
    private String gatewayReferenceId;
}
