/**
 * 
 */
package com.wibmo.dfs.wallet.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
public class UserLinkedCardInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int id;
	private int binId;
	private String customerId;
	private String cardNumber;
    private String expiryMm;
    private String expiryYyyy;
    private String nameOnCard;
    private String nickName;
    private String cardAddedSource;
    private String cvv2;
    private int status;
    private boolean primary;
    private String cardType;
    private String cardUnion;
    private String bankName;
    private String cardAssociation;
    private int onUs;
	private Timestamp cardAddedDate;
	private Timestamp cardUpdatedDate;

}
