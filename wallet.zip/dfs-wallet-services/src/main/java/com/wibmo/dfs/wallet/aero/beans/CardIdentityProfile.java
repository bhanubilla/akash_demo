package com.wibmo.dfs.wallet.aero.beans;

import java.io.Serializable;

import lombok.Data;

@Data
public class CardIdentityProfile implements Serializable {

	private static final long serialVersionUID = 1L;
	private String customerAadharCardNumber;
	private String customerPANCardNumber;
	private String customerPassportNumber;
	private String customerVoterIdNumber;
	private String customerDrivingLicenseNumber;
	private String creationDate;
	private String updatedDate;
	private String customerCkycRefNo;
	private String kycRefNo;
	private String kycDocRefNo;
	
}
