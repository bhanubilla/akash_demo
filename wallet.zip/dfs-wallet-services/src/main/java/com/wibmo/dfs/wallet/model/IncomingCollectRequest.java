package com.wibmo.dfs.wallet.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IncomingCollectRequest {
    private String collectStatus;
    private String txnMode;
    private long txnAmount;
    private String payerName;
    private String txnRefNumber;
    private String payeeMobileNumber;
    private String payeeVPA;
    private String payerVPA;
    private String walletId;
    private Map<String, String> additionalInformation;
    private String currency;
    private String remarks;
}
