package com.wibmo.dfs.wallet.controller;

import com.wibmo.dfs.wallet.adapter.CitrusPrepaidAdapter;
import com.wibmo.dfs.wallet.model.*;
import com.wibmo.dfs.wallet.service.*;
import com.wibmo.dfs.wallet.util.CommonUtil;
import com.wibmo.dfs.wallet.util.WibmoResponseUtil;
import com.wibmo.dfs.wallet.validation.RequestValidator;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;

@Slf4j
@RestController
@RequestMapping("/wallet/internal")
public class WalletInternalController {

	@Autowired
	private AccountsService service;
	
	@Autowired
	private AutoTopupService subscriptionService;

	@Autowired
	private WalletServiceFactory findService;

	@Autowired
	private RequestValidator validator;

	@Autowired
	private InternalWalletService internalWalletService;

	@Autowired
	private CitrusPrepaidAdapter citrusPrepaidAdapter;


	/**
	 * Validate Linked card Details
	 * @param request
	 * @param bankId
	 * @return
	 */
	
	@ApiOperation(value = "Validate Linked card Details", response = WibmoResponse.class)
	@ApiResponses(value={
	        @ApiResponse(code = 200, message = "Card Validated Successfully",response =WibmoResponse.class),
	        @ApiResponse(code = 100, message = "Card Not found",response =WibmoResponse.class),
	        @ApiResponse(code = 151, message = "Card number mismatched",response =WibmoResponse.class),
	        @ApiResponse(code = 152, message = "Expiry Month mismatched",response =WibmoResponse.class),
	        @ApiResponse(code = 153, message = "Expiry Year mismatched",response =WibmoResponse.class),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class),
	        @ApiResponse(code = 26, message = "customer id is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 58, message = "card number is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 400, message = "Request is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 59, message = "card expiry mm is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 60, message = "card expiry yyyy is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 66, message = "card id is empty",response =WibmoResponse.class)
	})
	@PostMapping("/validate/lc/v1")
	public ResponseEntity<WibmoResponse> validateLinkedCard(@RequestBody ValidateLinkedCardRequest request,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		request.setCustomerId(userId);
		Thread.currentThread().setName("validateLinkedCard");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), request.getCustomerId());
		WibmoResponse response = new WibmoResponse();
		validator.validatecardDetails(request, response, bankId);
		if (response.getResCode() > 0) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		return WibmoResponseUtil.frameResponse(service.validateLinkedCard(request, Integer.valueOf(bankId)));
	}
	
	@ApiOperation(value = "Check Wallet card Details", response = WibmoResponse.class)
	@ApiResponses(value={
	        @ApiResponse(code = 200, message = "Card Validated Successfully",response =WibmoResponse.class),
	        @ApiResponse(code = 100, message = "Card Not found",response =WibmoResponse.class),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class),
	        @ApiResponse(code = 21, message = "product type is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 150, message = "Mobile# or Customer Id is Mandatory",response =WibmoResponse.class),
	})
	@PostMapping("/check/wallet/v1")
	public ResponseEntity<WibmoResponse> checkWalletcard(@RequestBody CheckWalletCardRequest request,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {

		Thread.currentThread().setName("checkWalletCard");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), request.getCustomerId());
		WibmoResponse response = new WibmoResponse();
		validator.checkWalletCardDetails(request, response, bankId);
		if (response.getResCode() > 0) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		return WibmoResponseUtil.frameResponse(service.checkWalletCard(request, bankId));
	}
	
	@ApiOperation(value = "Update Auto Top Subscription", response = WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 69, message = "topup amount should not be lessthan or equal to zero",response=WibmoResponse.class),
			@ApiResponse(code = 80, message = "merchant Id is Mandatory",response=WibmoResponse.class),
			@ApiResponse(code = 83, message = "User Id Should be Greater than Zero",response=WibmoResponse.class),
			@ApiResponse(code = 84, message = "Subscription Status Should be Greater than Zero",response=WibmoResponse.class),
	        @ApiResponse(code = 100, message = "update Subscription Failed..",response =WibmoResponse.class),
	        @ApiResponse(code = 200, message = "Subscription updated Successfully..",response =WibmoResponse.class),
	        @ApiResponse(code = 400, message = "request is empty"),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR")
	})	
	@PostMapping("/updatesubscription/v1")
	public ResponseEntity<WibmoResponse> updateSubscription(@RequestBody UpdateAutoTopupSubscriptionRequest request,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		request.setUserId(Long.valueOf(userId));
		Thread.currentThread().setName("updateSubscription");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), String.valueOf(request.getUserId()));
		WibmoResponse response = new WibmoResponse();
		validator.validateUpdateSubscription(request, response, bankId);
		if (response.getResCode() > 0) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		return WibmoResponseUtil.frameResponse(subscriptionService.updateAutoTopup(request));
	}

	@ApiOperation(value = "Fetch user Details", response = WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 200, message = "Card Validated Successfully",response =WibmoResponse.class),
			@ApiResponse(code = 100, message = "Card Not found",response =WibmoResponse.class),
			@ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class)
	})
	@GetMapping("/fetch/user/{customerId}/v1")
	public ResponseEntity<WibmoResponse> fetchUserDetails(@NotNull @PathVariable("customerId")  String customerId, @RequestHeader(value = "X-PROGRAM-ID") String bankId) {
		Thread.currentThread().setName("fetcherUser");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), customerId);
		return WibmoResponseUtil.frameResponse(service.fetchUserDetails(customerId, bankId));
	}

	@ApiOperation(value = "Fetch user aml limits", response = WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 200, message = "Fetched limits successfully",response =WibmoResponse.class),
			@ApiResponse(code = 100, message = "Card Not found",response =WibmoResponse.class),
			@ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class)
	})
	@PostMapping("/check/user/aml-limits/v1")
	public ResponseEntity<WibmoResponse> checkUserAmlLimits(@RequestBody CheckUserAmlLimitsRequest request,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		request.setCustomerId(userId);
		Thread.currentThread().setName("checkUserAmlLimits");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), request.getCustomerId());
		WalletService ws = findService.getService(bankId);

		return WibmoResponseUtil.frameResponse(ws.checkAmlLimits(request,bankId));
	}

	@ApiOperation(value = "Check user limits", response = WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 200, message = "allow transaction",response =WibmoResponse.class),
			@ApiResponse(code = 37, message = "amount is zero",response =WibmoResponse.class),
			@ApiResponse(code = 101, message = "customerid/walletid or product type is mismatch",response =WibmoResponse.class),
			@ApiResponse(code = 110, message = "Transaction Flow is Mandatory",response =WibmoResponse.class),
			@ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class)
	})
	@PostMapping("/check/user/limits/v1")
	public ResponseEntity<WibmoResponse> checkUserLimits(@RequestBody CheckUserLimitsRequest request,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		request.setCustomerId(userId);
		Thread.currentThread().setName("checkUserLimits");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), request.getCustomerId());
		WibmoResponse response = new WibmoResponse();
		validator.validateUserLimits(request, response, bankId);
		if (response.getResCode() > 0) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		WalletService ws = findService.getService(bankId);

		return WibmoResponseUtil.frameResponse(ws.checkUserLimits(request,bankId));
	}


	@ApiOperation(value = "Update Card Holder Profile", response = WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 200, message = "Success",response =WibmoResponse.class),
			@ApiResponse(code = 150, message = "Failure",response =WibmoResponse.class),
	})
	@PutMapping("/v1/cardHolderProfile")
	public ResponseEntity<WibmoResponse> updateProfile(@RequestBody UpdateCardHolderProfileData request,
														 @RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		request.setAccountNumber(userId);
		Thread.currentThread().setName("updateCardHolderProfile");
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), request.getAccountNumber());
		WibmoResponse response = new WibmoResponse();
		if (response.getResCode() > 0) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		WalletService ws = findService.getService(bankId);

		return WibmoResponseUtil.frameResponse(ws.updateCardHolderProfile(request,bankId));
	}

	@PostMapping("/v1/persistWalletDetails")
	public ResponseEntity<WibmoResponse> saveCardDetails(@RequestHeader(value="X-PROGRAM-ID") String programId,
														 @RequestBody WalletDetailsRequest walletDetailsRequest){

		return WibmoResponseUtil.frameResponse(internalWalletService.persistWalletDetails(walletDetailsRequest,programId));
	}

	@PostMapping("/v1/mobileNumberBasedInquiry")
	public ResponseEntity<WibmoResponse> fetchCardAndMobileDetails(@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestBody WalletMobileNoBasedInquiryRequest walletMobileNoBasedInquiryRequest){
		log.info("mobileNumberBasedInquiry for mobile number : {}",walletMobileNoBasedInquiryRequest.getMobileNumber());
		walletMobileNoBasedInquiryRequest.setProgramId(bankId);
		return WibmoResponseUtil.frameResponse(citrusPrepaidAdapter.getCustomerProfile(walletMobileNoBasedInquiryRequest));
	}

}
