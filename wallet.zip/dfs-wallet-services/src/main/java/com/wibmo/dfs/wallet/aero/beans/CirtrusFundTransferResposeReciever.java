package com.wibmo.dfs.wallet.aero.beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CirtrusFundTransferResposeReciever {

        private long urn;
        private String customerId;
        private long accosaRefNo;
        private long availableBalance;
        private long transactionAmount;
}
