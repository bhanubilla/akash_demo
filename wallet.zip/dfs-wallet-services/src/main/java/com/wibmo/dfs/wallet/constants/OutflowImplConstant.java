package com.wibmo.dfs.wallet.constants;

/**
 *
 * @author ajay mahto
 */
public enum OutflowImplConstant {	
	
	P2P_DEBIT(10002);	
	
	private int implId;
	 OutflowImplConstant(int implId){
		this.implId=implId;
	}
	 
	public int getImplId() {
		return this.implId;
	}
	
}

