package com.wibmo.dfs.wallet.kafka.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class W2UPITxnDetailsRequest extends BaseDetails{
    private String paymentTxnId;
    private String sourceAccount;
    private String destAccount;
    private String additionalFields;
    private long txnDate;
    private String originalTxnId;
    private String ppTxnId;
    private String merTxnId;
}
