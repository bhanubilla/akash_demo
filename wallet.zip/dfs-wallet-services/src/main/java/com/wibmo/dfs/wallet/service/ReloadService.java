package com.wibmo.dfs.wallet.service;

public interface ReloadService {
    boolean reloadProgParameter(String programId, String paramName);
    boolean reloadMsgDetail(String programId, String msgName);
    boolean reloadAeroCMSConf(String programId, int ppBnkId);
    boolean reloadPPMaster(String programId, int ppId);
    boolean reloadPPBnkMapping(String programId, int ppBnkId);
    String fetchProgParameters(String programId, String paramName);
    String fetchMsgDetails(String programId, String msgName);
    boolean reloadBankId(String programId);
    boolean reloadWalletWithId(String programId, int walletId);
    boolean reloadWalletWithCustIdAndProdType(String programId, String custId, String productType);
}
