package com.wibmo.dfs.wallet.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BeneficiaryBankAccounts implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;
	private String customerId;
	private String accountNumber;
	private String accountName;
	private String ifscCode;
	private String vpa;
	private String bankName;
	private String accountType;
	private String branchName;	
	private Timestamp createdTime;
	private Timestamp updatedTime;
	
}
