package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SBTxnDetails {

	private String resDesc;
	private int resCode;
	private long amount ;
	private String txnId ;
	private String requesteeMobile;
	private String requesteeName;
}
