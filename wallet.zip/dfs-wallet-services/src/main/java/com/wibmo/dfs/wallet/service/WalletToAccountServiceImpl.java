package com.wibmo.dfs.wallet.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.platform.fw.multitenantconfig.ThreadLocalStorage;
import com.wibmo.dfs.wallet.common.MsgConstants;
import com.wibmo.dfs.wallet.common.ProgramParamConstants;
import com.wibmo.dfs.wallet.constants.AckTxnTypes;
import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.constants.ServiceHttpStatus;
import com.wibmo.dfs.wallet.entity.BeneficiaryBankAccounts;
import com.wibmo.dfs.wallet.entity.W2ACPConsumption;
import com.wibmo.dfs.wallet.entity.W2AConsumption;
import com.wibmo.dfs.wallet.kafka.KafkaProducer;
import com.wibmo.dfs.wallet.kafka.model.TxnDetails;
import com.wibmo.dfs.wallet.kafka.model.W2ATxnDetailsRequest;
import com.wibmo.dfs.wallet.model.*;
import com.wibmo.dfs.wallet.repository.*;
import com.wibmo.dfs.wallet.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URI;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class WalletToAccountServiceImpl implements WalletToAccountService{

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    MsgsRepository msgsRepository;

    @Autowired
    KafkaProducer kafkaProducer;

    @Autowired
    W2ALimitConsumptionRepository limitConsumptionRepo;

    @Autowired
    W2ACPLimitConsumptionRepository cpLimitConsumptionRepo;
    
    @Autowired
    BeneficaryBankAccountsRepository beneficaryBankAccountsRepository;

    @Value("${resource.url.admin}")
    String adminUrl;

    @Autowired
    WalletServiceFactory findService;

    @Autowired
    ProgramParametersRepository programParametersRepository;

    public static final BigDecimal ONE_HUNDRED = new BigDecimal(100);

    @Override
    public WibmoResponse w2aVerification(W2AVerificationRequest request, int bankId, String userId) {
        WibmoResponse wibmoResponse;
        ObjectMapper mapper = new ObjectMapper();
        BeneficiaryBankAccounts beneficiaryBankAccount;
        try{
        	
        	String transactionMode = programParametersRepository.fetchParamValueByParamName(String.valueOf(bankId),
    				ProgramParamConstants.ALLOWED_TRANSACTION_MODES);
    		List<String> transactionModes = Arrays.asList(transactionMode.split("\\s*,\\s*"));
    
				if (!transactionModes.contains("W2A")) {
					W2AVerificationResponse w2AVerificationResponse = new W2AVerificationResponse();
					w2AVerificationResponse.setTotalTxnAmount(request.getTxnAmt());
					wibmoResponse = new WibmoResponse(Constants.SUCCESS_RESPONSE_CODE, Constants.RESPONSE_DESC_SUCCESS, w2AVerificationResponse);
				} 
				
			 else {

            log.info("Request received for W2A Verification {} -- {} ",bankId, userId);

            wibmoResponse = checkWalletBalance(request, String.valueOf(bankId));

            if(wibmoResponse.getResCode() != 1)
            {
                return wibmoResponse;
            }

            FetchCardBalanceResponse walletBalance = (FetchCardBalanceResponse) wibmoResponse.getData();

            beneficiaryBankAccount = identifyBeneficiary(request, bankId, userId);

            beneficiaryBankAccount = verifyBeneficiary(beneficiaryBankAccount, request, bankId, userId);

            if (beneficiaryBankAccount == null) {
                log.info("Failed to saved Beneficiary Bank Account for customerId:{}", userId);
                wibmoResponse.setResCode(150);
                wibmoResponse.setResDesc(msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId), MsgConstants.BENEFICIARY_ACCOUNTS_ADD_FAILED));
                return wibmoResponse;
            } else {
                request.setBeneficiaryId(beneficiaryBankAccount.getId());
            }

            wibmoResponse = invokeApi(adminUrl, Constants.ADMIN_FETCH_CONFIG_URL, HttpMethod.GET, bankId, request.getTxnType());
            if(wibmoResponse == null){
                return new WibmoResponse(ServiceHttpStatus.FAILURE.getStatusCode(),msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),MsgConstants.FAILED_TO_CALL_SERVICE));
            }
            if(wibmoResponse.getResCode() != 200) {
                return wibmoResponse;
            }

            FetchConfigurationResponse configurations = mapper.convertValue(wibmoResponse.getData(),FetchConfigurationResponse.class);

            wibmoResponse = validateRequest(request, beneficiaryBankAccount,configurations,walletBalance, bankId, userId);
			}

        }
        catch(Exception e){
            log.error(Constants.ERR_DESC, e.getMessage());
            wibmoResponse = new WibmoResponse(ServiceHttpStatus.INTERNAL_ERROR.getStatusCode(),ServiceHttpStatus.INTERNAL_ERROR.getStatusMsg());
        }
        return wibmoResponse;
    }

    @Override
    public WibmoResponse w2aTransacation(W2ADebitRequest request, WalletService service, String bankId, String userId) {
        FundRequest fundRequest;
        WibmoResponse wibmoResponse;
        FetchCardRequest inquiry = new FetchCardRequest();
        try
        {
            inquiry.setWalletId(request.getWalletId());
            wibmoResponse = service.inquiry(inquiry);

            if(wibmoResponse.getResCode() != 1) {
                return wibmoResponse;
            }

            FetchCardResponse cardResp = (FetchCardResponse) wibmoResponse.getData();

            fundRequest = prepareWalletDebitReq(request);

            wibmoResponse = service.fundsUnload(fundRequest);

            FundResponse debitResponse = new ObjectMapper().convertValue(wibmoResponse.getData(), FundResponse.class);

            //Add Txn History kafka call
            prepareTxnHistoryData(request, debitResponse, cardResp, bankId);

        }
        catch(Exception e){
            log.error(Constants.ERR_DESC, e.getMessage());
            log.error("Problem is ",e);
            wibmoResponse = new WibmoResponse(ServiceHttpStatus.INTERNAL_ERROR.getStatusCode(),ServiceHttpStatus.INTERNAL_ERROR.getStatusMsg());
        }
        return wibmoResponse;
    }
    
    
    public void prepareTxnHistoryData(W2ADebitRequest request, FundResponse debitResponse, FetchCardResponse cardResp, String bankId) {
        StringBuilder txnDesc = new StringBuilder();
        String maskPattern = "";
        try {
            try {
                ThreadLocalStorage.setTenantId(Integer.parseInt(bankId));
                maskPattern = programParametersRepository
                        .fetchParamValueByParamName(bankId, ProgramParamConstants.CARD_MASK_PATTERN);
            } finally {
                ThreadLocalStorage.clear();
            }
            Map<String, Object> additionDetails = new HashMap<>();
            W2ATxnDetailsRequest w2ATxnDetailsRequest = new W2ATxnDetailsRequest();
            w2ATxnDetailsRequest.setCustomerId(request.getCustId());
            w2ATxnDetailsRequest.setMobile(cardResp.getMobile());
            w2ATxnDetailsRequest.setPaymentMode(cardResp.getProductType());
            w2ATxnDetailsRequest.setTxnType(Constants.W2A);
            w2ATxnDetailsRequest.setMerCategory(Constants.OTHERS);
            w2ATxnDetailsRequest.setTxnCategory(request.getTxnType());
            w2ATxnDetailsRequest.setTxnAmount(request.getFinalAmount());
            w2ATxnDetailsRequest.setPaymentTxnId(request.getRrn());
            w2ATxnDetailsRequest.setTxnStatus(Constants.PENDING);
            w2ATxnDetailsRequest.setTxnDate(Timestamp.valueOf(LocalDateTime.now()));
            w2ATxnDetailsRequest.setSourceAccount(CommonUtil.maskCardNumberWOPlaceHolder(cardResp.getCardNumber(),maskPattern));
            txnDesc.append(Constants.SENT).append(CommonUtil.decimalFormat(request.getTxnAmount())).append(Constants.TO);
            if(request.getTxnType().equals(Constants.W2A)) {
                txnDesc.append(request.getBeneficiaryAccountName());
                w2ATxnDetailsRequest.setTxnShortDesc(request.getBeneficiaryAccountName());
                log.info("beneficiary Acc no {} & maskPattern  {}", request.getBeneficiaryAccountNumber(), maskPattern);
                w2ATxnDetailsRequest.setDestAccount(CommonUtil.maskCardNumberWOPlaceHolder(request.getBeneficiaryAccountNumber(),maskPattern));
            }
            else {
                txnDesc.append(request.getBeneficiaryVpaName());
                w2ATxnDetailsRequest.setTxnShortDesc(request.getBeneficiaryVpaName());

                String[] account = request.getBeneficiaryVpa().split("@");
                w2ATxnDetailsRequest.setDestAccount("*".repeat(account[0].length())+"@"+account[1]);
            }
            w2ATxnDetailsRequest.setTxnDesc(txnDesc.toString());
            log.info("Txn desc {} {}",w2ATxnDetailsRequest.getTxnDesc(), request.getTxnAmount());
            w2ATxnDetailsRequest.setClosingBalance((long) CommonUtil.decimalFormatWithoutComma(cardResp.getBalance()));
            additionDetails.put(Constants.FEE_AMT, request.getFeeAmount());
            additionDetails.put(Constants.IGST_AMT, request.getGstAmount());
            additionDetails.put(Constants.CGST_AMT, request.getCgstAmount());
            additionDetails.put(Constants.SGST_AMT, request.getSgstAmount());
            additionDetails.put(Constants.FEE_GST_PERCENTAGE, request.getFeeGstPercentage());
            w2ATxnDetailsRequest.setAdditionalFields(new ObjectMapper().writeValueAsString(additionDetails));
            w2ATxnDetailsRequest.setPpTxnId(debitResponse.getPpTxnId());

            w2ATxnDetailsRequest.setTxnCategory(Constants.W2AD);
            w2ATxnDetailsRequest.setMerCategory(request.getTxnType());
            w2ATxnDetailsRequest.setTxnFlow(Constants.OUT_TXN_FLOW);
            w2ATxnDetailsRequest.setOriginalTxnId(request.getRrn());

            TxnDetails txn = new TxnDetails();
            txn.setProgramId(bankId);
            txn.setTxnType(AckTxnTypes.W2A.getType());
            txn.setData(w2ATxnDetailsRequest);
            Runnable runnable = () -> kafkaProducer.publishWalletTxn(txn);
            new Thread(runnable).start();
        }
        catch(Exception e)
        {
            log.debug("failed to push record to Transaction history {} -- SourceAccount {}",request, CommonUtil.maskCardNumberWOPlaceHolder(cardResp.getCardNumber(),maskPattern));
            log.error(" Problem is ", e);
        }
    }
    
    public FundRequest prepareWalletDebitReq(W2ADebitRequest request){
        FundRequest fundRequest = new FundRequest();
        fundRequest.setCustId(request.getCustId());
        fundRequest.setWalletId(request.getWalletId());
        fundRequest.setAmount(request.getFinalAmount());
        fundRequest.setRrn(request.getRrn());
        fundRequest.setTxnType(Constants.W2A_DEBIT);
        fundRequest.setMerchantId(request.getMerchantId());
        fundRequest.setSourceAccount(request.getSourceAccount());
        return fundRequest;
    }
    
    private WibmoResponse checkWalletBalance(W2AVerificationRequest request, String bankId)
    {
        FetchCardBalanceRequest fetchCardBalanceRequest = new FetchCardBalanceRequest();
        fetchCardBalanceRequest.setWalletId(Integer.parseInt(request.getSourceRefId()));
        WalletService ws = findService.getService(bankId);
        return ws.fetchCardBalance(fetchCardBalanceRequest);
    }
    private BeneficiaryBankAccounts identifyBeneficiary(W2AVerificationRequest request, int bankId, String userId) {
        BeneficiaryBankAccounts beneficiaryBankAccount = null;
        try {
            boolean useBeneficiaryId = request.getBeneficiaryId() != 0;
            if(useBeneficiaryId) {
                beneficiaryBankAccount = beneficaryBankAccountsRepository.fetchBeneficiaryBankAccByBenefId(userId, bankId, request.getBeneficiaryId());
            }
            else {
                beneficiaryBankAccount = beneficaryBankAccountsRepository.fetchBeneficaryBankAccByBenefInfo(userId, bankId, request);
            }
        }
        catch(Exception e){
            log.error("Error occurred in identifyBeneficiary {}", e.getMessage());
        }
        return beneficiaryBankAccount;
    }
    private BeneficiaryBankAccounts verifyBeneficiary(BeneficiaryBankAccounts beneficiaryBankAccount, W2AVerificationRequest request, int bankId, String userId){
        int beneficiarySaved = 0;
        try {
            if (null == beneficiaryBankAccount) {
                log.info("Beneficiary {} not there for customerId:{}", request.getBeneficiaryId(), userId);
                beneficiaryBankAccount = new BeneficiaryBankAccounts();
                beneficiaryBankAccount.setCustomerId(userId);
                if(request.getTxnType().equals(Constants.W2A)){
                    beneficiaryBankAccount.setAccountNumber(request.getBeneficiaryAccountNumber());
                    beneficiaryBankAccount.setAccountName(request.getBeneficiaryName());
                    beneficiaryBankAccount.setIfscCode(request.getBeneficiaryIfscCode());
                    beneficiarySaved = beneficaryBankAccountsRepository.save(beneficiaryBankAccount, bankId);
                }else if(request.getTxnType().equals(Constants.W2UPI)){
                    beneficiaryBankAccount.setVpa(request.getVpa());
                    beneficiarySaved = beneficaryBankAccountsRepository.save(beneficiaryBankAccount, bankId);
                }
                if(beneficiarySaved > 0)
                    return beneficaryBankAccountsRepository.fetchBeneficaryBankAccByBenefInfo(userId, bankId, request);
            }
            else {
                if(StringUtils.isEmpty(beneficiaryBankAccount.getVpa())){
                    if(!StringUtils.isEmpty(beneficiaryBankAccount.getAccountNumber())){
                        request.setTxnType(Constants.W2A);
                    }
                }
                else request.setTxnType(Constants.W2UPI);
            }
        }
        catch(Exception e){
            log.error(Constants.ERR_DESC, e.getMessage());
        }
        return beneficiaryBankAccount;
    }
    private WibmoResponse validateRequest(W2AVerificationRequest request, BeneficiaryBankAccounts beneficiaryBankAccount, FetchConfigurationResponse configurations, FetchCardBalanceResponse walletBalance, int bankId, String userId)
    {
        String limitKey = null;
        LocalDateTime fromCoolingPeriodTime;
        boolean coolingPeriodEnabled = false;
        LocalDateTime toCoolingPeriodTime = null;
        WibmoResponse wibmoResponse = new WibmoResponse();
        BeneficiaryLimits beneficiaryLimits = new BeneficiaryLimits();
        W2AVerificationResponse w2AVerificationResponse = new W2AVerificationResponse();
        DateTimeFormatter formatterCP = DateTimeFormatter.ofPattern(Constants.DATE_FORMAT_FOR_CP);
        try{

            CoolingPeriod coolingPeriod = configurations.getCoolingPeriod();
            if(coolingPeriod == null){
                log.debug("Cooling Period not configured for transaction type {}", request.getTxnType());
            }
            else{
                long beneficiaryCreatedTime = beneficiaryBankAccount.getCreatedTime().getTime();

                for (int i = 0; i < coolingPeriod.getLimit().size(); i++) {
                    int fromTime = coolingPeriod.getLimit().get(i).getFromTime() * 60 * 1000;
                    fromCoolingPeriodTime = (new Timestamp(beneficiaryCreatedTime + fromTime)).toLocalDateTime();

                    int toTime = coolingPeriod.getLimit().get(i).getToTime() * 60 * 1000;
                    toCoolingPeriodTime = (new Timestamp(beneficiaryCreatedTime + toTime)).toLocalDateTime();

                    if (LocalDateTime.now().isAfter(fromCoolingPeriodTime) && LocalDateTime.now().isBefore(toCoolingPeriodTime)) {
                        limitKey = formatterCP.format(toCoolingPeriodTime);
                        beneficiaryLimits = coolingPeriod.getLimit().get(i);
                        coolingPeriodEnabled = true;
                        break;
                    }
                }
            }

            w2AVerificationResponse.setBeneficiaryId(request.getBeneficiaryId());
            w2AVerificationResponse.setCoolingPeriod(coolingPeriodEnabled);
            w2AVerificationResponse.setLimitKey(limitKey);
            w2AVerificationResponse.setTxnAmt(request.getTxnAmt());
            w2AVerificationResponse.setProductType(walletBalance.getProductType());
            w2AVerificationResponse.setBeneficiaryName(beneficiaryBankAccount.getAccountName());
            w2AVerificationResponse.setBeneficiaryAccountNumber(beneficiaryBankAccount.getAccountNumber());
            w2AVerificationResponse.setBeneficiaryVpa(beneficiaryBankAccount.getVpa());

            log.debug("Fetch Limit Consumption from db");
            W2AWholeConsumption limitConsumption = fetchLimitConsumption(bankId, userId, request.getTxnType(), limitKey, request.getBeneficiaryId());
            if(limitConsumption == null) {
                wibmoResponse.setResCode(ServiceHttpStatus.FAILURE.getStatusCode());
                wibmoResponse.setResDesc(msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),MsgConstants.FAILED_CONSUMPTION));
                return wibmoResponse;
            }
           wibmoResponse = processCoolingPeriod(coolingPeriodEnabled, wibmoResponse, limitConsumption, beneficiaryLimits, bankId, toCoolingPeriodTime, request);

            if(wibmoResponse.getResCode() == 0 || wibmoResponse.getResCode() == 200) {
                wibmoResponse = verifyTransactionCountAndAmountLimit(request, configurations.getLimitMaster(), limitConsumption, String.valueOf(bankId));
            }
            if(wibmoResponse.getResCode() == 0 || wibmoResponse.getResCode() == 200) {
                wibmoResponse = calculateFee(request, configurations.getFeeMaster(), w2AVerificationResponse, walletBalance, bankId);
            }
            if(wibmoResponse.getResCode() == 0)
            {
                w2AVerificationResponse = prepareResponse(request, bankId, limitKey, coolingPeriodEnabled);
                wibmoResponse = new WibmoResponse(Constants.SUCCESS_RESPONSE_CODE, Constants.RESPONSE_DESC_SUCCESS, w2AVerificationResponse);
            }
        }
        catch(Exception e){
            log.error(Constants.ERR_DESC, e.getMessage());
            wibmoResponse = new WibmoResponse(ServiceHttpStatus.INTERNAL_ERROR.getStatusCode(),ServiceHttpStatus.INTERNAL_ERROR.getStatusMsg());
        }
        return wibmoResponse;
    }

    private WibmoResponse processCoolingPeriod(boolean coolingPeriodEnabled, WibmoResponse wibmoResponse, W2AWholeConsumption limitConsumption, BeneficiaryLimits beneficiaryLimits, int bankId, LocalDateTime toCoolingPeriodTime, W2AVerificationRequest request) {
        WibmoResponse response = wibmoResponse;
        if (coolingPeriodEnabled) {
            log.debug("Beneficiary {} is in cooling period. So checking Count & Amount Validation", request.getBeneficiaryId());
            response = verifyBeneficiaryCountAndAmountLimit(limitConsumption, beneficiaryLimits, bankId, toCoolingPeriodTime, request.getTxnAmt());
        } else
            log.debug("No need to check cooling period.Free to do transaction to beneficiary");
        return response;
    }

    private WibmoResponse verifyBeneficiaryCountAndAmountLimit(W2AWholeConsumption consumption, BeneficiaryLimits beneficiaryLimits, int bankId, LocalDateTime coolingPeriodEndTime, long txnAmt){
        StringBuilder errMsg = new StringBuilder();
        WibmoResponse response = new WibmoResponse();
        try {

            if(beneficiaryLimits.getCountLimit() != -1 && consumption.getBeneficiaryCntLmt()+1 > beneficiaryLimits.getCountLimit()) {
                response.setResCode(300);
                response.setResDesc(msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),MsgConstants.COOLING_PERIOD_COUNT_EXCEEDED));
                return response;
            }

            if(beneficiaryLimits.getAmountLimit() != -1 && Long.sum(consumption.getBeneficiaryAmtLmt(),txnAmt) > beneficiaryLimits.getAmountLimit()) {
                Duration duration = Duration.between(LocalDateTime.now().plusHours(8).plusMinutes(20), coolingPeriodEndTime);
                if(duration.toHours() > 0)
                    errMsg.append(duration.toHours()).append(" hour(s).");
                else
                    errMsg.append(duration.toMinutes()).append(" minute(s).");
                String velocityAmt = CommonUtil.decimalFormat(beneficiaryLimits.getAmountLimit() - consumption.getBeneficiaryAmtLmt());
                response.setResCode(300);
                response.setResDesc(String.format(msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),MsgConstants.COOLING_PERIOD_AMOUNT_EXCEEDED),velocityAmt,errMsg));
                return response;
            }
        }
        catch (Exception e){
            log.error(Constants.ERR_DESC, e.getMessage());
            response = new WibmoResponse(ServiceHttpStatus.INTERNAL_ERROR.getStatusCode(),ServiceHttpStatus.INTERNAL_ERROR.getStatusMsg());
        }
        return response;
    }
    private WibmoResponse verifyTransactionCountAndAmountLimit(W2AVerificationRequest request, LimitMaster limit, W2AWholeConsumption consumption, String bankId){
        TransactionLimits limits ;
        WibmoResponse response = new WibmoResponse();
        try {
            if(limit == null) {
                log.debug("Limit not configured for transaction type {}", request.getTxnType());
                return response;
            }
            if(request.getTxnAmt() > limit.getPerTxnAmt()){
                String velocityAmt = CommonUtil.decimalFormat(limit.getPerTxnAmt());
                response.setResCode(300);
                response.setResDesc(String.format(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.MAX_AMT_PER_TXN_EXCEEDED),velocityAmt));
                return response;
            }
            for (int i=0; i < limit.getLimit().size(); i++)
            {
                limits = limit.getLimit().get(i);
                if(Constants.LIMIT_WINDOW.DAILY.name().equals(limits.getWindow()))
                {
                    if(consumption.getDailyCntLmt()+1 > limits.getCountLimit()){
                        response.setResCode(300);
                        response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.DAILY_LMT_CNT_EXCEEDED));
                        return response;
                    }
                    if(Long.sum(consumption.getDailyAmtLmt(), request.getTxnAmt()) > limits.getAmountLimit()){
                        String velocityAmt = CommonUtil.decimalFormat(limits.getAmountLimit() - consumption.getDailyAmtLmt());
                        response.setResCode(300);
                        response.setResDesc(String.format(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.DAILY_LMT_AMT_EXCEEDED),velocityAmt));
                        return response;
                    }
                }
                response = processLimitWindowMonthly(limits, response, consumption, bankId, request);
            }

        }
        catch (Exception e){
            log.error(Constants.ERR_DESC, e.getMessage());
            return new WibmoResponse(ServiceHttpStatus.INTERNAL_ERROR.getStatusCode(), ServiceHttpStatus.INTERNAL_ERROR.getStatusMsg());
        }
        return response;
    }

    private WibmoResponse processLimitWindowMonthly(TransactionLimits limits, WibmoResponse response, W2AWholeConsumption consumption, String bankId, W2AVerificationRequest request) {
        WibmoResponse response1 = response;
        if (Constants.LIMIT_WINDOW.MONTHLY.name().equals(limits.getWindow())) {
            if (consumption.getMonthlyCntLmt() + 1 > limits.getCountLimit()) {
                response1.setResCode(300);
                response1.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId, MsgConstants.MONTHLY_LMT_CNT_EXCEEDED));
                return response1;
            }
            if (Long.sum(consumption.getMonthlyAmtLmt(), request.getTxnAmt()) > limits.getAmountLimit()) {
                String velocityAmt = CommonUtil.decimalFormat(limits.getAmountLimit() - consumption.getMonthlyAmtLmt());
                response1.setResCode(300);
                response1.setResDesc(String.format(msgsRepository.fetchMsgValueByMsgName(bankId, MsgConstants.MONTHLY_LMT_AMT_EXCEEDED), velocityAmt));
                return response1;
            }
        }
        return response1;
    }

    private WibmoResponse calculateFee(W2AVerificationRequest request, FeeMaster feeMaster, W2AVerificationResponse w2AVerificationResponse, FetchCardBalanceResponse walletBalance, int bankId)
    {
        WibmoResponse response = new WibmoResponse();
        try {
            w2AVerificationResponse.setBeneficiaryId(request.getBeneficiaryId());
            if (feeMaster == null) {
                log.debug("Fee not configured for transaction type {}", request.getTxnType());
                return response;
            }
            log.debug("Calculating Fee");
            if (feeValidation(w2AVerificationResponse, feeMaster, request.getTxnAmt(), bankId)) {

                if(CommonUtil.decimalFormatWithoutComma(w2AVerificationResponse.getTotalTxnAmount()) > walletBalance.getBalance())
                {
                    return new WibmoResponse(300, msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),MsgConstants.INSUFFICIANT_BALANCE));
                }
                return new WibmoResponse(Constants.SUCCESS_RESPONSE_CODE, Constants.RESPONSE_DESC_SUCCESS, w2AVerificationResponse);
            } else {
                response.setResCode(ServiceHttpStatus.FAILURE.getStatusCode());
                response.setResDesc(msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId), MsgConstants.FEE_VALIDATION_FAILED));
                return response;
            }
        }
        catch (Exception e){
            log.error(Constants.ERR_DESC, e.getMessage());
            return new WibmoResponse(ServiceHttpStatus.INTERNAL_ERROR.getStatusCode(), ServiceHttpStatus.INTERNAL_ERROR.getStatusMsg());
        }
    }
    public boolean feeValidation(W2AVerificationResponse w2AVerificationResponse, FeeMaster feeMaster, long txnAmt, int bankId){
        double feeAmt;
        double gstAmt;
        double originalTxnAmt;
        boolean response =false;
        TransactionGSTMaster gstMaster;
        try {
            gstMaster = feeMaster.getGst();
            originalTxnAmt = CommonUtil.decimalFormatWithoutComma(txnAmt);
            w2AVerificationResponse.setFeeAmount(percentage(BigDecimal.valueOf(originalTxnAmt), new BigDecimal(feeMaster.getFeePercentage())));
            feeAmt = CommonUtil.decimalFormatWithoutComma(originalTxnAmt * feeMaster.getFeePercentage());
            w2AVerificationResponse.setGst(percentage(BigDecimal.valueOf(feeAmt), new BigDecimal(feeMaster.getGst().getIgst())));
            gstAmt = CommonUtil.decimalFormatWithoutComma(feeAmt * Double.parseDouble(gstMaster.getIgst()));

            BigDecimal percentageAmt = BigDecimal.valueOf(Double.sum(originalTxnAmt, Double.sum(feeAmt, gstAmt)));
            w2AVerificationResponse.setTotalTxnAmount(Long.parseLong(percentageAmt.setScale(2, RoundingMode.HALF_UP).toString().replace("\\.","")));
            w2AVerificationResponse.setCgst(percentage(BigDecimal.valueOf(feeAmt), new BigDecimal(feeMaster.getGst().getCgst())));
            w2AVerificationResponse.setSgst(percentage(BigDecimal.valueOf(feeAmt), new BigDecimal(feeMaster.getGst().getSgst())));
            w2AVerificationResponse.setFeeGstPercentage(feeMaster.getFeePercentage()+"|"+gstMaster.getIgst()+"|"+gstMaster.getCgst()+"|"+gstMaster.getSgst());
            w2AVerificationResponse.setMessage(msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),MsgConstants.W2A_MESSAGE_TITLE));
            response = true;
        }
        catch (Exception e){
            log.error(Constants.ERR_DESC, e.getMessage());
        }
        return response;
    }

    public static long percentage(BigDecimal base, BigDecimal pct){
        BigDecimal percentageAmt = base.multiply(pct).divide(ONE_HUNDRED);
        log.info("Before roundOff {}", percentageAmt);
        return Long.parseLong(percentageAmt.setScale(2, RoundingMode.HALF_UP).toString().replace(".",""));
    }
    public WibmoResponse updateLimitConsumption(LimitConsumptionRequest request, int bankId, String userId)
    {
        int response = 0;
        WibmoResponse wibmoResponse;
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(Constants.DATE_FORMAT);
        String endDate = today.with(TemporalAdjusters.lastDayOfMonth()).toString();
        String startDate = today.with(TemporalAdjusters.firstDayOfMonth()).toString();
        try {
            if(request.isBenefIsInCoolingPeriod()){
                 response = chkCPConsumption(request, userId, request.getLimitKey());
                if(response == 0)  {
                    log.info("Failed to update limit consumption for beneficiary {} with txnType {} & limitKey {}", request.getBeneficiaryId(), request.getTxnType(), request.getLimitKey());
                }
            }
            request.setBeneficiaryId(0);
            log.info("Trying to update Daily Amount & Count");
            response = chkConsumption(request, userId, formatter.format(today), today.toString(), today.toString());

            if(response > 0) {
                log.info("Trying to update Monthly Amount & Count");
                response = chkConsumption(request, userId, formatter.format(today).substring(2, 8), startDate, endDate);
            }

            if(response > 0)  {
                wibmoResponse = new WibmoResponse(ServiceHttpStatus.SUCCESS.getStatusCode(), ServiceHttpStatus.SUCCESS.getStatusMsg());
            }else {
                wibmoResponse = new WibmoResponse(ServiceHttpStatus.FAILURE.getStatusCode(), ServiceHttpStatus.FAILURE.getStatusMsg());
            }

        }
        catch (Exception e){
            log.error(Constants.ERR_DESC, e.getMessage());
            wibmoResponse = new WibmoResponse(ServiceHttpStatus.INTERNAL_ERROR.getStatusCode(), ServiceHttpStatus.INTERNAL_ERROR.getStatusMsg());
        }
        return wibmoResponse;
    }
    public int chkConsumption(LimitConsumptionRequest request, String userId, String date, String startDate, String endDate) {
        W2AConsumption consumption;
        try
        {
            consumption = limitConsumptionRepo.isConsumptionAvailable(request, userId, date, startDate, endDate);
            consumption.setLimitKey(date);
            if(consumption.getCntLmt() == 0) {
                log.info("Consumption not available in db for limit key {}. Hence inserting for beneficiary is in cooling period", date);
                consumption.setAmtLmt(request.getTxnAmt());
                consumption.setCntLmt(1);
                return limitConsumptionRepo.save(consumption);
            }
            else {
                log.info("Consumption available in db for limit key {}. Hence updating for beneficiary is in cooling period", date);
                consumption.setAmtLmt(Long.sum(request.getTxnAmt(), consumption.getAmtLmt()));
                consumption.setCntLmt(consumption.getCntLmt() + 1);
                return limitConsumptionRepo.update(consumption, startDate, endDate);
            }
        }
        catch(Exception e)
        {
            log.info("Unable to proceed in chkConsumption >> Error is {}", e.getMessage());
        }
        return 0;
    }
    public int chkCPConsumption(LimitConsumptionRequest request, String userId, String date) {
        W2ACPConsumption consumption;
        String startDate = LocalDate.now().with(TemporalAdjusters.firstDayOfMonth()).toString();
        String endDate = LocalDate.now().with(TemporalAdjusters.lastDayOfMonth()).toString();
        try
        {
            consumption = cpLimitConsumptionRepo.isConsumptionAvailable(request, userId, date, startDate, endDate);
            consumption.setBeneficiaryId(request.getBeneficiaryId());
            consumption.setLimitKey(date);
            if(consumption.getCntLmt() == 0) {
                log.info("Consumption not available in db for limit key {}. Hence inserting for beneficiary is in cooling period", date);
                consumption.setAmtLmt(request.getTxnAmt());
                consumption.setCntLmt(1);
                return cpLimitConsumptionRepo.save(consumption);
            }
            else {
                log.info("Consumption available in db for limit key {}. Hence updating for beneficiary is in cooling period", date);
                consumption.setAmtLmt(Long.sum(request.getTxnAmt(), consumption.getAmtLmt()));
                consumption.setCntLmt(consumption.getCntLmt() + 1);
                return cpLimitConsumptionRepo.update(consumption, startDate, endDate);
            }
        }
        catch(Exception e)
        {
            log.info("Unable to proceed in chkCPConsumption >> Error is {}", e.getMessage());
        }
        return 0;
    }
    @Override
    public W2AWholeConsumption fetchLimitConsumption(int bankId, String userId, String txnType, String limitKey, int beneficiary)
    {
        W2AConsumption consumption;
        W2ACPConsumption cpConsumption;
        LocalDate today = LocalDate.now();
        W2AWholeConsumption wholeConsumption = new W2AWholeConsumption();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(Constants.DATE_FORMAT);
        String startDate = today.with(TemporalAdjusters.firstDayOfMonth()).toString();
        String endDate = today.with(TemporalAdjusters.lastDayOfMonth()).toString();
        try {
            wholeConsumption.setCustomerId(Integer.parseInt(userId));
            if(beneficiary > 0){
                wholeConsumption.setBeneficiaryId(beneficiary);
                cpConsumption = cpLimitConsumptionRepo.fetch(bankId, userId, txnType, beneficiary, limitKey, LocalDate.now().with(TemporalAdjusters.firstDayOfMonth()).toString(), LocalDate.now().with(TemporalAdjusters.lastDayOfMonth()).toString());
                if(cpConsumption.getCntLmt() != 0){
                    wholeConsumption.setBeneficiaryCntLmt(cpConsumption.getCntLmt());
                    wholeConsumption.setBeneficiaryAmtLmt(cpConsumption.getAmtLmt());
                }
            }
            consumption = limitConsumptionRepo.fetch(bankId, userId, txnType, formatter.format(today), today.toString(), today.toString());
            if(consumption.getCntLmt() != 0){
                wholeConsumption.setDailyCntLmt(consumption.getCntLmt());
                wholeConsumption.setDailyAmtLmt(consumption.getAmtLmt());
            }
            consumption = limitConsumptionRepo.fetch(bankId, userId, txnType, formatter.format(today).substring(2,8), startDate, endDate);
            if(consumption.getCntLmt() != 0){
                wholeConsumption.setMonthlyCntLmt(consumption.getCntLmt());
                wholeConsumption.setMonthlyAmtLmt(consumption.getAmtLmt());
            }
        }
        catch (Exception e)
        {
            log.error("Err Desc in fetchLimitConsumption {}", e.getMessage());
        }
        return wholeConsumption;
    }
    private W2AVerificationResponse prepareResponse (W2AVerificationRequest request, int bankId, String limitKey, boolean isCoolingPeriodEnabled)
    {
        W2AVerificationResponse response = new W2AVerificationResponse();
        response.setMessage(msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),MsgConstants.W2A_MESSAGE_TITLE));
        response.setBeneficiaryId(request.getBeneficiaryId());
        response.setCoolingPeriod(isCoolingPeriodEnabled);
        response.setLimitKey(limitKey);
        response.setFeeAmount(0);
        response.setGst(0);
        response.setSgst(0);
        response.setCgst(0);
        response.setFeeGstPercentage("0|0|0|0");
        response.setTotalTxnAmount(request.getTxnAmt());
        return response;
    }
    public WibmoResponse invokeApi(String url, String endPoint, HttpMethod method, int programId, String txnType) {
        try {
            if(endPoint.equals(Constants.ADMIN_FETCH_CONFIG_URL))
            {
                endPoint = endPoint.replace("{1}", txnType);
                endPoint = endPoint.replace("{2}", Constants.ALL_CONFIG);
            }
            URI uri = URI.create(url + endPoint);
            log.info("Trying to connect {} ", uri);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            if(programId != 0)
                headers.set(Constants.PROGRAM_ID, String.valueOf(programId));
            if(!StringUtils.isEmpty(txnType))
                headers.set(Constants.TXN_TYPE, txnType);
            HttpEntity<Object> entity = new HttpEntity<>(headers);
            ResponseEntity<WibmoResponse> result = restTemplate.exchange(uri, method, entity, WibmoResponse.class);
            return result.getBody();
        } catch (Exception e) {
            log.error("Error occurred in invokeApi {}", e.toString());
        }
        return null;
    }

    public WibmoResponse revertLimitConsumption(LimitConsumptionRequest request, String bankId, String userId)
    {
        int response = 0;
        WibmoResponse wibmoResponse;
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(Constants.DATE_FORMAT);
        String endDate = today.with(TemporalAdjusters.lastDayOfMonth()).toString();
        String startDate = today.with(TemporalAdjusters.firstDayOfMonth()).toString();
        try {
            if(request.isBenefIsInCoolingPeriod()){
                response = chkAndRevertCPConsumption(request, userId, request.getLimitKey());
                if(response == 0)  {
                    log.info("Failed to update limit consumption for beneficiary {} with txnType {} & limitKey {}", request.getBeneficiaryId(), request.getTxnType(), request.getLimitKey());
                }
            }
            request.setBeneficiaryId(0);
            log.info("Trying to update Daily Amount & Count");
            response = chkAndRevertConsumption(request, userId, formatter.format(today), today.toString(), today.toString());

            if(response > 0) {
                log.info("Trying to update Monthly Amount & Count");
                response = chkAndRevertConsumption(request, userId, formatter.format(today).substring(2, 8), startDate, endDate);
            }

            FundRequest fundLoadReq = new FundRequest();
            fundLoadReq.setWalletId(request.getWalletId());
            fundLoadReq.setAmount(request.getTxnAmt());
            fundLoadReq.setOriginalRRN(request.getTxnId());
            fundLoadReq.setTxnType(Constants.W2A_REFUND);
            fundLoadReq.setMerchantId(request.getMerchantId());
            fundLoadReq.setBeneficiaryName(request.getBeneficiaryName());
            WalletService ws = findService.getService(bankId);
            WibmoResponse creditResponse = ws.fundsLoad(fundLoadReq);

            if(creditResponse.getResCode() == 1)
                log.info("Wallet Refunded successfully");
            else
                log.info("Wallet Refund failed");

            if(response > 0)  {
                wibmoResponse = new WibmoResponse(ServiceHttpStatus.SUCCESS.getStatusCode(), ServiceHttpStatus.SUCCESS.getStatusMsg());
            }else {
                wibmoResponse = new WibmoResponse(ServiceHttpStatus.FAILURE.getStatusCode(), ServiceHttpStatus.FAILURE.getStatusMsg());
            }

        }
        catch (Exception e){
            log.error("Error occurred in updateLimitConsumption {}", e.getMessage());
            wibmoResponse = new WibmoResponse(ServiceHttpStatus.INTERNAL_ERROR.getStatusCode(), ServiceHttpStatus.INTERNAL_ERROR.getStatusMsg());
        }
        return wibmoResponse;
    }
    public int chkAndRevertConsumption(LimitConsumptionRequest request, String userId, String date, String startDate, String endDate) {
        W2AConsumption consumption;
        try
        {
            consumption = limitConsumptionRepo.isConsumptionAvailable(request, userId, date, startDate, endDate);
            consumption.setLimitKey(date);
            if(consumption.getCntLmt() == 0) {
                log.info("Consumption not available in db for limit key {}.", date);
            }
            else {
                log.info("Consumption available in db for limit key {}. Hence reverting the amount & count for beneficiary is in cooling period", date);
                consumption.setAmtLmt(consumption.getAmtLmt()- request.getTxnAmt());
                consumption.setCntLmt(consumption.getCntLmt() - 1);
                return limitConsumptionRepo.update(consumption, startDate, endDate);
            }
        }
        catch(Exception e)
        {
            log.info("Unable to proceed in chkAndRevertConsumption >> Error is {}", e.getMessage());
        }
        return 0;
    }
    public int chkAndRevertCPConsumption(LimitConsumptionRequest request, String userId, String date) {
        W2ACPConsumption consumption;
        String startDate = LocalDate.now().with(TemporalAdjusters.firstDayOfMonth()).toString();
        String endDate = LocalDate.now().with(TemporalAdjusters.lastDayOfMonth()).toString();
        try
        {
            consumption = cpLimitConsumptionRepo.isConsumptionAvailable(request, userId, date, startDate, endDate);
            consumption.setBeneficiaryId(request.getBeneficiaryId());
            consumption.setLimitKey(date);
            if(consumption.getCntLmt() == 0) {
                log.info("Consumption not available in db for limit key {}", date);
            }
            else {
                log.info("Consumption available in db for limit key {}. Hence reverting the amount & count for beneficiary is in cooling period", date);
                consumption.setAmtLmt(consumption.getAmtLmt() - request.getTxnAmt());
                consumption.setCntLmt(consumption.getCntLmt() - 1);
                return cpLimitConsumptionRepo.update(consumption, startDate, endDate);
            }
        }
        catch(Exception e)
        {
            log.info("Unable to proceed in chkAndRevertCPConsumption >> Error is {}", e.getMessage());
        }
        return 0;
    }
}
