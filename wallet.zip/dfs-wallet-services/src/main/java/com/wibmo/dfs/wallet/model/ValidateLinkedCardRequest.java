package com.wibmo.dfs.wallet.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ValidateLinkedCardRequest {

	@ApiModelProperty(required = false, hidden = true)
	private String customerId;
	
	@ApiModelProperty(required = true)
	private String cardNumber;
	
	@ApiModelProperty(required = true)
	private String expiryMM;
	
	@ApiModelProperty(required = true)
	private String expiryYYYY;
	
	@ApiModelProperty(required = true)
	private int cardRefId;
}
