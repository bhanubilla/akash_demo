/**
 * 
 */
package com.wibmo.dfs.wallet.repository;

import java.util.List;

import com.wibmo.dfs.wallet.entity.UserLinkedCardInfo;
import com.wibmo.dfs.wallet.entity.UserNickNameInfo;

/**
 * @author rajasekhar.kaniti
 *
 */

public interface UserLinkedCardRepository {
	int save(UserLinkedCardInfo userLinkedCardInfo,int bankId);
	int update(UserLinkedCardInfo userLinkedCardInfo, int id);
	List<UserLinkedCardInfo> fetchLinkedCardByCustId(String customerId, int bankId);
	boolean delete(int id,String customerId);
	int getCardAddedCountPerAccount(String customerId);
	int getCardAddedCount(String cardNumber, int bankId);
	UserLinkedCardInfo fetchLinkedCardById(int id, int bankId);
	List<UserLinkedCardInfo> fetchLinkedCardByCustIdOrId(String customerId, int id, int bankId);
	UserLinkedCardInfo fetchLinkedCardByCustIdAndId(String customerId, int id, int bankId);
	
	int updateNickName(UserNickNameInfo userNickNameInfo);
	
	UserLinkedCardInfo fetchLinkedCardByCustIdAndCardNumber(String customerId, String cardNumber, int bankId);
}
