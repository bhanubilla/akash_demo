package com.wibmo.dfs.wallet.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserAccountInfo implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private int id;
	private String customerId;
	private int kycLevel;
	private String mobile;
	private Timestamp createdDt;
	private Timestamp updatedDt;

}
