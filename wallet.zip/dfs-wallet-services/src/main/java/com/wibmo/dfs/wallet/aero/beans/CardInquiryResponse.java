package com.wibmo.dfs.wallet.aero.beans;

import java.io.Serializable;
import java.util.List;

/**
 * 
 * @author meriyala.raghavendra
 *
 */
public class CardInquiryResponse extends AeroResponse implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private long availableBalance;
    private long availableCashLimit;
    private StringBuilder cardNumber=new StringBuilder(20);
    private StringBuilder cardExpiry=new StringBuilder();
    private StringBuilder cardCVV2=new StringBuilder();
    private String cardStatus;
    private String activationTimeStamp;
    private CardHolder cardHolder;
    private String lastActivityTimeStamp;
    private List<CardTransactionProfile> cardTransactionProfile;

    public long getAvailableBalance() {
        return availableBalance;
    }

    public void setAvailableBalance(long availableBalance) {
        this.availableBalance = availableBalance;
    }

    public long getAvailableCashLimit() {
        return availableCashLimit;
    }

    public void setAvailableCashLimit(long availableCashLimit) {
        this.availableCashLimit = availableCashLimit;
    }

    public StringBuilder getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(StringBuilder cardNumber) {
        this.cardNumber=cardNumber;
    }

    public StringBuilder getCardExpiry() {
        return cardExpiry;
    }

    public void setCardExpiry(StringBuilder cardExpiry) {
        this.cardExpiry=cardExpiry;
    }

    public StringBuilder getCardCVV2() {
        return cardCVV2;
    }

    public void setCardCVV2(StringBuilder cardCVV2) {
        this.cardCVV2=cardCVV2;
    }

    public List<CardTransactionProfile> getCardTransactionProfile() {
        return cardTransactionProfile;
    }

    public void setCardTransactionProfile(List<CardTransactionProfile> cardTransactionProfile) {
        this.cardTransactionProfile = cardTransactionProfile;
    }

    public void clearCardExpiry() {
        this.cardExpiry.setLength(0);
        this.cardExpiry.append("000000");
        this.cardExpiry.setLength(0);
        this.cardExpiry.trimToSize();
    }
    
    public void clearCardCvv2() { 
        if (this.cardCVV2 != null) {
            this.cardCVV2.setLength(0);
            this.cardCVV2.append("000000");
            this.cardCVV2.setLength(0);
            this.cardCVV2.trimToSize();
        }
    }
    
     public void clearCardNumber() {        
        this.cardNumber.setLength(0);
        this.cardNumber.append("00000000000000000000");
        this.cardNumber.setLength(0);
        this.cardNumber.trimToSize();
    }
    
    public void clearCardInquiryResponse() {
        this.clearCardNumber();
        this.clearCardExpiry();
        this.clearCardCvv2();
    }

    public String getCardStatus() {
        return cardStatus;
    }

    public void setCardStatus(String cardStatus) {
        this.cardStatus = cardStatus;
    }

    public String getActivationTimeStamp() {
        return activationTimeStamp;
    }

    public void setActivationTimeStamp(String activationTimeStamp) {
        this.activationTimeStamp = activationTimeStamp;
    }

    public CardHolder getCardHolder() {
        return cardHolder;
    }

    public void setCardHolder(CardHolder cardHolder) {
        this.cardHolder = cardHolder;
    }

    public String getLastActivityTimeStamp() {
        return lastActivityTimeStamp;
    }

    public void setLastActivityTimeStamp(String lastActivityTimeStamp) {
        this.lastActivityTimeStamp = lastActivityTimeStamp;
    }
    
}
