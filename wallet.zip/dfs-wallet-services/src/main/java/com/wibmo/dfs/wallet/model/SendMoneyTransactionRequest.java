package com.wibmo.dfs.wallet.model;

import java.io.Serializable;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SendMoneyTransactionRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	private long amount;
	private String description;
	private String currency;
	private String transactionType;
	private String recipientMobileNo;
	private String beneficiaryAccountNumber;
	private String ifsc;
	private String beneficiaryName;
	private String beneficiaryId;
	private String sendervpa;
	private String recipientvpa;
	private String refCategory;
	private String refUrl;
	private String transactionReference;
	private int senderWalletId;
	private String productType;
	//for SCAN_PAY & INTENT_PAY
	private String mcc;
	private String upiRequestId;
	private Map<String, String> udfParams;
	
}
