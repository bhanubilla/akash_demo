package com.wibmo.dfs.wallet.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserVelocityCheck {
	@ApiModelProperty(required = false, dataType="String", hidden = true)
	private String customerId;
	private long val;
	private String txnType;
	private String cardNumber;
	private int kycLevel;
	private String productType;
	@ApiModelProperty(value = "bankId", hidden = true)
	private String bankId;
}
