package com.wibmo.dfs.wallet.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ServiceTypes {
	
	@ApiModelProperty(required = true)
	private boolean status;
	
	@ApiModelProperty(required = true)
	private String type;
}
