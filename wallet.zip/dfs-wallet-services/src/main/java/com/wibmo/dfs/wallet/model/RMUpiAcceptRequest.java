package com.wibmo.dfs.wallet.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RMUpiAcceptRequest implements Serializable{

		private String upiTxnRefNo;
		private String payerVirtualAddress;
		private String payerAccountId;
		private String npciTxnId;
		private String deviceId;
		private String mobileNo;
		private String simId;
		private String geoCode;
		private String location;
		private String ip;
		private String os;
		private String deviceType;
		private String appName;
		private String capability;
		private String approvalStatus;
		private String deviceName;
		private String payeeVPA;
		private String payeeName;
		private String txnAmount;
		private String txnNote;
		private String token;
		private String msgHash;
}
