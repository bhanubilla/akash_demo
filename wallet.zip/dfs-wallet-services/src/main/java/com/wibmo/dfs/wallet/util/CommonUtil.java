package com.wibmo.dfs.wallet.util;

import java.security.SecureRandom;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpHeaders;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.model.WibmoResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CommonUtil {

	private static final String YYYY_M_MDD_H_HMMSS_SSS = "yyyyMMddHHmmssSSS";
	public static final String URL = "url :: {}";
	private static SecureRandom srandom;

	static {
		try {
			srandom = SecureRandom.getInstance("SHA1PRNG");
		} catch (Exception e) {
			log.warn("SecureRandom generation failed! : {0}", e);
		}
	}

	private CommonUtil() {

	}

	public static String getYYYYfromYY(String year) {

		SimpleDateFormat yyyy = new SimpleDateFormat("yyyy");
		SimpleDateFormat mysdf = new SimpleDateFormat("yy");
		Date date;
		try {
			date = mysdf.parse(year);
		} catch (ParseException ex) {
			return null;
		}
		return yyyy.format(date);
	}

	/*
	 * This method will generate random string
	 * 
	 * @param len
	 * 
	 * @return String
	 */

	public static String generateRandomString(int len) {
		StringBuilder sb = new StringBuilder();
		while (sb.length() < len) {
			sb.append((char) ('0' + srandom.nextInt(10)));
			if(sb.length() < len) sb.append((char) ('a' + srandom.nextInt(26)));
			if(sb.length() < len) sb.append((char) ( 'A' + srandom.nextInt(26)));
		}
		return sb.toString();
	}

	/*
	 * This method will generate unique transaction id
	 * 
	 * @param programId
	 * 
	 * @return String
	 */
	public static String generateTxnId() {
		StringBuilder sb = new StringBuilder();
		sb.append(new SimpleDateFormat(YYYY_M_MDD_H_HMMSS_SSS).format(new Date()));
		sb.append(generateRandomString(4));

		return sb.toString();
	}

	public static String generateRequestTime(SimpleDateFormat sdf) {
		return sdf.format(new Date());
	}

	public static void startThreadNameForLogging(String orgThreadName, String... params) {
		try {
			StringBuilder sb = new StringBuilder(200);
			sb.append(orgThreadName);
			for (String param : params) {
				sb.append("|").append(param);
			}
			Thread.currentThread().setName(sb.toString());
		} catch (Exception e) {
			log.error("Exception while generating threadName ", e);
		}
	}

	public static long getTimeForTxnId(String txnId){
		long timeInMillis = 0;
		if(!StringUtils.isBlank(txnId)){
			SimpleDateFormat sdf = new SimpleDateFormat(YYYY_M_MDD_H_HMMSS_SSS);
			try {
				Date date = sdf.parse(txnId.substring(0, 17));
				timeInMillis = date.getTime();
			} catch (ParseException e) {
				log.debug("parse exception", e.getMessage());
			}
		}
		return timeInMillis;
	}

	public static String getDateFormatForTxnId(String txnId) {
		String txnDate = null;
		if (!StringUtils.isBlank(txnId)) {
			SimpleDateFormat sdf = new SimpleDateFormat(YYYY_M_MDD_H_HMMSS_SSS);

			try {
				Date date = sdf.parse(txnId.substring(0, 17));
				long timeInMillis = date.getTime();
				SimpleDateFormat formatter = new SimpleDateFormat("dd MMM yyyy hh:mm aa");
				Date d = new Date(timeInMillis);
				txnDate = formatter.format(d);
			} catch (ParseException e) {
				log.debug("parse exception", e.getMessage());
			}
		}

		return txnDate;
	}

	public static String generateWibmoTxnId() {
		StringBuilder sb = new StringBuilder();
		sb.append(new SimpleDateFormat(YYYY_M_MDD_H_HMMSS_SSS).format(new Date()));
		sb.append(generateRandomString(4));
		sb.append(generateRandomString(4));
		return sb.toString();
	}

	public static String generateFormat(String format) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		return dateFormat.format(new Date());
	}

	public static String decimalFormat(long amount) {
		DecimalFormat decimalFormat = new DecimalFormat("###,###.##");
		decimalFormat.setMinimumFractionDigits(2);
		return decimalFormat.format(amount / 100.0);

	}
	public static String decimalFormat(double amount) {
		DecimalFormat decimalFormat = new DecimalFormat("###,###.##");
		decimalFormat.setMinimumFractionDigits(2);
		return decimalFormat.format(amount / 100.0);

	}

	public static double decimalFormatWithoutComma(Object amount) {
		double amt = Double.parseDouble(String.valueOf(amount));
		DecimalFormat decimalFormat = new DecimalFormat("######.##");
		decimalFormat.setMinimumFractionDigits(2);
		return Double.parseDouble(decimalFormat.format(amt / 100.0));

	}
	public static String roundOff(double amount) {
		StringBuilder sb = new StringBuilder();
		String[] amt = String.valueOf(amount).split("\\.");
		sb.append(amt[0]);
		sb.append(".");
		if(amt[1].length() > 2)
			sb.append(amt[1].substring(0,2));
		else
			sb.append(amt[1]);
		log.info("roundOff ::: before {} after {}", amount, sb.toString());
		return sb.toString();
	}
	public static String mask(String pattern, String number, String placeholder) {
		if (StringUtils.isBlank(number) || "NNNNNNNNNNNNNNNN".equals(pattern)|| pattern == null) {
			return number;
		}

		StringBuilder output = new StringBuilder();
		if (number.length() == pattern.length()) {

			char[] lpattern = pattern.toCharArray();
			char[] lnumber = number.toCharArray();
			for (int i = 0; i < lpattern.length ; i++) {
				switch (lpattern[i]) {
				case 'N': {
					output.append(lnumber[i]);
					break;
				}
				case 'x','X':{
					if (placeholder != null) {
						output.append(placeholder);
					}
					break;
				}
				default: {
					output.append(lpattern[i]);
				}
				}
			}
		} else {
			unMatchedLength(pattern, number, placeholder, output);
		}

		return output.toString();
	}

	private static void unMatchedLength(String pattern, String number, String placeholder, StringBuilder output) {
		int firstClearDigits = 0;
		int lastClearDigits = 0;
		Character charobj = null;

		Character charobjn = 'N';
		for (int j = 0; j < pattern.length(); j++) {
			charobj = pattern.charAt(j);
			if (charobj.equals(charobjn)) {
				firstClearDigits++;
			} else {
				break;
			}
		}
		for (int j = pattern.length() - 1; j >= 0; j--) {
			charobj = pattern.charAt(j);
			if (charobj.equals(charobjn)) {
				lastClearDigits++;
			} else {
				break;
			}
		}
		output.append(number.substring(0, firstClearDigits));
		for (int j = 0; j < number.length() - firstClearDigits - lastClearDigits; j++) {
			output.append(placeholder);
		}
		output.append(number.substring(number.length() - lastClearDigits));
	}

	public static String maskCardNumber(String cardNumber, String mask) {

	    // format the number
	    int index = 0;
	    StringBuilder maskedNumber = new StringBuilder();
	    for (int i = 0; i < mask.length(); i++) {
	        char c = mask.charAt(i);
	        if (c == '#') {
	            maskedNumber.append(cardNumber.charAt(index));
	            index++;
	        } else if (c == 'x') {
	            maskedNumber.append(c);
	            index++;
	        } else {
	            maskedNumber.append(c);
	        }
	    }

	    // return the masked number
	    return maskedNumber.toString();
	}
	
	public static Map<String, String> generateFromAndToDates() {
		Calendar cal = Calendar.getInstance();
		int endDt = cal.getActualMaximum(Calendar.DATE);
		String month = CommonUtil.generateFormat("YYYY-MM");
		Map<String, String> map = new HashMap<>();
		map.put(Constants.START_DATE, month + "-01");
		map.put(Constants.END_DATE, month + "-" + endDt);
		return map;
	}

	public static int lastDayOfMonth(int year, int month, int date) {
		// Creating a calendar object
		Calendar cal = new GregorianCalendar(year, month, date);
		return cal.getActualMaximum(Calendar.DATE);
	}
	public static WibmoResponse invokeApi(RestTemplate restTemplate, HttpMethod method,String url, String endPoint, String programId, Object request) {
        String serverURL = url + endPoint;
        log.info(URL,serverURL);
        MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
		custHeader.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
		if(null != programId)
			custHeader.add(Constants.X_PROGRAM_ID, programId);
        HttpEntity<Object> entity = new HttpEntity<>(request, custHeader);
        ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(serverURL, method,entity,WibmoResponse.class);
        return responseEntity.getBody();
	}

	public static WibmoResponse invokeApi(RestTemplate restTemplate, HttpMethod method,String url, String endPoint, Object request, MultiValueMap<String, String> custHeader) {
		String serverURL = url + endPoint;
		log.info(URL,serverURL);
		HttpEntity<Object> entity = new HttpEntity<>(request, custHeader);
		ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(serverURL, method, entity,
				WibmoResponse.class);
		return responseEntity.getBody();
	}

	public static WibmoResponse invokeApi(RestTemplate restTemplate, HttpMethod method,String url, String endPoint, MultiValueMap<String, String> custHeader) {
		String serverURL = url + endPoint;
		log.info(URL,serverURL);
		HttpEntity<Object> entity = new HttpEntity<>(custHeader);
		ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(serverURL, method, entity,
				WibmoResponse.class);
		return responseEntity.getBody();
	}
	
	 public static String dateToString(Date dt) {
	    return dateToStringWithFormat(dt, "dd MMMM yyyy, hh:mm aa");
	  }
	 
	 public static String dateToStringWithFormat(Date dt, String format) {
		 String dateStr = null;
		 if(null == dt) return dateStr;
		 else {
			 dateStr = new SimpleDateFormat(format).format(dt);
		 }
	    return dateStr;
	  }

	public static String dateFormat(String dttm, String format) {
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		StringBuilder sb = new StringBuilder();
		sb.append(dttm.substring(6,8))
		.append("-")
		.append(dttm.substring(4, 6))
		.append("-")
		.append(dttm.substring(0, 4))
		.append(" ")
		.append(dttm.substring(8, 10))
		.append(":")
		.append(dttm.substring(10, 12))
		.append(":")
		.append(dttm.substring(12, 14));
		try {
			Date dt=sdf.parse(sb.toString());
			return dateToStringWithFormat(dt,format);
		} catch (ParseException e) {
			log.warn("exception on date format :{}",e);
		}  
		return null;
	}


	public static String maskCardNumberWOPlaceHolder(String cardNumber, String mask) {

		// format the number
		var index = 0;
		var maskedNumber = new StringBuilder();
		if (cardNumber.length() == mask.length()) {
			for (var i = 0; i < mask.length(); i++) {
				var c = mask.charAt(i);
				if (c == 'N') {
					maskedNumber.append(cardNumber.charAt(index));
					index++;
				} else if (c == '*') {
					maskedNumber.append(c);
					index++;
				} else {
					maskedNumber.append(c);
				}
			}
		} else {
			maskedCardNumber(cardNumber, maskedNumber);
		}

		// return the masked number
		return maskedNumber.toString();
	}

	private static void maskedCardNumber(String cardNumber, StringBuilder maskedNumber) {
		var newStr = new StringBuilder();
		for (var i = 0; i < cardNumber.length(); i++) {
			if (i >= 4) {
				newStr.append("*");
			}
		}
		newStr.append(cardNumber.substring(cardNumber.length() - 4));
		for (var i = 0; i < newStr.length(); i++) {
			if (i % 4 == 0 && i != 0) {
				maskedNumber.append(" ");
			}
			maskedNumber.append(newStr.charAt(i));
		}
	}
	public static String toDecimal(String value) {
		if(StringUtils.isNotBlank(value)) {
			double d = Double.parseDouble(value);
			DecimalFormat df = new DecimalFormat("#.00");
			return (df.format(d / 100.00) + "");
		}
		return null;
	}

}
