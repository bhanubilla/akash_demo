package com.wibmo.dfs.wallet.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UpiTransactionResponse implements Serializable {

	private static final long serialVersionUID = 1L;
	private String status;
    private String responseCode;
    private String responseMessage;
    private String udfParameters;
    @JsonIgnore
    private String customGatewayStatusCode;
    
	private String merchantId;
	private String merchantChannelId;
	private String merchantCustomerId;
	private String merchantRequestId;
	private String customerMobileNumber;
	private String payerVpa;
	private String payeeMcc;
	private String payeeMerchantCustomerId;
	private String payeeName;
	private String payeeVpa;
	private String refUrl;
	private String bankAccountUniqueId;
	private String bankCode;
	private String maskedAccountNumber;
	private String amount;
	private String transactionType;
	private String transactionTimestamp;
	private String gatewayTransactionId;
	private String gatewayReferenceId;
	private String gatewayResponseStatus;
	private String gatewayResponseCode;
	private String gatewayResponseMessage;
}
