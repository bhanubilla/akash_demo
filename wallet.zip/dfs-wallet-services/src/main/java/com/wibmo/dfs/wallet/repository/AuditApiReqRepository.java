package com.wibmo.dfs.wallet.repository;

import com.wibmo.dfs.wallet.entity.AuditApiReq;

public interface AuditApiReqRepository {

	int save(AuditApiReq auditReq);
	
	AuditApiReq fetchById(int id);
	
	boolean updateApiReq(AuditApiReq auditApiReq);
}
