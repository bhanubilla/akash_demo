package com.wibmo.dfs.wallet.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CheckUserLimitsRequest {
	@ApiModelProperty(required = false, dataType="String", notes="if walletId is missing", hidden = true)
	private String customerId;
	
	@ApiModelProperty(required = true, dataType="String", notes="if walletId is missing")
	private String productType;
	
	@ApiModelProperty(required = true, dataType="int", notes="if both customerId and productType are missing", example="1")
	private int walletId;
	
	@ApiModelProperty(required = true, dataType="long")
	private long txnAmount;

	@ApiModelProperty(required = true, dataType="String", notes = "LM for Load Money, P2P for Send Money")
	private String txnType;

	@ApiModelProperty(required = true, dataType="String", notes = "C for Credit, D for Debit")
	private String txnFlow;

	@ApiModelProperty(required = false)
	private String cardNumber;

}
