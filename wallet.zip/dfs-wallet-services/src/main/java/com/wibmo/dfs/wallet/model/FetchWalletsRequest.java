package com.wibmo.dfs.wallet.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FetchWalletsRequest {

	@ApiModelProperty(required = false, dataType="String", hidden = true)
	private String customerId;
	
	@ApiModelProperty(required = false, dataType="int")
	private int id;
}
