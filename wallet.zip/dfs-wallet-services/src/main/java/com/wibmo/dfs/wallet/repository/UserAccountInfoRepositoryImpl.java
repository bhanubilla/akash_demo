package com.wibmo.dfs.wallet.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.wibmo.dfs.wallet.entity.UserAccountInfo;

@Repository
@Slf4j
public class UserAccountInfoRepositoryImpl implements UserAccountInfoRepository {

	private static final String INSERT_QUERY = "insert into user_account_info(customer_id,kyc_level,mobile) values(?,?,?)";
	private static final String UPDATE_KYC_QUERY = "update user_account_info set kyc_level=? where customer_id=? and mobile=? ";
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int save(UserAccountInfo userAccount) {
		KeyHolder keyHolder = new GeneratedKeyHolder();
		log.debug("user Account info, custId:{}, kyclevel:{}, mobile:{}",userAccount.getCustomerId(), userAccount.getKycLevel(), userAccount.getMobile());
		jdbcTemplate.update(connection -> {
			PreparedStatement ps = connection.prepareStatement(INSERT_QUERY, Statement.RETURN_GENERATED_KEYS);
			int i = 1;
			ps.setString(i++, userAccount.getCustomerId());
			ps.setInt(i++, userAccount.getKycLevel());
			ps.setString(i++, userAccount.getMobile());

			return ps;
		}, keyHolder);

		Number value = keyHolder.getKey();
		return null != value ? value.intValue() : 0;
	}

	@Override
	public UserAccountInfo fetchByCustId(String custId) {
		BeanPropertyRowMapper<UserAccountInfo> rowMapper = BeanPropertyRowMapper.newInstance(UserAccountInfo.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<UserAccountInfo> li = jdbcTemplate.query("select * from user_account_info where customer_id = ?",
				new PreparedStatementSetter() {

					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setString(1, custId);
					}
				}, rowMapper);
		return !li.isEmpty() ? li.get(0) : null;
	}

	public int updateKycLevel(UserAccountInfo info) {
		log.debug("updated kyc level to :{}, customer: {}",info.getKycLevel(), info.getCustomerId());
		return jdbcTemplate.update(connection -> {
			PreparedStatement ps = connection.prepareStatement(UPDATE_KYC_QUERY, Statement.RETURN_GENERATED_KEYS);
			int i=1;

			ps.setInt(i++, info.getKycLevel());
			ps.setString(i++, info.getCustomerId());
			ps.setString(i++, info.getMobile());
			return ps;
		});
	}

	@Override
	public int checkAndSave(UserAccountInfo userAccount) {
		UserAccountInfo userInfo = fetchByCustId(userAccount.getCustomerId());
		if (null != userInfo) {
			log.debug("checking old kyc: {}, new Kyc:{}, for customer :{} and mobile{}",
					userInfo.getKycLevel(), userAccount.getKycLevel(),userAccount.getCustomerId(),userAccount.getMobile());
			if(userAccount.getKycLevel() != userInfo.getKycLevel() && userAccount.getKycLevel() > 0) {
				updateKycLevel(userAccount);
			}
			return 1;
		}
		else
			return save(userAccount);
	}

	@Override
	public UserAccountInfo fetchByMobileNo(String mobileNo) {
		BeanPropertyRowMapper<UserAccountInfo> rowMapper = BeanPropertyRowMapper.newInstance(UserAccountInfo.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<UserAccountInfo> li = jdbcTemplate.query("select * from user_account_info where mobile = ?",
				new PreparedStatementSetter() {

					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setString(1, mobileNo);
					}
				}, rowMapper);
		return !li.isEmpty() ? li.get(0) : null;
	}

}
