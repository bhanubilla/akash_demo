package com.wibmo.dfs.wallet.kafka.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TrackingTxnStatus {
    private long id;
    private String txnNumber;
    private String txnStatusName;
    private String txnStatusDescription;
    private Timestamp createAt;
}