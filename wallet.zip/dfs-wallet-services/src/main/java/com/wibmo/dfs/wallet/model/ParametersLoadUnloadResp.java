package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ParametersLoadUnloadResp {
    private int auditId;
    private String bankId;
    private String txnType;

}
