package com.wibmo.dfs.wallet.service;

import java.util.List;

import com.wibmo.dfs.wallet.entity.WalletCard;
import com.wibmo.dfs.wallet.model.*;

public interface WalletService {

	/**
	 * SVC Creation based on Product Type :RW,CB..
	 * 
	 * @param createCard
	 * @return WibmoResponse
	 */
	WibmoResponse create(CreateCard createCard);

	/**
	 * Returns the Card Details
	 * @param inquiry
	 * @return WibmoResponse
	 */
	WibmoResponse inquiry(FetchCardRequest inquiry);

	/**
	 * SVC Debit funds
	 * @param fundUnloadReq
	 * @return WibmoResponse
	 */
	WibmoResponse fundsUnload(FundRequest fundUnloadReq);

	/**
	 * SVC Credit funds 
	 * @param fundLoadReq
	 * @return WibmoResponse
	 */
	WibmoResponse fundsLoad(FundRequest fundLoadReq);

	/**
	 * Returns the Card status
	 * @param inquiry
	 * @return WibmoResponse
	 */
	WibmoResponse fetchCardStatus(FetchCardStatusRequest inquiry);

	/**
	 * Returns the Card Balance
	 * @param inquiry
	 * @return WibmoResponse
	 */
	WibmoResponse fetchCardBalance(FetchCardBalanceRequest inquiry);

	/**
	 * Returns the Card CVV
	 * @param inquiry
	 * @return WibmoResponse
	 */
	WibmoResponse fetchCardCVV(FetchCardCVVRequest inquiry);
	
	List<FetchCardResponse> fetchByWc(List<WalletCard> wcs);
	
	/**
	 * SVC SendMoney 
	 * @param sendMoneyReq
	 * @return WibmoResponse
	 */
	WibmoResponse sendMoney(SendMoneyRequest sendMoneyReq);


	WibmoResponse processP2P(P2PRequest p2pRequest);
	
	/**
	 * Update the Service Type Flag(Ex: E-COM)
	 * @param serviceReq
	 * @return WibmoResponse
	 */
	WibmoResponse updateServiceTypeFlag(ServiceTypeRequest serviceReq);

	WibmoResponse checkAmlLimits(CheckUserAmlLimitsRequest request, String bankId);

	WibmoResponse checkUserLimits(CheckUserLimitsRequest request, String bankId);

	/**
	 * Update cardholder profile
	 * @param profileUpdateRequest
	 * @param bankId
	 * @return
	 */
	WibmoResponse updateCardHolderProfile(UpdateCardHolderProfileData profileUpdateRequest, String bankId);

	WibmoResponse blockCard(BlockCardRequest request, String programId, String accountNumber);

	WibmoResponse unBlockCard(UnBlockCardRequest request, String programId, String accountNumber);
}
