package com.wibmo.dfs.wallet.model;

import lombok.Data;

@Data
public class WalletDetailsRequest {
    private long urn;
    private String customerId;
    private String last4digits;
    private String productType;
    private String hostCustomerId;
}
