package com.wibmo.dfs.wallet.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SBRequest {

	@ApiModelProperty(required = false, dataType="String", hidden = true)
	private String requesterCustomerId;

	@ApiModelProperty(required = true, dataType="String", allowableValues = "W2W,V2V")
	private String txnMode;
	
	//@ApiModelProperty(required = false, example = "mandatory if txnModel=W2W")
	private List<WalletUserReq> requesteeWallets;
	
	//@ApiModelProperty(required = false, dataType = "List<UpiToUpiRequestMoneyReq>", example = "mandatory if txnModel=V2V")
	private List<UpiToUpiRequestMoneyReq> requesteeAccounts;
}
