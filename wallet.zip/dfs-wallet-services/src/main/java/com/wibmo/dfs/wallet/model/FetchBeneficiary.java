package com.wibmo.dfs.wallet.model;

import lombok.Data;

@Data
public class FetchBeneficiary {
    private boolean vpaReq;
    private boolean accReq;
}
