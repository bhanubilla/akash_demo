package com.wibmo.dfs.wallet.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
public class BlockedDetails {
    private long id;
    private String accountNumber;
    private String vpa;
    private String blockedVpa;
    private String blockedVpaName;
    private String blockedMobileNumber;
    private Timestamp updatedTs;
    private Timestamp createdTs;
    private String blockedUserName;
}
