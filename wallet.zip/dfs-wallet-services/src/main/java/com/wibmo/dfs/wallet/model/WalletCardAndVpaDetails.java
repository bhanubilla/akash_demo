package com.wibmo.dfs.wallet.model;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class WalletCardAndVpaDetails {
	private boolean isWalletAvailable;
	private String recipientName;
	private List<VpaDetailsMini> vpaDetails;
}
