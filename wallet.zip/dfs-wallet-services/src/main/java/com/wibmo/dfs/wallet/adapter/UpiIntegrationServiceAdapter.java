package com.wibmo.dfs.wallet.adapter;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.wallet.adapter.response.VpaTxnInfo;
import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.entity.BlockedDetails;
import com.wibmo.dfs.wallet.model.*;
import com.wibmo.dfs.wallet.util.CommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.List;

@Component
@Slf4j
public class UpiIntegrationServiceAdapter {
    @Value("${resource.url.upiIntegrationService}")
    private String baseUrl;

    public static final String X_PROGRAM_ID = "X-PROGRAM-ID";
    public static final String X_ACCOUNT_NUMBER = "X-ACCOUNT-NUMBER";
    private String apiResponseData = "apiResponse.getData() :: {}";
    @Autowired
    private RestTemplate restTemplate;

    public WibmoResponse incomingCollectRequest(String bankId, String accountId, UpiIncomingCollectResponse upiICRequest){
        WibmoResponse response = null;
        String url =  baseUrl + Constants.INCOMING_REQUEST_MONEY;
        try {
            log.info("calling incoming collect request from adapter");
            MultiValueMap<String, String> custHeader = new LinkedMultiValueMap<>();
            custHeader.add(X_PROGRAM_ID, bankId);
            custHeader.add(X_ACCOUNT_NUMBER, accountId);
            HttpEntity<Object> entity = new HttpEntity<>(upiICRequest, custHeader);
            ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(url, HttpMethod.POST, entity,
                    WibmoResponse.class);
            log.info("setting upi response as return value");
            response = responseEntity.getBody();

        }catch (Exception ex){
            log.info("Exception while communicating upi integration service :: {} ",ex);
            response = new WibmoResponse();
            response.setResCode(500);
            response.setResDesc("Exception communicating upi integration service");
        }
        return response;
    }

    public RequestMoneyResponse invokeUPIRequestMoney(OutgoingCollectRequest request, String bankId, String accountNumber) {
       log.info("invokeUPIRequestMoney == starts for account :: {}",accountNumber);
        RequestMoneyResponse requestMoneyResponse = new RequestMoneyResponse();
        try {
            MultiValueMap<String, String> customFundHeader = new LinkedMultiValueMap<>();
            customFundHeader.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
            customFundHeader.add(X_PROGRAM_ID, bankId);
            customFundHeader.add(X_ACCOUNT_NUMBER, accountNumber);
            HttpEntity<Object> requestMoneyEntity = new HttpEntity<>(request, customFundHeader);
            ObjectMapper mapper = new ObjectMapper();
            UPIOutgoingCollectRequest upiRequest = new UPIOutgoingCollectRequest();
            upiRequest.setRemarks(request.getRemarks());
            upiRequest.setCurrency(request.getCurrency());
            upiRequest.setPayeeVPA(request.getPayeeVPA());
            upiRequest.setPayerVPA(request.getPayerVPA());
            upiRequest.setPayerName(request.getPayerName());
            upiRequest.setTxnAmount(request.getTxnAmount());
            upiRequest.setWalletId(request.getWalletId());
            String requestInStr = mapper.writeValueAsString(upiRequest);
            log.info("Request :: {}",requestInStr);
            ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(baseUrl + Constants.REQUEST_MONEY, HttpMethod.POST, requestMoneyEntity, WibmoResponse.class);
            WibmoResponse wibmoResponseEntity = responseEntity.getBody();
            if(wibmoResponseEntity!=null && wibmoResponseEntity.getResCode() == 200 && responseEntity.getBody()!=null){
                requestMoneyResponse = mapper.convertValue(wibmoResponseEntity.getData(), RequestMoneyResponse.class);
            }else{
                if(wibmoResponseEntity!=null) {
                    requestMoneyResponse.setWibmoResCode(wibmoResponseEntity.getResCode());
                    requestMoneyResponse.setWibmoResDesc(wibmoResponseEntity.getResDesc());
                    requestMoneyResponse.setWibmoErrorMessage(wibmoResponseEntity.getErrorMessage());
                }
            }


        }
        catch (Exception e) {
            log.error("Exception occurred while calling invokeUPIRequestMoney: ", e);
            requestMoneyResponse.setWibmoResCode(100);
            requestMoneyResponse.setWibmoErrorMessage("Exception while communicating UPI");
            requestMoneyResponse.setWibmoResDesc("Failure");
        }
        return requestMoneyResponse;
    }

    public List<PendingCollectResponse> pendingCollectRequests(String bankId, String accountNumber){
        List<PendingCollectResponse> cards = null;
        log.info("pendingCollectRequests == starts for account :: {}",accountNumber);
        try {
            MultiValueMap<String, String> customFundHeader = new LinkedMultiValueMap<>();
            customFundHeader.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
            customFundHeader.add(X_PROGRAM_ID, bankId);
            customFundHeader.add(X_ACCOUNT_NUMBER, accountNumber);
            HttpEntity<Object> requestMoneyEntity = new HttpEntity<>(customFundHeader);
            //PendingCollectResponse
            ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(baseUrl + Constants.PENDING_REQUEST_MONEY, HttpMethod.POST, requestMoneyEntity, WibmoResponse.class);
            ObjectMapper mapper = new ObjectMapper();
            WibmoResponse apiResponse = responseEntity.getBody();
             if (apiResponse != null && apiResponse.getResCode() == 200) {
                log.info(apiResponseData, apiResponse.getData());
                cards = mapper.convertValue(apiResponse.getData(), new TypeReference<List<PendingCollectResponse>>() {
                });
            } else {
                log.info("Issue in UPI service, Please check UPI logs for more details");
            }
        }catch (Exception ex){
            log.error("exception while communicating with UPI service :: {}",ex);
        }
        return cards;
    }

    public List<BlockedDetails> fetchBlockVpaList(String bankId, String accountNumber) {
        List<BlockedDetails> blockedVpaDetailsList = null;
        log.info("fetchBlockVpaList == starts for account :: {}", accountNumber);
        try {
            URI uri = URI.create(baseUrl + Constants.FETCHING_ALL_BLOCKED_VPA_LIST);
            MultiValueMap<String, String> header = new LinkedMultiValueMap<>();
            header.add(X_PROGRAM_ID, bankId);
            header.add(X_ACCOUNT_NUMBER, accountNumber);
            HttpEntity<Object> requestMoneyEntity = new HttpEntity<>(header);
            //fetch Block Vpa List Response
            ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(uri, HttpMethod.GET, requestMoneyEntity, WibmoResponse.class);
            ObjectMapper mapper = new ObjectMapper();
            WibmoResponse apiResponse = responseEntity.getBody();
            if (apiResponse != null && apiResponse.getResCode() == 200) {
                log.info(apiResponseData, apiResponse.getData());
                blockedVpaDetailsList = mapper.convertValue(apiResponse.getData(), new TypeReference<List<BlockedDetails>>() {
                });
            } else {
                log.info("Issue in UPI service, Please check UPI logs for more details");
            }
        } catch (Exception ex) {
            log.error("exception while communicating with UPI service fetchBlockVpaList() :: {}", ex);
        }
        return blockedVpaDetailsList;
    }

    public VerifyVpaResponse verifyVPA(String bankId, String vpa){
        log.info("verify vpa calling for :: {}, {}",vpa, bankId);
        VerifyVpaRequest request = new VerifyVpaRequest();
        request.setVpa(vpa);
        VerifyVpaResponse response = null;
        try{
            URI uri = URI.create(baseUrl + Constants.VERIFY_VPA);
            MultiValueMap<String, String> header = new LinkedMultiValueMap<>();
            header.add(X_PROGRAM_ID, bankId);
            HttpEntity<Object> requestMoneyEntity = new HttpEntity<>(request,header);
            //fetch Block Vpa List Response
            ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(uri, HttpMethod.POST, requestMoneyEntity, WibmoResponse.class);
            ObjectMapper mapper = new ObjectMapper();
            WibmoResponse apiResponse = responseEntity.getBody();
            if (apiResponse != null && apiResponse.getData() != null) {
                log.info(apiResponseData, apiResponse.getData());
                response = mapper.convertValue(apiResponse.getData(), new TypeReference<VerifyVpaResponse>() {
                });
            }
        }catch (Exception ex){
            log.error("Exception while communicating UPI service for verify VPA :: {}",ex);
        }
        return response;
    }

    public VpaTxnInfo fetchVpaTxnDetails(String bankId, String gatewayTxnId){
        log.info("fetchVpaTxnDetails for :: {}",gatewayTxnId);
        VpaTxnInfo response = null;
        try{
            URI uri = URI.create(baseUrl + "/upi/internal/vpaTxnDetails");
            MultiValueMap<String, String> header = new LinkedMultiValueMap<>();
            header.add(X_PROGRAM_ID, bankId);
            header.add("VPA-TXN-ID", gatewayTxnId);
            HttpEntity<Object> requestMoneyEntity = new HttpEntity<>(header);
            //fetch Block Vpa List Response
            ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(uri, HttpMethod.GET, requestMoneyEntity, WibmoResponse.class);
            ObjectMapper mapper = new ObjectMapper();
            WibmoResponse apiResponse = responseEntity.getBody();
            if (apiResponse != null && apiResponse.getData() != null) {
                log.info(apiResponseData, apiResponse.getData());
                response = mapper.convertValue(apiResponse.getData(), new TypeReference<VpaTxnInfo>() {
                });
            }
        }catch (Exception exception){
            log.error("Exception while fetchVpaTxnDetails :: {}",exception);
        }
        return response;
    }
}
