package com.wibmo.dfs.wallet.model;

import com.wibmo.dfs.wallet.aero.beans.CardIdentityProfile;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserInfo {
	@ApiModelProperty(required = true)
	private UserAccount account;
	
	@ApiModelProperty(required = true)
	private UserProfile profile;
	
	@ApiModelProperty(required = true)
	private UserAddress address;

	@ApiModelProperty(required = true)
	private CardIdentityProfile customerIdentityProfile;
	
	
}
