package com.wibmo.dfs.wallet.controller;

import com.wibmo.dfs.wallet.model.*;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wibmo.dfs.wallet.service.RequestMoneyService;
import com.wibmo.dfs.wallet.util.CommonUtil;
import com.wibmo.dfs.wallet.util.WibmoResponseUtil;
import com.wibmo.dfs.wallet.validation.RequestValidator;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("wallet/rm")
public class RequestMoneyController {

	
	@Autowired
	RequestMoneyService requestMoneyService;

	@Autowired
	private RequestValidator validator;
	
	@ApiOperation(value="Request Money Process API", response=WibmoResponse.class)
	@ApiResponses(value={
	        @ApiResponse(code = 200, message = "SUCCESS",response =WibmoResponse.class),
	        @ApiResponse(code = 400, message = "Request is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class)
	})
	@PostMapping(path = "/initiate/v1")
	public ResponseEntity<WibmoResponse> initiateRequestMoney(
			@RequestBody RMRequest rmRequest,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId , @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		
		Thread.currentThread().setName("requestMoneyInitiate");
				
		WibmoResponse response = new WibmoResponse();
		validator.validateInitRequestMoneyApi(rmRequest, response, bankId);
		
		if (response.getResCode() > 0) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), rmRequest.getTxnMode());
		
		return WibmoResponseUtil.frameResponse(requestMoneyService.processRequestMoney(rmRequest, response, bankId));
	}
	
	@ApiOperation(value="Request Money Fetch API", response=WibmoResponse.class)
	@ApiResponses(value={
	        @ApiResponse(code = 200, message = "SUCCESS",response =WibmoResponse.class),
	        @ApiResponse(code = 400, message = "Request is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class)
	})
	@PostMapping(path = "/fetch/v1")
	public ResponseEntity<WibmoResponse> collectRequestMoneyDetails(
			@RequestBody FetchRMRequest fetchRMRequest,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		//setting userId
		fetchRMRequest.setCustomerId(userId);
		Thread.currentThread().setName("fetchRM");
		
		WibmoResponse response = new WibmoResponse();
		validator.validateFetchRMApi(fetchRMRequest, response, bankId);
		
		if (response.getResCode() > 0) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), userId);
		
		return WibmoResponseUtil.frameResponse(requestMoneyService.fetchRequestMoneyDetails(fetchRMRequest, response, bankId));
	}
	@PostMapping(path = "/fetch/v2")
	public ResponseEntity<WibmoResponse> collectRequestMoneyDetails(
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId,
			@RequestBody PendingCollectMoneyRequest pendingCollectMoneyRequest) {
		Thread.currentThread().setName("fetchRMV2");

		WibmoResponse response = new WibmoResponse();
		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), userId);
		return WibmoResponseUtil.frameResponse(requestMoneyService.fetchRequestMoneyDetails(userId, response, bankId, pendingCollectMoneyRequest));
	}

	@PostMapping(path = "/quickpay/v1")
	public ResponseEntity<WibmoResponse> fetchQuickpayDetails(
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId,
			@RequestBody QuickPayRequest quickPayRequest) {
		Thread.currentThread().setName("quickpayV1");

		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), userId);
		return WibmoResponseUtil.frameResponse(requestMoneyService.fetchQuickPayDetails(bankId, userId, quickPayRequest));
	}


	@ApiOperation(value="Request Money Process API", response=WibmoResponse.class)
	@ApiResponses(value={
			@ApiResponse(code = 200, message = "SUCCESS",response =WibmoResponse.class),
			@ApiResponse(code = 400, message = "Request is empty",response =WibmoResponse.class),
			@ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class)
	})
	@PostMapping(path = "/initiate/v2")
	public ResponseEntity<WibmoResponse> initiateRequestMoneyForCollectRequest(
			@RequestBody OutgoingCollectRequest request,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId , @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {

		Thread.currentThread().setName("requestMoneyInitiateV2");

		CommonUtil.startThreadNameForLogging(Thread.currentThread().getName(), request.getTxnMode());

		return WibmoResponseUtil.frameResponse(requestMoneyService.initiateRequestMoney(request, bankId, userId));
	}



	@ApiOperation(value="Request Money Accept Initiate API", response=WibmoResponse.class)
	@ApiResponses(value={
	        @ApiResponse(code = 200, message = "SUCCESS",response =WibmoResponse.class),
	        @ApiResponse(code = 400, message = "Request is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class)
	})
	@PostMapping(path = "/accept/init/v1")
	public ResponseEntity<WibmoResponse> requestMoneyAccept(
			@RequestBody RMAcceptRequest rmAcceptRequest,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		
		Thread.currentThread().setName("RM Accept Request");
		
		WibmoResponse response = new WibmoResponse();
		//once App implements decline flow remove below check
		if(StringUtils.isBlank(rmAcceptRequest.getCollectStatus())) {
			rmAcceptRequest.setCollectStatus("A");
		}
		validator.validateRMAcceptApi(rmAcceptRequest, response, bankId);
		
		if (response.getResCode() > 0) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		
		return WibmoResponseUtil.frameResponse(requestMoneyService.acceptRequestMoney(rmAcceptRequest, response, bankId));	
	}

	@PostMapping(path = "/accept/init/v2")
	public ResponseEntity<WibmoResponse> requestMoneyAcceptV2(
			@RequestBody IncomingCollectRequest incomingCollectRequest,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {

		Thread.currentThread().setName("RMAcceptRequestV2");

		WibmoResponse response = new WibmoResponse();

		if (response.getResCode() > 0) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}

		return WibmoResponseUtil.frameResponse(requestMoneyService.incomingCollectRequest(bankId, userId, incomingCollectRequest));
	}
	
	@ApiOperation(value="Request Money Accept confirm API", response=WibmoResponse.class)
	@ApiResponses(value={
	        @ApiResponse(code = 200, message = "SUCCESS",response =WibmoResponse.class),
	        @ApiResponse(code = 400, message = "Request is empty",response =WibmoResponse.class),
	        @ApiResponse(code = 500, message = "INTERNAL ERROR",response =WibmoResponse.class)
	})
	@PostMapping(path = "/accept/confirm/v1")
	public ResponseEntity<WibmoResponse> requestMoneyAccept(
			@RequestBody RMAcceptConfirmRequest rmAcceptConfirmRequest,
			@RequestHeader(value = "X-PROGRAM-ID") String bankId, @RequestHeader(value = "X-ACCOUNT-NUMBER") String userId) {
		
		Thread.currentThread().setName("RM Accept Confirm Request");
		
		WibmoResponse response = new WibmoResponse();
		validator.validateRMAcceptConfirm(rmAcceptConfirmRequest, response, bankId);
		
		if (response.getResCode() > 0) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		
		return WibmoResponseUtil.frameResponse(requestMoneyService.acceptUpiRequestMoneyConfirm(rmAcceptConfirmRequest, response, bankId));
		
	}
}
