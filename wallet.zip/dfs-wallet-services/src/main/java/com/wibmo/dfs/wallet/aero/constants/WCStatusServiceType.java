package com.wibmo.dfs.wallet.aero.constants;

public enum WCStatusServiceType {

	ECOM_SERVICE("1", "e-Com");

	private String serviceType;
	private String serviceDesc;

	WCStatusServiceType(String serviceType, String serviceDesc) {

		this.serviceType = serviceType;
		this.serviceDesc = serviceDesc;
	}

	public String getServiceType() {
		return serviceType;
	}

	public String getServiceDesc() {
		return serviceDesc;
	}

	public static WCStatusServiceType getServices(String val) {
		for (WCStatusServiceType wcStatusServiceType : WCStatusServiceType.values()) {
			if (wcStatusServiceType.serviceType.equalsIgnoreCase(val) ||
					wcStatusServiceType.serviceDesc.equalsIgnoreCase(val)) {
				return wcStatusServiceType;
			}
		}
		throw new IllegalArgumentException("Invalid Service : " + val);
	}

	public static String serviceTypeToDesc(String eventType) {
		return getServices(eventType).getServiceDesc();
	}

	public static String serviceDescToType(String desc) {
		return getServices(desc).getServiceType();
	}
}
