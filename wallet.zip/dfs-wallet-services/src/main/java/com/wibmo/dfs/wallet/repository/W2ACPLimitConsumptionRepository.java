package com.wibmo.dfs.wallet.repository;

import com.wibmo.dfs.wallet.entity.W2ACPConsumption;
import com.wibmo.dfs.wallet.model.LimitConsumptionRequest;

public interface W2ACPLimitConsumptionRepository {
    int save(W2ACPConsumption w2ALimitConsumption);
    int update(W2ACPConsumption w2AConsumption, String startDate, String endDate);
    W2ACPConsumption fetch(int programId, String customerId, String txnType, int beneficiaryId, String limitKey, String startDate, String endDate);
    W2ACPConsumption isConsumptionAvailable(LimitConsumptionRequest request, String customerId, String date, String startDate, String endDate);
}
