package com.wibmo.dfs.wallet.model;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;


@Component
public class RMPendingResponseMapper {


    public List<TxnHistoryResponse> map(List<PendingCollectResponse> rmPendingCollectlist) {
        List<TxnHistoryResponse> txnHistoryResponseList = new ArrayList<>();
        for(PendingCollectResponse resp : rmPendingCollectlist){
            TxnHistoryResponse txnHistoryResponse = new TxnHistoryResponse();
            txnHistoryResponse.setMobile(resp.getPayeeMobileNumber());
            txnHistoryResponse.setMerName(resp.getPayeeName());
            txnHistoryResponse.setDestAccount(resp.getPayeeVPA());
            txnHistoryResponse.setTxnDate(resp.getRequestedDate());
            txnHistoryResponse.setTxnCategory("RM");
            txnHistoryResponse.setTxnType(resp.getTxnMode());
            txnHistoryResponse.setTxnRefNumber(resp.getTxnRefNumber());
            txnHistoryResponse.setTxnAmount(Long.parseLong(resp.getTxnAmount()));
            txnHistoryResponse.setTxnDesc(resp.getDesc());
            txnHistoryResponse.setTxnStatus("P");
            txnHistoryResponseList.add(txnHistoryResponse);
        }
        return txnHistoryResponseList;
    }
}
