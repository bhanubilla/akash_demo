package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
public class BlockedVpaDetails {
    private long id;
    private String accountNumber;
    private String vpa;
    private String blockedVpa;
    private String blockedVpaName;
    private String blockedMobileNumber;
    private Timestamp updatedTs;
    private Timestamp createdTs;
}
