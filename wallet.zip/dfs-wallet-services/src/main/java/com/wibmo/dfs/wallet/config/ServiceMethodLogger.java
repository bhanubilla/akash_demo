package com.wibmo.dfs.wallet.config;

import java.util.Arrays;

import lombok.SneakyThrows;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Aspect
@Component
@Slf4j
public class ServiceMethodLogger {
	
	/**
     * Adds trace logging before a proceeding join point method call.
     * @param pjp The proceeding joint point
     * @return Result of method call
     * @throws Throwable
     */
	@SneakyThrows
    @Around("execution(* com.wibmo.dfs.wallet.service..*.* (..)) || execution(* com.wibmo.dfs.wallet.aero.service..*.* (..)) || execution(* com.wibmo.dfs.wallet.helper..*.* (..))")
	public Object logBeforeAndAfterServiceMethods(ProceedingJoinPoint pjp) {
        final String joinPoints = Arrays.toString(pjp.getArgs());
        if(joinPoints!=null) {
        	log.debug(">> Entered {}.{}() with arguement[s]={} ", pjp.getSignature().getDeclaringTypeName(), pjp.getSignature().getName(), joinPoints);
        }
        final Object resultOfMethodCall;

            resultOfMethodCall = pjp.proceed();

        log.debug("<< Exit {}.{}() with result = {}", pjp.getSignature().getDeclaringTypeName(), pjp.getSignature().getName(), resultOfMethodCall);
        return resultOfMethodCall;
    }
	
}