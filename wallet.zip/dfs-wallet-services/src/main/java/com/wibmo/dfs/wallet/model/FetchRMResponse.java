package com.wibmo.dfs.wallet.model;

import java.io.Serializable;
import java.util.List;

import com.wibmo.dfs.wallet.bean.RMCollectListResponse;
import com.wibmo.dfs.wallet.bean.RMWalletListResponse;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FetchRMResponse implements Serializable{

	
	private static final long serialVersionUID = 1L;

	private boolean walletServiceError;
	private List<RMWalletListResponse> walletListResponse;
	private boolean upiServiceError;
	private RMCollectListResponse collectListResponse;
}
