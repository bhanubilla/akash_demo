package com.wibmo.dfs.wallet.aero.beans;

import java.io.Serializable;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author ajay.mahto
 */
@Data
@NoArgsConstructor
public class TransactionHistoryRequest extends AeroRequest implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private String fromDate;
    private String toDate;
	private int pageNumber;
	private int count;
	private long fromRowId;
	private boolean openAuthSettleCreditsRequired;
    
}

