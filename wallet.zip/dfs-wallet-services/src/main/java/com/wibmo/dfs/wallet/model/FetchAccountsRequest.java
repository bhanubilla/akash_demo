package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import io.swagger.annotations.ApiModelProperty;

@Data
@NoArgsConstructor
public class FetchAccountsRequest {
	@ApiModelProperty(required = true, dataType="String")
	private String customerId;
	
	@ApiModelProperty(required = false, dataType="String")
	private String category;
	
	@ApiModelProperty(required = false, dataType="int")
	private int id;
	
	@ApiModelProperty(required = false, dataType="String")
	private boolean lcGrouping;
}
