package com.wibmo.dfs.wallet.model;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BulkLinkAccountsRequest {
	@ApiModelProperty(required = false, dataType="String", hidden = true)
	private String customerId;
	
	@ApiModelProperty(required = true, dataType="String")
	private String mobile;
	
	@ApiModelProperty(required = true, dataType="String", example="ac", notes="possible value is either ac,lc,wc or all")
	private String category;
	
	@ApiModelProperty(required = true, dataType="List", notes="if category value is lc")
	private List<LinkedCardInfo> linkedCardInfo;
}
