package com.wibmo.dfs.wallet.model;

import lombok.Data;

@Data
public class QuickPayRequest {
    private String actionType;
}
