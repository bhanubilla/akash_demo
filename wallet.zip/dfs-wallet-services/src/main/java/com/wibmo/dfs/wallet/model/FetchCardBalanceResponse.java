package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FetchCardBalanceResponse {

	private String customerId;
	private int walletId;
	private long balance;
	private int kycLevel;
	private String productType;
	private String mobile;
}
