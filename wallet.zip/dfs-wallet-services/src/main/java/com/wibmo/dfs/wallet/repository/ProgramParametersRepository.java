/**
 * 
 */
package com.wibmo.dfs.wallet.repository;

import java.util.Map;

/**
 * @author rajasekhar.kaniti
 *
 */
public interface ProgramParametersRepository {
	Map<String, String> getAllProgramParams();
	String fetchParamValueByParamName(String programId, String paramName);
	boolean reloadProgParamValues(String programId, String paramName);
}
