package com.wibmo.dfs.wallet.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PrepaidBankMapping implements Serializable {
	private static final long serialVersionUID = 1L;

	private int id;
	private String bankId;
	private String countryCode;
	private String bankName;
	private int ppId;
	private Timestamp createdDt;
	private Timestamp updatedDt;
	
	private PrepaidMaster ppMaster;
}
