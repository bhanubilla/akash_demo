package com.wibmo.dfs.wallet.config;

import com.wibmo.dfs.wallet.entity.WalletTxnInfo;
import com.wibmo.dfs.wallet.model.FundResponse;
import lombok.extern.slf4j.Slf4j;
import org.dozer.DozerBeanMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 
 * @author meriyala.raghavendra
 *
 */
@Slf4j
@Configuration
public class BeanConfig {

	/**
	 * Create singleton DozerBeanMapper bean for mapping object to object.
	 * 
	 * @return
	 */
	@Bean
	public DozerBeanMapper dozerBeanMapper() {
		return new DozerBeanMapper();
	}

	@Bean
	public WalletTxnInfo getWalletTxnInfo() {
		return new WalletTxnInfo();
	}
	
	@Bean
	public FundResponse getFundResponse() {
		return new FundResponse();
	}
	
}
