package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class WalletInfo{

	private long loadAmt;
	private String customerId;
	private String kycLevel;
	private UserProfile profile;
	private Object resp;
	private String productType;

}
