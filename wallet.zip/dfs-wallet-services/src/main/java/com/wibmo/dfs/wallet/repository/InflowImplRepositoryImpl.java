package com.wibmo.dfs.wallet.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;
import com.wibmo.dfs.wallet.entity.InflowImpl;

@Repository
public class InflowImplRepositoryImpl implements InflowImplRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public InflowImpl fetchByImplId(String id) {

		BeanPropertyRowMapper<InflowImpl> rowMapper = BeanPropertyRowMapper.newInstance(InflowImpl.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<InflowImpl> list = jdbcTemplate.query("select * from inflow_impl where IF_IMPL_ID = ? and IMPL_STATUS=1",
				new PreparedStatementSetter() {

					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setString(1, id);
					}
				}, rowMapper);
		return !list.isEmpty() ? list.get(0) : null;

	}

	@Override
	public InflowImpl fetchByImplDesc(String implDesc) {

		BeanPropertyRowMapper<InflowImpl> rowMapper = BeanPropertyRowMapper.newInstance(InflowImpl.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<InflowImpl> list = jdbcTemplate.query("select * from inflow_impl where IMPL_DESC = ? and IMPL_STATUS=1",
				new PreparedStatementSetter() {

					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setString(1, implDesc);
					}
				}, rowMapper);
		return !list.isEmpty() ? list.get(0) : null;

	}

}
