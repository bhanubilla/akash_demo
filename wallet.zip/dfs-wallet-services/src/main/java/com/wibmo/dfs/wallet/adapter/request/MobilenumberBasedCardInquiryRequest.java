package com.wibmo.dfs.wallet.adapter.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MobilenumberBasedCardInquiryRequest {
    private int messageCode;
    private String clientId;
    private String secureCode;
    private String clientTxnId;
    private String requestDateTime;
    private int bankId;
    private String cardHolderMobileNumber;
}
