/**
 * 
 */
package com.wibmo.dfs.wallet.service;


import com.wibmo.dfs.wallet.model.AutoTopupAuthStatusUpdateRequest;
import com.wibmo.dfs.wallet.model.AutoTopupInitRequest;
import com.wibmo.dfs.wallet.model.AutoTopupStatusRequest;
import com.wibmo.dfs.wallet.model.ModifyAutotopupRequest;
import com.wibmo.dfs.wallet.model.UpdateAutoTopupSubscriptionRequest;
import com.wibmo.dfs.wallet.model.WibmoResponse;


/**
 * @author rajasekhar.kaniti
 *
 */
public interface AutoTopupService {
	
	WibmoResponse authStatusUpdate(AutoTopupAuthStatusUpdateRequest autoTopupSubscriptionRequest, int bankId);
	WibmoResponse fetchSubscriptionStatus(AutoTopupStatusRequest autoTopupStatusRequest, String bankId);
	WibmoResponse autoTopupInit(AutoTopupInitRequest autoTopupInitRequest, String bankId);
	WibmoResponse modifyAutoTopup(ModifyAutotopupRequest modifyAutotopupRequest, String bankId);
	WibmoResponse updateAutoTopup(UpdateAutoTopupSubscriptionRequest updateAutotopupRequest);
}
