package com.wibmo.dfs.wallet.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FetchTransactionHistoryRequest {
	@ApiModelProperty(required = true, dataType="String", notes="if walletId is missing")
	private String customerId;
	
	@ApiModelProperty(required = true, dataType="String", notes="if walletId is missing")
	private String productType;
	
	@ApiModelProperty(required = true, dataType="int", notes="if both customerId and productType are missing")
	private int walletId;
	
	@ApiModelProperty(required = false, dataType="String", example="2021")
    private String fromYear;
	
	@ApiModelProperty(required = false, dataType="String", example="2021")
    private String toYear;	
	
	@ApiModelProperty(required = false, dataType="String", example="01")
    private String fromMonth;
	
	@ApiModelProperty(required = false, dataType="String", example="02")
    private String toMonth;
	
	@ApiModelProperty(required = false, dataType="String", example="01")
    private String fromDay;	
	
	@ApiModelProperty(required = false, dataType="String", example="30")
    private String toDay;
	
	@ApiModelProperty(required = false, dataType="boolean")
    private boolean forceRefresh;
    

}
