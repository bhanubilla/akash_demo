package com.wibmo.dfs.wallet.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DeviceRegistrationInfo {
	private int accountNumber;
	private String deviceId;
	private String fcmId;
	private String clientIp;
	private int appVersion;
	private String osType;
	private String osVersion;
	private String deviceMake;
	private String deviceModel;
	private int deviceType;
	private String netOpertaor;
	private float gpsLatitude;
	private float gpsAccuracy;
	private float gpsLongitude;
	private String zipCode;
	private Date updDate;
}
