package com.wibmo.dfs.wallet.bean;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RMWalletListResponse implements Serializable{

	private static final long serialVersionUID = 1L;

	private String txnMode;
	private long txnAmt;
	private String payeeDetails;
	private String payeeId;
	private long txnDate;
}
