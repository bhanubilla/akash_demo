package com.wibmo.dfs.wallet.kafka.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class LoadMoneyEvent extends BaseDetails{

	private String destAccount;
	private String sourceAccount;
	private String paymentTxnId;
	private String ppTxnId;
	private String merTxnId;
	private String merchantId;
	private String merchantName;
	private String mcc;
	private String originalTxnId;
	private String additionalFields;
}
