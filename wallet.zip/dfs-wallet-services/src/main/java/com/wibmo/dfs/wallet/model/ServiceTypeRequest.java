package com.wibmo.dfs.wallet.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ServiceTypeRequest {

	@ApiModelProperty(required = false, hidden = true)
	private String customerId;
	
	@ApiModelProperty(required = true)
	private int walletId;

	@ApiModelProperty(required = true)
	private ServiceTypes service;
	
}
