package com.wibmo.dfs.wallet.adapter.util;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.util.Base64;

@Component
public class AESGCMPayLoadEncryption {

    private static final String ENCRYPT_ALGO = "AES/GCM/NoPadding";
	private static final int TAG_LENGTH_BIT = 128;
    private static final int IV_LENGTH_BYTE = 12;
    private static final int SALT_LENGTH_BYTE = 16;
    private static final Charset UTF_8 = StandardCharsets.UTF_8;

    /**
     * @param plainText
     * @param secretKey
     * @return Cipher String
     * @exception GeneralSecurityException
     * @apiNote : Encrypt the plaintext data with provided symmetric secretkey and
     *          return ciphertext else if in case of any exception , null value will
     *          be returned.
     */

    public  String encrypt(String plainText, String secretKey) {

        try {

            // 16 bytes salt
            byte[] salt = EncryptDecryptHelper.getRandomNonce(SALT_LENGTH_BYTE);

            // GCM recommended 12 bytes iv
            byte[] iv = EncryptDecryptHelper.getRandomNonce(IV_LENGTH_BYTE);

            // secret key from password
            SecretKey aesKeyFromPassword = EncryptDecryptHelper.getAESKeyFromSecretKey(Base64.getDecoder().decode(secretKey.getBytes()), salt);

            Cipher cipher = Cipher.getInstance(ENCRYPT_ALGO);

            // ASE-GCM needs GCMParameterSpec
            cipher.init(Cipher.ENCRYPT_MODE, aesKeyFromPassword, new GCMParameterSpec(TAG_LENGTH_BIT, iv));

            byte[] cipherText = cipher.doFinal(plainText.getBytes(UTF_8));

            // prefix IV and Salt to cipher text
            byte[] cipherTextWithIvSalt = ByteBuffer.allocate(  salt.length+ iv.length+ cipherText.length)
                    .put(salt).put(iv).put(cipherText).array();

            // string representation, base64, send this string to other for decryption.
            return Base64.getEncoder().encodeToString(cipherTextWithIvSalt);

        } catch (GeneralSecurityException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * @param cipherText
     * @param secretKey
     * @return Plain text
     * @exception GeneralSecurityException
     * @apiNote : Decrypt the ciphertext data with provided symmetric secretkey and
     *          return plaintext else if in case of any exception , null value will
     *          be returned.
     *
     */

    public String decrypt(String cipherText, String secretKey) {

        try {
            byte[] decode = Base64.getDecoder().decode(cipherText.getBytes(UTF_8));

            // get back the iv and salt from the cipher text
            ByteBuffer bb = ByteBuffer.wrap(decode);
            byte[] salt = new byte[SALT_LENGTH_BYTE];
            bb.get(salt);

            byte[] iv = new byte[IV_LENGTH_BYTE];
            bb.get(iv);

            byte[] cText = new byte[bb.remaining()];
            bb.get(cText);

            // get back the aes key from the same password and salt
            SecretKey aesKeyFromPassword = EncryptDecryptHelper.getAESKeyFromSecretKey(Base64.getDecoder().decode(secretKey.getBytes()), salt);
            Cipher cipher = Cipher.getInstance(ENCRYPT_ALGO);

            cipher.init(Cipher.DECRYPT_MODE, aesKeyFromPassword, new GCMParameterSpec(TAG_LENGTH_BIT, iv));

            byte[] plainText = cipher.doFinal(cText);

            return new String(plainText, UTF_8);

        } catch (GeneralSecurityException e) {
            e.printStackTrace();
        }
        return null;

    }

}
