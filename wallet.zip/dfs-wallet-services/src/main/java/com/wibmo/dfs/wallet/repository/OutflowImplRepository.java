package com.wibmo.dfs.wallet.repository;

import com.wibmo.dfs.wallet.entity.OutflowImpl;


public interface OutflowImplRepository {	
	
	OutflowImpl fetchByImplId(int ofImplId);
	
	OutflowImpl fetchByImplDesc(String txnType);
	
}
