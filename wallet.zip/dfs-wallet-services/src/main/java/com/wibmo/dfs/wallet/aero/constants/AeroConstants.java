package com.wibmo.dfs.wallet.aero.constants;

/**
 * 
 * @author meriyala.raghavendra
 *
 */

public class AeroConstants {
	private AeroConstants() {}
    
    public static final String REQUEST_CREATE_CARD = "1010";
    public static final String RESPONSE_CREATE_CARD = "1011";
    
    public static final String REQUEST_CARD_INQUIRY = "1090";
    public static final String RESPONSE_CARD_INQUIRY = "1061";
    
    public static final String REQUEST_TXN_INQUIRY = "1070";
    public static final String RESPONSE_TXN_INQUIRY = "1071";
    
    public static final String REQUEST_CREDIT_ACCOUNT = "1080";
    public static final String RESPONSE_CREDIT_ACCOUNT = "1081";
    
    public static final String REQUEST_DEBIT_ACCOUNT = "1480";
    public static final String RESPONSE_DEBIT_ACCOUNT = "1281";
    
    public static final String REQUEST_BLOCK_CARD = "1240";
    public static final String RESPONSE_BLOCK_CARD = "1241";
    
    public static final String REQUEST_UNBLOCK_CARD = "1250";
    public static final String RESPONSE_UNBLOCK_CARD = "1251";
    
    public static final String REQUEST_RESET_PIN = "1120";
    public static final String RESPONSE_RESET_PIN = "1121";
    
    public static final String REQUEST_UPDATE_CARD_HOLDER_PROFILE = "1280";
    public static final String RESPONSE_UPDATE_CARD_HOLDER_PROFILE = "1191";
    
    public static final String REQUEST_STATUS_INQUIRY = "1320";

    public static final String REQUEST_STATEMENT_INQUIRY ="1072";

    public static final String RESPONSE_STATUS_INQUIRY = "1241";

    public static final String REQUEST_AML_INQUIRY = "1550";
    public static final String RESPONSE_AML_INQUIRY = "1551";

    public static final String REQUEST_SERVICE_ENABLE_DISABLE_CARD = "1600";
    public static final String RESPONSE_SERVICE_ENABLE_DISABLE_CARD = "1611";

    public static final String RESPONSE_CODE_SUCCESS = "00";
    public static final String RESPONSE_CODE_DUPLICATE_SUCCESS = "5000";
    public static final String RESPONSE_MESSAGE_DUPLICATE_SUCCESS = "DUPLICATE REQUEST. SUCCESS";
    
    public static final String RESPONSE_CODE_CARD_ALREADY_CREATED = "10";
    public static final String RESPONSE_CODE_CARD_ALREADY_BLOCKED = "1064";
    public static final String RESPONSE_CODE_CARD_ALREADY_UNBLOCKED = "1067";

    public static final String RENEW_WALLET_CARD_REQUEST = "1570";
    public static final String RENEW_WALLET_CARD_RESPONSE = "1571";
    
    public static final String REQUEST_SEND_MONEY = "1680";  

    public static final String CMS_SUCCESS_CODE = "000";

    public static final String REQUEST_CARDHOLDER_PROFILE_UPDATE = "1280";

    //Status From Prepaid
    public static final int CARD_STATUS_ACTIVE = 0;
    public static final int CARD_STATUS_TEMP_BLOCKED = 12;
    public static final int CARD_STATUS_PERMANENT_BLOCKED = 13;
    public static final int CARD_STATUS_CUSTOM_BLOCKED = 18;
    public static final int CARD_STATUS_CREDIT_DEBIT_BLOCKED = 120;
    public static final int CARD_STATUS_ACTIVE_AND_AUTH = 1;
    public static final int CARD_STATUS_DEBIT_BLOCKED = 100;
    public static final int CARD_STATUS_CREDIT_BLOCKED = 110;


    //CMS config keys
    public static final String CMS_PRODUCT_ID_ACCOUNT = "CMS_PRODUCT_ID_ACCOUNT";
    public static final String CMS_INTERFACE_URL = "CMS_INTERFACE_URL";
    public static final String CMS_CLIENT_ID = "CMS_CLIENT_ID";
    public static final String CMS_SECURE_CODE = "CMS_SECURE_CODE";
    public static final String CMS_BANK_ID = "CMS_BANK_ID";
    public static final String CMS_PRODUCT_ID_LINKED_CARD = "CMS_PRODUCT_ID_LINKED_CARD";
    public static final String CMS_PRODUCT_ID_VCARD = "CMS_PRODUCT_ID_VCARD";
    public static final String CMS_ENTITY_ID = "CMS_ENTITY_ID";
    public static final String CMS_PRODUCT_CHECKSUM_KEY = "CMS_PRODUCT_CHECKSUM_KEY";
    public static final String CMS_ECARD_CREATION_TYPE = "CMS_ECARD_CREATION_TYPE";
    public static final String CMS_PHYSICAL_CARD_REQ_URL = "CMS_PHYSICAL_CARD_REQ_URL";
    //Cashback CMS config keys
    public static final String CMS_CASHBACK_PRODUCT_ID = "CMS_CASHBACK_PRODUCT_ID";

    //Cashback wallet keys
    public static final String CASHBACK_WALLET_ENABLED = "CASHBACK_WALLET_ENABLED";
    public static final String CASHBACK_WALLET_INFLOW_IMPL_IDS = "CASHBACK_WALLET_INFLOW_IMPL_IDS";
    public static final String CASHBACK_WALLET_OUTFLOW_IMPL_IDS = "CASHBACK_WALLET_OUTFLOW_IMPL_IDS";
    public static final String CASHBACK_WALLET_PROMO_CANCEL = "CASHBACK_WALLET_PROMO_CANCEL";
    
    // Fund Flow Types
    public static final String FUND_FLOW_TYPE_INFLOW = "I";
    public static final String FUND_FLOW_TYPE_OUTFLOW = "O";
    
    // Client Response Code
    public static final int CLIENT_RESPONSE_CODE_SUCCESS = 1;
    public static final int CLIENT_RESPONSE_CODE_FAILED = 2;
    public static final int CLIENT_RESPONSE_CODE_INTERNAL_ERROR = 3;
    
    // Audit Status Desc
    public static final String AUDIT_STATUS_DESC_SUCCESS = "Success";
    public static final String AUDIT_STATUS_DESC_FAILURE = "Failure";
    
    //User Consumption
    public static final String TXN_TYPE_P2P = "P2P";
    public static final String TXN_LIMIT_TYPE_AMT ="A";
    public static final String TXN_LIMIT_TYPE_CNT ="C";
    public static final String TXN_TYPE_DEBIT ="DEBIT";
    public static final String TXN_TYPE_CREDIT ="CREDIT";

    public static final int SEND_MONEY_W2W = 5021;

    public static final int WALLET_CREATE = 5022;
   
    

}
