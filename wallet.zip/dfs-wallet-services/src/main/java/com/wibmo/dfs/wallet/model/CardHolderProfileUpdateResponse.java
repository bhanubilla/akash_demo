package com.wibmo.dfs.wallet.model;


import lombok.Data;

@Data
public class CardHolderProfileUpdateResponse {

    private Integer urn;
    private String customerId;
    private String responseCode;
    private Integer messageCode;
    private String clientTxnId;
    private String clientId;
    private String responseDateTime;
    private Integer accosaTransactionId;
    private String responseMessage;
    private Integer bankId;
    private String accosaRefNo;
    private Integer cardProfileId;

}
