package com.wibmo.dfs.wallet.entity;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RequestMoneyTxnInfo implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private int id;
	private String txnId;
	private String requsterCustomerId;
	private String requsteeCustomerId;
	private long amount;
	private String rmStatus;
	private String reqType;
	private String sourceType;
	private String destinationType;
	private Date createdDt;
	private Date updatedDt;
	private String remarks;
	private String initiateFrom;
		
}
