package com.wibmo.dfs.wallet.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerMiniProfile {

    private String firstName;
    private String lastName;
    private String mobileNo;
    private String emailId;
    private int kycLevel;
    private String customerId;
}
