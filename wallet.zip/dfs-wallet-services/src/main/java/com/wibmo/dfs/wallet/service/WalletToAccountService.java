package com.wibmo.dfs.wallet.service;

import com.wibmo.dfs.wallet.model.*;

public interface WalletToAccountService {
    WibmoResponse w2aVerification(W2AVerificationRequest request, int bankId, String userId);
    WibmoResponse w2aTransacation(W2ADebitRequest request, WalletService service, String bankId, String userId);
    WibmoResponse updateLimitConsumption(LimitConsumptionRequest request, int bankId, String userId);
    W2AWholeConsumption fetchLimitConsumption(int bankId, String userId, String txnType, String limitKey, int beneficiary);
    WibmoResponse revertLimitConsumption(LimitConsumptionRequest request, String bankId, String userId);
	
}