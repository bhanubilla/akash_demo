package com.wibmo.dfs.wallet.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class BeneficaryBankAccountRequest {
	@ApiModelProperty(required = false, dataType="String", hidden = true)
	private String customerId;
	
	@ApiModelProperty(required = true, dataType="String")
	private String accountNumber;
	
	@ApiModelProperty(required = true, dataType="String")
	private String accountName;
	
	@ApiModelProperty(required = true, dataType="String")
	private String ifscCode;
	
	@ApiModelProperty(required = false, dataType="String")
	private String bankName;
	
	@ApiModelProperty(required = false, dataType="String")
	private String accountType;
	
	@ApiModelProperty(required = false, dataType="String")
	private String branchName;	
	
}
