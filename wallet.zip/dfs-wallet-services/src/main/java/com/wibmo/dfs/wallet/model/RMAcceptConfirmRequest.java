package com.wibmo.dfs.wallet.model;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RMAcceptConfirmRequest implements Serializable{

	private static final long serialVersionUID = 1L;
	private String msgHash;
	private String pspId;
	private String reqPspRefNo;
	private String upiTxnRefNo;
	private String npciTxnId;
	private String credentialType;
	private String credentialSubType;
	private String credentialDataValue;
	private String credentialDataCode = "NPCI";
	private String credentialDataKi;
	private String deviceId;
	private String mobileNo;
	private String simId;
	private String geoCode;
	private String location;
	private String ip;
	private String os;
	private String deviceType;
	private String appName;
	private String capability;
	private String deviceName;
	private String token;
}
