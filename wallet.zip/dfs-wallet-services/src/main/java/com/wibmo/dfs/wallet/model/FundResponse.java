package com.wibmo.dfs.wallet.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FundResponse {
	
	private String custId;
	private int walletId;	
	private String refNumber;
	private long amount;
	private long availableBal;
	private String remarks;
	private String ppTxnId;
	private String ppResponseCode;
	private String ppResponseMessage;
}

 