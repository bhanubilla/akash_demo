package com.wibmo.dfs.wallet.aero.beans;

import java.util.Date;


/**
 * @author Preeti
 * @author akshath
 * @author preetham
 */
public class CardUserInfo implements java.io.Serializable {
	static final long serialVersionUID = 1L;
	private static final String ZERO ="000000";
	private String urnNumber;
	private String cardHolderName;
	private StringBuilder cardnumber=new StringBuilder(20);
	private StringBuilder expiryMM=new StringBuilder();
	private StringBuilder expiryYYYY=new StringBuilder();
	private StringBuilder expiryMMYY=new StringBuilder();
	private String expiryYYYYMM=null;
	private StringBuilder cvv2=new StringBuilder();
	
	private String mobileNumberAssociated;

	
	private String emailAssociated;
	private String kycStatus;
	private long availableBalance;
	private String addressAssociated;
	private Date lastActivityTime;

	public String getStatusDescription() {
		return statusDescription;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}

	
	private String status;
	private String statusDescription;
	
	
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	  
        @Override
	public String toString() {
		return "CardDetail";
	}

	public String getUrnNumber() {
		return urnNumber;
	}

	public void setUrnNumber(String urnNumber) {
		this.urnNumber = urnNumber;
	}

	public String getCardHolderName() {
		return cardHolderName;
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}

	public String getMobileNumberAssociated() {
		return mobileNumberAssociated;
	}

	public void setMobileNumberAssociated(String mobileNumberAssociated) {
		this.mobileNumberAssociated = mobileNumberAssociated;
	}

	public String getEmailAssociated() {
		return emailAssociated;
	}

	public void setEmailAssociated(String emailAssociated) {
		this.emailAssociated = emailAssociated;
	}

	public String getKycStatus() {
		return kycStatus;
	}

	public void setKycStatus(String kycStatus) {
		this.kycStatus = kycStatus;
	}

	public long getAvailableBalance() {
		return availableBalance;
	}

	public void setAvailableBalance(long availableBalance) {
		this.availableBalance = availableBalance;
	}

	public String getAddressAssociated() {
		return addressAssociated;
	}

	public void setAddressAssociated(String addressAssociated) {
		this.addressAssociated = addressAssociated;
	}

	public String getExpiryYYYYMM() {
		if(expiryYYYYMM==null) {
			if((expiryMMYY!=null) && (expiryMMYY.length()==4)){
				setExpiryMM(new StringBuilder(expiryMMYY.substring(0, 2)));
				setExpiryYYYY(new StringBuilder("20" + expiryMMYY.substring(2)));
				expiryYYYYMM = getExpiryYYYY().toString() + getExpiryMM().toString();
				return expiryYYYYMM;
			} else {
				return null;
			}
		}
		return expiryYYYYMM;
	}

        public StringBuilder getExpiryMM() {
            return expiryMM;
        }

        public void setExpiryMM(StringBuilder expiryMM) {
            this.expiryMM=expiryMM;
        }

        public StringBuilder getExpiryYYYY() {
            return expiryYYYY;
        }

        public void setExpiryYYYY(StringBuilder expiryYYYY) {
            this.expiryYYYY=expiryYYYY;
        }

        public StringBuilder getExpiryMMYY() {
            return expiryMMYY;
        }

        public void setExpiryMMYY(StringBuilder expiryMMYY) {
            this.expiryMMYY=expiryMMYY;
        }

        public StringBuilder getCvv2() {
            return cvv2;
        }

        public void setCvv2(StringBuilder cvv2) {
            this.cvv2=cvv2;
        }

        public StringBuilder getCardnumber() {
            return cardnumber;
        }

        public void setCardnumber(StringBuilder cardnumber) {
            this.cardnumber=cardnumber;
        }

        public void clearExpiryMMYY() {        
            this.expiryMMYY.setLength(0);
            this.expiryMMYY.append(ZERO);
            this.expiryMMYY.setLength(0);
            this.expiryMMYY.trimToSize();
        }

        public void clearExpiryYYYY() {        
            this.expiryYYYY.setLength(0);
            this.expiryYYYY.append(ZERO);
            this.expiryYYYY.setLength(0);
            this.expiryYYYY.trimToSize();
        }

        public void clearExpiryMM() {        
            this.expiryMM.setLength(0);
            this.expiryMM.append(ZERO);
            this.expiryMM.setLength(0);
            this.expiryMM.trimToSize();
        }

        public void clearCvv2() {
            if(this.cvv2 != null) {
                this.cvv2.setLength(0);
                this.cvv2.append(ZERO);
                this.cvv2.setLength(0);
                this.cvv2.trimToSize();
            }
        }

         public void clearCardNumber() {        
            this.cardnumber.setLength(0);
            this.cardnumber.append("00000000000000000000");
            this.cardnumber.setLength(0);
            this.cardnumber.trimToSize();
        }

        public void clearCardUserInfo() {
            this.clearCardNumber();
            this.clearExpiryMM();
            this.clearExpiryYYYY();
            this.clearExpiryMMYY();
            this.clearCvv2();
        }
    
	
	public void setExpiryYYYYMM(String expiryYYYYMM) {
		this.expiryYYYYMM = expiryYYYYMM;
	}
	
	public Date getLastActivityTime() {
		return lastActivityTime;
	}

	public void setLastActivityTime(Date lastActivityTime) {
		this.lastActivityTime = lastActivityTime;
	}

	
}
