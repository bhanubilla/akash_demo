package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UpiIncomingCollectResponse {
    private String txnId;
    private String payerVpa;
    private String payeeVpa;
    private String payeeName;
    private String txnAmount;
    private String payeeMobileNumber;
    private String currency;
    private String approvalStatus;
    private String walletId;
    private long txnDate;
    private String remarks;
}

