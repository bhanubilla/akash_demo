package com.wibmo.dfs.wallet.aero.constants;

import io.swagger.annotations.ApiModelProperty;

public enum TxnTrackingConstants {
	
    PAYMENT_INITIATION_SUCCESS("PAY_INIT_SUCCESS", "payment initiated"),
    MONEY_DEBIT_SUCCESS("MONEY_DEBIT_SUCCESS", "Money debited from bank"),
    MONEY_DEBIT_FAILURE("MONEY_DEBIT_FAILURE", "Money debited from bank"),
    CREDIT_MONEY_PENDING("CREDIT_MONEY_PENDING", Constants.CREDIT_MONEY_PENDING),
    CREDIT_MONEY_SUCCESS("CREDIT_MONEY_SUCCESS", Constants.CREDIT_MONEY_PENDING),
    CREDIT_MONEY_FAILURE("CREDIT_MONEY_FAILURE",Constants.CREDIT_MONEY_PENDING),
    TXN_COMPLETE("TXN_COMPLETE","payment completed"),
    DEBIT_REVERSAL_SUCCESS("DEBIT_REVERSAL_SUCCESS","Money credit to bank"),
    DEBIT_REVERSAL_FAILURE("DEBIT_REVERSAL_ CREDIT_FAILURE","Money credit to bank"),
    TXN_DECLINE("TXN_DECLINE","Payment declined"),
    PAY_BACK("PAY_BACK","Payment reversed");
	
	private static class Constants {
        public static final String CREDIT_MONEY_PENDING = "Money Sent to receiver's bank";
    }

    @ApiModelProperty(notes = "Status Name", name = "statusName")
    private final String statusName;
    @ApiModelProperty(notes = "Status description", name = "statusDescription")
    private final String statusDescription;

    TxnTrackingConstants(String statusName, String statusDescription) {
        this.statusName = statusName;
        this.statusDescription = statusDescription;
    }

    /**
     * Return the status name.
     */
    public String getStatusName() {
        return this.statusName;
    }

    /**
     * Return the status msg.
     */
    public String getStatusDescription() {
        return this.statusDescription;
    }
}
