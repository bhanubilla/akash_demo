package com.wibmo.dfs.wallet.model;


import lombok.Data;

@Data
public class UpdateCardHolderProfileData {

    private String accountNumber;
    private String firstName;
    private String lastName;
    private String mobile;
    private String dob;
    private String email;
    private String address;
    private String city;
    private String state;
    private String zipCode;
    private String country;
    private String aadhaarNumber;
    private Integer kycLevel;
    private String panCardNumber;
    private String passportNumber;
    private String voterIdNumber;
    private String drivingLicenseNumber;

}
