/**
 * 
 */
package com.wibmo.dfs.wallet.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
public class UpdateNickNameRequest {
	@ApiModelProperty(required = true, dataType="long")
	private long cardRefId;
	
	@ApiModelProperty(required = false, dataType="String", hidden = true)
	private String customerId;
	
	@ApiModelProperty(required = true, dataType="String")
	private String nickName;
	

}
