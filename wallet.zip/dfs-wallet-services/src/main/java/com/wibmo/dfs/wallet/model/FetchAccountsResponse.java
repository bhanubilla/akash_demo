package com.wibmo.dfs.wallet.model;

import java.util.List;
import java.util.Map;

import com.wibmo.dfs.wallet.entity.BankAccounts;
import com.wibmo.dfs.wallet.entity.UserLinkedCardInfo;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FetchAccountsResponse {
	
	private List<BankAccounts> accounts;
	private List<UserLinkedCardInfo> linkedCards;
	private List<FetchCardResponse> wallets;
	private Map<String, List<UserLinkedCardInfo>> listOfCards;
}
