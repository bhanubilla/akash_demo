/**
 * 
 */
package com.wibmo.dfs.wallet.service;

import com.wibmo.dfs.wallet.repository.MsgsRepository;
import com.wibmo.dfs.wallet.repository.UserAccountInfoRepository;
import com.wibmo.dfs.wallet.repository.WalletCardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wibmo.dfs.wallet.common.MsgConstants;
import com.wibmo.dfs.wallet.entity.UserAccountInfo;
import com.wibmo.dfs.wallet.entity.WalletCard;
import com.wibmo.dfs.wallet.model.UserACSCheckRequest;

import lombok.extern.slf4j.Slf4j;

/**
 * @author rajasekhar.kaniti
 *
 */
@Slf4j
@Service
public class UserACSServiceImpl implements UserACSService {
	
	
	@Autowired
	private WalletCardRepository walletCardRepository;
	
	@Autowired
	private UserAccountInfoRepository userAccountInfoRepository;

	@Autowired
	private MsgsRepository msgsRepository;

	/*
	 * @param userCheckACSReq
	 * @return WibmoResponse
	 * 
	 */
	@Override
	public String userCheck(UserACSCheckRequest userCheckACSReq, StringBuilder resultString) {

		final String errorCode = "error_code=";
		final String errorDesc = "error_desc=";
		
		try {
			WalletCard walletCard = walletCardRepository.fetchByCardNumber(userCheckACSReq.getWalletCardNumber(),userCheckACSReq.getBankId());
			if(walletCard != null && walletCard.getCardNumber().equals(userCheckACSReq.getWalletCardNumber())) {
				UserAccountInfo userAccountInfo = userAccountInfoRepository.fetchByCustId(walletCard.getCustomerId());
				if(null != userAccountInfo && userCheckACSReq.getMobileNo().equals((userAccountInfo.getMobile()))) {
					log.info("user check success");
					resultString.append(errorCode).append("0");
					resultString.append("&");
					resultString.append(errorDesc).append("Success");
				}else {
					log.info("user check failed !!! "+ msgsRepository.fetchMsgValueByMsgName(userCheckACSReq.getBankId(),MsgConstants.MOBILE_AND_CARD_DETAILS_ARE_MISMATCH));
					resultString.append(errorCode).append("107");
					resultString.append("&");
					resultString.append(errorDesc).append("Mobile number not found or not verified");
				}
			}else {
				log.info("user check failed !!! "+ msgsRepository.fetchMsgValueByMsgName(userCheckACSReq.getBankId(),MsgConstants.WALLET_CARD_NOT_FOUND));
				resultString.append(errorCode).append("101");
				resultString.append("&");
				resultString.append(errorDesc).append("Card not found");
			}

		}catch(Exception ex) {
			log.error("Error : " + ex.getMessage());
			resultString.append(errorCode).append("103");
			resultString.append("&");
			resultString.append(errorDesc).append("Internal error");

		}

		return resultString.toString();
	}

}
