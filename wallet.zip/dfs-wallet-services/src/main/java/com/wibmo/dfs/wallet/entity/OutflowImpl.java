package com.wibmo.dfs.wallet.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OutflowImpl implements Serializable {
	private static final long serialVersionUID = 1L;

	private int ofImplId;
	private int implStatus;
	private String implDesc;	
	private Timestamp createdDate;
	private Timestamp updatedDate;
	
}
