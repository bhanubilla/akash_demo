/**
 * 
 */
package com.wibmo.dfs.wallet.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rajasekhar.kaniti
 *
 */
@Data
@NoArgsConstructor
public class FetchTxnInfoRequest {
	
	@ApiModelProperty(required = true, dataType="String")
	private String txnId;
	@ApiModelProperty(required = true, dataType="String", example="sm", notes="possible values are lm, and sm")
	private String category;

}
