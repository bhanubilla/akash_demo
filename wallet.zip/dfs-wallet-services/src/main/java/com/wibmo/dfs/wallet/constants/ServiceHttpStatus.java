package com.wibmo.dfs.wallet.constants;

/**
 * @author raghavendra.gr
 *
 */
public enum ServiceHttpStatus {

	SUCCESS(200, "SUCCESS"), INTERNAL_ERROR(500, "Internal Server Error"), FAILURE(100, "Execution Failure.");

	private final int statusCode;
	private final String statusMsg;

	ServiceHttpStatus(int statusCode, String statusMsg) {
		this.statusCode = statusCode;
		this.statusMsg = statusMsg;
	}

	/**
	 * Return the integer statusCode.
	 */
	public int getStatusCode() {
		return this.statusCode;
	}

	/**
	 * Return the status msg.
	 */
	public String getStatusMsg() {
		return this.statusMsg;
	}

}
