package com.wibmo.dfs.wallet.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@ApiModel(description = "Remove Favourite Payment Request model")
public class RemoveFavPaymentRequest {
    private String encCardNumber;
    private int accountNumber;
}
