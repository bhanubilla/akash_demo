/**
 * 
 */
package com.wibmo.dfs.wallet.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * @author rajasekhar.kaniti
 *
 */
@Repository
public class OnUsBanksRepositoryImpl implements OnUsBanksRepository {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<String> getAllOnUsBankIds() {
		BeanPropertyRowMapper<String> rowMapper = BeanPropertyRowMapper.newInstance(String.class);
        rowMapper.setPrimitivesDefaultedForNullValue(true);
        List<String> listOnUsBanks = jdbcTemplate.query("select * from on_us_banks",rowMapper);
        return !listOnUsBanks.isEmpty() ?listOnUsBanks  : null;
	}

}
