package com.wibmo.dfs.wallet.aero.beans;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 *
 * @author Ajay Mahto
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class FundTransferResponse extends AeroResponse implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
	private StringBuilder cardNumber=new StringBuilder(20);
	private long availableBalance;
	private long availableCashLimit;
	private long transactionAmount;
	private Sender[] senders;
	private Receiver[] receivers;

    public StringBuilder getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(StringBuilder cardNumber) {
        this.cardNumber = cardNumber;
    }    

    public long getAvailableBalance() {
        return availableBalance;
    }

    public void setAvailableBalance(long availableBalance) {
        this.availableBalance = availableBalance;
    }

    public long getAvailableCashLimit() {
        return availableCashLimit;
    }

    public void setAvailableCashLimit(long availableCashLimit) {
        this.availableCashLimit = availableCashLimit;
    }

    public long getTransactionAmount() {
        return transactionAmount;
    }

    public void setTransactionAmount(long transactionAmount) {
        this.transactionAmount = transactionAmount;
    }
    
    public void clearCardNumber() {        
        this.cardNumber.setLength(0);
        this.cardNumber.append("00000000000000000000");
        this.cardNumber.setLength(0);
        this.cardNumber.trimToSize();
    }

	public Sender[] getSenders() {
		return senders;
	}

	public void setSenders(Sender[] senders) {
		this.senders = senders;
	}

	public Receiver[] getReceivers() {
		return receivers;
	}

	public void setReceivers(Receiver[] receivers) {
		this.receivers = receivers;
	}
    
    
    
}
