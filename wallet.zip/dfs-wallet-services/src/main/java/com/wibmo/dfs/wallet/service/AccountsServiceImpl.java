package com.wibmo.dfs.wallet.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpHeaders;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.wibmo.dfs.hsm_client.CryptoException;
import com.wibmo.dfs.hsm_client.CryptoHandler;
import com.wibmo.dfs.wallet.aero.constants.AeroMsgDefinitions;
import com.wibmo.dfs.wallet.bean.PaymentCardObjectDetails;
import com.wibmo.dfs.wallet.common.MsgConstants;
import com.wibmo.dfs.wallet.common.ProgramParamConstants;
import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.constants.ServiceHttpStatus;
import com.wibmo.dfs.wallet.entity.BankBinMapping;
import com.wibmo.dfs.wallet.entity.BeneficiaryBankAccounts;
import com.wibmo.dfs.wallet.entity.PrepaidBankMapping;
import com.wibmo.dfs.wallet.entity.UserLinkedCardInfo;
import com.wibmo.dfs.wallet.entity.UserNickNameInfo;
import com.wibmo.dfs.wallet.entity.WalletCard;
import com.wibmo.dfs.wallet.helper.CommonHelper;
import com.wibmo.dfs.wallet.model.BeneficaryBankAccountRequest;
import com.wibmo.dfs.wallet.model.BulkLinkAccountsRequest;
import com.wibmo.dfs.wallet.model.CheckWalletCardRequest;
import com.wibmo.dfs.wallet.model.CustomerMiniProfile;
import com.wibmo.dfs.wallet.model.FetchAccountsRequest;
import com.wibmo.dfs.wallet.model.FetchAccountsResponse;
import com.wibmo.dfs.wallet.model.FetchBeneficaryBankAccountResponse;
import com.wibmo.dfs.wallet.model.FetchBeneficiary;
import com.wibmo.dfs.wallet.model.FetchCardResponse;
import com.wibmo.dfs.wallet.model.FetchLinkedCardsRequest;
import com.wibmo.dfs.wallet.model.FetchWalletsRequest;
import com.wibmo.dfs.wallet.model.LinkAccountsRequest;
import com.wibmo.dfs.wallet.model.LinkedCardInfo;
import com.wibmo.dfs.wallet.model.LinkedCardRefDetails;
import com.wibmo.dfs.wallet.model.RemoveFavPaymentRequest;
import com.wibmo.dfs.wallet.model.SearchWalletAccountsRequest;
import com.wibmo.dfs.wallet.model.UnlinkAccountsRequest;
import com.wibmo.dfs.wallet.model.UpdateNickNameRequest;
import com.wibmo.dfs.wallet.model.ValidateLinkedCardRequest;
import com.wibmo.dfs.wallet.model.VpaDetailsMini;
import com.wibmo.dfs.wallet.model.VpaDetailsRequest;
import com.wibmo.dfs.wallet.model.WalletCardAndVpaDetails;
import com.wibmo.dfs.wallet.model.WibmoResponse;
import com.wibmo.dfs.wallet.repository.BankAccountsRepository;
import com.wibmo.dfs.wallet.repository.BankBinMappingRepository;
import com.wibmo.dfs.wallet.repository.BeneficaryBankAccountsRepository;
import com.wibmo.dfs.wallet.repository.MsgsRepository;
import com.wibmo.dfs.wallet.repository.PrepaidBankMappingRepository;
import com.wibmo.dfs.wallet.repository.ProgramParametersRepository;
import com.wibmo.dfs.wallet.repository.UserLinkedCardRepository;
import com.wibmo.dfs.wallet.repository.WalletCardRepository;
import com.wibmo.dfs.wallet.util.ApiManagerUtil;
import com.wibmo.dfs.wallet.util.CommonUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class AccountsServiceImpl implements AccountsService {

	private static final String ERROR = "Error : ";

	@Autowired
	public DozerBeanMapper dozerBeanMapper;

	@Autowired
	private BankAccountsRepository repository;

	@Autowired
	private BankBinMappingRepository bankBinMappingRepository;

	@Autowired
	private UserLinkedCardRepository userLinkedCardRepository;

	@Autowired
	private WalletCardRepository walletRepro;

	@Autowired
	private PrepaidBankMappingRepository ppBankRepo;

	@Autowired
	private WalletServiceFactory findService;

	@Autowired
	private MsgsRepository msgsRepository;

	@Autowired
	private ProgramParametersRepository progParamRespository;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private BeneficaryBankAccountsRepository bankAccRepository;

	@Value("${resource.url.payment}")
	private String paymentServiceUrl;
	
	@Value("${resource.url.upiIntegrationService}")
	private String upiIntegrationServiceUrl;
	
	@Value("${resource.url.upiServiceVpaDetails}")
	private String upiIntegrationServiceGetVpaDetailsUrl;

	@Autowired
	CryptoHandler hsm;

	@Autowired
	private ApiManagerUtil apiManagerUtil;
	/*
	 * @param request
	 * 
	 * @return WibmoResponse
	 * 
	 * link the account/cards to user
	 */
	@Override
	public WibmoResponse addAccount(LinkAccountsRequest request, int bankId) {
		WibmoResponse response = new WibmoResponse();
		UserLinkedCardInfo linkedCardInfo = new UserLinkedCardInfo();

		if (request.getCategory().equals(Constants.LINKED_CARD)) {
			try {
				WibmoResponse response1 = validateCardMaxLimitCheckPerAccount(request, response, String.valueOf(bankId));
				if (response1 != null)
					return response1;

				WibmoResponse response2 = validateCardMaxLimitCheck(request, bankId, response);
				if (response2 != null)
					return response2;

				UserLinkedCardInfo cardInfo = userLinkedCardRepository.fetchLinkedCardByCustIdAndCardNumber(
						request.getCustomerId(), request.getLinkedCardInfo().getCardNumber(), bankId);
				if (cardInfo != null) {
					log.info("This card is already linked to the customer :  " + request.getCustomerId());
					response.setResCode(3);
					response.setResDesc(msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),MsgConstants.CARD_IS_ALREADY_LINKED));
					return response;
				}

				String bin = request.getLinkedCardInfo().getCardNumber().substring(0, 6);
				WibmoResponse response3 = chkBankbinMapping(request, response, linkedCardInfo, bin, String.valueOf(bankId));
				if (response3 != null)
					return response3;
				CommonHelper.prepareUserLinkedCardInfo(request, linkedCardInfo);

				int cardAddedId = userLinkedCardRepository.save(linkedCardInfo, bankId);
				if (cardAddedId > 0) {
					LinkedCardRefDetails cardRefId = new LinkedCardRefDetails();
					cardRefId.setCardRefId(cardAddedId);
					log.info("Card linked successfully to customer : " + request.getCustomerId());
					response.setResCode(1);
					response.setResDesc(msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),MsgConstants.CARD_LINKED_SUCCESSFULLY));
					response.setData(cardRefId);
				}
			} catch (Exception e) {
				log.error(ERROR + e.getMessage());
				response.setResCode(Constants.CLIENT_RESPONSE_CODE_INTERNAL_ERROR);
				response.setResDesc(msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),MsgConstants.RESPONSE_DESC_INTERNAL_ERROR));
			}
		} else {
			response.setResCode(3);
			response.setResDesc("unsupported category : " + request.getCategory());
		}

		return response;
	}

	private WibmoResponse chkBankbinMapping(LinkAccountsRequest request, WibmoResponse response,
			UserLinkedCardInfo linkedCardInfo, String bin, String bankId) {
		BankBinMapping bankBinMapping = bankBinMappingRepository.getByBin(bin);
		int binId = 0;

		if (bankBinMapping == null) {
			WibmoResponse cardTypeResonse = CommonUtil.invokeApi(restTemplate, HttpMethod.POST, paymentServiceUrl,
					"/payments/cardType/v1", bankId, request.getLinkedCardInfo().getCardNumber());
			if (null == cardTypeResonse) {
				log.info("payment response was null ");
				response.setResCode(2);
				response.setResDesc(
						msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.PAYMENT_CARDTYPE_RESPONSE_FAILED));
				return response;
			}

			if (cardTypeResonse.getResCode() == 200) {
				PaymentCardObjectDetails paymentCard = dozerBeanMapper.map(cardTypeResonse.getData(),
						PaymentCardObjectDetails.class);
				bankBinMapping = new BankBinMapping();
				bankBinMapping.setBin(bin);
				bankBinMapping.setCardType(paymentCard.getCardType());
				bankBinMapping.setCountryCode(paymentCard.getCountryCode());
				bankBinMapping.setBankName(paymentCard.getBankName());
				populateCardUnion(request, bankBinMapping, paymentCard);
				if (request.getLinkedCardInfo().getCardAssociation() != null) {
					bankBinMapping.setCardAssociation(request.getLinkedCardInfo().getCardAssociation());
				} else {
					bankBinMapping.setCardAssociation(CommonHelper.getCardAssociationId(bankBinMapping.getCardUnion()));
				}

				binId = bankBinMappingRepository.save(bankBinMapping);

				if (binId > 0)
					log.info("record inserted successfully into bank bin mapping for bin " + bin);

			} else if (cardTypeResonse.getResCode() != 200) {
				response.setResCode(2);
				response.setResDesc(cardTypeResonse.getResDesc());
				return response;
			}
		} else {
			binId = bankBinMapping.getId();
		}

		linkedCardInfo.setBinId(binId);
		return null;
	}

	private void populateCardUnion(LinkAccountsRequest request, BankBinMapping bankBinMapping,
			PaymentCardObjectDetails paymentCard) {
		if (paymentCard.getCardUnion() != null) {
			bankBinMapping.setCardUnion(paymentCard.getCardUnion());
		} else {
			bankBinMapping.setCardUnion(request.getLinkedCardInfo().getCardUnion());
		}
	}

	private WibmoResponse validateCardMaxLimitCheck(LinkAccountsRequest request, int bankId, WibmoResponse response) {
		String isAddCardMaxLimitCheckIsEnabled = progParamRespository
				.fetchParamValueByParamName(String.valueOf(bankId),ProgramParamConstants.IS_ADDING_CARD_MAX_LIMIT_CHECK_IS_ENABLED);
		if ("true".equalsIgnoreCase(isAddCardMaxLimitCheckIsEnabled)) {
			log.info("IS_ADDING_CARD_MAX_LIMIT_CHECK_IS_ENABLED: " + isAddCardMaxLimitCheckIsEnabled);
			int maxLimitOfAddCard = Integer.parseInt(
					progParamRespository.fetchParamValueByParamName(String.valueOf(bankId),ProgramParamConstants.MAX_LIMIT_OF_ADDING_CARD));

			int count = userLinkedCardRepository.getCardAddedCount(request.getLinkedCardInfo().getCardNumber(), bankId);
			log.info("card added count : " + count);
			if (count >= maxLimitOfAddCard) {
				log.warn("card adding limit exceeded :" + count);
				response.setResCode(3);
				response.setResDesc(
						msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),MsgConstants.MAX_LIMIT_OF_ADDING_CARD_EXCEEDED));
				return response;
			}
		}
		return null;
	}

	private WibmoResponse validateCardMaxLimitCheckPerAccount(LinkAccountsRequest request, WibmoResponse response, String bankId) {
		String isAddCardMaxLimitCheckPerAccountIsEnabled = progParamRespository
				.fetchParamValueByParamName(bankId,ProgramParamConstants.IS_ADDING_CARD_MAX_LIMIT_PER_ACCOUNT_CHECK_IS_ENABLED);
		if ("true".equalsIgnoreCase(isAddCardMaxLimitCheckPerAccountIsEnabled)) {
			log.info("IS_ADDING_CARD_MAX_LIMIT_PER_ACCOUNT_CHECK_IS_ENABLED: "
					+ isAddCardMaxLimitCheckPerAccountIsEnabled);
			int maxLimitOfAddCardPerAccount = Integer.parseInt(progParamRespository
					.fetchParamValueByParamName(bankId,ProgramParamConstants.MAX_LIMIT_OF_ADDING_CARD_PER_ACCOUNT));

			log.info("MAX_LIMIT_OF_ADDING_CARD_PER_ACCOUNT: " + maxLimitOfAddCardPerAccount);
			int count = userLinkedCardRepository.getCardAddedCountPerAccount(request.getCustomerId());
			log.info("card added count per account: " + count);
			if (count >= maxLimitOfAddCardPerAccount) {
				log.warn("card adding limit exceeded per account: " + count);
				response.setResCode(3);
				response.setResDesc(msgsRepository
						.fetchMsgValueByMsgName(bankId,MsgConstants.MAX_LIMIT_OF_ADDING_CARD_PER_ACCOUNT_EXCEEDED));
				return response;
			}
		}
		return null;
	}

	/*
	 * @param request
	 * 
	 * @return WibmoResponse
	 * 
	 * fetch linked cards/bank accounts/wallet card details based on user specified
	 * category if category null/empty or all then all type of categories it will
	 * fetch and return to user For category lc or null/empty or all if user passed
	 * lcGrouping as true then it will return extra map in response as linked card
	 * as a map group by card type
	 */
	@Override
	public WibmoResponse fetchAccounts(FetchAccountsRequest request, int bankId) {
		WibmoResponse response = new WibmoResponse();
		FetchAccountsResponse acctResp = new FetchAccountsResponse();

		if (null != request.getCategory() && request.getCategory().equalsIgnoreCase(Constants.BANK_ACCOUNT)) {
			acctResp.setAccounts(repository.fetchByCustIdOrId(request.getCustomerId(), request.getId()));
		} else if (null != request.getCategory() && request.getCategory().equalsIgnoreCase(Constants.LINKED_CARD)) {
			List<UserLinkedCardInfo> list = userLinkedCardRepository
					.fetchLinkedCardByCustIdOrId(request.getCustomerId(), request.getId(), bankId);
			if (request.isLcGrouping()) {
				acctResp.setListOfCards(fetchLinkedCardsByGrouping(list));
			} else {
				acctResp.setLinkedCards(list);
			}

		} else if (null != request.getCategory() && request.getCategory().equalsIgnoreCase(Constants.WALLET_CARD)) {
			acctResp.setWallets(fetchWalletsByCustIdOrId(request.getCustomerId(), request.getId(), String.valueOf(bankId)));
		} else if (null != request.getCategory() && request.getCategory().equalsIgnoreCase(Constants.ALL)) {
			fetchAll(request, acctResp, bankId);
		} else if (StringUtils.isEmpty(request.getCategory())) {
			// empty category considers all
			fetchAll(request, acctResp, bankId);
		} else {
			response.setResCode(2);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),MsgConstants.INVALID_CATEGORY_PASSED) + " "
					+ request.getCategory());
			return response;
		}

		response.setResCode(1);
		response.setResDesc(msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),MsgConstants.ACCOUNTS_FETCH_SUCCESSFULLY));
		response.setData(acctResp);
		return response;
	}

	/**
	 * @param request
	 * @param acctResp
	 */
	private void fetchAll(FetchAccountsRequest request, FetchAccountsResponse acctResp, int bankId) {
		acctResp.setAccounts(repository.fetchByCustId(request.getCustomerId()));
		acctResp.setWallets(fetchWalletsByCustId(request.getCustomerId(), String.valueOf(bankId)));
		List<UserLinkedCardInfo> list = userLinkedCardRepository.fetchLinkedCardByCustId(request.getCustomerId(),
				bankId);
		if (request.isLcGrouping()) {
			acctResp.setListOfCards(fetchLinkedCardsByGrouping(list));
		} else {
			acctResp.setLinkedCards(list);
		}

	}

	/*
	 * @param custId
	 * 
	 * @return List as fetchCardResponse
	 */
	private List<FetchCardResponse> fetchWalletsByCustId(String custId, String bankId) {
		List<WalletCard> wcs = walletRepro.fetchByCustId(custId, bankId);
		List<FetchCardResponse> wallets = new ArrayList<>();
		if (null != wcs && !wcs.isEmpty()) {
			PrepaidBankMapping bnk = ppBankRepo.fetchById(wcs.get(0).getPpBankId(), bankId);
			WalletService wservice = findService.getService(bnk.getBankId());
			wallets = wservice.fetchByWc(wcs);
		}
		return wallets;
	}

	/*
	 * @param request as UnlinkAccountsRequest
	 * 
	 * @return as WibmoResponse
	 * 
	 * it will unlink the linked cards and bank accounts specified by user as
	 * category
	 * 
	 * if user needs to specify ac for bank cards, lc for linked cards
	 */
	@Override
	public WibmoResponse deleteAccounts(UnlinkAccountsRequest request, String bankId) {
		WibmoResponse response = new WibmoResponse();
		boolean flag = false;

		if (request.getCategory().equals(Constants.LINKED_CARD)) {
			UserLinkedCardInfo userLinkedCardInfo = userLinkedCardRepository.fetchLinkedCardByCustIdAndId(request.getCustomerId(), request.getId(), Integer.parseInt(bankId));
			flag = userLinkedCardRepository.delete(request.getId(), request.getCustomerId());

			RemoveFavPaymentRequest removeFavPaymentRequest = null;
			try {
				String encCardNumber = hsm.secureData(userLinkedCardInfo.getCardNumber());
				removeFavPaymentRequest = new RemoveFavPaymentRequest(encCardNumber, Integer.parseInt(request.getCustomerId()));
				WibmoResponse cardTypeResonse = CommonUtil.invokeApi(restTemplate, HttpMethod.POST, paymentServiceUrl,
						"/merchant/user/v1/remove/favourite/payment", bankId, removeFavPaymentRequest);

				if(cardTypeResonse.getResCode() == 200)
					log.info("Favourite Transaction info deleted for cust Id {} " , request.getCustomerId());
				else
					log.info("Favourite Transaction info delete failed. Reason : {} " , cardTypeResonse.getErrorMessage());
			} catch (CryptoException e) {
				log.info("Favourite Transaction info delete failed. Reason : {} " , e.getMessage());
			}
		} else {
			response.setResCode(2);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.INVALID_CATEGORY_PASSED));
			return response;
		}

		if (flag) {
			log.info("Card Un-linked successfully to customer : " + request.getCustomerId());
			response.setResCode(1);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.ACCOUNT_UNLINK_SUCCESSFULLY));
		} else {
			log.info("Card Un-link Failed to customer : " + request.getCustomerId());
			response.setResCode(3);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.ACCOUNT_UNLINK_FAILED));
		}
		return response;
	}

	/*
	 * @param custId
	 * 
	 * @param id
	 * 
	 * @return list as FetchCardResponse
	 * 
	 * fetch Wallet card by customer id and wallet id
	 */
	private List<FetchCardResponse> fetchWalletsByCustIdAndId(String custId, int id, String bankId) {
		List<WalletCard> wcs = new ArrayList<>();
		List<FetchCardResponse> wallets = new ArrayList<>();
		WalletCard walletCard = walletRepro.fetchByCustIdAndId(custId, id, bankId);
		if (walletCard != null)
			wcs.add(walletCard);

		if (null != walletCard) {
			PrepaidBankMapping bnk = ppBankRepo.fetchById(walletCard.getPpBankId(), bankId);
			WalletService wservice = findService.getService(bnk.getBankId());
			wallets = wservice.fetchByWc(wcs);
		}
		return wallets;
	}

	/*
	 * @param custId
	 * 
	 * @param id
	 * 
	 * @return list as FetchCardResponse
	 * 
	 * fetch Wallet card either by customer id or wallet id
	 */

	private List<FetchCardResponse> fetchWalletsByCustIdOrId(String custId, int id, String bankId) {
		if (id > 0) {
			return fetchWalletsByCustIdAndId(custId, id, bankId);
		} else {
			return fetchWalletsByCustId(custId, bankId);
		}
	}

	/*
	 * @param list as UserLinkedCardInfo
	 * 
	 * @return map key as card type and value as list of linked cards as
	 * UserLinkedCardInfo
	 */

	private Map<String, List<UserLinkedCardInfo>> fetchLinkedCardsByGrouping(List<UserLinkedCardInfo> list) {
		Map<String, List<UserLinkedCardInfo>> map = new HashMap<>();
		for (UserLinkedCardInfo cardinfo : list) {
			String key = cardinfo.getCardType();
			List<UserLinkedCardInfo> cardInfoList = map.get(key);

			if (cardInfoList != null) {
				cardInfoList.add(cardinfo);
			} else {
				cardInfoList = new ArrayList<>();
				cardInfoList.add(cardinfo);
			}

			map.put(key, cardInfoList);

		}

		return map;
	}

	@Override
	public WibmoResponse updateNickName(UpdateNickNameRequest updateNickNameReq, String bankId) {
		WibmoResponse response = new WibmoResponse();
		UserNickNameInfo userNickNameInfo = dozerBeanMapper.map(updateNickNameReq, UserNickNameInfo.class);
		int id = userLinkedCardRepository.updateNickName(userNickNameInfo);
		if (id > 0) {
			log.info("user nickname updated successfully for user id : " + updateNickNameReq.getCustomerId());
			response.setResCode(200);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.NICKNAME_UPDATED_SUCCESSFULLY));
		} else {
			log.info("failed to update user nickname for user id : " + updateNickNameReq.getCustomerId());
			response.setResCode(100);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,MsgConstants.NICKNAME_UPDATE_FAILED));
		}

		return response;

	}

	@Override
	public WibmoResponse fetchLinkedCards(FetchLinkedCardsRequest request, int bankId) {
		WibmoResponse response = new WibmoResponse();
		List<UserLinkedCardInfo> list = userLinkedCardRepository.fetchLinkedCardByCustIdOrId(request.getCustomerId(),
				request.getId(), bankId);
		if (request.isLcGrouping()) {
			response.setData(fetchLinkedCardsByGrouping(list));
		} else {
			response.setData(list);
		}
		response.setResCode(200);
		response.setResDesc("User Linked cards fetched Successfully");

		return response;
	}

	@Override
	public WibmoResponse fetchWallets(FetchWalletsRequest request, String bankId) {
		WibmoResponse response = new WibmoResponse();
		List<FetchCardResponse> list = fetchWalletsByCustIdOrId(request.getCustomerId(), request.getId(), bankId);
		response.setResCode(200);
		response.setResDesc("User Wallet cards fetched Successfully");
		response.setData(list);
		return response;
	}

	@Override
	public WibmoResponse autoLinkCard(BulkLinkAccountsRequest request, int bankId) {
		log.info("Start AccountsServiceImpl : autoLinkCard for customerId {}", request.getCustomerId());
		WibmoResponse resp = null;
		WibmoResponse response = null;
		List<LinkedCardInfo> listOfCards = request.getLinkedCardInfo();
		for (LinkedCardInfo linkedCardInfo : listOfCards) {
			LinkAccountsRequest req = new LinkAccountsRequest(request.getCustomerId(),
					request.getCategory(), null, linkedCardInfo);
			response = addAccount(req, bankId);
		}
		if (null != response) {
			log.info("END AccountsServiceImpl : autoLinkCard response {}", response.getResDesc());
			resp = new WibmoResponse(response.getResCode(), response.getResDesc());
		}
		return resp;
	}

	@Override
	public WibmoResponse validateLinkedCard(ValidateLinkedCardRequest request, int bankId) {
		log.info("validate req for custId: {}, cardRefId : {}", request.getCustomerId(), request.getCardRefId());
		UserLinkedCardInfo info = userLinkedCardRepository.fetchLinkedCardByCustIdAndId(request.getCustomerId(),
				request.getCardRefId(), bankId);
		WibmoResponse response = new WibmoResponse(200,
				msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),AeroMsgDefinitions.LINKED_CARD_VALIDATED));
		if (null == info) {
			response.setResCode(100);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),AeroMsgDefinitions.LINKED_CARD_NOT_FOUND));
		} else {
			if (info.getCardNumber().equalsIgnoreCase(request.getCardNumber())) {
				if (!info.getExpiryMm().equalsIgnoreCase(request.getExpiryMM())) {
					response.setResCode(152);
					response.setResDesc(
							msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),AeroMsgDefinitions.EXPIRY_MONTH_MISMATCH));
				}
				if (!info.getExpiryYyyy().equalsIgnoreCase(request.getExpiryYYYY())) {
					response.setResCode(153);
					response.setResDesc(
							msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),AeroMsgDefinitions.EXPIRY_YEAR_MISMATCH));
				}
			} else {
				response.setResCode(151);
				response.setResDesc(msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),AeroMsgDefinitions.CARD_NUMBER_MISMATCH));
			}

		}
		log.debug("Response code: {}, desc: {}", response.getResCode(), response.getResDesc());
		return response;
	}

	@Override
	public WibmoResponse checkWalletCard(CheckWalletCardRequest request, String bankId) {
		WalletCard wc = null;
		WibmoResponse response = new WibmoResponse();
		if (StringUtils.isBlank(request.getCustomerId())) {
			CustomerMiniProfile userInfo = apiManagerUtil.fetchUserProfile(bankId, null, request.getMobile());
			if (null != userInfo) {
				log.info("Check wallet ,"+userInfo.getCustomerId() + request.getProductType());
				wc = walletRepro.fetchByCustIdAndProduct(userInfo.getCustomerId(), request.getProductType(), bankId);
			}
		} else {
			log.info(" Entering into else block of Check wallet", request.getCustomerId() + request.getProductType());
			wc = walletRepro.fetchByCustIdAndProduct(request.getCustomerId(), request.getProductType(), bankId);
		}
		if (null != wc) {
			log.info("fetch carddetails successfully");
			response.setResCode(200);
			response.setResDesc(
					msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.FETCH_CARD_DETAILS_SUCCESSFULLY));
			response.setData(wc.getId());
		} else {
			log.info("card not found");
			response.setResCode(100);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId,AeroMsgDefinitions.CARD_NOT_FOUND));
		}
		return response;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public WibmoResponse searchWalletAccounts(SearchWalletAccountsRequest request, String bankId) {
		WalletCard wc = null;
		WalletCardAndVpaDetails walletCardAndVpaDetails = new WalletCardAndVpaDetails();
		WibmoResponse response = new WibmoResponse();
		CustomerMiniProfile userInfo = apiManagerUtil.fetchUserProfile(bankId, null, request.getMobile());
		if (null != userInfo) {
			String productType = request.getProductType();
			request.setProductType(StringUtils.isNotEmpty(productType) ? productType : Constants.PRODUCT_TYPE_RW);
			wc = walletRepro.fetchByCustIdAndProduct(userInfo.getCustomerId(), request.getProductType(), bankId);
		}
		if (wc != null) {
			walletCardAndVpaDetails.setWalletAvailable(true);
			walletCardAndVpaDetails.setRecipientName(userInfo.getFirstName());
			String upiUrl = upiIntegrationServiceUrl + upiIntegrationServiceGetVpaDetailsUrl;
			MultiValueMap<String, String> customHeaders = new LinkedMultiValueMap<>();
			customHeaders.add(HttpHeaders.CONTENT_TYPE, "application/json");
			customHeaders.add("Accept", "application/json");
			customHeaders.add("X-PROGRAM-ID", bankId);
			customHeaders.add("X-ACCOUNT-NUMBER", wc.getCustomerId());
			customHeaders.add("X-MOBILE-NUMBER", request.getMobile());
			VpaDetailsRequest vpaDetailsRequest = new VpaDetailsRequest();
			vpaDetailsRequest.setMobileNumber(request.getMobile());

			HttpEntity<Object> entity = new HttpEntity<>(customHeaders);
			ResponseEntity<WibmoResponse> responseEntity = restTemplate.exchange(upiUrl, HttpMethod.GET, entity, WibmoResponse.class);
			WibmoResponse apiResponse = responseEntity.getBody();
			List<VpaDetailsMini> vpaDetailsMinilist = new ArrayList<>();
			if (apiResponse != null && apiResponse.getData() != null) {
				vpaDetailsMinilist = (List<VpaDetailsMini>) apiResponse.getData();
			}
			if (!vpaDetailsMinilist.isEmpty()) {
				walletCardAndVpaDetails.setVpaDetails(vpaDetailsMinilist);
				response.setResCode(200);
				response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId, AeroMsgDefinitions.FETCH_CARD_AND_VPA_DETAILS_SUCCESSFULLY));
				response.setData(walletCardAndVpaDetails);
			} else {
				walletCardAndVpaDetails.setVpaDetails(vpaDetailsMinilist);
				response.setResCode(200);
				response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId, AeroMsgDefinitions.FETCH_VPA_DETAILS_UNSUCCESSFUL));
				response.setData(walletCardAndVpaDetails);
			}
		} else {
			response.setResCode(100);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(bankId, AeroMsgDefinitions.CARD_NOT_FOUND));
		}
		return response;
	}

	/*
	 * @param request
	 * 
	 * @return WibmoResponse
	 * 
	 * link the Beneficary Bank Account to user
	 */
	@Override
	public WibmoResponse addBenficiaryBankAccount(BeneficaryBankAccountRequest request, int bankId) {
		WibmoResponse response = new WibmoResponse();
		BeneficiaryBankAccounts bankAc = new BeneficiaryBankAccounts();
		try {
			// chk bank account exist (MP-7118)
			if (bankAccRepository.isBankAccountExist(request.getCustomerId(), request.getAccountNumber(), bankId)) {
				log.info("Exist Bank Account for customerId:{}", request.getCustomerId());
				response.setResCode(180);
				response.setResDesc(
						msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId), MsgConstants.BENEFICIARY_ACCOUNTS_EXISTS));
			} else {
				bankAc = CommonHelper.prepareBeneficiaryBankAccount(request);
				int beneficaryBankId = bankAccRepository.save(bankAc, bankId);
				if (beneficaryBankId > 0) {
					log.info("Bank Account added successfully for customerId:{}, beneficaryBankId:{}",
							request.getCustomerId(), beneficaryBankId);
					response.setResCode(200);
					response.setResDesc(
							msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),MsgConstants.BENEFICIARY_ACCOUNTS_ADD_SUCCESSFULLY));
				} else {
					log.info("Failed to saved Beneficiary Bank Account for customerId:{}", request.getCustomerId());
					response.setResCode(150);
					response.setResDesc(
							msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),MsgConstants.BENEFICIARY_ACCOUNTS_ADD_FAILED));
				}
			}
		} catch (Exception e) {
			log.error(ERROR + e.getMessage());
			response.setResCode(Constants.CLIENT_RESPONSE_CODE_INTERNAL_ERROR);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),MsgConstants.RESPONSE_DESC_INTERNAL_ERROR));
		}
		return response;
	}

	/*
	 * @param request
	 * 
	 * @return WibmoResponse
	 * 
	 * fetch linked beneficary bank accounts based on customerId
	 */
	@Override
	public WibmoResponse fetchBenficiaryBankAccounts(String customerId, int bankId, FetchBeneficiary fetchBeneficiary) {
		WibmoResponse response = new WibmoResponse();
		List<BeneficiaryBankAccounts> bankAccList = null;
		try {
			bankAccList = bankAccRepository.fetchBeneficaryBankAccByCustId(customerId, bankId);
			if (null != bankAccList && !bankAccList.isEmpty()) {
				List<FetchBeneficaryBankAccountResponse> beneficaryAcclist = CommonHelper
						.prepareBeneficiaryBankAccountList(bankAccList, fetchBeneficiary);
				log.info("Bank Account(s) fetched successfully for customerId:{}, Benificiary Accounts: {}", customerId,
						bankAccList.size());
				response.setResCode(200);
				response.setResDesc(
						msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),MsgConstants.BENEFICIARY_ACCOUNTS_FETCH_SUCCESSFULLY));
				response.setData(beneficaryAcclist);
			} else {
				log.info("Bank Account(s) not there for customerId:{}", customerId);
				response.setResCode(150);
				response.setResDesc(
						msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),MsgConstants.BENEFICIARY_ACCOUNTS_NOT_AVAILABLE));
			}
		} catch (Exception ex) {
			log.error(ERROR + ex.getMessage());
			response.setResCode(Constants.CLIENT_RESPONSE_CODE_INTERNAL_ERROR);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),MsgConstants.RESPONSE_DESC_INTERNAL_ERROR));
		}
		return response;
	}

	@Override
	public WibmoResponse fetchUserDetails(String customerId, String programId) {
		WibmoResponse response = new WibmoResponse();
		CustomerMiniProfile user = apiManagerUtil.fetchUserProfile(programId, customerId, null);
		if(null != user) {
			response.setResCode(200);
			response.setResDesc("User Details fetched Successfully..");
			response.setData(user);
		} else {
			response.setResCode(100);
			response.setResDesc("User Details not found");
		}
		return response;
	}

	@Override
	public WibmoResponse fetchSpecificBeneficiaryBankAccount(String customerId, int bankId, int beneficiaryId) {
		WibmoResponse response = new WibmoResponse();
		try {
			log.info("Received request to fetch specific beneficiary for beneficiary Id {} for customer {}", beneficiaryId, customerId);
			BeneficiaryBankAccounts beneficiaryBankAccounts = bankAccRepository.fetchBeneficiaryBankAccByBenefId(customerId, bankId, beneficiaryId);
			if(beneficiaryBankAccounts == null){
				response.setResCode(150);
				response.setResDesc(msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),MsgConstants.BENEFICIARY_ACCOUNTS_NOT_AVAILABLE));
			}
			else{
				response.setResCode(ServiceHttpStatus.SUCCESS.getStatusCode());
				response.setResDesc(ServiceHttpStatus.SUCCESS.getStatusMsg());
				response.setData(beneficiaryBankAccounts);
			}
		}
		catch(Exception e){
			log.error(ERROR+" {}", e.getMessage());
			response.setResCode(Constants.CLIENT_RESPONSE_CODE_INTERNAL_ERROR);
			response.setResDesc(msgsRepository.fetchMsgValueByMsgName(String.valueOf(bankId),MsgConstants.RESPONSE_DESC_INTERNAL_ERROR));
		}
		return response;
	}
}
