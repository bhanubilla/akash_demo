package com.wibmo.dfs.wallet.repository;

import com.wibmo.dfs.wallet.entity.BlockedDetails;
import com.wibmo.dfs.wallet.model.BlockedMobileDetailsReq;

import java.util.List;

public interface BlockedMobileNumberDetailsRepo {
     int save(BlockedMobileDetailsReq blockedMobileDetailsReq);
     List<BlockedDetails>  fetchBlockedMobileNumbers(String accountNumber);
     BlockedDetails fetchBlockedMobileNumber(String accountNumber, String blockedMobileNumber);
     int delete(String accountNumber,String unBlockMobileNumber);
}
