/**
 *
 */
package com.wibmo.dfs.wallet.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.wibmo.dfs.wallet.constants.Constants;
import com.wibmo.dfs.wallet.model.W2AVerificationRequest;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.wibmo.dfs.wallet.entity.BeneficiaryBankAccounts;
import com.wibmo.dfs.hsm_client.CryptoException;
import com.wibmo.dfs.hsm_client.CryptoHandler;

import lombok.extern.slf4j.Slf4j;

/**
 * @author ajay.mahto
 *
 */
@Slf4j
@Repository
public class BeneficaryBankAccountsRepositoryImpl implements BeneficaryBankAccountsRepository {

	private static final String INSERT_QUERY = "INSERT INTO beneficary_bank_accounts (CUSTOMER_ID, ACCOUNT_NAME, IFSC_CODE, BANK_NAME, ACCOUNT_TYPE, BRANCH_NAME, ACCOUNT_NUMBER)"
			+ " VALUES (?,?,?,?,?,?,?)";
	private static final String INSERT_UPI_QUERY = "INSERT INTO beneficary_bank_accounts (CUSTOMER_ID, VPA)"
			+ " VALUES (?,?)";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	CryptoHandler hsm;

	@Override
	public int save(BeneficiaryBankAccounts benefBankAcc, int bankId) {
		KeyHolder keyHolder = new GeneratedKeyHolder();
		log.debug("Saving beneficiary details by information :{}", benefBankAcc.getCustomerId());
		String query = StringUtils.isEmpty(benefBankAcc.getVpa()) ? INSERT_QUERY : INSERT_UPI_QUERY;
		jdbcTemplate.update(connection -> {
			PreparedStatement preparedStmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
			int i = 1;

			preparedStmt.setString(i++, benefBankAcc.getCustomerId());
			if(query.equals(INSERT_QUERY)) {
				preparedStmt.setString(i++, benefBankAcc.getAccountName());
				preparedStmt.setString(i++, benefBankAcc.getIfscCode());
				preparedStmt.setString(i++, benefBankAcc.getBankName());
				preparedStmt.setString(i++, benefBankAcc.getAccountType());
				preparedStmt.setString(i++, benefBankAcc.getBranchName());
				try {
					preparedStmt.setString(i++, hsm.secureData(bankId, benefBankAcc.getAccountNumber()));
				} catch (CryptoException e) {
					log.debug("Error :{}", e.getMessage());
				}
			}else
			{
				preparedStmt.setString(i++, benefBankAcc.getVpa());
			}
			return preparedStmt;
		}, keyHolder);

		Number key = keyHolder.getKey();
		return null != key ? key.intValue() : 0;
	}

	@Override
	public List<BeneficiaryBankAccounts> fetchBeneficaryBankAccByCustId(String customerId, int bankId) {
		log.debug("customerId :{}", customerId);
		BeanPropertyRowMapper<BeneficiaryBankAccounts> rowMapper = BeanPropertyRowMapper
				.newInstance(BeneficiaryBankAccounts.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<BeneficiaryBankAccounts> benefAccountsList = jdbcTemplate
				.query("select * from beneficary_bank_accounts where customer_id = ?", new PreparedStatementSetter() {

					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setString(1, customerId);
					}
				}, rowMapper);
		List<BeneficiaryBankAccounts> decrBenefAccList = new ArrayList<>();
		for (BeneficiaryBankAccounts bankAcc : benefAccountsList) {
			try {
				bankAcc.setAccountNumber(hsm.getClearData(bankId, bankAcc.getAccountNumber()));
			} catch (CryptoException e) {
				log.error("Exception :", e.getMessage());
			}
			decrBenefAccList.add(bankAcc);
		}

		return decrBenefAccList;
	}

	@Override
	public boolean isBankAccountExist(String customerId, String accountNumber, int bankId)  {
		int count = 0;
		try {
			count = jdbcTemplate.queryForObject("select count(1) from beneficary_bank_accounts where customer_id = ? and ACCOUNT_NUMBER=?", Integer.class, customerId,hsm.secureData(bankId, accountNumber));
		} catch (DataAccessException e) {
			log.warn("DAException : {}", e);
		} catch (CryptoException e) {
			log.warn("CryptoException : {}", e);
		}
		return count > 0;
	}
	@Override
	public BeneficiaryBankAccounts fetchBeneficiaryBankAccByBenefId(String customerId, int bankId, int beneficiaryId) {
		log.debug("fetching beneficiary by beneficiary Id {}", beneficiaryId);
		BeanPropertyRowMapper<BeneficiaryBankAccounts> rowMapper = BeanPropertyRowMapper
				.newInstance(BeneficiaryBankAccounts.class);
		rowMapper.setPrimitivesDefaultedForNullValue(true);
		List<BeneficiaryBankAccounts> benefAccountsList = jdbcTemplate
				.query("select * from beneficary_bank_accounts where customer_id = ? and id =?", preparedStatement -> {
					preparedStatement.setString(1, customerId);
					preparedStatement.setInt(2, beneficiaryId);
				}, rowMapper);
		List<BeneficiaryBankAccounts> decrBenefAccList = new ArrayList<>();
		for (BeneficiaryBankAccounts bankAcc : benefAccountsList) {
			try {
				bankAcc.setAccountNumber(hsm.getClearData(bankId, bankAcc.getAccountNumber()));
			} catch (CryptoException e) {
				log.error("Exception : {} ", e.getMessage());
			}
			decrBenefAccList.add(bankAcc);
		}

		return (decrBenefAccList.isEmpty()) ? null : decrBenefAccList.get(0);
	}

	@Override
	public BeneficiaryBankAccounts fetchBeneficaryBankAccByBenefInfo(String customerId, int bankId, W2AVerificationRequest w2AVerificationRequest) {
		log.debug("fetching beneficiary by beneficiary Information for txnType {}",w2AVerificationRequest.getTxnType());
		String securedBankAccNo = null;
		StringBuilder query = new StringBuilder();
		List<BeneficiaryBankAccounts> decrBenefAccList = new ArrayList<>();
		try {
			query.append("select * from beneficary_bank_accounts where customer_id = ");
			query.append(customerId);
			query.append(" and ");
			if(w2AVerificationRequest.getTxnType().equals(Constants.W2A))
			{
				query.append("ACCOUNT_NUMBER = '");
				securedBankAccNo = hsm.secureData(bankId, w2AVerificationRequest.getBeneficiaryAccountNumber());
				query.append(securedBankAccNo);
				query.append("' AND ACCOUNT_NAME = '");
				query.append(w2AVerificationRequest.getBeneficiaryName());
				query.append("' AND IFSC_CODE = '");
				query.append(w2AVerificationRequest.getBeneficiaryIfscCode());
			}
			else {
				query.append("VPA = '");
				query.append(w2AVerificationRequest.getVpa());
			}
			query.append("'");

			BeanPropertyRowMapper<BeneficiaryBankAccounts> rowMapper = BeanPropertyRowMapper
					.newInstance(BeneficiaryBankAccounts.class);
			rowMapper.setPrimitivesDefaultedForNullValue(true);
			List<BeneficiaryBankAccounts> benefAccountsList = jdbcTemplate
					.query(query.toString(),  rowMapper);
			for (BeneficiaryBankAccounts bankAcc : benefAccountsList) {
				bankAcc.setAccountNumber(hsm.getClearData(bankId, bankAcc.getAccountNumber()));
				decrBenefAccList.add(bankAcc);
			}

		} catch (CryptoException e) {
			log.error("Error Occurred {}",e.getMessage());
		}
		return decrBenefAccList.isEmpty() ? null : decrBenefAccList.get(0);
	}
}
