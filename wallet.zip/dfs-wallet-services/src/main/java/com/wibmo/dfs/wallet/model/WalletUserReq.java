package com.wibmo.dfs.wallet.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class WalletUserReq {

	private String requesteeCustomerId;
	private String requesteeMobile;
	private String requesteeName;
	private long amount;
	private long walletId;
}
