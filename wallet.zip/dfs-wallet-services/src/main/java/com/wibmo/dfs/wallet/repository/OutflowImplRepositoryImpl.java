package com.wibmo.dfs.wallet.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;
import com.wibmo.dfs.wallet.entity.OutflowImpl;

@Repository
public class OutflowImplRepositoryImpl implements OutflowImplRepository {	

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	/**
	 * This method is used to fetch outflowimpl object bassed on implId
	 * @param id
	 * 
	 * @return outflowImpl
	 */
	@Override
	public OutflowImpl fetchByImplId(int ofImplId) {
		
		BeanPropertyRowMapper<OutflowImpl> rowMapper = BeanPropertyRowMapper.newInstance(OutflowImpl.class);
        rowMapper.setPrimitivesDefaultedForNullValue(true);
        List<OutflowImpl> list = jdbcTemplate.query("select * from outflow_impl where OF_IMPL_ID = ? and IMPL_STATUS = 1", new PreparedStatementSetter() {

			public void setValues(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setInt(1, ofImplId);
			}
		} , rowMapper);
        return !list.isEmpty() ? list.get(0) : null;
        
	}
	
	/**
	 * This method is used to fetch outflowimpl object based on implDesc
	 * @param implDesc
	 * 
	 * @return outflowImpl
	 */
	@Override
	public OutflowImpl fetchByImplDesc(String implDesc) {
		
		BeanPropertyRowMapper<OutflowImpl> rowMapper = BeanPropertyRowMapper.newInstance(OutflowImpl.class);
        rowMapper.setPrimitivesDefaultedForNullValue(true);
        List<OutflowImpl> list = jdbcTemplate.query("select * from outflow_impl where IMPL_DESC = ? and IMPL_STATUS = 1",  new PreparedStatementSetter() {

			public void setValues(PreparedStatement preparedStatement) throws SQLException {
				preparedStatement.setString(1, implDesc);
			}
		}, rowMapper);
        return !list.isEmpty() ? list.get(0) : null;
        
	}

}
