/**
 * 
 */
package com.wibmo.dfs.wallet.repository;

import com.wibmo.dfs.wallet.entity.AutoTopupRenewal;

/**
 * @author rajasekhar.kaniti
 *
 */
public interface AutoTopUpRenewalRepository {
	
	int save(AutoTopupRenewal autoTopupRenewal);
	boolean updateAuthStatus(AutoTopupRenewal autoTopupRenewal);
	boolean updateCreditStatus(AutoTopupRenewal autoTopupRenewal);
	boolean updateRefundStatus(AutoTopupRenewal autoTopupRenewal);
	AutoTopupRenewal fetchById(String txnId);

}
