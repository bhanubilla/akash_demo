package com.wibmo.dfs.wallet.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.google.common.base.Predicates;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/*
 * /*
 * This will use to integrate Swagger configuration
 * it will build the docket object and API meta data
 * 
 * @author rkaniti
 */
@Configuration
@EnableSwagger2
public class SwaggerConfig {


	/*
	 * Builds the Docket by merging user specified values.
	 * Builds the Docket by merging user specified values.
	 * this will pick only api details available in base package 
	 * where we implement all the controllers 
	 */
	@Bean
	public Docket wibmoApi() {
		return new Docket(DocumentationType.SWAGGER_2)
				.select()
				.apis(RequestHandlerSelectors.basePackage("com.wibmo.dfs.wallet.controller"))
				.paths(PathSelectors.any())
				.paths(Predicates.not(PathSelectors.regex("/hsm.*")))
				.build()
				.apiInfo(metaData());
	}
	
	/*
	 *Set the api's meta information
	 */
	private ApiInfo metaData() {
		return new ApiInfoBuilder()
				.title("WALLET SERVICE")
				.description("\"WALLET SERVICE API\"")
				.version("1.0.0")
				.build();
	}

}