package com.wibmo.dfs.wallet.repository;

import java.util.List;
import java.util.Map;

import com.wibmo.dfs.wallet.entity.LMUserConsumption;

public interface LMUserConsumptionRepository {

	int saveOrUpdate(List<LMUserConsumption> lmCons);
	int save(LMUserConsumption lmCons);
	int update(LMUserConsumption lmCons);
	LMUserConsumption fetchByCustIdAndKey(String customerId, String productType, String key);
	Map<String,Long> fetchByCustId(String customerId, String productType, String... keys);
	
}
