package com.wibmo.dfs.wallet.helper;

import java.util.ArrayList;
import java.util.List;

import com.wibmo.dfs.wallet.constants.CardAddedSource;
import com.wibmo.dfs.wallet.entity.BankBinMapping;
import com.wibmo.dfs.wallet.entity.BeneficiaryBankAccounts;
import com.wibmo.dfs.wallet.entity.UserAccountInfo;
import com.wibmo.dfs.wallet.entity.UserLinkedCardInfo;
import com.wibmo.dfs.wallet.entity.WalletCard;
import com.wibmo.dfs.wallet.entity.WalletTxnInfo;
import com.wibmo.dfs.wallet.model.BeneficaryBankAccountRequest;
import com.wibmo.dfs.wallet.model.FetchBeneficaryBankAccountResponse;
import com.wibmo.dfs.wallet.model.FetchBeneficiary;
import com.wibmo.dfs.wallet.model.LinkAccountsRequest;
import com.wibmo.dfs.wallet.util.CommonUtil;

public class CommonHelper {
	private CommonHelper() {}

	public static void setUserInfo(LinkAccountsRequest request,UserAccountInfo info) {
		info.setCustomerId(request.getCustomerId());
		// insertion not required
	}
	
	public static WalletTxnInfo prepareWalletInfo(long amount,WalletCard cardDetails,WalletTxnInfo walletTxnInfo ) {
		//setting data into walletTxnInfo
		walletTxnInfo.setUserId(cardDetails.getCustomerId());
		walletTxnInfo.setAmount(amount);
		walletTxnInfo.setWalletId(cardDetails.getId());
		walletTxnInfo.setTxnId(CommonUtil.generateTxnId());

		return walletTxnInfo;
	}
	
	public static void prepareUserLinkedCardInfo(LinkAccountsRequest linkAccReq, UserLinkedCardInfo cardInfo){
		cardInfo.setCustomerId(linkAccReq.getCustomerId());
		cardInfo.setCardNumber(linkAccReq.getLinkedCardInfo().getCardNumber());
		cardInfo.setExpiryMm(linkAccReq.getLinkedCardInfo().getCardExpiryMM());
		cardInfo.setExpiryYyyy(linkAccReq.getLinkedCardInfo().getCardExpiryYYYY());
		cardInfo.setNameOnCard(linkAccReq.getLinkedCardInfo().getNameOnCard());
		cardInfo.setNickName(linkAccReq.getLinkedCardInfo().getNickName());
		cardInfo.setStatus(1);
		cardInfo.setPrimary(linkAccReq.getLinkedCardInfo().isPrimary());
		if(linkAccReq.getLinkedCardInfo().getAddedSource() != null && 
				linkAccReq.getLinkedCardInfo().getAddedSource().equalsIgnoreCase(CardAddedSource.SELF.getType())) {
			cardInfo.setCardAddedSource(CardAddedSource.SELF.getType());
		}else if(linkAccReq.getLinkedCardInfo().getAddedSource() != null && 
				linkAccReq.getLinkedCardInfo().getAddedSource().equalsIgnoreCase(CardAddedSource.ONFLY.getType())) {
			cardInfo.setCardAddedSource(CardAddedSource.ONFLY.getType());
		}else {
			cardInfo.setCardAddedSource("UNKNOWN");
		}
		
	}
	
	public static String getCardAssociationId(String cardUnion) {
		if(cardUnion!= null && cardUnion.equalsIgnoreCase("Master")) {
			return "M";
		}else if(cardUnion!= null && cardUnion.equalsIgnoreCase("Visa")) {
			return "V";
		}else {
			return "U";
		}
	}

	public static void prepareBankBinMappingInfo(LinkAccountsRequest request, BankBinMapping bankBinMapping) {
		String bin = request.getLinkedCardInfo().getCardNumber().substring(0, 6);
		bankBinMapping.setBin(bin);
		bankBinMapping.setBankName(request.getLinkedCardInfo().getBankName());
		bankBinMapping.setCardType(request.getLinkedCardInfo().getCardType());
		bankBinMapping.setCardUnion(request.getLinkedCardInfo().getCardUnion());
		bankBinMapping.setCountryCode(request.getLinkedCardInfo().getCountryCode());
		bankBinMapping.setOnUs(request.getLinkedCardInfo().getOnUs());
		if(request.getLinkedCardInfo().getCardAssociation() != null) {
			bankBinMapping.setCardAssociation(request.getLinkedCardInfo().getCardAssociation());
		}else {
			String cardAssociation = getCardAssociationId(request.getLinkedCardInfo().getCardUnion());
			bankBinMapping.setCardAssociation(cardAssociation);
		}
		
	}
	
	public static String extractMobileNo(String comments) {
    	String mobileNo = null;
    	if(comments != null && comments.contains(":")) {
    		mobileNo = comments.split(":")[1];
    	}
    	return mobileNo;
    }
	
	public static BeneficiaryBankAccounts prepareBeneficiaryBankAccount(BeneficaryBankAccountRequest request) {
		BeneficiaryBankAccounts  bankAc = new BeneficiaryBankAccounts();
		
		bankAc.setCustomerId(request.getCustomerId());
		bankAc.setAccountNumber(request.getAccountNumber());
		bankAc.setAccountName(request.getAccountName());
		bankAc.setAccountType(request.getAccountType());
		bankAc.setBankName(request.getBankName());
		bankAc.setBranchName(request.getBranchName());
		bankAc.setIfscCode(request.getIfscCode());

		return bankAc;
	}
	
	public static List<FetchBeneficaryBankAccountResponse> prepareBeneficiaryBankAccountList(List<BeneficiaryBankAccounts> beneficaryList, FetchBeneficiary fetchBeneficiary) {
		List<FetchBeneficaryBankAccountResponse> beneficaryAcclist = new ArrayList<>();
		
		for(BeneficiaryBankAccounts bankAcc : beneficaryList) {
			if(bankAcc.getVpa() != null && fetchBeneficiary.isVpaReq()) {
				FetchBeneficaryBankAccountResponse benificaryRes = new FetchBeneficaryBankAccountResponse();
				benificaryRes.setId(bankAcc.getId());
				benificaryRes.setCustomerId(bankAcc.getCustomerId());
				benificaryRes.setVpa(bankAcc.getVpa());
				beneficaryAcclist.add(benificaryRes);
			}
			else if(bankAcc.getAccountNumber() != null && fetchBeneficiary.isAccReq()){
				FetchBeneficaryBankAccountResponse benificaryRes = new FetchBeneficaryBankAccountResponse();
				benificaryRes.setId(bankAcc.getId());
				benificaryRes.setCustomerId(bankAcc.getCustomerId());
				benificaryRes.setAccountNumber(bankAcc.getAccountNumber());
				benificaryRes.setAccountName(bankAcc.getAccountName());
				benificaryRes.setAccountType(bankAcc.getAccountType());
				benificaryRes.setBankName(bankAcc.getBankName());
				benificaryRes.setBranchName(bankAcc.getBranchName());
				benificaryRes.setIfscCode(bankAcc.getIfscCode());
				beneficaryAcclist.add(benificaryRes);
			}
		}	

		return beneficaryAcclist;
	}
}
