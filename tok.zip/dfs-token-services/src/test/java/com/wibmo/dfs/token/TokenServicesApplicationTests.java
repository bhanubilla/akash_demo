package com.wibmo.dfs.token;

import com.wibmo.dfs.token.pojo.TokenResponse;
import com.wibmo.dfs.token.constants.ResponseCode;
import com.wibmo.dfs.token.pojo.TokenRequest;
import com.wibmo.dfs.token.service.TokenService;
import io.jsonwebtoken.lang.Assert;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigInteger;
import java.util.Random;

@SpringBootTest
class TokenServicesApplicationTests {

	@Autowired
	TokenService clientCredentialService;
	@Test
	void contextLoads() {
		TokenRequest tokenRequest = new TokenRequest();
		tokenRequest.setApiKey("MOB-APP");
		tokenRequest.setApiKey("TEST123");
		BigInteger localPrivateKey = BigInteger.valueOf((int)(new Random().nextDouble()*100));
		BigInteger localPublicKey = BigInteger.valueOf(9).modPow(localPrivateKey, BigInteger.valueOf(23));
		tokenRequest.setPublicKey(null);
		TokenResponse response =  clientCredentialService.generateToken(tokenRequest);
		Assert.notNull(response);
		Assert.isTrue(response.getResCode()== ResponseCode.SUCCESS);
	}

}
