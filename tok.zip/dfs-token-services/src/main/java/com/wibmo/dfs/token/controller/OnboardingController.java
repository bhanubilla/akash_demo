package com.wibmo.dfs.token.controller;


import com.wibmo.dfs.token.pojo.ClientCreateRequest;
import com.wibmo.dfs.token.pojo.ClientCreateResponse;
import com.wibmo.dfs.token.service.ClientCredentialsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotNull;

/*
@Author pavan.konakanchi 
Created on : 01/06/2021 - 1:46 PM
*/
@RestController
@RequestMapping("/onboard")
public class OnboardingController {
    @Autowired
    private ClientCredentialsService clientCredentialsService;

    @PostMapping("/new/client")
    public ClientCreateResponse onboardClient(@RequestBody @NotNull ClientCreateRequest request) {
        return clientCredentialsService.createClient(request);
    }
}
