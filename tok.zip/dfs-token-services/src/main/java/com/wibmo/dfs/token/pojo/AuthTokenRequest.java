package com.wibmo.dfs.token.pojo;

import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.HashMap;

@Data
public class AuthTokenRequest implements Serializable {
    @NotNull
    private transient HashMap<String,Object> claims;
    @NotNull
    @NotEmpty
    private String token;
    @Min(1)
    private int expiry;
}
