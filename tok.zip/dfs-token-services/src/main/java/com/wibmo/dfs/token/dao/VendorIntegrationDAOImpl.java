package com.wibmo.dfs.token.dao;

import com.wibmo.dfs.token.constants.Constants;
import com.wibmo.dfs.token.pojo.VendorIntegrationRequest;
import com.wibmo.dfs.token.pojo.VendorIntegrationResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Slf4j
@Repository
public class VendorIntegrationDAOImpl implements VendorIntegrationDAO {

    private static final String INSERT_QUERY = "INSERT INTO  AUDIT_USER_DETAILS(USER_ID,KEY_REF,REMARKS,TYPE) VALUES(?,?,?,?)";
    private static final String UPDATE_QUERY = "UPDATE AUDIT_USER_DETAILS SET REMARKS=?, STATUS_CODE=? WHERE KEY_REF=?";
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public void auditTokenCreate(String token, String remark, String userId) {
        try {
            if (StringUtils.isNotEmpty(token)) {
                jdbcTemplate.update(INSERT_QUERY, userId, token ,remark, Constants.TOKEN_SERVICES);
            }
        } catch (Exception e) {
            log.error(Constants.EXCEPTION_AUDITING_MSG + e);
        }
    }

    @Override
    public void auditTokenFetch(String token, String remark, int statusCode) {
        try {
            if (StringUtils.isNotEmpty(token)) {
                jdbcTemplate.update(UPDATE_QUERY, remark, statusCode, token);
            }
        } catch (Exception e) {
            log.error(Constants.EXCEPTION_AUDITING_MSG + e);
        }
    }
}
