package com.wibmo.dfs.token.pojo;

import lombok.Data;

import java.io.Serializable;

@Data
public class ClientCredentials implements Serializable {
    public static final String CACHE_KEY = "ClientCredentials";
    public static final String API_ACCESS_CACHE_KEY = "ApiAccess";
    private String apikey;
    private String secret;
    private String ipRestrictionEnabled;
    private String allowedIp;
    private String role;
    private int programId;
    private int expiry;
    private long uniqueId;
    private String payloadSecret;
    private boolean tokenAllowed;
    private int status;
}
