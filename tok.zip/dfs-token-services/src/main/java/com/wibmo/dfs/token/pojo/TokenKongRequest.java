package com.wibmo.dfs.token.pojo;

import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Map;

@Data
public class TokenKongRequest implements Serializable {
    @NotNull
    @NotEmpty
    private String apiKey;
    @NotNull
    @NotEmpty
    private String secret;
    @NotNull
    @NotEmpty
    private String publicKey;
    private String firstName;
    //private String sdkApiKey;
    private String lastName;
    @Min(1)
    private long accountNumber;
    private int isdCode;
    private long mobileNumber;
    private int dob;
    private String email;
   // private String sdkPublicKey;
    private String referenceId;
    private Map<String, String> data;
}
