package com.wibmo.dfs.token.dao;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;

@Repository
@Slf4j
public class TokenServiceDAOImpl implements TokenServiceDAO{
    @Autowired
    @Qualifier("multiTenantJdbcTemplate")
    private  JdbcTemplate jdbcTemplate;
    @Override
    public void invalidateToken(String referenceId) {
        String sql = "UPDATE AUTH_TOKENS SET STATUS_CODE=? WHERE ID=?";
        jdbcTemplate.update(sql, 3, referenceId);
    }
    @Override
    public void createToken(String referenceId, long accountNumber) {
        String sql = "INSERT INTO  AUTH_TOKENS(ID, ACCOUNT_NUMBER,STATUS_CODE) VALUES(?,?,?)";
        jdbcTemplate.update(sql, referenceId, accountNumber,1);

    }
    @Override
    public void updateRenewal(String referenceId) {
        String sql = "UPDATE AUTH_TOKENS SET STATUS_CODE=? WHERE ID=? AND STATUS_CODE != ?";
        jdbcTemplate.update(sql, 2, referenceId,3);

    }
    @Override
    public boolean isValid(String loginHistoryID) {
        try {
            return jdbcTemplate.queryForObject("SELECT ID FROM  AUTH_TOKENS WHERE ID=?  AND STATUS_CODE !=3 ",  new RowMapper<Boolean>() {
                @Override
                public Boolean mapRow(ResultSet rs, int rwNumber) throws SQLException {
                  return true;
                }},loginHistoryID);

        } catch (EmptyResultDataAccessException e) {
            log.info("no valid token found found");
            return false;
        }

    }
}
