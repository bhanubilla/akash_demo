package com.wibmo.dfs.token.dao;

import com.wibmo.dfs.cache_client.manager.DfsCacheManager;
import com.wibmo.dfs.token.constants.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

@Slf4j
@Repository
public class ProgramParameterDAOImpl implements ProgramParameterDAO {

    private static final String CACHE_KEY = "PROGRAM-PARAMS";
    private static final String DB_LOG_MSG = "NFC - going to DB programId:{} paramName:{}";

    @Autowired
    private DfsCacheManager cacheManager;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public String fetchProgramParam(String programId, String param) {
        String value = (String) cacheManager.get(CACHE_KEY + Constants.UNDER_SCORE + programId + Constants.UNDER_SCORE + param);
        if (StringUtils.hasLength(value)) {
            return value;
        }
        log.info(DB_LOG_MSG, programId, param);
        return loadFromDB(programId, param);
    }

    private String loadFromDB(String programId, String paramName) {
        String paramValue = "";
        try {
            paramValue = jdbcTemplate.queryForObject("select param_value from program_parameters where param_name=?", String.class, paramName);
        } catch (EmptyResultDataAccessException e) {
            paramValue = null;
        }
        if (StringUtils.hasLength(paramValue)) {
            cacheManager.put(CACHE_KEY + Constants.UNDER_SCORE + programId + Constants.UNDER_SCORE + paramName, paramValue);
        }
        return paramValue;
    }
}
