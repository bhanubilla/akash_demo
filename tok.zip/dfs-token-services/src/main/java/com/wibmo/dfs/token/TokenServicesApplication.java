package com.wibmo.dfs.token;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.info.BuildProperties;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;


@SpringBootApplication
@EnableDiscoveryClient
@ComponentScan("com.wibmo.dfs")
@Slf4j
public class TokenServicesApplication {

    @Autowired
    private BuildProperties buildProperties;

    public static void main(String[] args) {
        SpringApplication.run(TokenServicesApplication.class, args);
    }

    @EventListener
    public void handleContextRefresh(ContextRefreshedEvent event) {

        log.info("Build Version : {}", buildProperties.getVersion());
        log.info("Build Release Time: {}", buildProperties.get("buildReleaseTime"));
    }

}
