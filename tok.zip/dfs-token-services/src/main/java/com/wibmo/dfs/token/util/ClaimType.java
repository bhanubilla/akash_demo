package com.wibmo.dfs.token.util;

public enum ClaimType{
    SUBJECT("SUBJECT"),
    EXPIRY("EXPIRY"),
    ALLOWED_IP("ALLOWED_IP"),
    MERCHANT_ID("MERCHANT"),
    CUSTOMER_EMAIL("CUSTOMER_EMAIL"),
    CUSTOMER_MOBILE("CUSTOMER_MOBILE"),
    WIBMO_AC_NUMBER("WIBMO_AC_NUMBER");

    private final String label;

    private ClaimType(String label) {
        this.label = label;
    }

    @Override
    public String toString() {
        return this.label;
    }
}
