package com.wibmo.dfs.token.pojo;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class VendorIntegrationResponse extends WibmoResponse{
    private transient Object data;

    public VendorIntegrationResponse(int code, String desc){
        this.setResCode(code);
        this.setResDesc(desc);
    }
}
