package com.wibmo.dfs.token.dao;

import com.wibmo.dfs.token.pojo.MerchantClientConfig;

public interface MerchantClientConfigDAO {
    MerchantClientConfig findByApiKeyBySdk(String apikey);

    void save(int programId, String apiKey, String referenceId, String localDerivedKey, long expiry);

    MerchantClientConfig findByApiKeyByApp(String apiKey);
}
