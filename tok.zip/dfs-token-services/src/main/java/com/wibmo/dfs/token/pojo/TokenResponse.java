package com.wibmo.dfs.token.pojo;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TokenResponse extends WibmoResponse {

    private String token;
    private long expiry;
    private String serverPublicKey;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String referenceId;

    public TokenResponse(String token) {
    }

    public TokenResponse(int resCode, String resDesc) {
        this.setResCode(resCode);
        this.setResDesc(resDesc);
    }


}
