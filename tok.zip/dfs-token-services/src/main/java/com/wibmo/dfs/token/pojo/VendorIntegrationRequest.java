package com.wibmo.dfs.token.pojo;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import java.util.Map;

@Data
@NoArgsConstructor
public class VendorIntegrationRequest {
    @NotEmpty(message = "userName is Required")
    private String userName;
    @NotEmpty(message = "UserId is Required")
    private String userId;
    private String mobileNo;
    private String emailId;
    private Map<String, Object> reserveFields;
}
