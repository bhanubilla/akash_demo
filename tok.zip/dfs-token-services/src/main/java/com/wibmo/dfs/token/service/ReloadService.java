package com.wibmo.dfs.token.service;

/*
@Author pavan.konakanchi 
Created on : 14/05/2021 - 4:17 PM
*/
public interface ReloadService {
    boolean reloadAllApiAccess();

    boolean reloadAllClientKeys();
}
