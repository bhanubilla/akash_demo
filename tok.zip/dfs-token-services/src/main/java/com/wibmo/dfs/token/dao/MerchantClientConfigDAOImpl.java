package com.wibmo.dfs.token.dao;

import com.wibmo.dfs.token.pojo.MerchantClientConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;

@Repository
@Slf4j
public class MerchantClientConfigDAOImpl implements MerchantClientConfigDAO {

    @Autowired
    @Qualifier("globalJdbcTemplate")
    JdbcTemplate jdbcTemplate;

    public static final String SELECT_FROM_MERCHANT_CONFIG_WHERE_API_KEY = "SELECT * FROM  merchant_config WHERE API_KEY=?";
    public static final String EXCEPTION_IN_MERCHANT_CLIENT_CONFIG_FIND_BY_API_KEY_BY_SDK = "Exception in MerchantClientConfigDAOImpl : findByApiKeyBySdk : {}";
    public static final String INSERT_QUERY = "INSERT INTO  merchant_keyexchange(PROGRAM_ID, API_KEY,REFERENCE_ID, CRYPTO_KEY1, CRYPTO_KEY2, EXPIRY) VALUES(?,?,?,?,?,?)";
    public static final String EXCEPTION_IN_MERCHANT_CLIENT_CONFIG_SAVE = "Exception in MerchantClientConfigDAOImpl : save : {} ";
    public static final String EXCEPTION_IN_MERCHANT_CLIENT_CONFIG_FIND_BY_API_KEY = "Exception in MerchantClientConfigDAOImpl : findByApiKeyByApp : {} ";

    @Override
    public MerchantClientConfig findByApiKeyBySdk(final String apikey) {
        log.debug("MerchantClientConfigDAOImpl : findByApiKeyBySdk : apikey : {}", apikey);
        try {
            return jdbcTemplate.queryForObject(SELECT_FROM_MERCHANT_CONFIG_WHERE_API_KEY, new RowMapper<MerchantClientConfig>() {
                @Override
                public MerchantClientConfig mapRow(ResultSet rs, int rwNumber) throws SQLException {
                    MerchantClientConfig merchantClientConfig = new MerchantClientConfig();
                    merchantClientConfig.setProgramId(rs.getInt("PROGRAM_ID"));
                    merchantClientConfig.setApikey(rs.getString("API_KEY"));
                    merchantClientConfig.setAccessType(rs.getString("ACCESS_TYPE"));
                    merchantClientConfig.setDefaultCryptoKey(rs.getString("DEFAULT_CRYPTO_KEY"));
                    merchantClientConfig.setAllowedIp(rs.getString("ALLOWED_IP"));
                    merchantClientConfig.setTokenAllowed(rs.getInt("TOKEN_ALLOWED"));
                    merchantClientConfig.setExpiry(rs.getInt("EXPIRY"));
                    merchantClientConfig.setIss(rs.getString("ISS"));
                    merchantClientConfig.setRole(rs.getString("ROLE"));
                    return merchantClientConfig;
                }
            }, apikey);
        } catch (EmptyResultDataAccessException exception) {
            log.error(EXCEPTION_IN_MERCHANT_CLIENT_CONFIG_FIND_BY_API_KEY_BY_SDK, exception);
            return null;
        }

    }

    @Override
    public void save(int programId, String apiKey, String referenceId, String localDerivedKey, long expiry) {
        log.debug("MerchantClientConfigDAOImpl : save : apikey : {} program id : {}", apiKey, programId);
        try{
            jdbcTemplate.update(INSERT_QUERY, programId, apiKey, referenceId, localDerivedKey, null, expiry);
        } catch(Exception e){
            log.error(EXCEPTION_IN_MERCHANT_CLIENT_CONFIG_SAVE, e);
        }

    }

    @Override
    public MerchantClientConfig findByApiKeyByApp(final String apikey) {
        log.debug("MerchantClientConfigDAOImpl : findByApiKeyByApp : apikey :{} ", apikey);
        try {
            return jdbcTemplate.queryForObject(SELECT_FROM_MERCHANT_CONFIG_WHERE_API_KEY, new RowMapper<MerchantClientConfig>() {
                @Override
                public MerchantClientConfig mapRow(ResultSet rs, int rwNumber) throws SQLException {
                    MerchantClientConfig merchantClientConfig = new MerchantClientConfig();
                    merchantClientConfig.setProgramId(rs.getInt("PROGRAM_ID"));
                    merchantClientConfig.setApikey(rs.getString("API_KEY"));
                    merchantClientConfig.setAccessType(rs.getString("ACCESS_TYPE"));
                    merchantClientConfig.setDefaultCryptoKey(rs.getString("DEFAULT_CRYPTO_KEY"));
                    merchantClientConfig.setAllowedIp(rs.getString("ALLOWED_IP"));
                    merchantClientConfig.setTokenAllowed(rs.getInt("TOKEN_ALLOWED"));
                    merchantClientConfig.setExpiry(rs.getInt("EXPIRY"));
                    merchantClientConfig.setIss(rs.getString("ISS"));
                    merchantClientConfig.setRole(rs.getString("ROLE"));
                    return merchantClientConfig;
                }
            }, apikey);
        } catch (EmptyResultDataAccessException exception) {
            log.error(EXCEPTION_IN_MERCHANT_CLIENT_CONFIG_FIND_BY_API_KEY, exception);
            return null;
        }

    }
}
