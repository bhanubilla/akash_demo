package com.wibmo.dfs.token.dao;

import com.wibmo.dfs.cache_client.manager.DfsCacheManager;
import com.wibmo.dfs.token.pojo.ClientCredentials;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
@Slf4j
public class ClientCredentialsDAOImpl implements ClientCredentialsDAO {

    private static final String UNDER_SCORE = "_";
    @Autowired
    @Qualifier("globalJdbcTemplate")
    JdbcTemplate jdbcTemplate;
    @Autowired
    DfsCacheManager cacheManager;


    @Override
    public ClientCredentials findByApiKey(final String apikey) {
        try {
            ClientCredentials clientCredentials = (ClientCredentials) cacheManager.get(ClientCredentials.CACHE_KEY + UNDER_SCORE + apikey);
            if (clientCredentials != null) {
                return clientCredentials;
            }
        } catch (Exception e) {
            log.warn("Serialization mismatch it will go to db and reload new value:{}",e);
        }

        String sql = "SELECT * FROM  CLIENT_KEYS WHERE API_KEY=?";

                try {
                  return   jdbcTemplate.queryForObject(sql, new RowMapper<ClientCredentials>() {
                        @Override
                        public ClientCredentials mapRow(ResultSet rs, int rwNumber) throws SQLException {
                            ClientCredentials clientCredentials = new ClientCredentials();
                            clientCredentials.setProgramId(rs.getInt("PROGRAM_ID"));
                            clientCredentials.setApikey(rs.getString("API_KEY"));
                            clientCredentials.setAllowedIp(rs.getString("ALLOWED_IP"));
                            clientCredentials.setRole(rs.getString("ROLE"));
                            clientCredentials.setExpiry(rs.getInt("EXPIRY"));
                            clientCredentials.setSecret(rs.getString("SECRET"));
                            clientCredentials.setUniqueId(rs.getInt("UNIQUE_ID"));
                            clientCredentials.setTokenAllowed(rs.getBoolean("TOKEN_ALLOWED"));
                            clientCredentials.setPayloadSecret(rs.getString("PAYLOAD_SECRET"));
                            cacheManager.put(ClientCredentials.CACHE_KEY + UNDER_SCORE + apikey, clientCredentials);
                            return clientCredentials;
                        }
                    }, apikey);
                }catch (EmptyResultDataAccessException exception){
                    return null;
                }

    }

    @Override
    public boolean reloadAllClientCredentials() {
        List<String> list = jdbcTemplate.query("SELECT API_KEY FROM  CLIENT_KEYS", (rs, rowNum) ->
                rs.getString("API_KEY")
        );
        list.forEach(paramId -> {
            log.info("removing from cache: apikey:{}", paramId);
            cacheManager.remove(ClientCredentials.CACHE_KEY + UNDER_SCORE + paramId);
        });
        return true;
    }

    @Override
    public boolean reloadAllApiAccessList() {

        try {
            log.debug("going to DB");
            jdbcTemplate.query("SELECT PROGRAM_ID,URI FROM  API_ACCESS ", (rs, rowNum) -> {

                String programId = rs.getString("PROGRAM_ID");
                String uri = rs.getString("URI");
                log.info("removing from  the cache  programId:{} URI:{} ", programId, programId);
                cacheManager.remove(ClientCredentials.API_ACCESS_CACHE_KEY + UNDER_SCORE + programId + UNDER_SCORE + uri);
                return uri;
            });
            return true;
        } catch (EmptyResultDataAccessException e) {
            log.info("no data found");
            return false;
        }

    }

    @Override
    public boolean createClient(ClientCredentials clientCredentials) {
        String sql = "INSERT INTO  CLIENT_KEYS(PROGRAM_ID, API_KEY, SECRET, ALLOWED_IP, EXPIRY, ROLE, status, unique_id, TOKEN_ALLOWED, PAYLOAD_SECRET)" +
                " VALUES(?,?,?,?,?,?,?,?,?,?)";
        int count = jdbcTemplate.update(sql, clientCredentials.getProgramId(), clientCredentials.getApikey(), clientCredentials.getSecret()
                , clientCredentials.getAllowedIp(), clientCredentials.getExpiry(), clientCredentials.getRole(), clientCredentials.getStatus(), clientCredentials.getUniqueId(), clientCredentials.isTokenAllowed(), clientCredentials.getPayloadSecret());
        return count > 0;
    }
}
