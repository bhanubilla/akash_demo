package com.wibmo.dfs.token.pojo;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
public class TokenRequest implements Serializable {
    @NotNull
    @NotEmpty
    private String apiKey;
    @NotNull
    @NotEmpty
    private String publicKey;
}
