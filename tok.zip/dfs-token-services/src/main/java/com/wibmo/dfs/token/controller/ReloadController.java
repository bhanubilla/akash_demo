package com.wibmo.dfs.token.controller;


import com.wibmo.dfs.token.service.ReloadService;
import com.wibmo.dfs.token.constants.ResponseCode;
import com.wibmo.dfs.token.constants.ResponseDesc;
import com.wibmo.dfs.token.pojo.WibmoResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/*
@Author pavan.konakanchi 
Created on : 14/05/2021 - 4:13 PM
*/
@RestController
@RequestMapping(value = "/reload")
@Slf4j
public class ReloadController {

    @Autowired
    private ReloadService reloadService;

    @GetMapping(value = "/api-access/all")
    public WibmoResponse reloadAllApiAccess() {
        log.info("reload api access");
        if (reloadService.reloadAllApiAccess()) {
            return new WibmoResponse(ResponseCode.SUCCESS, ResponseDesc.SUCCESS);
        }
        return new WibmoResponse(ResponseCode.FAILED, ResponseDesc.FAILED);


    }

    @GetMapping(value = "/client-keys/all")
    public WibmoResponse reloadAllClientKeys() {
        log.info("reload api access");
        if (reloadService.reloadAllClientKeys()) {
            return new WibmoResponse(ResponseCode.SUCCESS, ResponseDesc.SUCCESS);
        }
        return new WibmoResponse(ResponseCode.FAILED, ResponseDesc.FAILED);
    }
}
