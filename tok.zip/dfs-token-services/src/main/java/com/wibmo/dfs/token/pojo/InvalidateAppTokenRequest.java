package com.wibmo.dfs.token.pojo;

import lombok.Data;

@Data
public class InvalidateAppTokenRequest {
    private String tokenReferenceId;
}
