package com.wibmo.dfs.token.pojo;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;

/*
@Author pavan.konakanchi 
Created on : 20/04/2021 - 2:08 PM
*/
@Data
@NoArgsConstructor
public class ClaimsResponse extends WibmoResponse {
    private transient HashMap<String, Object> claims;

    public ClaimsResponse(int resCode, String resDesc) {
        this.setResCode(resCode);
        this.setResDesc(resDesc);
    }
}
