package com.wibmo.dfs.token.dao;

public interface VendorIntegrationDAO {
    void auditTokenCreate(String token, String response, String userId);

    void auditTokenFetch(String token, String resDesc, int resCode);
}
