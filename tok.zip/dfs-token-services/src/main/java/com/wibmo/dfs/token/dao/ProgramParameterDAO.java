package com.wibmo.dfs.token.dao;

public interface ProgramParameterDAO {
    String fetchProgramParam(String programId, String param);
}
