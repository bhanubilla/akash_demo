package com.wibmo.dfs.token.controller;

import com.wibmo.dfs.token.pojo.VendorIntegrationRequest;
import com.wibmo.dfs.token.pojo.VendorIntegrationResponse;
import com.wibmo.dfs.token.service.VendorIntegrationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@Slf4j
@RestController
@RequestMapping("/vendor")
public class VendorIntegrationController {

    @Autowired
    private VendorIntegrationService vendorIntegrationService;

    @PostMapping("/v1/saveUserProfile/")
    public VendorIntegrationResponse saveUserProfile(@RequestHeader(name = "X-PROGRAM-ID") int programId, @Valid @RequestBody VendorIntegrationRequest request, Errors errors) {
        return vendorIntegrationService.saveUserProfile(programId, request, errors);
    }

    @GetMapping("/v1/userProfile/")
    public VendorIntegrationResponse fetchUserProfile(@RequestHeader(name = "X-PROGRAM-ID") int programId, @RequestHeader(name = "KEY-REF") String keyRef) {
        log.info("user profile request for program id : {}", programId);
        return vendorIntegrationService.fetchUserProfile(keyRef);
    }
}
