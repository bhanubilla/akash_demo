package com.wibmo.dfs.token.dao;

import com.wibmo.dfs.token.pojo.ClientCredentials;

public interface ClientCredentialsDAO {
    ClientCredentials findByApiKey(String apikey);
    boolean reloadAllClientCredentials();
    boolean reloadAllApiAccessList();

    boolean createClient(ClientCredentials clientCredentials);
}
