package com.wibmo.dfs.token.controller;

import com.wibmo.dfs.token.service.EncryptionDecryptionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/token/filter")
@Slf4j
public class EncryptDecryptController {

    @Autowired
    private EncryptionDecryptionService encryptionDecryptionService;

    @PostMapping("/v1/encrypt")
    public String encryptedData(@RequestBody @NotNull @NotEmpty @Valid String incReq, BindingResult errors, HttpServletRequest request) throws IOException {
        log.debug("Coming to encrypt the response {}",incReq);
        if (errors.hasErrors()) {
            StringBuilder errorMessage = new StringBuilder();
            for (FieldError error : errors.getFieldErrors()) {
                errorMessage.append(error.getDefaultMessage());
            }
            log.debug("error message {}", errorMessage);
        }
        String encryptedResponse = "";
        Map<String, String> map = new HashMap<String, String>();
        Enumeration headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String key = (String) headerNames.nextElement();
            String value = request.getHeader(key);
            map.put(key, value);
        }
        String apiKey = map.get("x-api-key");
        String apiToken = map.get("x-api-token");
        encryptedResponse = encryptionDecryptionService.getEncryptedData(incReq, apiKey, apiToken);
        return encryptedResponse;
    }

    @PostMapping("/v1/decrypt")
    public ResponseEntity<String> decryptedData(@RequestBody String bodyCipher, BindingResult errors, HttpServletRequest request) throws IOException {
        log.debug("Coming to decrypt the request {}",bodyCipher);
        if (errors.hasErrors()) {
            StringBuilder errorMessage = new StringBuilder();
            for (FieldError error : errors.getFieldErrors()) {
                errorMessage.append(error.getDefaultMessage());
            }
            log.info("error message {}", errorMessage);
        }
        Map<String, String> map = new HashMap<String, String>();
        Enumeration headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String key = (String) headerNames.nextElement();
            String value = request.getHeader(key);
            map.put(key, value);
        }
        String apiKey = map.get("x-api-key");
        String apiToken = map.get("x-api-token");
        return encryptionDecryptionService.getDecryptedData(bodyCipher, apiKey, apiToken);
    }
}
