package com.wibmo.dfs.token.pojo;

import lombok.Data;

import java.io.Serializable;

@Data
public class MerchantKeyExchange implements Serializable {
    private String apikey;
    private int programId;
    private String referenceId;
    private String cryptoKey1;
    private String cryptoKey2;
    private int expiry;
}
