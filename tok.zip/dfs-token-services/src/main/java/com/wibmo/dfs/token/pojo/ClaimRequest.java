package com.wibmo.dfs.token.pojo;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

/*
@Author pavan.konakanchi 
Created on : 20/04/2021 - 2:02 PM
*/
@Data
public class ClaimRequest implements Serializable {
    @NotNull
    private List<String> claims;
    @NotNull
    @NotEmpty
    private String token;
}
