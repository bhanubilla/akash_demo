package com.wibmo.dfs.token.pojo;

import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/*
@Author pavan.konakanchi 
Created on : 01/06/2021 - 1:48 PM
*/
@Data
public class ClientCreateRequest {
    @Min(0)
    private int programId;
    @NotNull
    @NotEmpty
    private String role;
    private boolean tokenAllowed;
    private long uniqueId;
    private int tokenExpiryinMinutes;
    @NotNull
    @NotEmpty
    private String allowedIPs;
}
