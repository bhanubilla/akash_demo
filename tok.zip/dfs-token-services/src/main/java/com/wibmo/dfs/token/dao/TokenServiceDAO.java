package com.wibmo.dfs.token.dao;


public interface TokenServiceDAO {
    void invalidateToken( String referenceId);
    void createToken(String referenceId, long accountNumber);
    boolean isValid(String loginHistoryID);
    void updateRenewal(String referenceId);
}
