package com.wibmo.dfs.token.dao;

import com.wibmo.dfs.token.pojo.MerchantKeyExchange;

public interface MerchantKeyExchangeDAO {
    MerchantKeyExchange findByRefId(String referenceId, String apiKey);
}
