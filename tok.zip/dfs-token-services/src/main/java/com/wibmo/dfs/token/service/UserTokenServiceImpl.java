package com.wibmo.dfs.token.service;

import com.wibmo.dfs.jwt.JWTConstants;
import com.wibmo.dfs.jwt.JwsTokenUtil;
import com.wibmo.dfs.token.pojo.AuthTokenRequest;
import com.wibmo.dfs.token.pojo.LogoutRequest;
import com.wibmo.dfs.token.pojo.RefreshTokenRequest;
import com.wibmo.dfs.token.pojo.TokenResponse;
import com.wibmo.dfs.token.constants.ResponseCode;
import com.wibmo.dfs.token.constants.ResponseDesc;
import com.wibmo.dfs.jwt.RoleType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class UserTokenServiceImpl implements UserTokenService{
    @Autowired
    private JwsTokenUtil jwsTokenUtil;
    @Override
    public TokenResponse refresh(RefreshTokenRequest tokenRequest) {

        TokenResponse tokenResponse = new TokenResponse(ResponseCode.SUCCESS, ResponseDesc.SUCCESS);
        tokenResponse.setExpiry(System.currentTimeMillis()+(tokenRequest.getExpiry()*60*1000));
        String token = jwsTokenUtil.refreshToken(tokenRequest.getToken(),tokenRequest.getExpiry());

        tokenResponse.setToken(token);
        return tokenResponse;
    }

    @Override
    public TokenResponse generateUserAuthToken(AuthTokenRequest tokenRequest) {
        try {
            Map<String, Object> claims = jwsTokenUtil.validateAndGetClaims(tokenRequest.getToken(), RoleType.NEW_USER.toString());
           log.info("inside generateUserAuthToken claims {}", claims);
            // converting immutable to mutable
            claims = new HashMap<>(claims);
            claims.putAll(tokenRequest.getClaims());
            TokenResponse tokenResponse = new TokenResponse(ResponseCode.SUCCESS, ResponseDesc.SUCCESS);
            tokenResponse.setExpiry(System.currentTimeMillis() + (tokenRequest.getExpiry() * 60 * 1000));
            log.info("claims in auth token :{}, token claims :{}", claims, tokenRequest.getClaims());
            String token = jwsTokenUtil.generateUserAuthToken(claims, RoleType.LOGIN_USER.toString(), tokenRequest.getExpiry());
            tokenResponse.setToken(token);
            return tokenResponse;
        }
        catch (Exception e){
            log.error(e.getMessage());
        }
        return null;
    }

    @Override
    public String logoutUser(LogoutRequest tokenRequest) {
        Map<String, Object> claims =   jwsTokenUtil.validateAndGetClaims(tokenRequest.getToken(), RoleType.LOGIN_USER.toString());
       if(claims!=null){
           return (String) claims.get(JWTConstants.LOGIN_HISTORY_ID);
       }
       return null;
    }
    @Override
    public TokenResponse updateClaimsInAuthToken(AuthTokenRequest tokenRequest) {
        Map<String, Object> claims =  jwsTokenUtil.validateAndGetClaims(tokenRequest.getToken(), RoleType.LOGIN_USER.toString());
        // converting immutable to mutable
        claims = new HashMap<>(claims);
        claims.putAll(tokenRequest.getClaims());
        TokenResponse tokenResponse = new TokenResponse(ResponseCode.SUCCESS, ResponseDesc.SUCCESS);
        tokenResponse.setExpiry(System.currentTimeMillis()+(tokenRequest.getExpiry()*60*1000));
        String token = jwsTokenUtil.generateUserAuthToken(claims, RoleType.LOGIN_USER.toString(), tokenRequest.getExpiry());
        tokenResponse.setToken(token);
        return tokenResponse;
    }
}
