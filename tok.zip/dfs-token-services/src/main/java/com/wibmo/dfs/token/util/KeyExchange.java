package com.wibmo.dfs.token.util;


import com.wibmo.dfs.key_exchange.KeyExchangeException;
import com.wibmo.dfs.key_exchange.KeyExchangeHelper;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.security.KeyPair;
import java.security.interfaces.ECPrivateKey;
import java.security.interfaces.ECPublicKey;

@Data
@NoArgsConstructor
public class KeyExchange {
    private String localPublicKey;
    private String localDerivedKey;

    public KeyExchange(String publicKey, String apiKey) {
        try {
            KeyPair keyPair = KeyExchangeHelper.gettInstance().generateECKeyPair();
            localDerivedKey = KeyExchangeHelper.gettInstance().generateSymetricKey(publicKey, (ECPrivateKey) keyPair.getPrivate(), apiKey);
            localPublicKey = KeyExchangeHelper.gettInstance().convertPublicKeyToString((ECPublicKey) keyPair.getPublic());
        } catch (KeyExchangeException e) {
            e.printStackTrace();
        }


    }


}
