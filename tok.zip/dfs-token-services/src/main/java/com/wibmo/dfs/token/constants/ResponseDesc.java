package com.wibmo.dfs.token.constants;

public interface ResponseDesc {
    String SUCCESS = "Success";
    String INVALID_TOKEN = "Invalid Token";
    String INVALID_API_KEY = "Invalid ApiKey passed";
    String INVALID_CLIENT_SECRET = "Secret key is invalid";
    String CREDENTIALS_DEACTIVATED = "Your credentials are not active";
    String FAILED = "FAILED";
    String CREDENTIALS_NOT_ALLOWED = "Your credentials not allowed to generate token";
}
