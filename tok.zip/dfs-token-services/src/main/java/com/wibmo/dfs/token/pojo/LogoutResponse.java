package com.wibmo.dfs.token.pojo;

import lombok.Data;

import java.io.Serializable;

/*
@Author pavan.konakanchi 
Created on : 20/04/2021 - 5:00 PM
*/
@Data
public class LogoutResponse extends WibmoResponse implements Serializable {
    private String loginHistoryId;

    public LogoutResponse(int success, String success1) {
        this.setResCode(success);
        this.setResDesc(success1);
    }
}
