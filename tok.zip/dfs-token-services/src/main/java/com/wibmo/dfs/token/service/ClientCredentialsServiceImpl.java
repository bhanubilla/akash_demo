package com.wibmo.dfs.token.service;

import com.wibmo.dfs.token.constants.ResponseCode;
import com.wibmo.dfs.token.constants.ResponseDesc;
import com.wibmo.dfs.token.dao.ClientCredentialsDAO;
import com.wibmo.dfs.token.pojo.ClientCreateRequest;
import com.wibmo.dfs.token.pojo.ClientCreateResponse;
import com.wibmo.dfs.token.pojo.ClientCredentials;
import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.UUID;

/*
@Author pavan.konakanchi 
Created on : 01/06/2021 - 1:58 PM
*/
@Service
@Slf4j
public class ClientCredentialsServiceImpl implements ClientCredentialsService {
    @Autowired
    private ClientCredentialsDAO clientCredentialsDAO;

    @Override
    public ClientCreateResponse createClient(ClientCreateRequest request) {
        ClientCredentials clientCredentials = new ClientCredentials();
        clientCredentials.setAllowedIp(request.getAllowedIPs());
        clientCredentials.setApikey(UUID.randomUUID().toString());
        clientCredentials.setSecret(UUID.randomUUID().toString());
        clientCredentials.setPayloadSecret(generatePayloadSecret());
        clientCredentials.setProgramId(request.getProgramId());
        clientCredentials.setUniqueId(request.getUniqueId());
        clientCredentials.setExpiry(request.getTokenExpiryinMinutes());
        clientCredentials.setTokenAllowed(request.isTokenAllowed());
        clientCredentials.setRole(request.getRole());
        clientCredentials.setStatus(1);
        ClientCreateResponse response = new ClientCreateResponse();
        if (clientCredentialsDAO.createClient(clientCredentials)) {
            response.setResCode(ResponseCode.SUCCESS);
            response.setResDesc(ResponseDesc.SUCCESS);
            response.setApiKey(clientCredentials.getApikey());
            response.setApiSecret(clientCredentials.getSecret());
            response.setPayloadSecret(clientCredentials.getPayloadSecret());
            response.setStatus(clientCredentials.getStatus());
        } else {
            response.setResCode(ResponseCode.FAILED);
            response.setResDesc(ResponseDesc.FAILED);
        }
        return response;

    }

    private String generatePayloadSecret() {
        SecureRandom rand = new SecureRandom();
        KeyGenerator generator = null;
        try {
            generator = KeyGenerator.getInstance("AES");
            generator.init(256, rand);
            SecretKey key = generator.generateKey();
            return Base64.encodeBase64String(key.getEncoded());
        } catch (NoSuchAlgorithmException e) {
            log.warn(e.getMessage(), e);
        }
        return null;

    }
}
