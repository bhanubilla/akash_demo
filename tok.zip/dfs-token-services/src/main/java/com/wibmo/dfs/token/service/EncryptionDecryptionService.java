package com.wibmo.dfs.token.service;

import org.springframework.http.ResponseEntity;

import java.io.IOException;

public interface EncryptionDecryptionService {
    String getEncryptedData(String incReq, String apiKey, String apiToken) throws IOException;

    ResponseEntity<String> getDecryptedData(String bodyCipher, String apiKey, String apiToken) throws IOException;
}
