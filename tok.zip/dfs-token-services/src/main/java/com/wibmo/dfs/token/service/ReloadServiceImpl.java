package com.wibmo.dfs.token.service;

import com.wibmo.dfs.token.dao.ClientCredentialsDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/*
@Author pavan.konakanchi 
Created on : 14/05/2021 - 4:22 PM
*/
@Service
public class ReloadServiceImpl implements ReloadService{
    @Autowired
    private ClientCredentialsDAO clientCredentialsDAO;
    @Override
    public boolean reloadAllApiAccess() {
       return clientCredentialsDAO.reloadAllApiAccessList();
    }

    @Override
    public boolean reloadAllClientKeys() {
        return clientCredentialsDAO.reloadAllClientCredentials();
    }
}
