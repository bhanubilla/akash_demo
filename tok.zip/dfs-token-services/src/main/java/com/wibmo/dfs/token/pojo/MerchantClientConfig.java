package com.wibmo.dfs.token.pojo;

import lombok.Data;

import java.io.Serializable;

@Data
public class MerchantClientConfig implements Serializable {
    private String apikey;
    private int programId;
    private String accessType;
    private String defaultCryptoKey;
    private String allowedIp;
    private int tokenAllowed;
    private int expiry;
    private String iss;
    private String role;
}
