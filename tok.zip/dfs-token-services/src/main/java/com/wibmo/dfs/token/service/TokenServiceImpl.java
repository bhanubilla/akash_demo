package com.wibmo.dfs.token.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.jwt.JWTConstants;
import com.wibmo.dfs.jwt.JwsTokenUtil;
import com.wibmo.dfs.jwt.RoleType;
import com.wibmo.dfs.token.constants.Constants;
import com.wibmo.dfs.token.constants.ResponseCode;
import com.wibmo.dfs.token.constants.ResponseDesc;
import com.wibmo.dfs.token.dao.ClientCredentialsDAO;
import com.wibmo.dfs.token.dao.MerchantClientConfigDAO;
import com.wibmo.dfs.token.dao.TokenServiceDAO;
import com.wibmo.dfs.token.pojo.*;
import com.wibmo.dfs.token.util.KeyExchange;
import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
@Slf4j
public class TokenServiceImpl implements TokenService {

    @Autowired
    private ClientCredentialsDAO clientCredentialsDAO;
    @Autowired
    private JwsTokenUtil jwsTokenUtil;

    @Autowired
    private TokenServiceDAO tokenServiceDAO;

    @Autowired
    private MerchantClientConfigDAO merchantClientConfigDAO;

    private ObjectMapper mapper = new ObjectMapper();




    @Override
    public TokenResponse generateToken(TokenRequest tokenRequest) {
        MerchantClientConfig clientCredentials = merchantClientConfigDAO.findByApiKeyByApp(tokenRequest.getApiKey());
        if (clientCredentials == null) {
            log.warn("credential not found with apiKey:{}",tokenRequest.getApiKey());
            return new TokenResponse(ResponseCode.INVALID_API_KEY, ResponseDesc.INVALID_API_KEY);
        }
        if(clientCredentials.getTokenAllowed() ==0 ){
            log.info("credentials not allowed to generate token apiKey:{}",tokenRequest.getApiKey());
            return new TokenResponse(ResponseCode.CREDENTIALS_NOT_ALLOWED, ResponseDesc.CREDENTIALS_NOT_ALLOWED);
        }
        Map<String, Object> claims = new HashMap<>();
        KeyExchange diffieHellman = new KeyExchange(tokenRequest.getPublicKey(), tokenRequest.getApiKey());
        long expireAt = System.currentTimeMillis() + clientCredentials.getExpiry() * 60 * 1000;
        claims.put(JWTConstants.PROGRAM_ID, clientCredentials.getProgramId());
        claims.put(JWTConstants.TOKEN_EXPIRY, clientCredentials.getExpiry());
        claims.put(JWTConstants.ALLOWED_IPS, clientCredentials.getAllowedIp());
        String referenceId =  UUID.randomUUID().toString();
        claims.put("REFERENCE_ID", referenceId);
        claims.put("iss", clientCredentials.getIss());
        String token = jwsTokenUtil.generateToken(clientCredentials.getRole(), clientCredentials.getExpiry(), claims);
        log.info("token generated : {}",token);
        if (StringUtils.isNotEmpty(token)) {
            TokenResponse tokenResponse = new TokenResponse(ResponseCode.SUCCESS, ResponseDesc.SUCCESS);
            tokenResponse.setServerPublicKey(diffieHellman.getLocalPublicKey());
            tokenResponse.setToken(token);
            tokenResponse.setExpiry(expireAt);
            savingMerchantKeyExchange(clientCredentials.getProgramId(), tokenRequest.getApiKey(), referenceId, diffieHellman.getLocalDerivedKey(), clientCredentials.getExpiry() );
            return tokenResponse;
        }
        return new TokenResponse(ResponseCode.FAILED, ResponseDesc.FAILED);
    }

    @Override
    public ClaimsResponse listClaims(ClaimRequest claimRequest) {
        Claims claims = jwsTokenUtil.validateAndGetClaims(claimRequest.getToken());
        ClaimsResponse response = null;
        if (claims != null) {
            response = new ClaimsResponse(ResponseCode.SUCCESS, ResponseDesc.SUCCESS);
            HashMap<String, Object> claims1 = new HashMap<>();
            for (String claim : claimRequest.getClaims()) {
                claims1.put(claim, claims.get(claim));
            }
            response.setClaims(claims1);
        } else {
            response = new ClaimsResponse(ResponseCode.INVALID_TOKEN, ResponseDesc.INVALID_TOKEN);
        }
        return response;
    }

    @Override
    public TokenResponse generateTokenForClientApp(int programId, ClientAppTokenRequest tokenRequest)  {
        MerchantClientConfig clientCredentials = merchantClientConfigDAO.findByApiKeyBySdk(tokenRequest.getSdkApiKey());
        if (clientCredentials == null) {
            log.warn("credential not found with apiKey:{}",tokenRequest.getSdkApiKey());
            return new TokenResponse(ResponseCode.INVALID_API_KEY, ResponseDesc.INVALID_API_KEY);
        }
        Map<String, Object> claims = new HashMap<>();
        KeyExchange diffieHellman = new KeyExchange(tokenRequest.getSdkPublicKey(), tokenRequest.getSdkApiKey());
        long expireAt = System.currentTimeMillis() + clientCredentials.getExpiry() * 60 * 1000;
        claims.put(JWTConstants.TOKEN_EXPIRY, clientCredentials.getExpiry());
        String referenceId = String.valueOf(new Date().getTime());
        claims.put(JWTConstants.LOGIN_HISTORY_ID, referenceId);
        claims.put("REFERENCE_ID", referenceId);
        claims.put(JWTConstants.USER_ID, tokenRequest.getAccountNumber());
        claims.put(JWTConstants.PROGRAM_ID, clientCredentials.getProgramId());
        claims.put(JWTConstants.ALLOWED_IPS, clientCredentials.getAllowedIp());
        claims.put(Constants.X_ACCOUNT_NUMBER, tokenRequest.getAccountNumber());
        claims.put("iss", clientCredentials.getIss());
        try {
            claims.put(JWTConstants.CLIENT_INFO, mapper.writeValueAsString(tokenRequest));
        } catch (JsonProcessingException e) {
            log.error("Error:{}",e.getMessage());
        }
        log.info("Claims {} ", claims);
        String token = jwsTokenUtil.generateToken(RoleType.CLIENT_APP.toString(), clientCredentials.getExpiry(), claims);
        log.info("client token :{}",token);
        if (StringUtils.isNotEmpty(token)) {
            tokenServiceDAO.createToken(referenceId,tokenRequest.getAccountNumber());
            TokenResponse tokenResponse = new TokenResponse(ResponseCode.SUCCESS, ResponseDesc.SUCCESS);
            tokenResponse.setServerPublicKey(diffieHellman.getLocalPublicKey());
            tokenResponse.setToken(token);
            tokenResponse.setExpiry(expireAt);
            tokenResponse.setReferenceId(referenceId);
            savingMerchantKeyExchange(programId, tokenRequest.getSdkApiKey(), referenceId, diffieHellman.getLocalDerivedKey(),clientCredentials.getExpiry());
            return tokenResponse;

        }
        return new TokenResponse(ResponseCode.FAILED, ResponseDesc.FAILED);
    }

    private void savingMerchantKeyExchange(int programId, String sdkApiKey, String referenceId, String localDerivedKey, long expireAt) {
        merchantClientConfigDAO.save(programId, sdkApiKey,referenceId,localDerivedKey,expireAt);
    }


    @Override
    public TokenResponse inValidateClientAppToken(int programId, String referenceId) {
        tokenServiceDAO.invalidateToken(referenceId);
        return new TokenResponse(ResponseCode.SUCCESS, ResponseDesc.SUCCESS);
    }
    @Override
    public TokenResponse renewClientAppToken(String token) {
        Map<String, Object> claims =   jwsTokenUtil.validateAndGetClaims(token, RoleType.CLIENT_APP.toString());
        if(claims!=null){
            String loginHistoryID = (String) claims.get(JWTConstants.LOGIN_HISTORY_ID);
            if(tokenServiceDAO.isValid(loginHistoryID)){
                tokenServiceDAO.updateRenewal(loginHistoryID);
                TokenResponse response =new TokenResponse(ResponseCode.SUCCESS, ResponseDesc.SUCCESS);
                response.setExpiry(System.currentTimeMillis()+((Integer) claims.get(JWTConstants.TOKEN_EXPIRY)*60*1000));
                 token = jwsTokenUtil.generateUserAuthToken(claims, RoleType.CLIENT_APP.toString(), (Integer) claims.get(JWTConstants.TOKEN_EXPIRY));
                response.setToken(token);
                response.setReferenceId(loginHistoryID);
                return response;
            }else{
                log.info("token is already invalidated by client app server");
            }

        }else{
            log.info("token is already expired or invalid token passed");
        }
        return new TokenResponse(ResponseCode.INVALID_TOKEN, ResponseDesc.INVALID_TOKEN);
    }
}
