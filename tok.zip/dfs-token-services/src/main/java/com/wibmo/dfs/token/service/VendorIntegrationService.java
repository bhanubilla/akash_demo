package com.wibmo.dfs.token.service;

import com.wibmo.dfs.token.pojo.VendorIntegrationRequest;
import com.wibmo.dfs.token.pojo.VendorIntegrationResponse;
import org.springframework.validation.Errors;

public interface VendorIntegrationService {

    VendorIntegrationResponse saveUserProfile(int programId, VendorIntegrationRequest request, Errors errors);

    VendorIntegrationResponse fetchUserProfile(String keyRef);
}
