package com.wibmo.dfs.token.pojo;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/*
@Author pavan.konakanchi 
Created on : 27/04/2021 - 3:54 PM
*/
@Data
public class LogoutRequest implements Serializable {

    @NotNull
    @NotEmpty
    private String token;
}
