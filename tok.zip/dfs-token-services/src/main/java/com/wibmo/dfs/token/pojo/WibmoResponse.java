package com.wibmo.dfs.token.pojo;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class WibmoResponse implements Serializable {
    private int resCode;
    private String resDesc;

    public WibmoResponse(int resCode, String resDesc) {
        this.resCode = resCode;
        this.resDesc = resDesc;
    }
}
