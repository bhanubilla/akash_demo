package com.wibmo.dfs.token.controller;

import com.wibmo.dfs.token.pojo.*;
import com.wibmo.dfs.token.constants.ResponseCode;
import com.wibmo.dfs.token.constants.ResponseDesc;
import com.wibmo.dfs.token.service.UserTokenService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@RestController
@Slf4j
@RequestMapping(value = "user")
public class UserTokenController {

    @Autowired
    UserTokenService tokenService;

    @PostMapping(value = "/refresh")
    public ResponseEntity<TokenResponse> refreshUserToken(@RequestBody @NotNull @Valid RefreshTokenRequest tokenRequest) {
        log.info("refresh token request");
        TokenResponse tokenResponse = tokenService.refresh(tokenRequest);
        return ResponseEntity.ok(tokenResponse);
    }

    @PostMapping(value = "/auth-token")
    public ResponseEntity<TokenResponse> generateAuthToken(@RequestBody @NotNull @Valid AuthTokenRequest tokenRequest) {
        log.info("upgrade token request");
        TokenResponse tokenResponse = tokenService.generateUserAuthToken(tokenRequest);
        return ResponseEntity.ok(tokenResponse);
    }

    @PostMapping(value = "/logout")
    public ResponseEntity<LogoutResponse> logout(@RequestBody @NotNull @Valid LogoutRequest tokenRequest) {
        log.info("logout token request");
        String tokenResponse = tokenService.logoutUser(tokenRequest);
        LogoutResponse response = null;
        if (tokenResponse != null) {
            response = new LogoutResponse(ResponseCode.SUCCESS, ResponseDesc.SUCCESS);
            response.setLoginHistoryId(tokenResponse);
        } else {
            response = new LogoutResponse(ResponseCode.FAILED, ResponseDesc.FAILED);
        }
        return ResponseEntity.ok(response);
    }
    @PostMapping(value = "/update-claim")
    public ResponseEntity<TokenResponse> updateClaimsInAuthToken(@RequestBody @NotNull @Valid AuthTokenRequest tokenRequest) {
        log.info("upgrade token request");
        TokenResponse tokenResponse = tokenService.updateClaimsInAuthToken(tokenRequest);
        return ResponseEntity.ok(tokenResponse);
    }

}
