package com.wibmo.dfs.token.pojo;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TokenKongReqResponse {
    private String token;
}
