package com.wibmo.dfs.token.constants;

public class Constants {

    private Constants(){}

    public static final int FAILED_CODE = 100;
    public static final int SUCCESS_CODE = 200;
    public static final String UNDER_SCORE = "_";
    public static final String TOKEN_SERVICES = "Token Services";
    public static final String CACHE_KEY = "USER_FISDOM_INTEGRATION";
    public static final String SAVE_USER_PROFILE_MSG = "Key Ref Generated Successfully";
    public static final String FAILED_SAVE_USER_PROFILE_MSG = "Reference generation failed";
    public static final String EXCEPTION_SAVE_USER_PROFILE_MSG = "Exception while generation of reference :{}";
    public static final String FETCH_USER_PROFILE_MSG = "User Profile Fetched Successfully";
    public static final String EXCEPTION_FETCH_USER_PROFILE_MSG = "Exception while fetching given key :{}";
    public static final String FAILED_FETCH_USER_PROFILE_MSG = "No Data Found for given key";
    public static final String EXCEPTION_FETCH_TOKEN = "Exception occurred while fetching key-ref";
    public static final String VENDOR_INTEGRATION_FAILED = "Vendor Integration Failed";
    public static final String EXCEPTION_AUDITING_MSG = "Exception in Auditing User Details : {}";
    public static final String USR_DTLS_TTL_IN_MINS_KEY = "USR_DTLS_TTL_IN_MINS_KEY";
    public static final int TEN_MINUTES = 10;
    public static final String USER_DETAILS = "USER_DETAILS";
    public static final String EMPTY_ROLE = "Role is empty or null";
    public static final String DEFAULT_ROLE = "LOGIN_USER";
    public static final String X_ACCOUNT_NUMBER = "X-ACCOUNT-NUMBER";
}
