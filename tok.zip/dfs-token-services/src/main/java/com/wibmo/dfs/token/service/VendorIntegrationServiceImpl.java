package com.wibmo.dfs.token.service;

import com.wibmo.dfs.jwt.JWTConstants;
import com.wibmo.dfs.jwt.JwsTokenUtil;
import com.wibmo.dfs.token.constants.Constants;
import com.wibmo.dfs.token.dao.ProgramParameterDAO;
import com.wibmo.dfs.token.dao.VendorIntegrationDAO;
import com.wibmo.dfs.token.pojo.VendorIntegrationRequest;
import com.wibmo.dfs.token.pojo.VendorIntegrationResponse;
import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
public class VendorIntegrationServiceImpl implements VendorIntegrationService {

    @Autowired
    private VendorIntegrationDAO vendorIntegrationDAO;

    @Autowired
    private ProgramParameterDAO programParameterDAO;

    @Autowired
    private JwsTokenUtil jwsTokenUtil;

    @Autowired
    private DozerBeanMapper dozzer;

    @Override
    public VendorIntegrationResponse saveUserProfile(int programId, VendorIntegrationRequest request, Errors errors) {
        VendorIntegrationResponse response = validateRequest(errors);
        if (response != null)
            return response;
        response = new VendorIntegrationResponse();
        try {
            String userDetailTtl = programParameterDAO.fetchProgramParam(String.valueOf(programId), Constants.USR_DTLS_TTL_IN_MINS_KEY);
            int userDetailTTL = StringUtils.isNotEmpty(userDetailTtl) ? Integer.parseInt(userDetailTtl) : Constants.TEN_MINUTES;
            Map<String, Object> claims = new HashMap<>();
            claims.put(JWTConstants.PROGRAM_ID, programId);
            claims.put(JWTConstants.TOKEN_EXPIRY, userDetailTTL);
            claims.put(Constants.USER_DETAILS, request);
            String token = jwsTokenUtil.generateToken(Constants.DEFAULT_ROLE, userDetailTTL, claims);
            if (StringUtils.isNotEmpty(token)) {
                response.setData(token);
            }
            response.setResDesc(Constants.SAVE_USER_PROFILE_MSG);
            response.setResCode(Constants.SUCCESS_CODE);
            vendorIntegrationDAO.auditTokenCreate(token, response.getResDesc(), request.getUserId());
        } catch (Exception e) {
            response.setResCode(Constants.FAILED_CODE);
            response.setResDesc(Constants.FAILED_SAVE_USER_PROFILE_MSG);
            log.error(Constants.EXCEPTION_SAVE_USER_PROFILE_MSG, e);
        }
        return response;
    }

    private VendorIntegrationResponse validateRequest(Errors errors) {
        if (errors.hasErrors()) {
            VendorIntegrationResponse response = new VendorIntegrationResponse();
            response.setResCode(HttpStatus.BAD_REQUEST.value());
            StringBuilder errorMessage = new StringBuilder();
            for (FieldError error : errors.getFieldErrors()) {
                errorMessage.append(error.getDefaultMessage());
            }
            response.setResDesc(errorMessage.toString());
            return response;
        }
        return null;
    }

    @Override
    public VendorIntegrationResponse fetchUserProfile(String token) {
        VendorIntegrationResponse response = new VendorIntegrationResponse();
        String claim = Constants.USER_DETAILS;
        try {
            Claims tokenClaims = jwsTokenUtil.validateAndGetClaims(token);
            if (tokenClaims != null) {
                VendorIntegrationRequest vendorIntegrationRequest = dozzer.map(tokenClaims.get(claim), VendorIntegrationRequest.class);
                response.setData(vendorIntegrationRequest);
                response.setResCode(Constants.SUCCESS_CODE);
                response.setResDesc(Constants.FETCH_USER_PROFILE_MSG);
            } else {
                response.setResDesc(Constants.FAILED_FETCH_USER_PROFILE_MSG);
                response.setResCode(Constants.FAILED_CODE);
            }
        } catch (Exception e) {
            log.error(Constants.EXCEPTION_FETCH_USER_PROFILE_MSG, e);
            response.setResDesc(Constants.EXCEPTION_FETCH_TOKEN);
            response.setResCode(Constants.FAILED_CODE);
        }
        vendorIntegrationDAO.auditTokenFetch(token, response.getResDesc(), response.getResCode());
        return response;
    }
}
