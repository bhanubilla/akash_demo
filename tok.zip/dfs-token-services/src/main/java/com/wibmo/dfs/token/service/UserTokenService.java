package com.wibmo.dfs.token.service;

import com.wibmo.dfs.token.pojo.AuthTokenRequest;
import com.wibmo.dfs.token.pojo.LogoutRequest;
import com.wibmo.dfs.token.pojo.RefreshTokenRequest;
import com.wibmo.dfs.token.pojo.TokenResponse;

public interface UserTokenService {
    TokenResponse refresh(RefreshTokenRequest tokenRequest);
    TokenResponse generateUserAuthToken(AuthTokenRequest tokenRequest);

    String logoutUser(LogoutRequest tokenRequest);
    TokenResponse updateClaimsInAuthToken(AuthTokenRequest tokenRequest);
}
