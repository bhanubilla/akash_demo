package com.wibmo.dfs.token.service;

import com.wibmo.dfs.token.pojo.*;

public interface TokenService {
    TokenResponse generateToken(TokenRequest tokenRequest);

    ClaimsResponse listClaims(ClaimRequest claimRequest);

    TokenResponse generateTokenForClientApp(int programId, ClientAppTokenRequest tokenRequest);

    TokenResponse inValidateClientAppToken(int programId, String token);

    TokenResponse renewClientAppToken(String token);
}
