package com.wibmo.dfs.token.controller;

import com.wibmo.dfs.token.pojo.TokenResponse;
import com.wibmo.dfs.token.service.TokenService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/client/app")
public class ClientAppController {
    @Autowired
    private TokenService tokenService;

    @PostMapping(value = "/renew/token")
    public ResponseEntity<TokenResponse> createAuthenticationToken(@RequestHeader(name = "X-API-TOKEN") String token) {
        log.info("renew token request");
        TokenResponse tokenResponse = tokenService.renewClientAppToken(token);
        return ResponseEntity.ok(tokenResponse);
    }
}
