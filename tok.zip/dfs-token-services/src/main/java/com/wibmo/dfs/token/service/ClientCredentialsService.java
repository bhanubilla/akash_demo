package com.wibmo.dfs.token.service;

import com.wibmo.dfs.token.pojo.ClientCreateRequest;
import com.wibmo.dfs.token.pojo.ClientCreateResponse;

/*
@Author pavan.konakanchi 
Created on : 01/06/2021 - 1:56 PM
*/
public interface ClientCredentialsService {
    ClientCreateResponse createClient(ClientCreateRequest request);
}
