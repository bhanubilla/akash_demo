package com.wibmo.dfs.token.pojo;

import lombok.Data;

/*
@Author pavan.konakanchi 
Created on : 01/06/2021 - 1:49 PM
*/
@Data
public class ClientCreateResponse {
    private int resCode;
    private String resDesc;
    private String apiKey;
    private String apiSecret;
    private String payloadSecret;
    private int tokenExpiryinMinutes;
    private int status;


}
