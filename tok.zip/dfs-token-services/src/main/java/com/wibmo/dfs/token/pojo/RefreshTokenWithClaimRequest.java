package com.wibmo.dfs.token.pojo;


import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

@Data
public class RefreshTokenWithClaimRequest implements Serializable {

    @NotNull
    @NotEmpty
    private String token;

    private int expiry;

    @NotNull
    HashMap<String, Object> claims;
}
