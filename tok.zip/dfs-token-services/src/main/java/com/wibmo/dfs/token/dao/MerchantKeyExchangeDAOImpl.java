package com.wibmo.dfs.token.dao;

import com.wibmo.dfs.token.pojo.MerchantKeyExchange;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;

@Repository
@Slf4j
public class MerchantKeyExchangeDAOImpl implements MerchantKeyExchangeDAO {

    @Autowired
    @Qualifier("globalJdbcTemplate")
    JdbcTemplate jdbcTemplate;

    public static final String SELECT_FROM_MERCHANT_KEY_EXCHANGE_WHERE_API_KEY_AND_REFERENCE_ID = "SELECT * FROM  merchant_keyexchange WHERE API_KEY=? AND REFERENCE_ID=?";
    public static final String EXCEPTION_IN_MERCHANT_KEY_EXCHANGE_DAOIMPL_FIND_BY_REF_ID = "Exception in MerchantKeyExchangeDAOImpl : findByRefId : {}";

    @Override
    public MerchantKeyExchange findByRefId(final String referenceId, final String apiKey) {
        log.info("MerchantKeyExchangeDAOImpl : findByRefId : referenceId :{} apiKey : {}", referenceId, apiKey);
        try {
            return jdbcTemplate.queryForObject(SELECT_FROM_MERCHANT_KEY_EXCHANGE_WHERE_API_KEY_AND_REFERENCE_ID, new RowMapper<MerchantKeyExchange>() {
                @Override
                public MerchantKeyExchange mapRow(ResultSet rs, int rwNumber) throws SQLException {
                    MerchantKeyExchange merchantKeyExchange = new MerchantKeyExchange();
                    merchantKeyExchange.setProgramId(rs.getInt("PROGRAM_ID"));
                    merchantKeyExchange.setApikey(rs.getString("API_KEY"));
                    merchantKeyExchange.setReferenceId(rs.getString("REFERENCE_ID"));
                    merchantKeyExchange.setCryptoKey1(rs.getString("CRYPTO_KEY1"));
                    merchantKeyExchange.setCryptoKey2(rs.getString("CRYPTO_KEY1"));
                    merchantKeyExchange.setExpiry(rs.getInt("EXPIRY"));
                    return merchantKeyExchange;
                }
            }, apiKey, referenceId);
        } catch (
                EmptyResultDataAccessException exception) {
            log.error(EXCEPTION_IN_MERCHANT_KEY_EXCHANGE_DAOIMPL_FIND_BY_REF_ID, exception);
            return null;
        }
    }
}
