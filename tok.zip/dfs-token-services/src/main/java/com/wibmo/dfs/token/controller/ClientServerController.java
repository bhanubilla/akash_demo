package com.wibmo.dfs.token.controller;

import com.wibmo.dfs.token.pojo.ClientAppTokenRequest;
import com.wibmo.dfs.token.pojo.InvalidateAppTokenRequest;
import com.wibmo.dfs.token.pojo.TokenResponse;
import com.wibmo.dfs.token.service.TokenService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@RestController
@RequestMapping("/client/server")
@Slf4j
public class ClientServerController {
    @Autowired
    private TokenService tokenService;
    @PostMapping(value = "/new/token")
    public ResponseEntity<TokenResponse> createAuthenticationToken( @RequestHeader(name = "X-PROGRAM-ID") int programId,@RequestBody @NotNull @Valid ClientAppTokenRequest tokenRequest) {
        log.info("generate new token request");
        TokenResponse tokenResponse = tokenService.generateTokenForClientApp(programId, tokenRequest);
        return ResponseEntity.ok(tokenResponse);
    }
    @PostMapping(value = "/invalidate/token")
    public ResponseEntity<TokenResponse> invalidateToken( @RequestHeader(name = "X-PROGRAM-ID") int programId,@RequestBody InvalidateAppTokenRequest request) {
        log.info("invalidate token request");
        TokenResponse tokenResponse = tokenService.inValidateClientAppToken(programId, request.getTokenReferenceId());
        return ResponseEntity.ok(tokenResponse);
    }
}
