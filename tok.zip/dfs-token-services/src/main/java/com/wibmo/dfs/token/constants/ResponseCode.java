package com.wibmo.dfs.token.constants;

public interface ResponseCode {
    int SUCCESS = 100;
    int INVALID_API_KEY = 10;
    int INVALID_CLIENT_SECRET = 20;
    int CREDENTIALS_NOT_ALLOWED = 30;
    int CREDENTIALS_DEACTIVATED = 70;
    int FAILED = 50;
    int INVALID_TOKEN = 60;
}
