package com.wibmo.dfs.token.pojo;

import lombok.Data;

import javax.validation.constraints.Min;
import java.util.Map;

@Data
public class ClientAppTokenRequest {
    private String firstName;
    private String sdkApiKey;
    private String lastName;
    @Min(1)
    private long accountNumber;
    private int isdCode;
    private long mobileNumber;
    private int dob;
    private String email;
    private String sdkPublicKey;
    private String referenceId;
    private Map<String, String> data;
}
