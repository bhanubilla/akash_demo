package com.wibmo.dfs.token.controller;

import com.wibmo.dfs.token.pojo.ClaimRequest;
import com.wibmo.dfs.token.pojo.TokenResponse;
import com.wibmo.dfs.token.pojo.TokenRequest;
import com.wibmo.dfs.token.pojo.WibmoResponse;
import com.wibmo.dfs.token.service.TokenService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@RestController
@Slf4j
public class TokenController {

    @Autowired
    private TokenService tokenService;

    @PostMapping(value = "/new/token")
    public ResponseEntity<TokenResponse> createAuthenticationToken(@RequestBody @NotNull @Valid TokenRequest tokenRequest) {
        log.info("generate token request");
        TokenResponse tokenResponse = tokenService.generateToken(tokenRequest);
        return ResponseEntity.ok(tokenResponse);
    }

    @PostMapping(value = "/claim/get")
    public ResponseEntity<WibmoResponse> fetchClaim(@RequestBody @NotNull @Valid ClaimRequest claimRequest) {
        log.info("generate token request");
        WibmoResponse tokenResponse = tokenService.listClaims(claimRequest);
        return ResponseEntity.ok(tokenResponse);
    }


}