package com.wibmo.dfs.token.service;

import com.wibmo.dfs.jwt.JWTConstants;
import com.wibmo.dfs.jwt.JwsTokenUtil;
import com.wibmo.dfs.token.dao.MerchantClientConfigDAO;
import com.wibmo.dfs.token.dao.MerchantKeyExchangeDAO;
import com.wibmo.dfs.token.pojo.MerchantClientConfig;
import com.wibmo.dfs.token.pojo.MerchantKeyExchange;
import com.wibmo.dfs.token.util.EncryptDecryptHelper;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.util.Base64;

@Service
@Slf4j
public class EncryptionDecryptionServiceImpl implements EncryptionDecryptionService {
    private static final String ENCRYPT_ALGO = "AES/GCM/NoPadding";
    private static final int TAG_LENGTH_BIT = 128;
    private static final int IV_LENGTH_BYTE = 12;
    private static final int SALT_LENGTH_BYTE = 16;
    private static final Charset UTF_8;
    private static final String SDK = "SERVER";
    private static final String DEFAULT_KEY = "";

    static {
        UTF_8 = StandardCharsets.UTF_8;
    }

    @Autowired
    private MerchantClientConfigDAO kongClientConfigDAO;
    @Autowired
    private MerchantKeyExchangeDAO merchantKeyExchangeDAO;

    @Autowired
    private JwsTokenUtil jwsTokenUtil;

    /**
     *
     * @param incReq
     * @return
     * @throws IOException
     * method is used to encrypt payload data
     */
    @Override
    public String getEncryptedData(String incReq, String apiKey, String apiToken) throws IOException {
        String secretKey = DEFAULT_KEY;
        String cipherText = "";
        log.debug("inside encryptedData {}");
        try {
            secretKey = getSecretKey(secretKey, apiKey, apiToken);
            log.info("encrypted secret key :{}", secretKey);
            if(StringUtils.isEmpty(secretKey)){
                log.info("Secret key is empty in getEncryptedData()");
            } else {
                cipherText = encrypt(incReq, secretKey);
            }
        } catch (Exception e) {
            log.error("Exception while calling encryptedData() : {}", e);
        }
        return cipherText;
    }

    /**
     *
     * @param bodyCipher
     * @return
     * @throws IOException
     * method is used to decrypt the payload data
     */
    @Override
    public ResponseEntity<String> getDecryptedData(String bodyCipher, String apiKey, String apiToken) throws IOException {
        String plainText = "";
        String secretKey = DEFAULT_KEY;
        HttpHeaders responseHeaders = new HttpHeaders();
        JSONObject json = null;
        ResponseEntity<String> responseEntity = null;
        try {
            //fetch secret key from SDK/APP flow
            secretKey = getSecretKey(secretKey, apiKey, apiToken);
            if(StringUtils.isEmpty(secretKey)){
                log.info("Secret key is empty in getDecryptedData()");
            } else {
                plainText = decrypt(bodyCipher, secretKey);
                json = new JSONObject(plainText);
                responseHeaders.set("Content-Type", "application/json");
                responseEntity = new ResponseEntity<String>(json.toString(), responseHeaders, HttpStatus.OK);
            }
        } catch (Exception e) {
            log.error("Exception while calling decryptedData() : {}", e);
        }
        return responseEntity;
    }

    /**
     *
     * @param secret
     * @param apiKey
     * @param apiToken
     * fetching secret from DB
     * @return
     */
    private String getSecretKey(String secret, String apiKey, String apiToken) {
        try {
            MerchantClientConfig merchantClientConfig = kongClientConfigDAO.findByApiKeyBySdk(apiKey);
            log.info("merchantClientConfig :{} details : secret : {} apiKey : {} apiToken : {}", merchantClientConfig, secret, apiKey, apiToken);
            if (merchantClientConfig != null) {
                if (SDK.equalsIgnoreCase(merchantClientConfig.getAccessType())) {
                    log.debug("inside SDK flow");
                    if(apiToken !=null &&  !apiToken.isEmpty()){
                        log.debug("apiToken is not null in sdk flow");
                        secret = fetchSecretFromApiToken(apiToken, apiKey);
                    } else {
                        log.info("inside SDK flow fetching secret for client new token");
                        if (merchantClientConfig.getDefaultCryptoKey() != null) {
                            secret = merchantClientConfig.getDefaultCryptoKey();
                        } else {
                            log.info("secret for SDK is null");
                        }
                    }
                } else {
                    log.debug("inside app flow");
                    secret = fetchSecretFromApiToken(apiToken, apiKey);
                }
            } else{
                log.info("merchantClientConfig is null");
            }
        } catch (Exception e) {
            log.error("Exception while fetching Secret Key : {}", e);
        }
        return secret;
    }

    private Claims fetchClaimsFromToken(String apiToken) {
        Claims claims = null;
        try {
            claims = jwsTokenUtil.validateAndGetClaims(apiToken);
        } catch (Exception e) {
            log.error("Exception while fetching claims : {}", e);
        }
        return claims;
    }

    private String encrypt(String plainText, String secretKey) {
        try {
            byte[] salt = EncryptDecryptHelper.getRandomNonce(SALT_LENGTH_BYTE);
            byte[] iv = EncryptDecryptHelper.getRandomNonce(IV_LENGTH_BYTE);
            SecretKey aesKeyFromPassword = EncryptDecryptHelper.getAESKeyFromSecretKey(Base64.getDecoder().decode(secretKey.getBytes()), salt);
            Cipher cipher = Cipher.getInstance(ENCRYPT_ALGO);
            cipher.init(1, aesKeyFromPassword, new GCMParameterSpec(TAG_LENGTH_BIT, iv));
            byte[] cipherText = cipher.doFinal(plainText.getBytes(UTF_8));
            byte[] cipherTextWithIvSalt = ByteBuffer.allocate(salt.length + iv.length + cipherText.length).put(salt).put(iv).put(cipherText).array();
            return Base64.getEncoder().encodeToString(cipherTextWithIvSalt);
        } catch (GeneralSecurityException var9) {
            var9.printStackTrace();
            return null;
        }
    }

    private String decrypt(String cipherText, String secretKey) {
        try {
            byte[] decode = Base64.getDecoder().decode(cipherText.getBytes(UTF_8));
            ByteBuffer bb = ByteBuffer.wrap(decode);
            byte[] salt = new byte[SALT_LENGTH_BYTE];
            bb.get(salt);
            byte[] iv = new byte[IV_LENGTH_BYTE];
            bb.get(iv);
            byte[] cText = new byte[bb.remaining()];
            bb.get(cText);
            SecretKey aesKeyFromPassword = EncryptDecryptHelper.getAESKeyFromSecretKey(Base64.getDecoder().decode(secretKey.getBytes()), salt);
            Cipher cipher = Cipher.getInstance(ENCRYPT_ALGO);
            cipher.init(2, aesKeyFromPassword, new GCMParameterSpec(TAG_LENGTH_BIT, iv));
            byte[] plainText = cipher.doFinal(cText);
            return new String(plainText, UTF_8);
        } catch (GeneralSecurityException var11) {
            var11.printStackTrace();
            return null;
        }
    }

    private String fetchSecretFromApiToken(String apiToken, String apiKey) {
        log.info("fetchSecretFromApiToken : apiToken : {} apiKey :{}", apiToken, apiKey);
        String secret = "";
        Claims claims = fetchClaimsFromToken(apiToken);
        log.info("claims {}", claims);
        if (claims != null) {
            String referenceId = (String) claims.get("REFERENCE_ID");
            int programId = (int) claims.get(JWTConstants.PROGRAM_ID);
            log.debug("claims reference ID and program ID :{}, {}", referenceId, programId);
            MerchantKeyExchange merchantKeyExchange = merchantKeyExchangeDAO.findByRefId(referenceId, apiKey);
            if (merchantKeyExchange != null && merchantKeyExchange.getCryptoKey1() != null) {
                secret = merchantKeyExchange.getCryptoKey1();
            }
        } else {
            throw new JwtException("Unauthorised Access");
        }
        return secret;
    }
}
