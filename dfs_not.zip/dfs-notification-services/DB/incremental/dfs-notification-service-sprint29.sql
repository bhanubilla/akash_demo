

INSERT INTO `dfs_notification_service`.`alert_parameters`
(`PARAM_ID`,`PARAM_VALUE`,`STATUS`,`PROGRAM_ID`) VALUES ('EMAIL_ALERT_SERVER_URL', 'http://15.207.252.87:6216/v1/send/alert', 1, 1111);
INSERT INTO `dfs_notification_service`.`alert_parameters`
(`PARAM_ID`,`PARAM_VALUE`,`STATUS`,`PROGRAM_ID`) VALUES ('EMAIL_ALERT_FROM_EMAIL', 'test@bankezy.co',1,1111);
INSERT INTO `dfs_notification_service`.`alert_parameters`
(`PARAM_ID`,`PARAM_VALUE`,`STATUS`,`PROGRAM_ID`) VALUES ('ALERT_SMTP_SERVER_URL', 'http://15.207.252.87:9036/user/root', 1, 1111);
INSERT INTO `dfs_notification_service`.`alert_parameters`
(`PARAM_ID`,`PARAM_VALUE`,`STATUS`,`PROGRAM_ID`) VALUES ('ALERT_SMTP_SERVER_CONNECTION_TYPE', 'DIRECT', 1, 1111);
INSERT INTO `dfs_notification_service`.`alert_parameters`
(`PARAM_ID`,`PARAM_VALUE`,`STATUS`,`PROGRAM_ID`) VALUES ('ALERT_SMS_SERVER_URL', 'http://15.207.252.87:6391/MessageServiceGeneric/msgSendReq', 1, 1111);
INSERT INTO `dfs_notification_service`.`alert_parameters`
(`PARAM_ID`,`PARAM_VALUE`,`STATUS`,`PROGRAM_ID`) VALUES ('ALERT_SMS_SERVER_CONNECTION_TYPE', 'DIRECT', 1, 1111);


INSERT INTO `dfs_notification_service`.`alert_parameters`
(`PARAM_ID`,`PARAM_VALUE`,`STATUS`, `PROGRAM_ID`) VALUES ('ALERT_FIREBASE_BANKEZY_PUSH_JSON', 'OpPlCVcXpRBvoMoK4E8pIihdz8nI7Y4wTwzgfdEmXfmnow1T/Xf//ONggPRqxgEq2ovZOxEOUaBi3Kehh0oCDghGyFnnt0NiCyngXqBlNLpTwrcAagWOxDzxruuX/+tVnvuwaiCme+MwA7xtgr9WXWRdm1FFbS/+6oZDdiOJ/J0tmtywANYE21iiuJoZBnmHXWpm2/hOpAUcQlT+Q0FnOOoy1wA8UhyeUCb6Go+cQATujMXbHUwxPIKRnxmVK9HHQ6Jn1usWhiEqiWsoQnzCzXPHUyiHblRP+aINSdxTTO2ALpUNQ8wgCMwqbVW12UfvlIj9pV1al4oilWkmL9XBtoIe3d8J5jKVtH2BXUNL9gJ1zX6URIzJoTVAaJLD7pR1cqzQGXnQovVesKkjlMUvjT5FycCfjpfRtcOj/bPsJLH3YonL3ZtH5Xzgn/c+C7DdqAhdgJl3lXkZ/2b1X7FX6RSTT+gVp9KBTKayn4LkEG6cBhxZYN7boB5w7hODoXRBlLXwkyRIhc+prPs/60FDKUKiAg6qZTFrKcq5bEdeUUFXOiXaQ9vPYYuiwJFsP0t1NkYAG3RSpc1TX24GyqzPhKUkl0dnmld46gpMYXoHG8k+Q/682kuaEm4Vl/wY+AwCTa0QGbkqqH1ibqM1r3PPwuBUXE0cgd29ASWKFNLokusDF03h7T/vo77iqJOab+Xivl8veF0nUbqDYQtTIERGxhGF2pEQfN0MNZGoH126ibrePiX+jhvh/gGmoGNwDNT8Y0BKzZFZ5dzMQ7BbaSMhS/azbeIij2lI3YZVnDNfLbo/Po6V5jzwGGEL6rdu2b1KVoKa1K6lTRy5KZriNO5XN9uK3aHQMhESjNjV7zGznfRA8HjHVltYR1yqt2OKqgm3Wfx1lsZGaBQ5aSNeoDAVAe7V883fhu0qoc+OgQqWCoQbMJCQ4oDQEKjTIrsHIRlk24GVaoEJkQOkkD344eNEcdiCBz2O2k9z0hrfwAwoiP9OAq6sjytcV8mCJyz0QxKa6OJl1GyY04RTE2nRTU/TqRHClqqWik7DjYSFw+laajfiGVEIYghrwwawnIZ44ctN7O9lWQpDfa44DoHBLtMEC1vzrS2T2sSqkWxBaEDsuAZQA8nvkybiRKaS8Q6LVPtHjmzplcdnX6TsiZkO/yKQX3u+IjcgzaILFp6/vx2wORFAzf04PWK4XDpuv7u2/zfehbRzAcsUE3zt+2BxdBAAUWA7J1DXqyrP2W/Gox/NZe1CxnKJubDPASPQV/5we198omg0nN1PZ0bodiUkfDNTtiCup6Je5pqB6Oou9UhSWfS7d9DKGHqJu1sgFfs8b/VfKx/ohzOvagjNx1g6vTyAsN5RgfQrH0t2R12utj/8n3S2tRPMpa7P6nDKPdnkNEtOVcuf+T0OvsXdv1jr/xvmB06r4BRKwdfb+FXLSpn0LL1+NRqz9rGvzmUE9Po3FegR0q0wV6uoLH+jPPhzzAklh5jqbbfJgrwD1QFMJjJeMPcDkYJlgamF86v1HiKAvq+Jyea9dmbdzE7lY0EPkXkP1RYdv6a7hctCk9QYlo/d+0UsHB2mhR+hl42u0vd/tUlfLkuJ0CbNFREUZE1Ug94KXufo2FsAzltPiacToOP4oiAICkZg2pyV29kAkJ9jhNJzl/MYBJrf3rvIHK8UbNhc+BYdkSvt8z14Hz7Wmee6QgG92YUkA0ghw381j9hIKzvWDptL9Dst4Qv9Eodl27gsLLGvU2eT7Je/IZ3bPWOK3+qTlz2CG8lhktltCHH/3dGz1wRp/lv6/udvu80lIAWIB/OnSEQFDkIyvKfRcPq/R2cAOKfR/t3Qc37gfCHU+1OYdVRQMZOa6VLBhJKXFWrp42jfwOI6vxeUCjXH0FcmWMZECIQ+rNUXM3FVxRZhEdo2xs6jbGGOJ2zKrjiPjQXjWxSSLZTvrG+pnoTNZMu9uhJNdlk4riudW/q3tq+3Ae5+p/C8p0ja3Sg6YfopXt9YbkOKpjttOFNYk1W88JvMjzgkN8Uf4Tb0r5eayYM7UGodMSjTl4EG6+VvM6ENe1F1IXUaeMP2XFobfGnMoHrW6PundgQ/wyeFRkLsdyBduegmz7r4gk2n/2cYOYFFdsFgAEMSz5eF4Zo2iQ3tc47sDp8+EcIg/RbB2hXSHIsUuFKy6/iClRTbjlKc1nd5v5ZAlB3l/TYFB7m+bSXNlQunqwCIn/Kicnmwu6ViSN3fPitk8uoi4AA9JtWYyErL/iMPfTtEGRNvPgxNe0Xq+RvHUR6yJxKdeX/MYM3NUtTtSPUg6gIphWUQLypGELfSf7X8UHGYUsCTA+FrslBqVMIhE+cgkVDxrwH6FCzrAPdAGWCoSMjXr0w8D94le9FMZHDifl728MSz8ImOADBhP2oP58wxFvqKB1gXA+GU4q1iQldaNaCW6rWE9UJCoCe8RQEHAXdXI8H0VrzHYAqitEGGYjh7hPELtzAyJ1PHwkiBp7EuZ6RpmetwrNyZOLo7SRY1ckU559sdl52i/wZqNLgckwBnottn5H/Hug53EmQYOJgEk740L5wnQDoU8bicDVT8FNfL6sATIfO3gzJzBIY9N1NorLsa9q4ht3JY6A10bjscMKw+N9aPD+hYjkAX/FI70IpJk2nTLpLtfo175MrVjwtYJ9aPO6B9d3KIRYziMBg47eUEhNjtseG/6Z+g6VFcr8Xt0R0etx9C2cG0+wCxKe98PNY+Zp/1eEsD3FR/U96mUMcBVet7b7Sls+pgL2qoDaR2QxzO3Lvp97PJRJNCxxGO+WG3TI7AvzSNPiFFeFBZh/4mKO4gEoSSFBjZl8BV28nqcgbD+PSmaSESXOtQ2dSgErVlwRfHTeTpbboqPkNVkqJjygYyx+ZmxQY35mQgyOALQAbjDSVwXgzXhNExPd67BBOAKkrXQt5o+TQ39+sTh8qLpHEsIRo+gH+1nQhldmJR2b7iUEyfyej8un1wF5P78hnuMQN8kDyATXAWkHnI6ZG2EPS5Jd55DBl/6RM1sMF9fUIDToitrJFUOWA0Bw9njSmh2DRVydNs7RgLgPXzmP6RESyInUA9VZiGgnkzCcTT8lfVyGLUQFqSWKxX5ZxiwmiUzfwiBbZbP+oH8mrn',1,1111);


INSERT INTO `dfs_notification_service`.`alert_messages`
(`EVENT_ID`,`ALERT_TYPE`,`TEMPLATE_BODY`,`STATUS`,`TEMPLATE_SUBJECT`) VALUES (5013, 'SMS','{CardNumber} is your One Time Password (OTP) for registration. Kindly complete the process to enjoy secure transactions.', 1, 'Wallet');INSERT INTO `dfs_notification_service`.`alert_messages`
(`EVENT_ID`,`ALERT_TYPE`,`TEMPLATE_BODY`,`STATUS`,`TEMPLATE_SUBJECT`) VALUES (5013, 'EMAIL','{CardNumber} is your One Time Password (OTP) for registration. Kindly complete the process to enjoy secure transactions.', 1, 'Wallet');

INSERT INTO `dfs_notification_service`.`alert_messages`
(`EVENT_ID`,`ALERT_TYPE`,`TEMPLATE_BODY`,`STATUS`,`TEMPLATE_SUBJECT`) VALUES (1003, 'SMS','You have successfully reset your secure PIN on BankEzy', 1, 'Pin reset msg');

INSERT INTO `dfs_notification_service`.`alert_messages`
(`EVENT_ID`,`ALERT_TYPE`,`TEMPLATE_BODY`,`STATUS`,`TEMPLATE_SUBJECT`) VALUES (1003, 'EMAIL','You have successfully reset your secure PIN on BankEzy', 1, 'Pin reset msg');

INSERT INTO `dfs_notification_service`.`alert_messages`
(`EVENT_ID`,`ALERT_TYPE`,`TEMPLATE_BODY`,`STATUS`,`TEMPLATE_SUBJECT`) VALUES (1004, 'SMS', 'Congrats! Your Basic KYC is complete. Enjoy BankEzy wallet benefits. - WIBMO', 1, 'KYC Validation Success');

INSERT INTO `dfs_notification_service`.`alert_messages`
(`EVENT_ID`,`ALERT_TYPE`,`TEMPLATE_BODY`,`STATUS`,`TEMPLATE_SUBJECT`) VALUES (1004, 'EMAIL', 'Congrats! Your Basic KYC is complete. Enjoy BankEzy wallet benefits. - WIBMO', 1, 'KYC Validation Success');

INSERT INTO `dfs_notification_service`.`alert_messages`
(`EVENT_ID`,`ALERT_TYPE`,`TEMPLATE_BODY`,`STATUS`,`TEMPLATE_SUBJECT`) VALUES (1001, 'EMAIL', '<#> OTP_VALUE is the OTP to reset your secure PIN on BankEzy . It is valid for 10 mins. Do not share this OTP with anyone. 6Qfz8X4D+aT', 1, 'Sending OTP is successful');

INSERT INTO `dfs_notification_service`.`alert_messages`
(`EVENT_ID`,`ALERT_TYPE`,`TEMPLATE_BODY`,`STATUS`,`TEMPLATE_SUBJECT`) VALUES (1001, 'SMS', '<#> OTP_VALUE is the OTP to reset your secure PIN on BankEzy . It is valid for 10 mins. Do not share this OTP with anyone. 6Qfz8X4D+aT', 1, 'BANKEZY');

INSERT INTO `dfs_notification_service`.`alert_messages`
(`EVENT_ID`,`ALERT_TYPE`,`TEMPLATE_BODY`,`STATUS`,`TEMPLATE_SUBJECT`) VALUES (1002, 'SMS','Welcome to BankEzy! Your registration is successful. Enjoy unlimited benefits on the app.', 1, 'Registration successful');

INSERT INTO `dfs_notification_service`.`alert_messages`
(`EVENT_ID`,`ALERT_TYPE`,`TEMPLATE_BODY`,`STATUS`,`TEMPLATE_SUBJECT`) VALUES (1002, 'EMAIL','Welcome to BankEzy! Your registration is successful. Enjoy unlimited benefits on the app.', 1, 'Registration successful');

INSERT INTO `dfs_notification_service`.`alert_messages` (`EVENT_ID`, `ALERT_TYPE`, `TEMPLATE_BODY`, `STATUS`, `TEMPLATE_SUBJECT`) VALUES ('1012', 'SMS', '<#> OTP_VALUE is the OTP for mobile number verification on BankEzy . It is valid for 10 mins. Do not share this OTP with anyone. 6Qfz8X4D+aT', '1', 'Mobile number verification');

INSERT INTO `dfs_notification_service`.`alert_messages` (`EVENT_ID`, `ALERT_TYPE`, `TEMPLATE_BODY`, `STATUS`, `TEMPLATE_SUBJECT`) VALUES ('1012', 'EMAIL', '<#> OTP_VALUE is the OTP for mobile number verification on BankEzy . It is valid for 10 mins. Do not share this OTP with anyone. 6Qfz8X4D+aT', '1', 'Mobile number verification');
=======
USE dfs_notification_service;

INSERT INTO `alert_messages` (`EVENT_ID`, `ALERT_TYPE`, `TEMPLATE_BODY`, `STATUS`, `TEMPLATE_SUBJECT`) VALUES ('5020', 'SMS', 'Congrats! Your Aadhar card verification is successful. Enjoy Full KYC wallet benefits', '1', 'Ekyc is successfully completed.');
INSERT INTO `alert_messages` ( `EVENT_ID`, `ALERT_TYPE`, `TEMPLATE_BODY`, `STATUS`, `TEMPLATE_SUBJECT`) VALUES ('5020', 'EMAIL', 'Congrats! Your Aadhar card verification is successful. Enjoy Full KYC wallet benefits', '1', 'Ekyc is successfully completed.');
INSERT INTO `alert_messages` ( `EVENT_ID`, `ALERT_TYPE`, `TEMPLATE_BODY`, `STATUS`, `TEMPLATE_SUBJECT`) VALUES ('5020', 'PUSH', 'Congrats! Your Aadhar card verification is successful. Enjoy Full KYC wallet benefits', '1', 'Ekyc is successfully completed.');

