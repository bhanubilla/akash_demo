use `dfs_notification_service_2001`;
DELETE FROM  alert_messages where EVENT_ID = 6001;
DELETE FROM  alert_messages where EVENT_ID = 9999;

INSERT INTO alert_messages ( `EVENT_ID`, `ALERT_TYPE`, `TEMPLATE_BODY`, `STATUS`, `TEMPLATE_SUBJECT`) VALUES ('6001', 'PUSH', 'On approving the request, {AMOUNT} will be debited from your account', '1', '{XYZ} has requested money from you' );
INSERT INTO alert_messages ( `EVENT_ID`, `ALERT_TYPE`, `TEMPLATE_BODY`, `STATUS`, `TEMPLATE_SUBJECT`) VALUES ('9999', 'PUSH', 'Your request for Rs. {amount} has been {action} by {XYZ}', '1', '{XYZ} has {action} your request' );
