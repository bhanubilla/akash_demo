use `dfs_notification_service_2001`;
DELETE FROM  alert_messages where EVENT_ID = 1001;
DELETE FROM  alert_messages where EVENT_ID = 1012;
DELETE FROM  alert_messages where EVENT_ID = 1002;
DELETE FROM  alert_messages where EVENT_ID = 1003;
DELETE FROM  alert_messages where EVENT_ID = 1004;
DELETE FROM  alert_messages where EVENT_ID = 1005;

INSERT INTO alert_messages ( `EVENT_ID`, `ALERT_TYPE`, `TEMPLATE_BODY`, `STATUS`, `TEMPLATE_SUBJECT`) VALUES ('1001', 'EMAIL', '<#> OTP_VALUE is the OTP to reset your secure PIN on Citrus . It is valid for 10 mins. Do not share this OTP with anyone.', '1', 'App login Citrus' );
INSERT INTO alert_messages ( `EVENT_ID`, `ALERT_TYPE`, `TEMPLATE_BODY`, `STATUS`, `TEMPLATE_SUBJECT`) VALUES ('1001', 'SMS', '<#> OTP_VALUE is the OTP to reset your secure PIN on Citrus . It is valid for 10 mins. Do not share this OTP with anyone.', '1', 'App login Citrus' );

INSERT INTO alert_messages ( `EVENT_ID`, `ALERT_TYPE`, `TEMPLATE_BODY`, `STATUS`, `TEMPLATE_SUBJECT`) VALUES ('1002', 'EMAIL', 'Welcome to Citrus! Your registration is successful. Enjoy unlimited benefits on the app.', '1', 'Registration is successful' );
INSERT INTO alert_messages ( `EVENT_ID`, `ALERT_TYPE`, `TEMPLATE_BODY`, `STATUS`, `TEMPLATE_SUBJECT`) VALUES ('1002', 'SMS', 'Welcome to Citrus! Your registration is successful. Enjoy unlimited benefits on the app.', '1', 'Registration is successful' );

INSERT INTO alert_messages ( `EVENT_ID`, `ALERT_TYPE`, `TEMPLATE_BODY`, `STATUS`, `TEMPLATE_SUBJECT`) VALUES ('1003', 'EMAIL', 'You have successfully reset your secure PIN on Citrus', '1', 'App login1 Citrus' );
INSERT INTO alert_messages ( `EVENT_ID`, `ALERT_TYPE`, `TEMPLATE_BODY`, `STATUS`, `TEMPLATE_SUBJECT`) VALUES ('1003', 'SMS', 'You have successfully reset your secure PIN on Citrus', '1', 'App login1 Citrus' );

INSERT INTO alert_messages ( `EVENT_ID`, `ALERT_TYPE`, `TEMPLATE_BODY`, `STATUS`, `TEMPLATE_SUBJECT`) VALUES ('1004', 'EMAIL', 'Congrats! Your Basic KYC on Citrus is complete. Enjoy Citrus wallet benefits.', '1', 'KYC Validation Success' );
INSERT INTO alert_messages ( `EVENT_ID`, `ALERT_TYPE`, `TEMPLATE_BODY`, `STATUS`, `TEMPLATE_SUBJECT`) VALUES ('1004', 'SMS', 'Congrats! Your Basic KYC on Citrus is complete. Enjoy Citrus wallet benefits.', '1', 'KYC Validation Success' );

INSERT INTO alert_messages ( `EVENT_ID`, `ALERT_TYPE`, `TEMPLATE_BODY`, `STATUS`, `TEMPLATE_SUBJECT`) VALUES ('1005', 'EMAIL', 'Your Basic KYC on Citrus has failed due to incorrect details. Kindly submit it again to complete KYC', '1', 'PAN KYC fails Citrus' );
INSERT INTO alert_messages ( `EVENT_ID`, `ALERT_TYPE`, `TEMPLATE_BODY`, `STATUS`, `TEMPLATE_SUBJECT`) VALUES ('1005', 'SMS', 'Your Basic KYC on Citrus has failed due to incorrect details. Kindly submit it again to complete KYC', '1', 'PAN KYC fails Citrus' );

INSERT INTO alert_messages ( `EVENT_ID`, `ALERT_TYPE`, `TEMPLATE_BODY`, `STATUS`, `TEMPLATE_SUBJECT`) VALUES ('1012', 'EMAIL', '<#> OTP_VALUE is the OTP for mobile number verification on Citrus . It is valid for 1 mins. Do not share this OTP with anyone.ltPf9u2j/if', '1', 'Mobile no verification Citrus 1' );
INSERT INTO alert_messages ( `EVENT_ID`, `ALERT_TYPE`, `TEMPLATE_BODY`, `STATUS`, `TEMPLATE_SUBJECT`) VALUES ('1012', 'SMS', '<#> OTP_VALUE is the OTP for mobile number verification on Citrus . It is valid for 1 mins. Do not share this OTP with anyone.ltPf9u2j/if', '1', 'Mobile no verification Citrus 1' );

INSERT INTO alert_parameters (`PARAM_ID`, `param_value`, `STATUS`) VALUES ('CONFIG_VALUE_MESSAGE_FROM_ID', 'CITRUS', '1');
UPDATE alert_parameters SET param_value = 'test@citrus.co' WHERE (param_id = 'EMAIL_ALERT_FROM_EMAIL');

INSERT INTO alert_messages (`EVENT_ID`, `ALERT_TYPE`, `TEMPLATE_BODY`, `STATUS`, `TEMPLATE_SUBJECT`) VALUES ('1101', 'EMAIL', 'You have successfully registered for UPI services on Citrus', '1', 'UPI Registration Citrus');
INSERT INTO alert_messages (`EVENT_ID`, `ALERT_TYPE`, `TEMPLATE_BODY`, `STATUS`, `TEMPLATE_SUBJECT`) VALUES ('1101', 'SMS', 'You have successfully registered for UPI services on Citrus', '1', 'UPI Registration Citrus');

INSERT INTO alert_parameters (`PARAM_ID`, `param_value`, `STATUS`) VALUES ('CONFIG_VALUE_MESSAGE_GROUP_ID', 'KOTDB_OTP_GROUP', '1');
INSERT INTO alert_parameters (`PARAM_ID`, `param_value`, `STATUS`) VALUES ('ALERT_BIN_ID', '49', '1');


use `dfs_notification_service`;
INSERT INTO alert_parameters (`PARAM_ID`, `param_value`, `STATUS`) VALUES ('CONFIG_VALUE_MESSAGE_FROM_ID', 'WIBINC', '1');
INSERT INTO alert_parameters (`PARAM_ID`, `param_value`, `STATUS`) VALUES ('CONFIG_VALUE_MESSAGE_GROUP_ID', 'BNKEZY1_SMS_GROUP', '1');
INSERT INTO alert_parameters (`PARAM_ID`, `param_value`, `STATUS`) VALUES ('ALERT_BIN_ID', '8888', '1');