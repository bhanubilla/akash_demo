use `dfs_notification_service_2001`;
DELETE FROM  alert_messages where EVENT_ID = 6001;
DELETE FROM  alert_messages where EVENT_ID = 9999;
