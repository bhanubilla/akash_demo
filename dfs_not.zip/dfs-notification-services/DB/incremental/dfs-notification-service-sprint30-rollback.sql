USE dfs_notification_service;

DELETE FROM `alert_messages` WHERE `EVENT_ID` = '5021';
DELETE FROM `alert_messages` WHERE `EVENT_ID` = '5022';
DELETE FROM `alert_messages` WHERE `EVENT_ID` = '5023';
DELETE FROM `alert_messages` WHERE `EVENT_ID` = '5024';
DELETE FROM `alert_messages` WHERE `EVENT_ID` = '5025';
DELETE FROM `alert_messages` WHERE `EVENT_ID` = '5026';

