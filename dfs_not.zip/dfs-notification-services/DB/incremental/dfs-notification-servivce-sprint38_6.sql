-- (for Azure dev env only)
use dfs_notification_service_2001;
UPDATE `alert_messages` SET `TEMPLATE_BODY` = '<#> OTP_VALUE is the OTP for mobile number verification on Citrus . It is valid for 1 mins. Do not share this OTP with anyone.M40ka6OAjCj' WHERE (`EVENT_ID` = '1012');
UPDATE `alert_messages` SET `TEMPLATE_BODY` = '<#> OTP_VALUE is the OTP to reset your secure PIN on Citrus . It is valid for 10 mins. Do not share this OTP with anyone.M40ka6OAjCj' WHERE (`EVENT_ID` = '1001');

-- (for QA env only)
use dfs_notification_service_2001;
UPDATE `alert_messages` SET `TEMPLATE_BODY` = '<#> OTP_VALUE is the OTP to reset your secure PIN on Citrus . It is valid for 10 mins. Do not share this OTP with anyone.ltPf9u2j/if' WHERE (`EVENT_ID` = '1001');