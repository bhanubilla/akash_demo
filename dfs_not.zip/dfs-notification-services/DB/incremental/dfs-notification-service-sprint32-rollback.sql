use dfs_notification_service;
DELETE FROM  alert_messages where EVENT_ID = 5017;