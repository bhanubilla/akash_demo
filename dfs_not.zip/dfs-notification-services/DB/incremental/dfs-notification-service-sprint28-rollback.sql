use dfs_notification_service;

delete from alert_messages where EVENT_ID='5017';