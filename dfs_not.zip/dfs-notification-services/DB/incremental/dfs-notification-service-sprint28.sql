use dfs_notification_service;

insert into alert_messages(EVENT_ID, ALERT_TYPE, TEMPLATE_BODY, STATUS, TEMPLATE_SUBJECT)
values (5017, 'EMAIL',
'Dear {Name}, <br/> Thanks for being a loyal {ProductName} customer. <br/> PFB the link for downloading the account statement for the requested period. <br/> {PdfUrl} <br/> Regards, <br/> BankEzy Wallet Team',
'1', 'BankEzy Wallet Account Statement for the period {FromDate} to {ToDate}');