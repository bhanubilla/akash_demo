use `dfs_notification_service_2001`;
DELETE FROM alert_messages where EVENT_ID = 1001;
DELETE FROM alert_messages where EVENT_ID = 1012;
DELETE FROM alert_messages where EVENT_ID = 1002;
DELETE FROM alert_messages where EVENT_ID = 1003;
DELETE FROM alert_messages where EVENT_ID = 1004;
DELETE FROM alert_messages where EVENT_ID = 1005;
DELETE FROM alert_parameters WHERE PARAM_ID='CONFIG_VALUE_MESSAGE_FROM_ID';
UPDATE alert_parameters SET param_value = 'test@bankezy.co' WHERE (param_id = 'EMAIL_ALERT_FROM_EMAIL');
DELETE FROM alert_messages WHERE EVENT_ID = 1101;
DELETE FROM alert_parameters WHERE PARAM_ID='CONFIG_VALUE_MESSAGE_FROM_ID';
DELETE FROM alert_parameters WHERE PARAM_ID='CONFIG_VALUE_MESSAGE_GROUP_ID';
DELETE FROM alert_parameters WHERE PARAM_ID='ALERT_BIN_ID';

use `dfs_notification_service`;
DELETE FROM alert_parameters WHERE PARAM_ID='CONFIG_VALUE_MESSAGE_FROM_ID';
DELETE FROM alert_parameters WHERE PARAM_ID='CONFIG_VALUE_MESSAGE_GROUP_ID';
DELETE FROM alert_parameters WHERE PARAM_ID='ALERT_BIN_ID';
