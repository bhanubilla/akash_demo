USE dfs_notification_service;

INSERT INTO `alert_messages`
(`EVENT_ID`,`ALERT_TYPE`,`TEMPLATE_BODY`,`STATUS`,`TEMPLATE_SUBJECT`) VALUES
 (5021, 'SMS','Dear CUSTOMER_NAME,You have successfully transferred CURRENCY  AMOUNT to XXXLAST_4_DIGITS_OF_RECIPIENT_MOBILE NUMBER - WIBMO', 1, 'Send Money Successful');

 INSERT INTO `alert_messages`
(`EVENT_ID`,`ALERT_TYPE`,`TEMPLATE_BODY`,`STATUS`,`TEMPLATE_SUBJECT`) VALUES
 (5022, 'SMS','Dear CUSTOMER_NAME, Congratulations! You have successfully activated your account - WIBMO', 1, 'Wallet Created');

 INSERT INTO `alert_messages`
(`EVENT_ID`,`ALERT_TYPE`,`TEMPLATE_BODY`,`STATUS`,`TEMPLATE_SUBJECT`) VALUES
 (5023, 'SMS','Dear CUSTOMER_NAME,Your account has been successfully loaded with INR AMOUNT. - WIBMO', 1, 'Load Money Successful');

 INSERT INTO `alert_messages`
(`EVENT_ID`,`ALERT_TYPE`,`TEMPLATE_BODY`,`STATUS`,`TEMPLATE_SUBJECT`) VALUES
 (5024, 'SMS','Dear CUSTOMER_NAME,You have successfully transferred CURRENCY  AMOUNT to XXXLAST 4 DIGITS OF ACCOUNT NUMBER - WIBMO', 1, 'Send Money Successful');

 INSERT INTO `alert_messages`
 (`EVENT_ID`,`ALERT_TYPE`,`TEMPLATE_BODY`,`STATUS`,`TEMPLATE_SUBJECT`) VALUES
 (5025, 'SMS','Dear CUSTOMER_NAME, you have done a purchase of INR AMOUNT using your account. Your updated balance is CLOSING_AMOUNT - WIBMO', 1, 'Wallet Card Transaction');

 INSERT INTO `alert_messages`
(`EVENT_ID`,`ALERT_TYPE`,`TEMPLATE_BODY`,`STATUS`,`TEMPLATE_SUBJECT`) VALUES
 (5026, 'SMS','ALERT: You have spent CURRENCY AMOUNT via DEBITCREDIT card XXLAST_4_DIGITS at MERCHANT_NAME. Not you? call CUSTOMER_CARE_NUMBER - WIBMO', 1, 'Linked Card Transaction');