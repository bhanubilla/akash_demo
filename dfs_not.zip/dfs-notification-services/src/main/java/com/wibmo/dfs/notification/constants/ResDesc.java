package com.wibmo.dfs.notification.constants;

/*
@Author pavan.konakanchi 
Created on : 28/04/2021 - 3:17 PM
*/
public final class ResDesc {
    public static final String SUCCESS = "SUCCESS";
    public static final String FAILED = "FAILED";
    public static final String INVALID_DATA = "BAD INPUT";
    public static final String IN_PROCESS = "Notification service in process";
    private ResDesc() {
    }
}
