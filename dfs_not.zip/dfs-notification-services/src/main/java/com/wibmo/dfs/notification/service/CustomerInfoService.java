package com.wibmo.dfs.notification.service;

import com.wibmo.dfs.notification.pojo.*;

/*
@Author pavan.konakanchi 
Created on : 04/08/2021 - 11:57 AM
*/
public interface CustomerInfoService {
    boolean saveDeviceInfo(int programId, DeviceInfo deviceInfo);
    boolean mapDevice(int programId, CustomerDeviceMapping deviceInfo);
    boolean mapMobile(int programId, CustomerMobileInfo deviceInfo);
    boolean mapEmail(int programId, CustomerEmailInfo deviceInfo);
    boolean deleteEmail(int programId, CustomerEmailInfo deviceInfo);
    boolean subscribeForWhatsapp(int programId, SubscriptionInfo subscriptionInfo);
}
