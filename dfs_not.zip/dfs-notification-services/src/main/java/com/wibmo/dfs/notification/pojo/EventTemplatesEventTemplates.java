package com.wibmo.dfs.notification.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author bhanu.prasad
 *
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class EventTemplatesEventTemplates {
	@JsonProperty("PASSWORD_EVENT")
	private PasswordEvent passwordEvent;
}
