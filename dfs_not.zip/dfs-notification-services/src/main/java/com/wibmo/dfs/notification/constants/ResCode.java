package com.wibmo.dfs.notification.constants;

/*
@Author pavan.konakanchi 
Created on : 28/04/2021 - 3:17 PM
*/
public final class ResCode {
    public static final int SUCCESS = 100;
    public static final int FAILED = 50;
    public static final int INVALID_DATA = 51;


    private ResCode() {
    }
}
