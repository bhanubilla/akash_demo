package com.wibmo.dfs.notification.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.wibmo.dfs.notification.dao.AlertMessagesDAO;
import com.wibmo.dfs.notification.dao.CustomerInfoDAO;
import com.wibmo.dfs.notification.entity.AlertMessage;
import com.wibmo.dfs.notification.exception.DeviceUnregisteredException;
import com.wibmo.dfs.notification.pojo.AlertRequest;
import com.wibmo.dfs.notification.pojo.DeviceInfo;
import com.wibmo.dfs.notification.pojo.FCMData;
import com.wibmo.dfs.notification.pojo.NotificationRequest;
import com.wibmo.dfs.notification.pojo.PushNotificationRequest;
import com.wibmo.dfs.notification.pojo.WibmoResponse;
import com.wibmo.dfs.notification.service.NotificationService;

import lombok.extern.slf4j.Slf4j;

/**
 * Service to send the notification. It can be sms , email,push or whats app
 * notifications. Depends upon event id and request data (like sms,email,push or
 * whatsapp), this service decides which are the notifications to be send
 * 
 * @author palash.bera
 */
@Service
@Slf4j
public class NotificationServiceImpl implements NotificationService {
	@Autowired
	private AlertMessagesDAO alertMessagesDAO;
	@Autowired
	private AlertEmailService alertEmailService;
	@Autowired
	private AlertSmsService alertSmsService;
	@Autowired
	private CustomerInfoDAO customerInfoDAO;
	@Autowired
	private PushNotificationService pushNotificationService;

	@Async
	public WibmoResponse sendNotification(int programId, AlertRequest alert) {
		log.info("Thread 2----------> {}" + Thread.currentThread().getName());
		log.debug("executing sendNotification(int programId, AlertRequest alert)--> ");
		log.info("Notification requested for Email: {} mobile:{} ", alert.getEmailId(), alert.getMobileNumber());
		
		WibmoResponse response = null;
		List<AlertMessage> alertMessages = alertMessagesDAO.findByProgramIdAndEventId(programId, alert.getEventId());
		populateRequiredDetails(programId, alertMessages, alert);

		for (AlertMessage messages : alertMessages) {
			if (messages.getStatus() == 1) {
				switch (messages.getAlertType()) {

					case "EMAIL":
						response = this.handleEmail(programId, messages, alert);
						break;
	
					case "SMS":
						response = this.handleSMS(programId, messages, alert);
						break;
	
					case "PUSH":
						response = this.handlePushNotifcation(programId, messages, alert);
						break;
						
					case "WHATSAPP":
						log.error("Whatsapp is not enabled");
						break;
						
					default:
						break;
				}
			}
		}
		return response;
	}


	@Override
	public WibmoResponse sendPushNotification(int programId, PushNotificationRequest alertRequest) {
		FCMData fcmData = new FCMData();
		fcmData.setBody(alertRequest.getBody());
		fcmData.setCollapseKey(alertRequest.getMessageKey());
		fcmData.setTitle(alertRequest.getTitle());
		fcmData.setImage(alertRequest.getImageUrl());
		fcmData.setPrority(true);
		fcmData.setTopic(alertRequest.getTopic());
		fcmData.setToken(alertRequest.getFcmToken());

		if (alertRequest.getData() == null) {
			Map<String, String> data = new HashMap<>();
			data.put("actionCode", alertRequest.getActionCode() != null ? alertRequest.getActionCode() : "");
			data.put("actionData", alertRequest.getActionData() != null ? alertRequest.getActionData() : "");
			alertRequest.setData(data);
		} else {
			alertRequest.getData().put("actionCode",
					alertRequest.getActionCode() != null ? alertRequest.getActionCode() : "");
			alertRequest.getData().put("actionData",
					alertRequest.getActionData() != null ? alertRequest.getActionData() : "");
		}
		fcmData.setData(alertRequest.getData());
		if (alertRequest.getTtl() == 0) {
			log.info("ttl is not sent setting the default 30 days");
			alertRequest.setTtl(30 * 24 * 60 * 60);
		}
		fcmData.setTtl(alertRequest.getTtl());
		try {
			return pushNotificationService.sendNotification(programId, fcmData.makePayload());
		} catch (DeviceUnregisteredException e) {
			e.printStackTrace();
			return null;
		}

	}

	public String formatBody(String template, Map<String, String> replacements) {
		if (replacements == null) {
			return template;
		}
		Pattern pattern = Pattern.compile("\\{(.+?)\\}");
		Matcher matcher = pattern.matcher(template);
		StringBuffer buffer = new StringBuffer();
		while (matcher.find()) {
			Object replacement = replacements.get(matcher.group(1));
			if (replacement != null) {
				matcher.appendReplacement(buffer, "");
				buffer.append(replacement);
			}
		}
		matcher.appendTail(buffer);
		return buffer.toString();
	}

	private void populateRequiredDetails(int programId, List<AlertMessage> alertMessages, AlertRequest alert) {
		var isPushEnabled = false;

		for (AlertMessage messages : alertMessages) {
			if ("PUSH".equalsIgnoreCase(messages.getAlertType()) && (messages.getStatus() == 1)) {
				isPushEnabled = true;
			}
		}

		if (isPushEnabled && !StringUtils.hasText(alert.getFcmToken()) && alert.getAccountNumber() != 0) {
			DeviceInfo deviceInfo = customerInfoDAO.findDeviceInfoByAccountNumber(programId, alert.getAccountNumber());
			if (deviceInfo != null) {
				alert.setFcmToken(deviceInfo.getFcmToken());
				alert.setDeviceId(deviceInfo.getDeviceId());
			}
		}
	}
	
	private WibmoResponse handleEmail(int programId, AlertMessage messages, AlertRequest alert) {

		WibmoResponse response = null;
		if (StringUtils.hasText(alert.getEmailId())) {
			NotificationRequest notificationRequest = new NotificationRequest();
			notificationRequest.setProgramId(programId);
			notificationRequest.setEventId(alert.getEventId());
			notificationRequest.setPlaceHolders(alert.getPlaceHolders());
			notificationRequest.setAccountNumber(alert.getAccountNumber());
			notificationRequest.setEmailId(alert.getEmailId());
			notificationRequest.setBody(formatBody(messages.getTemplateBody(), alert.getPlaceHolders()));
			notificationRequest.setSubject(formatBody(messages.getTemplateSubject(), alert.getPlaceHolders()));
			response = alertEmailService.sendNotificationToUser(notificationRequest);
		} else {
			log.warn("email address not available in request.");
		}
		
		return response;
	}

	private WibmoResponse handleSMS(int programId, AlertMessage messages, AlertRequest alert) {

		WibmoResponse response = null;
		if (StringUtils.hasText(alert.getMobileNumber())) {
			NotificationRequest notificationRequest = new NotificationRequest();
			notificationRequest.setProgramId(programId);
			notificationRequest.setEventId(alert.getEventId());
			notificationRequest.setMobileNumber(alert.getMobileNumber());
			notificationRequest.setPlaceHolders(alert.getPlaceHolders());
			notificationRequest.setAccountNumber(alert.getAccountNumber());
			notificationRequest.setSubject(formatBody(messages.getTemplateSubject(), alert.getPlaceHolders()));
			notificationRequest.setBody(formatBody(messages.getTemplateBody(), alert.getPlaceHolders()));
			response =  alertSmsService.sendNotificationToUser(notificationRequest);
		} else {
			log.warn("Mobile number is not valid or not available request.");
		}
		return response;
	}

	private WibmoResponse handlePushNotifcation(int programId, AlertMessage messages, AlertRequest alert) {

		WibmoResponse response = null;
		if (StringUtils.hasText(alert.getFcmToken())) {
			FCMData fcmData = new FCMData();
			Map<String, String> data = alert.getPlaceHolders();
			fcmData.setBody(formatBody(messages.getTemplateSubject(), alert.getPlaceHolders()));
			fcmData.setCollapseKey(UUID.randomUUID().toString());
			fcmData.setTitle(formatBody(messages.getTemplateSubject(), alert.getPlaceHolders()));
			fcmData.setPrority(true);
			fcmData.setToken(alert.getFcmToken());
			data.put("body", formatBody(messages.getTemplateBody(), alert.getPlaceHolders()));
			data.put("title", formatBody(messages.getTemplateSubject(), alert.getPlaceHolders()));
			fcmData.setData(data);
			fcmData.setTtl(7 * 24 * 60 * 60); // 7days
			try {
				response = pushNotificationService.sendNotification(programId, fcmData.makePayload());
			} catch (DeviceUnregisteredException e) {
				customerInfoDAO.unregisterPushNotification(programId, alert.getDeviceId());
			}
		}
		
		return response;
	}
}
