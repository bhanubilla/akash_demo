package com.wibmo.dfs.notification.service.impl;

import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;
import com.wibmo.dfs.notification.service.FireBaseService;
import com.wibmo.dfs.hsm_client.CryptoException;
import com.wibmo.dfs.hsm_client.CryptoHandler;
import com.wibmo.dfs.notification.constants.AlertParamConstants;
import com.wibmo.dfs.notification.constants.ResCode;
import com.wibmo.dfs.notification.constants.ResDesc;
import com.wibmo.dfs.notification.dao.AlertParametersDAO;
import com.wibmo.dfs.notification.exception.DeviceUnregisteredException;
import com.wibmo.dfs.notification.pojo.WibmoResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Service for push notification
 *
 * @author Pavan Konakanchi
 */
@Service
@Slf4j
public class PushNotificationService {
	@Autowired
	private FireBaseService fireBaseService;

	@Autowired
	AlertParametersDAO alertParametersDAO;

	@Autowired
	CryptoHandler cryptoHandler;

	/**
	 * Sends the push notification to the user by invoking google push notification
	 * service
	 *
	 * @param request
	 * @return WibmoResponse
	 */
	public WibmoResponse sendNotification(int programId, Message request) throws DeviceUnregisteredException {
		log.info("Executing PushNotifictionService sendNotification(int programId, Message request)-->");
		long start = System.currentTimeMillis();
		String encFirebaseJson = alertParametersDAO
				.findByProgramIdAndParamId(programId, AlertParamConstants.ALERT_FIREBASE_BANKEZY_PUSH_JSON)
				.getParamValue();
		String decFirebaseJson = "";
		try {
			if(encFirebaseJson!=null) {
			decFirebaseJson = cryptoHandler.getClearData(encFirebaseJson);
			} else {
				log.error("Firebase application json data is empty");
			}
		} catch (CryptoException e) {
			e.printStackTrace();
		}

		try {

			boolean hasBeenInitialized=false;
			List<FirebaseApp> firebaseApps = FirebaseApp.getApps();
			log.info("Firebase Apps -> {}", firebaseApps);
			FirebaseApp firebaseApp = null;
			for(FirebaseApp app : firebaseApps){
				if(app.getName().equals(FirebaseApp.DEFAULT_APP_NAME)){
					hasBeenInitialized=true;
					firebaseApp = app;
				}
			}
			if(!hasBeenInitialized) {
				firebaseApp = fireBaseService.getInstance(programId, decFirebaseJson);
			}
			log.info("Firebase App -> {}", firebaseApp);
			FirebaseMessaging firebaseMessaging = FirebaseMessaging.getInstance(firebaseApp);
			String message = firebaseMessaging.send(request);
			long end = System.currentTimeMillis();
			long elapsedTime = end - start;
			log.info("time taken for PushNotifictionService sendNotification(int programId, Message request)--> "+elapsedTime);
			log.info("firebase response: {}", message);
			return new WibmoResponse(ResCode.SUCCESS, ResDesc.SUCCESS);
		} catch (FirebaseMessagingException e) {
			log.error("error", e);
			switch (e.getMessagingErrorCode().name()) {
			case "INVALID_ARGUMENT","UNSPECIFIED_ERROR":
				return new WibmoResponse(ResCode.FAILED, ResDesc.FAILED);
			case "UNREGISTERED":
				throw new DeviceUnregisteredException();
			default:
				break;
			}

			log.warn("error while sending notification:{}", e.getMessage(), e);
		}
		return new WibmoResponse(ResCode.FAILED, ResDesc.FAILED);
	}

}
