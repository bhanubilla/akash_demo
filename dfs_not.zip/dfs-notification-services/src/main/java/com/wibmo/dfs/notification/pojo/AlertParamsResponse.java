package com.wibmo.dfs.notification.pojo;

import com.wibmo.dfs.notification.entity.AlertParameter;
import lombok.Data;

import java.util.List;

/*
@Author pavan.konakanchi 
Created on : 09/08/2021 - 5:13 PM
*/
@Data
public class AlertParamsResponse extends WibmoResponse {
    List<AlertParameter> parameters;

    public AlertParamsResponse(int resCode, String resDesc) {

        this.setResCode(resCode);
        this.setResDesc(resDesc);
    }
}
