package com.wibmo.dfs.notification.service.impl;

import com.wibmo.dfs.notification.dao.CustomerInfoDAO;
import com.wibmo.dfs.notification.pojo.*;
import com.wibmo.dfs.notification.service.CustomerInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/*
@Author pavan.konakanchi 
Created on : 04/08/2021 - 12:31 PM
*/
@Slf4j
@Service
public class CustomerInfoServiceImpl implements CustomerInfoService {

    CustomerInfoDAO customerInfoDAO;
    @Override
    public boolean mapDevice(int programId, CustomerDeviceMapping deviceInfo) {
        try {
            customerInfoDAO.mapDeviceInfo(programId,deviceInfo);
            return true;
        }catch (Exception e){
            log.error("Error while saving device info:{}",e);
            return false;
        }
    }


    @Override
    public boolean mapMobile(int programId, CustomerMobileInfo deviceInfo) {
        try {
            customerInfoDAO.mapMobile(programId,deviceInfo);
            return true;
        }catch (Exception e){
            log.error("Error while saving mobile info:{}",e);
            return false;
        }
    }

    @Override
    public boolean mapEmail(int programId, CustomerEmailInfo deviceInfo) {
        try {
            customerInfoDAO.mapEmail(programId,deviceInfo);
            return true;
        }catch (Exception e){
            log.error("Error while saving email info:{}",e);
            return false;
        }
    }

    @Override
    public boolean deleteEmail(int programId, CustomerEmailInfo deviceInfo) {
        try {
            customerInfoDAO.deleteEmail(programId,deviceInfo);
            return true;
        }catch (Exception e){
            log.error("Error while deleteing email info:{}",e);
            return false;
        }
    }

    @Override
    public boolean subscribeForWhatsapp(int programId, SubscriptionInfo subscriptionInfo) {
        try {
            customerInfoDAO.updateWhatsAppSubscription(programId,subscriptionInfo);
            return true;
        }catch (Exception e){
            log.error("Error while saving whatsapp subscription info:{}",e);
            return false;
        }
    }
    @Override
    public boolean saveDeviceInfo(int programId, DeviceInfo deviceInfo) {
        try {
            customerInfoDAO.saveDeviceInfo(programId, deviceInfo);
            return true;
        } catch (Exception e) {
            log.error("Error while saving device info:{}", e);
            return false;
        }

    }
}
