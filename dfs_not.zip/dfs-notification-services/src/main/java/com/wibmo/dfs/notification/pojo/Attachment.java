package com.wibmo.dfs.notification.pojo;

import lombok.Data;

@Data
public class Attachment {
    private String content; //Base64encoded string
    private String name;
    private String contentType;
}
