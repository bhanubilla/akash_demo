package com.wibmo.dfs.notification.kafka;

/*
@Author pavan.konakanchi 
Created on : 12/08/2021 - 2:07 PM
*/
public class ProcessMessageException extends Exception {
}
