package com.wibmo.dfs.notification.controller;

import brave.Tracer;
import com.wibmo.dfs.notification.constants.ResCode;
import com.wibmo.dfs.notification.constants.ResDesc;
import com.wibmo.dfs.notification.pojo.DeviceInfo;
import com.wibmo.dfs.notification.pojo.WibmoResponse;
import com.wibmo.dfs.notification.service.CustomerInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/*
@Author pavan.konakanchi
Created on : 28/04/2021 - 9:44 AM
*/
@RequestMapping("/device")
@RestController
public class DeviceInfoController {
    @Autowired
    CustomerInfoService deviceInfoService;
    @Autowired
    private Tracer tracer;

    @PostMapping("/save")
    public WibmoResponse saveDeviceInfo(@RequestHeader("X-PROGRAM-ID") int programId, @RequestBody DeviceInfo deviceInfo) {

        boolean reloaded = deviceInfoService.saveDeviceInfo(programId, deviceInfo);
        if (reloaded) {
            return new WibmoResponse(ResCode.SUCCESS, ResDesc.SUCCESS,tracer.currentSpan().context().traceIdString());
        } else {
            return new WibmoResponse(ResCode.FAILED, ResDesc.FAILED,tracer.currentSpan().context().traceIdString());
        }
    }


}
