package com.wibmo.dfs.notification.exception;

/*
@Author pavan.konakanchi 
Created on : 09/08/2021 - 1:32 PM
*/
public class DeviceUnregisteredException extends Exception {
}
