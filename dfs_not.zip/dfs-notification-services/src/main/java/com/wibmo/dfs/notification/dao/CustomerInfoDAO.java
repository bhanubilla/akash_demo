package com.wibmo.dfs.notification.dao;

import com.wibmo.dfs.notification.entity.CustomerInfo;
import com.wibmo.dfs.notification.pojo.*;

/*
@Author pavan.konakanchi 
Created on : 04/08/2021 - 12:17 PM
*/
public interface CustomerInfoDAO {

    void saveDeviceInfo(int programId, DeviceInfo deviceInfo);
    void mapDeviceInfo(int programId, CustomerDeviceMapping deviceInfo);

    void mapMobile(int programId, CustomerMobileInfo deviceInfo);

    void updateWhatsAppSubscription(int programId, SubscriptionInfo subscriptionInfo);

    void deleteEmail(int programId, CustomerEmailInfo deviceInfo);

    void mapEmail(int programId, CustomerEmailInfo deviceInfo);

    CustomerInfo findByAccountNumber(int programId, long accountNumber);
    DeviceInfo findDeviceInfoByAccountNumber(int programId, long accountNumber);

    void unregisterPushNotification(int programId, String deviceId);

}
