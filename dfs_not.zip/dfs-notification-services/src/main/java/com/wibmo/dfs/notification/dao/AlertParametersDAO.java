package com.wibmo.dfs.notification.dao;

import com.wibmo.dfs.notification.entity.AlertParameter;

import java.util.List;

/**
 * DAO for alert parameters
 * @author palash.bera
 */
public interface AlertParametersDAO  {
    public AlertParameter findByProgramIdAndParamId(Integer programId , String paramId);
    public void reload(Integer programId , String paramId);
    public void reload(Integer programId);
    public List<AlertParameter> listByProgramId(Integer programId);

}
