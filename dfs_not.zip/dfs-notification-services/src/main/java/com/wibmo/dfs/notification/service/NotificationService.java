package com.wibmo.dfs.notification.service;

import com.wibmo.dfs.notification.pojo.AlertRequest;
import com.wibmo.dfs.notification.pojo.PushNotificationRequest;
import com.wibmo.dfs.notification.pojo.WibmoResponse;

public interface NotificationService {
	public WibmoResponse sendNotification(int programId,AlertRequest alertRequest);
	public WibmoResponse sendPushNotification(int programId, PushNotificationRequest alertRequest);
}
