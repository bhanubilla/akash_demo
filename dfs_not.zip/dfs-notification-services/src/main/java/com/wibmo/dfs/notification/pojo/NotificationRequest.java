package com.wibmo.dfs.notification.pojo;

import lombok.Data;

@Data
public class NotificationRequest extends AlertRequest {
	
	private static final long serialVersionUID = -8656193191110729288L;

	private String subject;
    private String body;
    private int programId;

}
