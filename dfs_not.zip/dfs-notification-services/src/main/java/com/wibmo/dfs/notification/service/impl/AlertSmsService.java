package com.wibmo.dfs.notification.service.impl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.notification.constants.AlertParamConstants;
import com.wibmo.dfs.notification.constants.ResCode;
import com.wibmo.dfs.notification.constants.ResDesc;
import com.wibmo.dfs.notification.dao.AlertMessagesDAO;
import com.wibmo.dfs.notification.dao.AlertParametersDAO;
import com.wibmo.dfs.notification.pojo.AlertServiceRequest;
import com.wibmo.dfs.notification.pojo.ConfigValue;
import com.wibmo.dfs.notification.pojo.ConfigValueEventTemplates;
import com.wibmo.dfs.notification.pojo.EventTemplatesEventTemplates;
import com.wibmo.dfs.notification.pojo.NotificationRequest;
import com.wibmo.dfs.notification.pojo.PasswordEvent;
import com.wibmo.dfs.notification.pojo.Server;
import com.wibmo.dfs.notification.pojo.UamAlertConfig;
import com.wibmo.dfs.notification.pojo.WibmoResponse;

import lombok.extern.slf4j.Slf4j;

/**
 * Service for sms notification
 * 
 * @author bhanu.prasad
 *
 */
@Slf4j
@Service
public class AlertSmsService {

	@Autowired
	AlertParametersDAO alertParametersDAO;
	@Autowired
	AlertMessagesDAO alertMessagesDAO;
	@Autowired
	RestTemplate restTemplate;

	/**
	 * Sends the sms notification to the user by invoking sms server
	 * 
	 * @param alert
	 * @return WibmoResponse
	 */
	public WibmoResponse sendNotificationToUser(NotificationRequest alert) {
		log.debug("Executing sendNotificationToUser (NotificationRequest alert)-->");
		String emailServerUrl = alertParametersDAO
				.findByProgramIdAndParamId(alert.getProgramId(), AlertParamConstants.EMAIL_ALERT_SERVER_URL)
				.getParamValue();
		String apiKey = alertParametersDAO
				.findByProgramIdAndParamId(alert.getProgramId(), AlertParamConstants.SMS_API_KEY).getParamValue();
		String apiUser = alertParametersDAO
				.findByProgramIdAndParamId(alert.getProgramId(), AlertParamConstants.SMS_API_USER).getParamValue();
		String msgServerUrl = alertParametersDAO
				.findByProgramIdAndParamId(alert.getProgramId(), AlertParamConstants.ALERT_SMS_SERVER_URL)
				.getParamValue();
		String msgServerConnType = alertParametersDAO
				.findByProgramIdAndParamId(alert.getProgramId(), AlertParamConstants.ALERT_SMS_SERVER_CONNECTION_TYPE)
				.getParamValue();
		log.info("programId for configValueMessageFromId: ", alert.getProgramId());
		String configValueMessageFromId = alertParametersDAO.findByProgramIdAndParamId(alert.getProgramId(), AlertParamConstants.CONFIG_VALUE_MESSAGE_FROM_ID).getParamValue();
		log.info("configValueMessageFromId: ", configValueMessageFromId);
		log.info("programId for configValueMessageGroupId ", alert.getProgramId());
		String configValueMessageGroupId = alertParametersDAO.findByProgramIdAndParamId(alert.getProgramId(), AlertParamConstants.CONFIG_VALUE_MESSAGE_GROUP_ID).getParamValue();
		log.info("configValueMessageGroupId: ", configValueMessageGroupId);
		String alertBinId = alertParametersDAO.findByProgramIdAndParamId(alert.getProgramId(), AlertParamConstants.ALERT_BIN_ID).getParamValue();
		String alertSmsCountryCode= alertParametersDAO.findByProgramIdAndParamId(alert.getProgramId(), AlertParamConstants.ALERT_SMS_COUNTRY_CODE_INDIA).getParamValue();

		if (msgServerUrl == null) {
			log.error(AlertParamConstants.ALERT_SMS_SERVER_URL + " is empty");
		}
		AlertServiceRequest alertServiceReq = createAlertServiceRequest(alert, alertBinId, alertSmsCountryCode);
		ConfigValue configValue = createConfigValue(alert, configValueMessageFromId, configValueMessageGroupId);
		createMessageServer(msgServerUrl, msgServerConnType, configValue);
		PasswordEvent passwordEvent = createPasswordEvent(alert);
		UamAlertConfig uamAlertConfig = createUamAlertConfig(configValue, passwordEvent);
		alertServiceReq.setUamAlertConfig(uamAlertConfig);

		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json;charset=utf-8");
		headers.set("X-API-KEY", apiKey);
		headers.set("X-API-User", apiUser);
		headers.set("X-PROGRAM-ID", Integer.toString(alert.getProgramId()));

		HttpEntity<Object> httpEntity = new HttpEntity<>(alertServiceReq, headers);
		ObjectMapper obj = new ObjectMapper();
		try {
			String reqJson = obj.writeValueAsString(alertServiceReq);
			log.debug("sending sms : alertServiceRequestObj : {}", reqJson);
		} catch (JsonProcessingException e) {
			
			e.printStackTrace();
		}
		if (emailServerUrl != null) {
			try{
				ResponseEntity<Object> result = restTemplate.exchange(emailServerUrl, HttpMethod.POST, httpEntity,
						Object.class);
				Object resultBody = result.getBody();
				if (resultBody != null) {
					String responseStr = resultBody.toString();
					if (!responseStr.contains("failed")) {
						log.info("sms delivery status for " + alert.getMobileNumber() + " is " + ResDesc.SUCCESS);
						return new WibmoResponse(ResCode.SUCCESS, ResDesc.SUCCESS);
					}
				}
			}catch(Exception ex){
				log.error("Exception while sending sms :: ",ex);
			}
		} else {
			log.error(AlertParamConstants.EMAIL_ALERT_SERVER_URL + " is empty");
		}
		log.info("sms delivery status for " + alert.getMobileNumber() + " is " + ResDesc.SUCCESS);
		return new WibmoResponse(ResCode.SUCCESS, ResDesc.SUCCESS);
	}

	private UamAlertConfig createUamAlertConfig(ConfigValue configValue, PasswordEvent passwordEvent) {
		EventTemplatesEventTemplates eventTempEventTemplates = new EventTemplatesEventTemplates();
		eventTempEventTemplates.setPasswordEvent(passwordEvent);
		ConfigValueEventTemplates configValueEventTemplates = new ConfigValueEventTemplates();
		configValueEventTemplates.setEventTemplates(eventTempEventTemplates);
		configValue.setEventTemplates(configValueEventTemplates);
		UamAlertConfig uamAlertConfig = new UamAlertConfig();
		uamAlertConfig.setConfigValue(configValue);
		return uamAlertConfig;
	}

	private ConfigValue createConfigValue(NotificationRequest alert, String configValueMessageFromId, String configValueMessageGroupId) {
		ConfigValue configValue = new ConfigValue();
		configValue.setMessageGroupId(configValueMessageGroupId);
		configValue.setMessageServerType(AlertParamConstants.CONFIG_VALUE_MESSAGE_SERVER_TYPE);
		configValue.setMessageFromId(configValueMessageFromId);
		configValue.setMessageTemplate(alert.getBody());
		configValue.setSendSMS(true);
		return configValue;
	}

	private AlertServiceRequest createAlertServiceRequest(NotificationRequest alert, String alertBinId, String alertSmsCountryCode) {
		log.info("Creating AlertServiceRequest obj-->");
		Timestamp currentDateTime = new Timestamp(new Date().getTime());
		UUID requestId = UUID.randomUUID();
		AlertServiceRequest alertServiceReq = new AlertServiceRequest();
		alertServiceReq.setBankId(alert.getProgramId());
		alertServiceReq.setBinId(alertBinId);
		alertServiceReq.setProductId(Integer.toString(alert.getEventId()));
		alertServiceReq.setRequestId(requestId);
		alertServiceReq.setEventId(AlertParamConstants.ALERT_PASSWORD_EVENT);
		alertServiceReq.setMobileNumber(Long.parseLong(alertSmsCountryCode+alert.getMobileNumber()));
		alertServiceReq.setTimeStamp(currentDateTime);
		alertServiceReq.setTransactionId(requestId);
		alertServiceReq.setAlertTypeId(AlertParamConstants.ALERT_SERVICE_ALERT_TYPE_SMS);
		alertServiceReq.setAlertPriority(AlertParamConstants.ALERT_PRIORITY_ZERO);
		alertServiceReq.setDynamicFieldCount(5);
		alertServiceReq.setDynamicFields(alert.getPlaceHolders());
		return alertServiceReq;
	}

	private PasswordEvent createPasswordEvent(NotificationRequest alert) {
		PasswordEvent passwordEvent = new PasswordEvent();
		passwordEvent.setSubject(alert.getSubject());
		passwordEvent.setEnabled(true);
		passwordEvent.setText(alert.getBody());
		return passwordEvent;
	}

	private void createMessageServer(String msgServerUrl, String msgServerConnType, ConfigValue configValue) {
		Server messageServer = new Server();
		messageServer.setEndpointUrl(msgServerUrl);
		messageServer.setConnectType(msgServerConnType);
		configValue.setMessageServer(messageServer);
	}
}
