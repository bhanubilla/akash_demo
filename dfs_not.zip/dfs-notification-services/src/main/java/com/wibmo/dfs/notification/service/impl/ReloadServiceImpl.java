package com.wibmo.dfs.notification.service.impl;

import com.wibmo.dfs.notification.dao.AlertMessagesDAO;
import com.wibmo.dfs.notification.dao.AlertParametersDAO;
import com.wibmo.dfs.notification.entity.AlertMessage;
import com.wibmo.dfs.notification.entity.AlertParameter;
import com.wibmo.dfs.notification.service.ReloadService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/*
@Author pavan.konakanchi 
Created on : 28/04/2021 - 1:24 PM
*/
@Service
@Slf4j
public class ReloadServiceImpl implements ReloadService {
    @Autowired
    private AlertMessagesDAO alertMessagesDAO;

    @Autowired
    private AlertParametersDAO alertParametersDAO;
    @Override
    public List<AlertMessage> listAlertMessages(Integer programId, Integer eventId) {
        List<AlertMessage> messages = null;
        try{
          messages =  alertMessagesDAO.findByProgramIdAndEventId(programId,eventId);
        }catch (Exception e){
            log.warn(e.getMessage(),e);
        }
        return messages;
    }

    @Override
    public List<AlertMessage> listAlertMessages(Integer programId) {
        List<AlertMessage> messages = null;
        try{
            messages =  alertMessagesDAO.listAll(programId);
        }catch (Exception e){
            log.warn(e.getMessage(),e);
        }
        return messages;
    }

    @Override
    public boolean reloadAlertMessages(Integer programId) {

        try{
            alertMessagesDAO.reload(programId);
            return  true;
        }catch (Exception e){
            log.warn(e.getMessage(),e);
        }
        return false;
    }

    @Override
    public boolean reloadAlertMessages(Integer programId, int eventId) {
        try{
            alertMessagesDAO.reloadByEventId(programId,eventId);
            return  true;
        }catch (Exception e){
            log.warn(e.getMessage(),e);
        }
        return false;
    }

    @Override
    public AlertParameter findAlertParameter(Integer programId, String paramId) {
       AlertParameter alertParameter = null;
       try{
            alertParameter =  alertParametersDAO.findByProgramIdAndParamId(programId,paramId);
        }catch (Exception e){
            log.warn(e.getMessage(),e);
        }
        return  alertParameter;
    }

    @Override
    public boolean reloadAlertParameters(Integer programId, String paramId) {
        try{
            alertParametersDAO.reload(programId,paramId);
            return  true;
        }catch (Exception e){
            log.warn(e.getMessage(),e);
        }
        return false;
    }

    @Override
    public boolean reloadAlertParameters(Integer programId) {
        try{
            alertParametersDAO.reload(programId);
            return  true;
        }catch (Exception e){
            log.warn(e.getMessage(),e);
        }
        return false;
    }

    @Override
    public List<AlertParameter> listAlertParameters(Integer programId) {
        List<AlertParameter> alertParameter = null;
        try{
            alertParameter =  alertParametersDAO.listByProgramId(programId);
        }catch (Exception e){
            log.warn(e.getMessage(),e);
        }
        return  alertParameter;
    }
}
