package com.wibmo.dfs.notification.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/*
@Author pavan.konakanchi 
Created on : 03/08/2021 - 4:39 PM
*/
@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DeviceInfo {
    @NotNull
    @NotEmpty
    private String deviceId;
    @NotNull
    @NotEmpty
    private String osType;
    @NotNull
    @NotEmpty
    private String osVersion;
    @NotNull
    @NotEmpty
    private String appVersion;
    @NotNull
    @NotEmpty
    private String fcmToken;
}
