package com.wibmo.dfs.notification.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/*
@Author pavan.konakanchi 
Created on : 04/08/2021 - 12:02 PM
*/
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubscriptionInfo {
    @Min(1)
    @NotNull
    private long accountNumber;
    private boolean suscribe;
}
