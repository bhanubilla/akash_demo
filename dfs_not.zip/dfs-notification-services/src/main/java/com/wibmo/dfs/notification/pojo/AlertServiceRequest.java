package com.wibmo.dfs.notification.pojo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Map;
import java.util.UUID;

/**
 * @author bhanu.prasad
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AlertServiceRequest implements Serializable {

	private static final long serialVersionUID = 4735715936055754272L;
	
	@NotNull
	private int bankId;
	@NotNull
	private String binId;
	@NotNull
	private String productId;
	@NotNull
	private UUID requestId;
	@NotNull
	private String eventId;
	@NotNull
	private long mobileNumber;
	//toEmailAddress
	private String emailId;
    private String emailType;
    private String fromEmailAddress;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss.SSSSSS")
    private Timestamp timeStamp;
    private UUID transactionId;
    private String alertTypeId;
	private String alertPriority;
    private int dynamicFieldCount;
    private Map<String,String> dynamicFields;
    private transient UamAlertConfig uamAlertConfig;
}
