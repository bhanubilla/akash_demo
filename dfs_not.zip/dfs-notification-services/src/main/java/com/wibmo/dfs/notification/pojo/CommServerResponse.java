package com.wibmo.dfs.notification.pojo;

import lombok.Data;

import java.io.Serializable;

/*
@Author pavan.konakanchi 
Created on : 28/04/2021 - 4:11 PM
*/
@Data
public class CommServerResponse implements Serializable {
    private String resCode;
    private String resDesc;
}
