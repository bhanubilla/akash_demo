package com.wibmo.dfs.notification.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

/*
@Author pavan.konakanchi 
Created on : 03/08/2021 - 6:07 PM
*/
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerDeviceMapping {
    private String deviceId;
    private long accountNumber;
}
