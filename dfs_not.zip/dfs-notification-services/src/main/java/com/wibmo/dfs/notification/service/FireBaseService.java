package com.wibmo.dfs.notification.service;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/*
@Author pavan.konakanchi 
Created on : 05/08/2021 - 2:12 PM
*/
@Service
@Slf4j
public class FireBaseService {

    private final Map<Integer, FirebaseApp> apps = new HashMap<>();

    public FirebaseApp getInstance(int programId, String firebaseJson) {
        if (apps.containsKey(programId)) {
            return apps.get(programId);
        }
        try {
            return initialise(programId, firebaseJson);
        } catch (IOException e) {
            log.error("error while initialising firebase admin SDK:{}", e);
            return null;
        }

    }

    public FirebaseApp initialise(int programId, String firebaseJson) throws IOException {
    	InputStream serviceAccount = new ByteArrayInputStream(firebaseJson.getBytes(StandardCharsets.UTF_8));
        FirebaseOptions options = FirebaseOptions.builder()
                .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                .build();
        FirebaseApp.initializeApp(options);
        apps.put(programId, FirebaseApp.getInstance());
        return apps.get(programId);
    }
}
