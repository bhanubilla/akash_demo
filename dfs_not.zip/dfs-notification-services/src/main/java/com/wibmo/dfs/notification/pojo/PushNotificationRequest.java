package com.wibmo.dfs.notification.pojo;

import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.Map;

/*
@Author pavan.konakanchi 
Created on : 04/08/2021 - 5:55 PM
*/
@Data
public class PushNotificationRequest {
    @NotNull
    @NotEmpty
    private String title;
    @NotNull
    @NotEmpty
    private String body;
    private String imageUrl;
    private String actionCode;
    private String actionData;
    @NotNull
    @NotEmpty
    private String messageKey;
    private String fcmToken;
    private Map<String,String> data;
    private int ttl;
    @NotNull
    @NotEmpty
    private String topic;

}
