package com.wibmo.dfs.notification.kafka;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.notification.dao.AlertParametersDAO;
import com.wibmo.dfs.notification.service.KafkaService;
import com.wibmo.dfs.platform.fw.multitenantconfig.ThreadLocalStorage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

/*
@Author pavan.konakanchi 
Created on : 12/08/2021 - 11:29 AM
*/
@Component
@Slf4j
public class KafkaConsumer {

	@Autowired
	KafkaService kafkaService;

	@Autowired
	AlertParametersDAO parametersDAO;

	@KafkaListener(topics = "${kafka.topic.notification}", groupId = "notification-cons")
	public void consumeTxnDetailsJson(String message) {
		log.info("Consumed JSON Message: {}", message);

		KafkaMessage kafkaMessage = null;
		try {
			kafkaMessage = new ObjectMapper().readValue(message, KafkaMessage.class);
		} catch (Exception e) {
			log.error("Parsing Exception :{}", e.toString());
			return;
		}
		if (kafkaMessage.getProgramId() != 0) {
			try {
				ThreadLocalStorage.setTenantId(kafkaMessage.getProgramId());
				kafkaService.processMessage(kafkaMessage);
			} catch (ProcessMessageException e) {
				// configure retry
			} finally {
				ThreadLocalStorage.clear();
			}
		} else {
			log.warn("program id did not set in message so cant process the request");
		}
	}
}
