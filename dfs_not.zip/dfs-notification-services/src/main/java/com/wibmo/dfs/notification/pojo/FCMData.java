package com.wibmo.dfs.notification.pojo;

/*
@Author pavan.konakanchi 
Created on : 05/08/2021 - 4:26 PM
*/


import com.google.firebase.messaging.*;
import lombok.Data;
import org.springframework.util.StringUtils;

import java.util.Map;

@Data
public class FCMData {


    private String title;
    private String body;
    private String image;
    private boolean isPrority;
    private int ttl;
    private String collapseKey;
    private String token;
    private String topic;
    private Map<String, String> data;


    public Message makePayload() {
        Message.Builder message = Message.builder()
                .setNotification(Notification.builder().setImage(image).build())
                .setAndroidConfig(AndroidConfig.builder().setCollapseKey(collapseKey)
                        .setTtl(ttl)
                        .setPriority(isPrority ? AndroidConfig.Priority.HIGH : AndroidConfig.Priority.NORMAL).build())
                .setApnsConfig(ApnsConfig.builder().putHeader("apns-priority", isPrority ? "10" : "5")
                        .putHeader("apns-expiration", String.valueOf(System.currentTimeMillis() / 1000 + ttl))
                        .putHeader("collapse_key", collapseKey).setAps(Aps.builder().build()).build())
                .putAllData(data);
        if (StringUtils.hasLength(topic)) {
            return message.setTopic(topic).build();
        } else {
            return message.setToken(token).build();
        }

    }

}
