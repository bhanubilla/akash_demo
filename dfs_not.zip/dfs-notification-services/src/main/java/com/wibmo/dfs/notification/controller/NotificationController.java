package com.wibmo.dfs.notification.controller;

import brave.Tracer;
import com.wibmo.dfs.notification.constants.ResCode;
import com.wibmo.dfs.notification.constants.ResDesc;
import com.wibmo.dfs.notification.pojo.AlertRequest;
import com.wibmo.dfs.notification.pojo.PushNotificationRequest;
import com.wibmo.dfs.notification.pojo.WibmoResponse;
import com.wibmo.dfs.notification.service.NotificationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * Controller for notification. Here we can be able to send sms , email,push notification, whatsapp notification
 *
 * @author palash.bera
 */
@Slf4j
@RestController
@RequestMapping("/notification")
public class NotificationController {
    @Autowired
    NotificationService notificationService;
    @Autowired
    private Tracer tracer;
    /**
     * End point to send notifications
     *
     * @param alertRequest
     * @return WibmoResponse
     */
    @PostMapping("/sendAlert")
    public WibmoResponse sendNotification(@RequestBody AlertRequest alertRequest, @RequestHeader("X-PROGRAM-ID") int programId) {

        log.info("Notification is invoked for mobile: {} EventId: {}", alertRequest.getMobileNumber(), alertRequest.getEventId());
        log.info("Thread 1-----------> {}"+Thread.currentThread().getName());
        notificationService.sendNotification(programId, alertRequest);
        WibmoResponse response = new WibmoResponse();
        response.setResCode(ResCode.SUCCESS);
        response.setResDesc(ResDesc.IN_PROCESS);
        log.info("response of sendNotification :{}", response);
        response.setReferenceId(tracer.currentSpan().context().traceIdString());
        return response;
    }
    @PostMapping("/sendPushNotification")
    public WibmoResponse sendPushNotification(@RequestBody PushNotificationRequest alertRequest, @RequestHeader("X-PROGRAM-ID") int programId) {

        log.info("Notification is invoked for message: {} programId: {}", alertRequest.getMessageKey(), programId);

        WibmoResponse response =  notificationService.sendPushNotification(programId, alertRequest);
        response.setReferenceId(tracer.currentSpan().context().traceIdString());
        return response;
    }
}
