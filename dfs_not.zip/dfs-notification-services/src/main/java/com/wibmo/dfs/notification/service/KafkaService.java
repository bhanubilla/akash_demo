package com.wibmo.dfs.notification.service;

import com.wibmo.dfs.notification.dao.CustomerInfoDAO;
import com.wibmo.dfs.notification.kafka.KafkaMessage;
import com.wibmo.dfs.notification.kafka.ProcessMessageException;
import com.wibmo.dfs.notification.pojo.*;
import lombok.extern.slf4j.Slf4j;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/*
@Author pavan.konakanchi 
Created on : 12/08/2021 - 1:51 PM
*/
@Service
@Slf4j
public class KafkaService {
    @Autowired
    private DozerBeanMapper mapper;

    @Autowired
    private CustomerInfoDAO customerInfoDAO;
    @Autowired
    private NotificationService notificationService;

    public void processMessage(KafkaMessage message) throws ProcessMessageException {
        switch (message.getEventType()) {
            case "NOTIFICATION":
                processNotification(message);
                break;
            case "MOBILE_UPDATE":
                processMobileUpdate(message);
                break;
            case "EMAIL_UPDATE":
                processEmailUpdate(message);
                break;
            case "EMAIL_REMOVE":
                processEmailDelete(message);
                break;
            case "LOGIN":
                processCustomerDeviceMapping(message);
                break;
            case "WHATSAPP_SUBSCRIPTION":
                processWhatsappSubscriptionUpdate(message);
                break;
            default:
                break;
        }
    }

    private void processWhatsappSubscriptionUpdate(KafkaMessage message) throws ProcessMessageException {

        try {
            SubscriptionInfo subscriptionInfo = mapper.map(message.getData(), SubscriptionInfo.class);
            customerInfoDAO.updateWhatsAppSubscription(message.getProgramId(), subscriptionInfo);
        } catch (RuntimeException e) {
            log.error(e.getMessage(), e);
            throw new ProcessMessageException();
        }

    }

    private void processCustomerDeviceMapping(KafkaMessage message) throws ProcessMessageException {
        try {
            CustomerDeviceMapping customerDeviceMapping = mapper.map(message.getData(), CustomerDeviceMapping.class);
            customerInfoDAO.mapDeviceInfo(message.getProgramId(), customerDeviceMapping);
        } catch (RuntimeException e) {
            log.error(e.getMessage(), e);
            throw new ProcessMessageException();
        }
    }

    private void processMobileUpdate(KafkaMessage message) throws ProcessMessageException {
        try {
            CustomerMobileInfo customerMobileInfo = mapper.map(message.getData(), CustomerMobileInfo.class);
            customerInfoDAO.mapMobile(message.getProgramId(), customerMobileInfo);
        } catch (RuntimeException e) {
            log.error(e.getMessage(), e);
            throw new ProcessMessageException();
        }
    }

    private void processEmailDelete(KafkaMessage message) throws ProcessMessageException {
        try {
            CustomerEmailInfo subscriptionInfo = mapper.map(message.getData(), CustomerEmailInfo.class);
            customerInfoDAO.deleteEmail(message.getProgramId(), subscriptionInfo);
        } catch (RuntimeException e) {
            log.error(e.getMessage(), e);
            throw new ProcessMessageException();
        }
    }

    private void processEmailUpdate(KafkaMessage message) throws ProcessMessageException {
        try {
            CustomerEmailInfo customerEmailInfo = mapper.map(message.getData(), CustomerEmailInfo.class);
            customerInfoDAO.mapEmail(message.getProgramId(), customerEmailInfo);
        } catch (RuntimeException e) {
            log.error(e.getMessage(), e);
            throw new ProcessMessageException();
        }
    }

    private void processNotification(KafkaMessage message) throws ProcessMessageException {
        try {
            AlertRequest alertRequest = mapper.map(message.getData(), AlertRequest.class);
            notificationService.sendNotification(message.getProgramId(), alertRequest);
        } catch (RuntimeException e) {
            log.error(e.getMessage(), e);
            throw new ProcessMessageException();
        }
    }
}
