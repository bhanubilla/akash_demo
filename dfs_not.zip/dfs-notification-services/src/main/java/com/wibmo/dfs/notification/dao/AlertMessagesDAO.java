package com.wibmo.dfs.notification.dao;

import com.wibmo.dfs.notification.entity.AlertMessage;

import java.util.List;

/**
 * DAO for alert messages.
 * @author palash.bera
 */
public interface AlertMessagesDAO  {
     List<AlertMessage> findByProgramIdAndEventId(Integer programId, Integer eventId);
     List<AlertMessage> listAll(Integer programId);
    void reload(Integer programId);

    void reloadByEventId(Integer programId, int eventId);
}
