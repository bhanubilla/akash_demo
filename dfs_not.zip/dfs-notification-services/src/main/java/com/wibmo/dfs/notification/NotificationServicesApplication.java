package com.wibmo.dfs.notification;

import lombok.extern.slf4j.Slf4j;

import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.AsyncConfigurerSupport;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.lang.reflect.Method;

/**
 * Notification service runner
 *
 * @author palash.bera, Pavan Konakanchi
 */
@SpringBootApplication
@Slf4j
@ComponentScan("com.wibmo.dfs")
@EnableAsync
public class NotificationServicesApplication extends AsyncConfigurerSupport {
	
	@Autowired
	private BuildProperties buildProperties;

    @Bean("threadPoolTaskExecutor")
    public TaskExecutor getAsyncExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(2);
        executor.setMaxPoolSize(3);
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setThreadNamePrefix("Async-");
        return executor;
    }

    public static void main(String[] args) {
        SpringApplication.run(NotificationServicesApplication.class, args);
        log.info(".........Notification Service is started.........");
    }

    @EventListener
    public void handleContextRefresh(ContextRefreshedEvent event) {

        log.info("Build Version : {}", buildProperties.getVersion());
        log.info("Build Release Time: {}", buildProperties.get("buildReleaseTime"));
    }

    @Override
    public AsyncUncaughtExceptionHandler getAsyncUncaughtExceptionHandler() {
        return new AsyncUncaughtExceptionHandler() {

            @Override
            public void handleUncaughtException(Throwable ex, Method method, Object... params) {
                log.error("Exception occurred while Async flow: {}", ex.getMessage());
                log.error("Error occurred in Method Name: {}", method.getName());
            }
        };
    }
}