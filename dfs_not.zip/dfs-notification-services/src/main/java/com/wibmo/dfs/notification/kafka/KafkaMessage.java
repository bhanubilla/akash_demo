package com.wibmo.dfs.notification.kafka;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

/*
@Author pavan.konakanchi 
Created on : 12/08/2021 - 12:07 PM
*/
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class KafkaMessage {

    private int programId;
    private String eventType;
    private int retryCount;
    private Object data;
}
