package com.wibmo.dfs.notification.constants;

/**
 * Constants class for alert parameters
 * @author palash.bera
 */
public class AlertParamConstants {
    public static final String EMAIL_SERVER_URL="EMAIL_SERVER_URL";
    public static final String EMAIL_API_KEY="EMAIL_API_KEY";
    public static final String EMAIL_API_USER="EMAIL_API_USER";
    public static final String FROM_EMAIL_ADDRESS="FROM_EMAIL_ADDRESS";
    public static final String EMAIL_ALERT_SERVER_URL="EMAIL_ALERT_SERVER_URL";
    public static final String EMAIL_ALERT_FROM_EMAIL="EMAIL_ALERT_FROM_EMAIL";
    public static final String ALERT_SMTP_SERVER_URL="ALERT_SMTP_SERVER_URL";
    public static final String ALERT_SMTP_SERVER_CONNECTION_TYPE="ALERT_SMTP_SERVER_CONNECTION_TYPE";
    public static final String CONFIG_VALUE_MAIL_USER="ROOT";


    public static final String SMS_API_KEY="SMS_API_KEY";
    public static final String SMS_API_USER="SMS_API_USER";
    public static final String SMS_SERVER_URL="SMS_SERVER_URL";
    public static final String SMS_SENDER_ID="SMS_SENDER_ID";
    
    public static final String ALERT_SERVICE_ALERT_TYPE_EMAIL="2";
    public static final String ALERT_SERVICE_ALERT_TYPE_SMS="1";
    public static final String ALERT_SERVICE_ALERT_TYPE_EMAIL_SMS="3";
    public static final String ALERT_SMS_SERVER_URL="ALERT_SMS_SERVER_URL";
    public static final String ALERT_SMS_SERVER_CONNECTION_TYPE="ALERT_SMS_SERVER_CONNECTION_TYPE";
    public static final String CONFIG_VALUE_MESSAGE_GROUP_ID="CONFIG_VALUE_MESSAGE_GROUP_ID";
    public static final String CONFIG_VALUE_MESSAGE_SERVER_TYPE="DROPWIZARD";
    public static final String CONFIG_VALUE_MESSAGE_FROM_ID="CONFIG_VALUE_MESSAGE_FROM_ID";
    public static final String ALERT_PRIORITY_ZERO="0";
    public static final String ALERT_PASSWORD_EVENT="PASSWORD_EVENT";
    public static final String ALERT_BIN_ID="ALERT_BIN_ID";
    public static final String ALERT_FIREBASE_BANKEZY_PUSH_JSON="ALERT_FIREBASE_BANKEZY_PUSH_JSON";
    public static final String ALERT_SMS_COUNTRY_CODE_INDIA="ALERT_SMS_COUNTRY_CODE_INDIA";

    private AlertParamConstants(){

    }

}
