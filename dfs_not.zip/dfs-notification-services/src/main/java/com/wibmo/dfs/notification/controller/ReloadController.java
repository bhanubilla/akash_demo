package com.wibmo.dfs.notification.controller;

import brave.Tracer;
import com.wibmo.dfs.notification.constants.ResCode;
import com.wibmo.dfs.notification.constants.ResDesc;
import com.wibmo.dfs.notification.pojo.WibmoResponse;
import com.wibmo.dfs.notification.service.ReloadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/*
@Author pavan.konakanchi 
Created on : 28/04/2021 - 9:44 AM
*/
@RequestMapping("/reload")
@RestController
public class ReloadController {
    @Autowired
    ReloadService reloadService;

    @Autowired
    private Tracer tracer;

    @GetMapping("/alert-messages")
    public WibmoResponse reloadAlertMessages( @RequestHeader("X-PROGRAM-ID") int programId){

        boolean reloaded = reloadService.reloadAlertMessages(programId);
        if(reloaded){
            return new WibmoResponse(ResCode.SUCCESS, ResDesc.SUCCESS, tracer.currentSpan().context().traceIdString());
        }else{
            return new WibmoResponse(ResCode.FAILED, ResDesc.FAILED, tracer.currentSpan().context().traceIdString());
        }
    }
    @GetMapping("/alert-messages/{eventId}")
    public WibmoResponse reloadAlertMessages(@RequestHeader("X-PROGRAM-ID") int programId,@PathVariable ("eventId") int eventId){

        boolean reloaded = reloadService.reloadAlertMessages(programId, eventId);
        if(reloaded){
            return new WibmoResponse(ResCode.SUCCESS, ResDesc.SUCCESS, tracer.currentSpan().context().traceIdString());
        }else{
            return new WibmoResponse(ResCode.FAILED, ResDesc.FAILED, tracer.currentSpan().context().traceIdString());
        }
    }
    @GetMapping("/alert-parameters")
    public WibmoResponse sendNotification(@RequestHeader("X-PROGRAM-ID") int programId){

        boolean reloaded = reloadService.reloadAlertParameters(programId);
        if(reloaded){
            return new WibmoResponse(ResCode.SUCCESS, ResDesc.SUCCESS, tracer.currentSpan().context().traceIdString());
        }else{
            return new WibmoResponse(ResCode.FAILED, ResDesc.FAILED, tracer.currentSpan().context().traceIdString());
        }
    }
    @GetMapping("/alert-parameters/{paramName}")
    public WibmoResponse sendNotification(@RequestHeader("X-PROGRAM-ID") int programId,@PathVariable ("paramId") String paramId){

        boolean reloaded = reloadService.reloadAlertParameters(programId,paramId);
        if(reloaded){
            return new WibmoResponse(ResCode.SUCCESS, ResDesc.SUCCESS, tracer.currentSpan().context().traceIdString());
        }else{
            return new WibmoResponse(ResCode.FAILED, ResDesc.FAILED, tracer.currentSpan().context().traceIdString());
        }
    }
}
