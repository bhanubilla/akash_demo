package com.wibmo.dfs.notification.dao.impl;

import com.wibmo.dfs.cache_client.manager.DfsCacheManager;
import com.wibmo.dfs.notification.dao.AlertMessagesDAO;
import com.wibmo.dfs.notification.entity.AlertMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;


/*
@Author pavan.konakanchi 
Created on : 27/04/2021 - 9:48 AM
*/
@Repository
@Slf4j
public class AlertMessageDAOImpl implements AlertMessagesDAO {
    private static final String UNDERSCORE = "_";
    private static final String EVENT_ID = "EVENT_ID";
    private static final String ALERT_MESSAGE = "ALERT_MESSAGE";
    @Autowired
    JdbcTemplate jdbcTemplate;
    @Autowired
    private DfsCacheManager cacheManager;

    @Override
    public List<AlertMessage> findByProgramIdAndEventId(Integer programId, Integer eventId) {
        List<AlertMessage> list = null;
        try {
            list = (List<AlertMessage>) cacheManager.get(ALERT_MESSAGE + UNDERSCORE + eventId + UNDERSCORE + programId);
            if (list != null) {
                log.debug("found in cache");
                return list;
            }
        } catch (Exception e) {
            log.error("error while fetching alert messages");
        }


        try {
            log.debug("going to DB");
            list = jdbcTemplate.query("SELECT * FROM ALERT_MESSAGES WHERE EVENT_ID=?", (rs, rowNum) -> {
                AlertMessage alertMessage = new AlertMessage();
                alertMessage.setId(rs.getInt("ID"));
                alertMessage.setAlertType(rs.getString("ALERT_TYPE"));
                alertMessage.setEventId(rs.getInt(EVENT_ID));
                alertMessage.setStatus(rs.getInt("STATUS"));
                alertMessage.setTemplateBody(rs.getString("TEMPLATE_BODY"));
                alertMessage.setTemplateSubject(rs.getString("TEMPLATE_SUBJECT"));
                return alertMessage;
            }, eventId);
            if (!list.isEmpty()) {
                log.info("caching the list eventId:{} programId:{}", eventId, programId);

                    cacheManager.put(ALERT_MESSAGE + UNDERSCORE + eventId + UNDERSCORE + programId, list);


            }

            return list;
        } catch (EmptyResultDataAccessException e) {
            log.info("no data found");
            return new ArrayList<>();
        }

    }

    @Override
    public List<AlertMessage> listAll(Integer programId) {

        List<AlertMessage> list = null;
        try {
            log.debug("going to DB");
            list = jdbcTemplate.query("SELECT * FROM ALERT_MESSAGES ", (rs, rowNum) -> {
                AlertMessage alertMessage = new AlertMessage();
                alertMessage.setId(rs.getInt("ID"));
                alertMessage.setAlertType(rs.getString("ALERT_TYPE"));
                alertMessage.setEventId(rs.getInt(EVENT_ID));
                alertMessage.setStatus(rs.getInt("STATUS"));
                alertMessage.setTemplateBody(rs.getString("TEMPLATE_BODY"));
                alertMessage.setTemplateSubject(rs.getString("TEMPLATE_SUBJECT"));
                return alertMessage;
            });


            return list;
        } catch (EmptyResultDataAccessException e) {
            log.info("no data found");
            return new ArrayList<>();
        }
    }

    @Override
    public void reload(Integer programId) {
        try {
            List<String> list = jdbcTemplate.query("SELECT DISTINCT EVENT_ID FROM ALERT_MESSAGES", (rs, rowNum) ->
                    rs.getString(EVENT_ID)
            );
            list.forEach(eventId -> {
                log.info("removing from cache: programId:{} eventId:{}", programId, eventId);
                cacheManager.remove(ALERT_MESSAGE + UNDERSCORE + eventId + UNDERSCORE + programId);
            });

        } catch (EmptyResultDataAccessException e) {
            log.info("no data found to reload");

        }
    }

    @Override
    public void reloadByEventId(Integer programId, int eventId) {

        log.info("removing from cache: programId:{} eventId:{}", programId, eventId);
        cacheManager.remove(ALERT_MESSAGE + UNDERSCORE + eventId + UNDERSCORE + programId);

    }
}
