package com.wibmo.dfs.notification.pojo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AlertEvent {
	
	private String subject;
	private String text;
	private boolean enabled;
	

}
