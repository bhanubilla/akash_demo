package com.wibmo.dfs.notification.pojo;

import com.wibmo.dfs.notification.entity.AlertMessage;
import lombok.Data;

import java.util.List;

/*
@Author pavan.konakanchi 
Created on : 09/08/2021 - 5:13 PM
*/
@Data
public class AlertMessagesResponse extends WibmoResponse{
    List<AlertMessage> messages;

    public AlertMessagesResponse(int resCode, String resDesc) {

        this.setResCode(resCode);
        this.setResDesc(resDesc);
    }
}
