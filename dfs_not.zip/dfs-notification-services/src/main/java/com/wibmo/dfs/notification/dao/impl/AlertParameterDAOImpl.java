package com.wibmo.dfs.notification.dao.impl;

import com.wibmo.dfs.cache_client.manager.DfsCacheManager;
import com.wibmo.dfs.notification.dao.AlertParametersDAO;
import com.wibmo.dfs.notification.entity.AlertParameter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

/*
@Author pavan.konakanchi 
Created on : 27/04/2021 - 9:53 AM
*/
@Repository
@Slf4j
public class AlertParameterDAOImpl implements AlertParametersDAO {
    private static final String ALERT_PARAMETER = "ALERT_PARAMETER";
    private static final String UNDERSCORE = "_";
    private static final String PARAM_ID = "PARAM_ID";
    @Autowired
    JdbcTemplate jdbcTemplate;
    @Autowired
    private DfsCacheManager cacheManager;

    public AlertParameter findByProgramIdAndParamId(Integer programId, String paramId) {
        try{
            AlertParameter alertParameter = (AlertParameter) cacheManager.get(ALERT_PARAMETER + UNDERSCORE + paramId + UNDERSCORE + programId);
            if (alertParameter != null) {
                log.debug("found in cache");
                return alertParameter;
            }
        }catch (Exception e){
            log.error("Error while reading from cache:{}",e);
        }

        final AlertParameter alertParam = new AlertParameter();
        try {
            jdbcTemplate.queryForObject("SELECT * FROM ALERT_PARAMETERS WHERE PARAM_ID=? AND STATUS=1", (rs, rowNum) -> {
                alertParam.setId(rs.getInt("ID"));
                alertParam.setParamValue(rs.getString("PARAM_VALUE"));
                alertParam.setStatus(rs.getInt("STATUS"));
                return alertParam;
            }, paramId);
            cacheManager.put(ALERT_PARAMETER + UNDERSCORE + paramId + UNDERSCORE + programId, alertParam);
            return alertParam;
        } catch (EmptyResultDataAccessException e) {
            log.info("no data found");
            return null;
        }

    }

    public void reload(Integer programId, String paramId) {
        log.info("deleting from cache programId:{}, paramId:{}", programId, paramId);
        cacheManager.remove(ALERT_PARAMETER + UNDERSCORE + paramId + UNDERSCORE + programId);

    }

    public void reload(Integer programId) {
        try {
            List<String> list = jdbcTemplate.query("SELECT PARAM_ID FROM ALERT_PARAMETERS ", (rs, rowNum) ->
                 rs.getString(PARAM_ID)
            );
            list.forEach(paramId -> {
                log.info("removing from cache: programId:{} paramId:{}", programId, paramId);
                cacheManager.remove(ALERT_PARAMETER + UNDERSCORE + paramId + UNDERSCORE + programId);
            });

        } catch (EmptyResultDataAccessException e) {
            log.info("no data found to reload");

        }
    }

    public List<AlertParameter> listByProgramId(Integer programId) {

        try {
            return jdbcTemplate.query("SELECT * FROM ALERT_PARAMETERS", (rs, rowNum) -> {
                AlertParameter alertParam = new AlertParameter();
                alertParam.setId(rs.getInt("ID"));
                alertParam.setParamValue(rs.getString("PARAM_VALUE"));
                alertParam.setStatus(rs.getInt("STATUS"));
                return alertParam;
            });


        } catch (EmptyResultDataAccessException e) {
            log.info("no data found");
            return new ArrayList<>();
        }

    }

}
