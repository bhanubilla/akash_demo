package com.wibmo.dfs.notification.pojo;

import lombok.Data;

@Data
public class SmsAlertRequest {
    private String to;
    private String senderId;
    private String body;

}
