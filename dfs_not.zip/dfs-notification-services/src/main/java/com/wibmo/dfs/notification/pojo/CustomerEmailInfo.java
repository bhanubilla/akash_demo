package com.wibmo.dfs.notification.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

/*
@Author pavan.konakanchi 
Created on : 04/08/2021 - 11:54 AM
*/
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerEmailInfo {
    private String email;
    private long accountNumber;
}
