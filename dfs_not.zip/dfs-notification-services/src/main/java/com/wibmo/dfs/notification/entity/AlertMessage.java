package com.wibmo.dfs.notification.entity;
import lombok.Data;


import java.io.Serializable;

/**
 * Entity which represents the alert messages table structure.
 * @author palash.bera
 */

@Data
public class AlertMessage implements Serializable {

    private int eventId;

    private int id;

    private String alertType;

    private String templateBody;

    private String templateSubject;

    private int status;
}
