package com.wibmo.dfs.notification.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author bhanu.prasad
 *
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class UamAlertConfig {

	@JsonProperty("config_value")
	private ConfigValue configValue;

}
