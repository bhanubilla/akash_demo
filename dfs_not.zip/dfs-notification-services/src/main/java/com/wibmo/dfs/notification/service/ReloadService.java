package com.wibmo.dfs.notification.service;

import com.wibmo.dfs.notification.entity.AlertMessage;
import com.wibmo.dfs.notification.entity.AlertParameter;

import java.util.List;

/*
@Author pavan.konakanchi 
Created on : 28/04/2021 - 1:04 PM
*/
public interface ReloadService {
    List<AlertMessage> listAlertMessages(Integer programId, Integer eventId);

    List<AlertMessage> listAlertMessages(Integer programId);

    boolean reloadAlertMessages(Integer programId);

    boolean reloadAlertMessages(Integer programId, int eventId);

    AlertParameter findAlertParameter(Integer programId, String paramId);

    boolean reloadAlertParameters(Integer programId, String paramId);

    boolean reloadAlertParameters(Integer programId);

    List<AlertParameter> listAlertParameters(Integer programId);
}
