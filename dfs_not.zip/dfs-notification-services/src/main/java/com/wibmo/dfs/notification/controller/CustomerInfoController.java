package com.wibmo.dfs.notification.controller;

import brave.Tracer;
import com.wibmo.dfs.notification.constants.ResCode;
import com.wibmo.dfs.notification.constants.ResDesc;
import com.wibmo.dfs.notification.pojo.*;
import com.wibmo.dfs.notification.service.CustomerInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
/*
@Author pavan.konakanchi 
Created on : 04/08/2021 - 11:28 AM
*/
@RestController
@RequestMapping("/customer-info")
public class CustomerInfoController {

    @Autowired
    CustomerInfoService customerInfoService;
    @Autowired
    private Tracer tracer;

    @PostMapping("/device")
    public WibmoResponse saveDeviceInfo(@RequestHeader("X-PROGRAM-ID") int programId, @RequestBody CustomerDeviceMapping deviceInfo){

        boolean reloaded = customerInfoService.mapDevice(programId, deviceInfo);
        if(reloaded){
            return new WibmoResponse(ResCode.SUCCESS, ResDesc.SUCCESS,tracer.currentSpan().context().traceIdString());
        }else{
            return new WibmoResponse(ResCode.FAILED, ResDesc.FAILED,tracer.currentSpan().context().traceIdString());
        }
    }
    @PostMapping("/mobile")
    public WibmoResponse saveMobile(@RequestHeader("X-PROGRAM-ID") int programId, @RequestBody CustomerMobileInfo mobileInfo){

        boolean reloaded = customerInfoService.mapMobile(programId, mobileInfo);
        if(reloaded){
            return new WibmoResponse(ResCode.SUCCESS, ResDesc.SUCCESS);
        }else{
            return new WibmoResponse(ResCode.FAILED, ResDesc.FAILED);
        }
    }
    @PostMapping("/email")
    public WibmoResponse saveEmail(@RequestHeader("X-PROGRAM-ID") int programId, @RequestBody CustomerEmailInfo emailInfo){

        boolean reloaded = customerInfoService.mapEmail(programId, emailInfo);
        if(reloaded){
            return new WibmoResponse(ResCode.SUCCESS, ResDesc.SUCCESS,tracer.currentSpan().context().traceIdString());
        }else{
            return new WibmoResponse(ResCode.FAILED, ResDesc.FAILED,tracer.currentSpan().context().traceIdString());
        }
    }
    @DeleteMapping("/email")
    public WibmoResponse deleteEmail(@RequestHeader("X-PROGRAM-ID") int programId, @RequestBody CustomerEmailInfo emailInfo){

        boolean reloaded = customerInfoService.deleteEmail(programId, emailInfo);
        if(reloaded){
            return new WibmoResponse(ResCode.SUCCESS, ResDesc.SUCCESS,tracer.currentSpan().context().traceIdString());
        }else{
            return new WibmoResponse(ResCode.FAILED, ResDesc.FAILED,tracer.currentSpan().context().traceIdString());
        }
    }
    @PostMapping("/whatsAppSubscription")
    public WibmoResponse saveEmail(@RequestHeader("X-PROGRAM-ID") int programId, @RequestBody SubscriptionInfo subscriptionInfo){

        boolean reloaded = customerInfoService.subscribeForWhatsapp(programId, subscriptionInfo);
        if(reloaded){
            return new WibmoResponse(ResCode.SUCCESS, ResDesc.SUCCESS,tracer.currentSpan().context().traceIdString());
        }else{
            return new WibmoResponse(ResCode.FAILED, ResDesc.FAILED,tracer.currentSpan().context().traceIdString());
        }
    }

}
