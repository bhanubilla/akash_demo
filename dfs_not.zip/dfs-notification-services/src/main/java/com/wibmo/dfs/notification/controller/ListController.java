package com.wibmo.dfs.notification.controller;

import com.wibmo.dfs.notification.constants.ResCode;
import com.wibmo.dfs.notification.constants.ResDesc;
import com.wibmo.dfs.notification.entity.AlertMessage;
import com.wibmo.dfs.notification.entity.AlertParameter;
import com.wibmo.dfs.notification.pojo.AlertMessagesResponse;
import com.wibmo.dfs.notification.pojo.AlertParamsResponse;
import com.wibmo.dfs.notification.service.ReloadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/*
@Author pavan.konakanchi 
Created on : 28/04/2021 - 3:44 PM
*/
@RestController
@RequestMapping("/list")
public class ListController {

    @Autowired
    ReloadService reloadService;

    @GetMapping("/alert-messages")
    public AlertMessagesResponse listAlertMessages(@RequestHeader("X-PROGRAM-ID") int programId){

        List<AlertMessage> list = reloadService.listAlertMessages(programId);
        if(list!=null){
            AlertMessagesResponse response= new AlertMessagesResponse(ResCode.SUCCESS, ResDesc.SUCCESS);
            response.setMessages(list);
            return response;
        }else{
            return new AlertMessagesResponse(ResCode.SUCCESS, ResDesc.SUCCESS);
        }
    }
    @GetMapping("/alert-parameters")
    public AlertParamsResponse listAlertParameters(@RequestHeader("X-PROGRAM-ID") int programId){

        List<AlertParameter> list = reloadService.listAlertParameters(programId);
        if(list!=null){
            AlertParamsResponse response= new AlertParamsResponse(ResCode.SUCCESS, ResDesc.SUCCESS);
           response.setParameters(list);
            return response;
        }else{
            return new AlertParamsResponse(ResCode.SUCCESS, ResDesc.SUCCESS);
        }
    }
}
