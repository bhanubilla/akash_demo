package com.wibmo.dfs.notification.pojo;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author bhanu.prasad
 *
 */
@Data
@NoArgsConstructor
public class ConfigValue {

	private String messageGroupId;
	private String messageServerType;
	private String messageFromId;
	private String messageTemplate;
	private boolean sendEmail;
	private Server smtpServer;
	private String emailType;
	private String fromEmailAddress;
	private String mailUser;
	private boolean sendSMS;
	private Server messageServer;
	private ConfigValueEventTemplates eventTemplates;
}
