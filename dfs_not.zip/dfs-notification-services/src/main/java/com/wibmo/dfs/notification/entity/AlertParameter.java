package com.wibmo.dfs.notification.entity;

import lombok.Data;

import java.io.Serializable;

/**
 * Entity that represents the alert parameter table structure
 *
 * @author palash.bera
 */
@Data
public class AlertParameter implements Serializable {

    private int id;
    private String paramValue;
    private int status;
    private int programId;

}
