package com.wibmo.dfs.notification.service.impl;

import java.sql.Timestamp;
import java.util.Base64;
import java.util.Date;
import java.util.Random;
import java.util.UUID;

import com.wibmo.dfs.notification.constants.ResCode;
import com.wibmo.dfs.notification.constants.ResDesc;
import com.wibmo.dfs.notification.dao.AlertMessagesDAO;
import com.wibmo.dfs.notification.dao.AlertParametersDAO;
import com.wibmo.dfs.notification.pojo.AlertServiceRequest;
import com.wibmo.dfs.notification.pojo.ConfigValue;
import com.wibmo.dfs.notification.pojo.ConfigValueEventTemplates;
import com.wibmo.dfs.notification.pojo.EventTemplatesEventTemplates;
import com.wibmo.dfs.notification.pojo.NotificationRequest;
import com.wibmo.dfs.notification.pojo.PasswordEvent;
import com.wibmo.dfs.notification.pojo.Server;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wibmo.dfs.notification.constants.AlertParamConstants;
import com.wibmo.dfs.notification.pojo.UamAlertConfig;
import com.wibmo.dfs.notification.pojo.WibmoResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;

import javax.ws.rs.core.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;

/**
 * Service for email notification
 * 
 * @author bhanu.prasad
 *
 */
@Slf4j
@Service
public class AlertEmailService {
	public static final int SUCCESS_RESPONSE_CODE = 200;

	@Autowired
	AlertParametersDAO alertParametersDAO;
	@Autowired
	AlertMessagesDAO alertMessagesDAO;
	@Autowired
	RestTemplate restTemplate;

	/**
	 * Sends the email notification to the user by invoking email server
	 * 
	 * @param alert
	 * @return WibmoResponse
	 */
	public WibmoResponse sendNotificationToUser(NotificationRequest alert) {
		log.info("Executing sendNotificationToUser service-->");
		String emailServerUrl = alertParametersDAO
				.findByProgramIdAndParamId(alert.getProgramId(), AlertParamConstants.EMAIL_ALERT_SERVER_URL)
				.getParamValue();
		String apiKey = alertParametersDAO
				.findByProgramIdAndParamId(alert.getProgramId(), AlertParamConstants.EMAIL_API_KEY).getParamValue();
		String apiUser = alertParametersDAO
				.findByProgramIdAndParamId(alert.getProgramId(), AlertParamConstants.EMAIL_API_USER).getParamValue();
		String senderEmail = alertParametersDAO
				.findByProgramIdAndParamId(alert.getProgramId(), AlertParamConstants.EMAIL_ALERT_FROM_EMAIL)
				.getParamValue();
		String smtpServerUrl = alertParametersDAO
				.findByProgramIdAndParamId(alert.getProgramId(), AlertParamConstants.ALERT_SMTP_SERVER_URL)
				.getParamValue();
		String smtpServerConnType = alertParametersDAO
				.findByProgramIdAndParamId(alert.getProgramId(), AlertParamConstants.ALERT_SMTP_SERVER_CONNECTION_TYPE)
				.getParamValue();
		String alertBinId = alertParametersDAO.findByProgramIdAndParamId(alert.getProgramId(), AlertParamConstants.ALERT_BIN_ID).getParamValue();
		
		if (senderEmail == null) {
			log.error(AlertParamConstants.EMAIL_ALERT_FROM_EMAIL + " is emptpy");
		}
		if (smtpServerUrl == null) {
			log.error(AlertParamConstants.ALERT_SMTP_SERVER_URL + " is empty");
		}
		AlertServiceRequest alertServiceReq = createAlertServiceRequest(alert, senderEmail, alertBinId);
		ConfigValue configValue = createConfigValue(senderEmail);
		createSmtpServer(smtpServerUrl, smtpServerConnType, configValue);
		PasswordEvent passwordEvent = createPasswordEvent(alert);
		UamAlertConfig uamAlertConfig = createUamAlertConfig(configValue, passwordEvent);
		alertServiceReq.setUamAlertConfig(uamAlertConfig);

		HttpHeaders headers = new HttpHeaders();
		headers.set("Content-Type", "application/json;charset=utf-8");
		headers.set("X-API-KEY", apiKey);
		headers.set("X-API-User", apiUser);
		headers.set("X-PROGRAM-ID", Integer.toString(alert.getProgramId()));

		HttpEntity<Object> httpEntity = new HttpEntity<>(alertServiceReq, headers);
		ObjectMapper obj = new ObjectMapper();
		try {
			String reqJson = obj.writeValueAsString(alertServiceReq);
			log.debug("alert service request obj: {}", reqJson);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		
		if (emailServerUrl != null) {
			ResponseEntity<Object> result = restTemplate.exchange(emailServerUrl, HttpMethod.POST, httpEntity,
					Object.class);
			Object resultBody = result.getBody();
			if (resultBody != null) {
				String responseStr = resultBody.toString();
				if (responseStr.contains("messageId")) {
					log.info("email delivery status for " + alert.getEmailId() + " is " + ResDesc.SUCCESS);
					return new WibmoResponse(ResCode.SUCCESS, ResDesc.SUCCESS);
				}
			}
		} else {
			log.error(AlertParamConstants.EMAIL_ALERT_SERVER_URL + " is empty");
		}
		log.error("email delivery status for " + alert.getEmailId() + " is " + ResDesc.FAILED);
		return new WibmoResponse(ResCode.FAILED, ResDesc.FAILED);
	}

	private UamAlertConfig createUamAlertConfig(ConfigValue configValue, PasswordEvent passwordEvent) {
		EventTemplatesEventTemplates eventTempEventTemplates = new EventTemplatesEventTemplates();
		eventTempEventTemplates.setPasswordEvent(passwordEvent);
		ConfigValueEventTemplates configValueEventTemplates = new ConfigValueEventTemplates();
		configValueEventTemplates.setEventTemplates(eventTempEventTemplates);
		configValue.setEventTemplates(configValueEventTemplates);
		UamAlertConfig uamAlertConfig = new UamAlertConfig();
		uamAlertConfig.setConfigValue(configValue);
		return uamAlertConfig;
	}

	private PasswordEvent createPasswordEvent(NotificationRequest alert) {
		PasswordEvent passwordEvent = new PasswordEvent();
		passwordEvent.setSubject(alert.getSubject());
		passwordEvent.setEnabled(true);
		passwordEvent.setText(alert.getBody());
		return passwordEvent;
	}

	private void createSmtpServer(String smtpServerUrl, String smtpServerConnType, ConfigValue configValue) {
		Server smtpServer = new Server();
		smtpServer.setEndpointUrl(smtpServerUrl);
		smtpServer.setConnectType(smtpServerConnType);
		configValue.setSmtpServer(smtpServer);
	}

	private ConfigValue createConfigValue(String senderEmail) {
		ConfigValue configValue = new ConfigValue();
		configValue.setSendEmail(true);
		configValue.setEmailType(MediaType.TEXT_HTML);
		configValue.setFromEmailAddress(senderEmail);
		configValue.setMailUser(AlertParamConstants.CONFIG_VALUE_MAIL_USER);
		return configValue;
	}

	private AlertServiceRequest createAlertServiceRequest(NotificationRequest alert, String senderEmail, String alertBinId) {
		log.info("Creating AlertServiceRequest obj-->");
		Timestamp currentDateTime = new Timestamp(new Date().getTime());
		UUID requestId = UUID.randomUUID();
		AlertServiceRequest alertServiceReq = new AlertServiceRequest();
		alertServiceReq.setBankId(alert.getProgramId());
		alertServiceReq.setBinId(alertBinId);
		alertServiceReq.setProductId(Integer.toString(alert.getEventId()));
		alertServiceReq.setRequestId(requestId);
		alertServiceReq.setEventId(AlertParamConstants.ALERT_PASSWORD_EVENT);
		alertServiceReq.setEmailId(alert.getEmailId());
		alertServiceReq.setEmailType(MediaType.TEXT_HTML);
		alertServiceReq.setFromEmailAddress(senderEmail);
		alertServiceReq.setTimeStamp(currentDateTime);
		alertServiceReq.setTransactionId(requestId);
		alertServiceReq.setAlertTypeId(AlertParamConstants.ALERT_SERVICE_ALERT_TYPE_EMAIL);
		alertServiceReq.setAlertPriority(AlertParamConstants.ALERT_PRIORITY_ZERO);
		alertServiceReq.setDynamicFieldCount(5);
		alertServiceReq.setDynamicFields(alert.getPlaceHolders());
		return alertServiceReq;
	}
}
