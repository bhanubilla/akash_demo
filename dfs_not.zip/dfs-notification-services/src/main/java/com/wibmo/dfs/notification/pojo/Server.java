package com.wibmo.dfs.notification.pojo;

import lombok.Getter;
import lombok.Setter;

/**
 * @author bhanu.prasad
 *
 */
@Getter
@Setter
public class Server {
	
	 private String endpointUrl;
     private String connectType;

}
