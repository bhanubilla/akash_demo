package com.wibmo.dfs.notification.pojo;

import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
public class WibmoResponse {
    private int resCode;
    private String resDesc;
    private String referenceId;
    private Object data;

    public WibmoResponse(int resCode, String resDesc) {
        this.resCode = resCode;
        this.resDesc = resDesc;
    }
    public WibmoResponse(int resCode, String resDesc,String referenceId) {
        this.resCode = resCode;
        this.resDesc = resDesc;
        this.referenceId = referenceId;
    }
}
