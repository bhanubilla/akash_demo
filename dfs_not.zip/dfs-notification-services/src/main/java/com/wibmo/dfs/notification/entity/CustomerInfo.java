package com.wibmo.dfs.notification.entity;

import lombok.Data;

/*
@Author pavan.konakanchi 
Created on : 06/08/2021 - 10:57 AM
*/
@Data
public class CustomerInfo {
    private long accountNumber;
    private String emailId;
    private String mobileNumber;
    private boolean suscribedForWahtsapp;
}
