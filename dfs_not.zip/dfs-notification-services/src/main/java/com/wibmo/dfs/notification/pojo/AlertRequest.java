package com.wibmo.dfs.notification.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * POJO that represents /send payload data
 *
 * @author palash.bera
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class AlertRequest implements Serializable {

	private static final long serialVersionUID = -9048534539305002846L;

	@Min(1)
	private int eventId;
	private String fcmToken;
	private String mobileNumber;
	private String emailId;
	private long accountNumber;
	private String deviceId;
	private boolean whatsappEnabled;
	@NotNull
	private transient Map<String, String> placeHolders;

	private transient List<Attachment> attachments;

}
