package com.wibmo.dfs.notification.dao.impl;

import com.wibmo.dfs.notification.dao.CustomerInfoDAO;
import com.wibmo.dfs.notification.entity.CustomerInfo;
import com.wibmo.dfs.notification.pojo.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;

/*
@Author pavan.konakanchi 
Created on : 04/08/2021 - 12:16 PM
*/
@Repository
@Slf4j
public class CustomerInfoDAOImpl implements CustomerInfoDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public void saveDeviceInfo(int programId, DeviceInfo deviceInfo) {
        jdbcTemplate.update("INSERT INTO DEVICE_INFO (DEVICE_ID, FCM_TOKEN, OS_TYPE, OS_VERSION, APP_VERSION) VALUES(?,?,?,?,?) " +
                        " ON DUPLICATE KEY UPDATE FCM_TOKEN=?, OS_VERSION=?, APP_VERSION=? ,STATUS_CODE=?, UPDATED_TIME=now()", deviceInfo.getDeviceId(), deviceInfo.getFcmToken(),
                deviceInfo.getOsType(), deviceInfo.getOsVersion(), deviceInfo.getAppVersion(), deviceInfo.getFcmToken(),
                deviceInfo.getOsVersion(), deviceInfo.getAppVersion(),1);
    }
    @Override
    public void mapDeviceInfo(int programId, CustomerDeviceMapping deviceInfo) {
        jdbcTemplate.update("INSERT INTO CUSTOMER_DEVICES (WIB_AC_NUMBER, DEVICE_ID) VALUES(?,?) " +
                " ON DUPLICATE KEY UPDATE WIB_AC_NUMBER=? UPDATED_TIME=now()", deviceInfo.getAccountNumber(), deviceInfo.getDeviceId(),deviceInfo.getAccountNumber());
    }

    @Override
    public void updateWhatsAppSubscription(int programId, SubscriptionInfo subscriptionInfo) {
        jdbcTemplate.update("UPDATE CUSTOMER_INFO SET WHATSAPP_ENABLED =? WHERE WIB_AC_NUMBER=? ",subscriptionInfo.isSuscribe(),subscriptionInfo.getAccountNumber());
    }

    @Override
    public void deleteEmail(int programId, CustomerEmailInfo deviceInfo) {
        try{
            jdbcTemplate.update("UPDATE CUSTOMER_INFO SET EMAIL = NULL  WHERE WIB_AC_NUMBER=?",
                deviceInfo.getAccountNumber());
        }catch (Exception e){
            log.error("Error occurred in  deleteEmail:{}",e.getMessage(), e);
        }
    }

    @Override
    public void mapEmail(int programId, CustomerEmailInfo deviceInfo) {
        try{
            jdbcTemplate.update("UPDATE CUSTOMER_INFO SET EMAIL=?  WHERE WIB_AC_NUMBER=?",
                deviceInfo.getEmail(),deviceInfo.getAccountNumber());
        }catch (Exception e){
            log.error("Error occurred in  mapEmail:{}",e.getMessage(), e);
        }
    }

    @Override
    public CustomerInfo findByAccountNumber(int programId, long accountNumber) {
        try{
            return jdbcTemplate.queryForObject("SELECT * FROM CUSTOMER_INFO WHERE  WIB_AC_NUMBER=? ",(rs, rowNum) -> {
                CustomerInfo customerInfo = new CustomerInfo();
                customerInfo.setAccountNumber(accountNumber);
                customerInfo.setEmailId(rs.getString("EMAIL"));
                customerInfo.setMobileNumber(rs.getString("COUNTRY_CODE")+rs.getString("MOBILE"));
                customerInfo.setSuscribedForWahtsapp(rs.getBoolean("WHATSAPP_ENABLED"));
                return customerInfo;
            }, accountNumber);
        }catch (  EmptyResultDataAccessException e){
            log.error("No records found for accountNUmber:{}",accountNumber);
            return null;
        }

    }
    @Override
    public DeviceInfo findDeviceInfoByAccountNumber(int programId, long accountNumber) {
        try{
            return  jdbcTemplate.queryForObject("SELECT D.FCM_TOKEN AS FCM_TOKEN, D.DEVICE_ID AS DEVICE_ID FROM DEVICE_INFO D," +
                            " CUSTOMER_DEVICES C  WHERE D.DEVICE_ID=C.DEVICE_ID AND  C.WIB_AC_NUMBER=? AND D.STATUS_CODE=? ORDER BY C.UPDATED_TIME DESC LIMIT 1 ",
                    new RowMapper<DeviceInfo>() {
                        @Override
                        public DeviceInfo mapRow(ResultSet rs, int rwNumber) throws SQLException {
                            DeviceInfo deviceInfo = new DeviceInfo();
                            deviceInfo.setFcmToken(rs.getString("FCM_TOKEN"));
                            deviceInfo.setDeviceId(rs.getString("DEVICE_ID"));
                            return deviceInfo;
                        }
                    }
            , accountNumber,1);
        }catch (  EmptyResultDataAccessException e){
            log.info("No active records found for accountNUmber:{}",accountNumber);
            return null;
        }catch (Exception e){
            log.error("Error occurred in  findDeviceInfo:{}",e);
            return null;

        }

    }

    @Override
    public void unregisterPushNotification(int programId, String deviceId) {
        try {
            jdbcTemplate.update("UPDATE DEVICE_INFO SET STATUS_CODE=? WHERE DEVICE_ID=?",2,deviceId);
        }catch (Exception e){
            log.error("Error occurred in  unregister push:{}",e.getMessage(), e);
        }

    }


    @Override
    public void mapMobile(int programId, CustomerMobileInfo deviceInfo) {
        try {
            jdbcTemplate.update("UPDATE CUSTOMER_INFO SET COUNTRY_CODE=? , MOBILE=? WHERE WIB_AC_NUMBER=?",
                    deviceInfo.getCountryCode(), deviceInfo.getMobile(), deviceInfo.getAccountNumber());
        } catch (Exception e) {
            log.error("Error occurred in  mapMobile:{}", e.getMessage(), e);
        }
    }
}
