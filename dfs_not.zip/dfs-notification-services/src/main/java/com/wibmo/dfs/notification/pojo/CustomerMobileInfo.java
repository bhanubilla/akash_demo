package com.wibmo.dfs.notification.pojo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/*
@Author pavan.konakanchi 
Created on : 03/08/2021 - 6:07 PM
*/
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerMobileInfo {
    @NotNull
    @NotEmpty
    private String countryCode;
    @NotNull
    @Min(1)
    private long accountNumber;
    @NotNull
    @NotEmpty
    private String mobile;
}
