package com.wibmo.dfs.notification.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author bhanu.prasad
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PasswordEvent {

	private String subject;
	private String text;
	private boolean enabled;
}
